--update guides set str1='70601 810 1 75002 610101'
select --(select name from types where type_id=g.type_doc) wow,
rowid,g.* 
,nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0)
from guides g 
where 
--type_doc in (669)
type_doc in (10036)
and code like '209%'
--type_doc in (9039)  -- ��� ��
and str1 like '70601%610101'
and code !='FORM_STORAGE'


select --(select name from types where type_id=g.type_doc) wow,
rowid,g.* 
,nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0)
from guides g 
where 
type_doc in (669)
--and code like '209%'
--type_doc in (9039)  -- ��� ��
--and str1 like '70601%610101'
and code !='FORM_STORAGE'


select * from account where code like '70601810%610101'

select * from account where code like '70606810%610101'

select * from account where code like '70606810%'


nvl(regexp_replace(substr(a1.name,-3),'[^[[:digit:]]]*'),0)>0


select * from account where 
code in (
select distinct nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0)
from guides g 
where 
type_doc in (10036)
and code like '209%'
--and str1 like '70601%610101'
and code !='FORM_STORAGE'
)


