-- ��� ������������� � ���������� ������ ���������� ������� ���� DATE3 
-- + date1 � date2 ������ ���� ���������.
-- -1 � num2 - �� ����������� ������������� (������ ����� � ����� �� ������)

select 
(select name from types where type_id=g.type_doc) wow,
rowid,g.* 
--distinct str5
from guides g 
--update guides set date1 = to_date('04.07.2018','dd.mm.yyyy'),date3=null
where 
type_doc in (2372)
--and code='6027077643' -- ���
and str5='358' 
-- � �������
and name in ('40802810200640006898','40802810700640103479') -- ����
--and date2 is null
--and date1 is null
--and date3 is null
and code !='FORM_STORAGE'

order by str5

select * from account where code like '47416%' and upper(name) like upper('������������ ����������� �� ���������%')




/
declare
v_date date;
begin
    for rec in (select * from guides  
                where type_doc in (2372)
                and code='6027077643'
                and date1 is null
                and code !='FORM_STORAGE'
    ) loop
        select distinct to_date(DATE_STOP,'dd.mm.yyyy') into v_date  
        from no_file  
            where date_create BETWEEN --trunc(sysdate) 
                      TO_DATE ('20181224', 'yyyymmdd')
                        AND trunc(sysdate) 
                        --TO_DATE ('20180812', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
                    and INN=rec.code
                    and NUMBER_STOP = rec.str5
                    and rownum<=1;

        update guides set date1 = v_date, date3=null
        where 
            type_doc in (2372)
            and code=rec.code
            and str5=rec.str5 
            and name = rec.name
            and reference=rec.reference
            and branch=rec.branch
            and code !='FORM_STORAGE';
            
        DBMS_OUTPUT.PUT_LINE(rec.reference);
                        
    end loop;
end;

/


/
declare
v_date date;
v_cancel NO_FILE.NUMBER_CANCEL%type;
begin
    for rec in (select * from guides  
                where type_doc in (2372)
                and code='711616883520'
                and date2 is null
                and str5='358' 
                and name in ('40802810200640006898','40802810700640103479') -- ����
                and code !='FORM_STORAGE'
    ) loop
--        select distinct to_date(DATE_CANCEL,'dd.mm.yyyy') into v_date  
        select distinct to_date(DATE_CANCEL,'dd.mm.yyyy'),number_cancel into v_date, v_cancel  
        from no_file  
            where date_create BETWEEN --trunc(sysdate) 
                      TO_DATE ('20181224', 'yyyymmdd')
                        AND trunc(sysdate) 
                        --TO_DATE ('20180812', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
                    and (instr(FILE_NAME,'ROO')>0 or instr(FILE_NAME,'RBO')>0)
                    and INN=rec.code
                    and NUMBER_STOP = rec.str5
                    and rownum<=1;

        update guides set date2 = v_date, date3=null, num3=v_cancel
        where 
            type_doc in (2372)
            and code=rec.code
            and str5=rec.str5 
            and name = rec.name
            and reference=rec.reference
            and branch=rec.branch
            and code !='FORM_STORAGE';
            
        DBMS_OUTPUT.PUT_LINE(rec.reference);
                        
    end loop;
end;

/


        select distinct to_date(DATE_CANCEL,'dd.mm.yyyy') --into v_date  
        from no_file  
            where date_create BETWEEN --trunc(sysdate) 
                      TO_DATE ('20181224', 'yyyymmdd')
                        AND trunc(sysdate) 
                        --TO_DATE ('20180812', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
                    and INN='711616883520'
                    and NUMBER_STOP = '358'
                    and rownum<=1;


711616883520