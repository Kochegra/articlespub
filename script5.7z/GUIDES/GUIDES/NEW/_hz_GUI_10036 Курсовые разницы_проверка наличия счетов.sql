select * from account where code in ( 
select acc from (
select distinct str1
,nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0) acc
from guides g 
where 
type_doc in (10036)
and code !='FORM_STORAGE'
)
)


select --distinct str1
(select name from types where type_id=g.type_doc) wow,
rowid,g.* 
,nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0) acc1
from guides g 
where 
type_doc in (10036)
and code !='FORM_STORAGE'
and nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0) not in (
select code from account where code in ( 
select acc from (
select distinct str1
,nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0) acc
from guides g 
where 
type_doc in (10036)
and code !='FORM_STORAGE'
)
)
)

select * from account@lnk_202 where code like '70601810%610102'

