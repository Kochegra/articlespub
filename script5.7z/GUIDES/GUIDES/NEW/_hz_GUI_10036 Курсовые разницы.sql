-- ��� ���� ������ ������� � ������
-- ��� ��������������� ������, ��� �� ��� ��� ��������...

--update guides g set 
--str1=substr(g.str1,1,5)||' '||substr(g.str1,6,3)||' '||substr(g.str1,9,1)||' '||substr(g.str1,10,5)||' '||substr(g.str1,15,6) 
--,str2=substr(g.str2,1,5)||' '||substr(g.str2,6,3)||' '||substr(g.str2,9,1)||' '||substr(g.str2,10,5)||' '||substr(g.str2,15,6)


select --distinct str2 --str4--str3--code --str1 
(select name from types where type_id=g.type_doc) wow,
rowid,g.* 
,''''||nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0)||''','
from guides g 
where 
--type_doc in (669)
type_doc in (10036)
--and trim(str1) is not null
and code='209'  -- ���������
--and str4!='1'
--and code like '209%'
--type_doc in (9039)  -- ��� ��
--and str1 like '70601%610101'
and code !='FORM_STORAGE'
--order by to_number(code)
--order by to_number(str4),str3


select * from account where code like '70601810%610101'

select * from account where code like '70601810_00232201401'

select * from account where --code like '70606810%'
code in ('70601810975002610301',
'70601810975002620401',
'70601810075002610201',
'70601810075002620301',
'70601810175002610101',
'70601810175002620201',
'70601810275002620101',
'70601810675002610601',
'70601810775002610501',
'70601810775002620601',
'70601810875002610401',
'70601810875002620501',
'70603810675002630113',
'70603810775002630411'
)


nvl(regexp_replace(substr(a1.name,-3),'[^[[:digit:]]]*'),0)>0


select * from account where 
code in (
select distinct nvl(regexp_replace(str1,'[^[[:digit:]]]*'),0)
from guides g 
where 
type_doc in (10036)
--and code like '20%'
--and str1 like '70601%610101'
and code !='FORM_STORAGE'
)


