declare
v_g_nex number;
v_id_oo number;
v_cnt   number;
v_acc   account.code%type;
begin
    --1 �����
    -- �������� �� ������ ����������� �� ��������
    select id into v_id_oo from subdepartments s where id like mbfilid||'%' and date_close is null and substr(name,3,1)<>'_' and type=301
    and id =207003;
    -- ��������� ���������� ��� ������ �� �������� (code='2041100') � ��������� ��� ������������ ������� 
    -- ��������� ���������� ��� ������ �� ��������� (code='2041101') � ��������� ��� ������������ ������� 
--/*
    for g9922 in (select * from guides where type_doc in (9922) and code !='FORM_STORAGE' and code between '05' and '16')
    loop
DBMS_OUTPUT.PUT_LINE('1');
            select count(*) into v_cnt from guides where type_doc=10233 and code='2041100' and trim(str2)=trim(g9922.code) and str1=v_id_oo;
            if v_cnt < 1 then
DBMS_OUTPUT.PUT_LINE('2');
                v_g_nex := guides_reference.nextval;
                insert into guides (REFERENCE,BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,STR1,STR2,DATE3,CODE1)
                select v_g_nex,mbfilid,0,10233,0,1403,0,0,to_date('01012016','ddmmyyyy'),'2041100',v_id_oo,
                g9922.code,to_date('29122015 17:23:00','ddmmyyyy hh24:mi:ss'),v_g_nex
                from dual
                where not exists (select null from guides where type_doc=10233 and code='2041100' and trim(str2)=trim(g9922.code) and str1=v_id_oo);
                commit;
            end if;

            select count(*) into v_cnt from guides where type_doc=10233 and code='2041101' and trim(str2)=trim(g9922.code) and str1=v_id_oo;
            if v_cnt < 1 then
DBMS_OUTPUT.PUT_LINE('3');
                v_g_nex := guides_reference.nextval;
                insert into guides (REFERENCE,BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,STR1,STR2,DATE3,CODE1)
                select v_g_nex,mbfilid,0,10233,0,1403,0,0,to_date('01012016','ddmmyyyy'),'2041101',v_id_oo,
                g9922.code,to_date('29122015 17:23:00','ddmmyyyy hh24:mi:ss'),v_g_nex
                from dual
                where not exists (select null from guides where type_doc=10233 and code='2041101' and trim(str2)=trim(g9922.code) and str1=v_id_oo);
                commit;
            end if;
            
    end loop;
--*/
commit;
    --
    -- 2 ����� (����� ������ ���� ������������)
    --
    -- ����������� ���������� ���� ������� �� ��������
--/*  
    select count(*) into v_cnt from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%2880202';
    if v_cnt = 1 then
        select code into v_acc from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%2880202';
        update guides set str3=v_acc
        where type_doc in (10233) and code='2041100' and code !='FORM_STORAGE' and str1=v_id_oo;
        commit;
    end if;
--*/    --
--/*    -- ����������� ���������� ���� ������� �� ���������
    for g10233 in (select * from guides where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and str1=v_id_oo
        ) loop
            if trim(g10233.str2) between '05' and '13' then
                select count(*) into v_cnt from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||g10233.str2||'01';                    
                if v_cnt = 1 then
DBMS_OUTPUT.PUT_LINE('4');
                    select code into v_acc from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||g10233.str2||'01';
                    update guides set str3=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;

            if trim(g10233.str2) = '14' then
                select count(*) into v_cnt from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||'18'||'01';                    
                if v_cnt = 1 then
DBMS_OUTPUT.PUT_LINE('5');
                    select code into v_acc from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||'18'||'01';
                    update guides set str3=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;

--            if trim(g10233.str2) = '15' then
--DBMS_OUTPUT.PUT_LINE('6');
--                
--            end if;

            if trim(g10233.str2) = '16' then
                select count(*) into v_cnt from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||'14'||'01';                    
                if v_cnt = 1 then
DBMS_OUTPUT.PUT_LINE('7');
                    select code into v_acc from account where code like '70601810_'||trim(global_parameters.get_param('���',v_id_oo))||'%242'||'14'||'01';
                    update guides set str3=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;
        end loop;   

--*/        


--/*    -- ����������� ���������� ���� �������� �� ��������
    for v_cnt2 in 1..9 loop 
        select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3120'||to_char(v_cnt2)||'01';
        if v_cnt = 1 then
            select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3120'||to_char(v_cnt2)||'01';
            if v_cnt2+4 <= 9 then 
                update guides set str4=v_acc
                where type_doc in (10233) and code='2041100' and code !='FORM_STORAGE' and trim(str2)='0'||to_char(v_cnt2+4) and str1=v_id_oo;
            else
                update guides set str4=v_acc
                where type_doc in (10233) and code='2041100' and code !='FORM_STORAGE' and trim(str2)=to_char(v_cnt2+4) and str1=v_id_oo;
            end if;
            commit;
        end if;
    end loop;

    select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3121201';
    if v_cnt = 1 then
        select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3121201';
        update guides set str4=v_acc
        where type_doc in (10233) and code='2041100' and code !='FORM_STORAGE' and trim(str2)='14' and str1=v_id_oo;
        commit;
    end if;

    select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3121301';
    if v_cnt = 1 then
        select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%3121301';
        update guides set str4=v_acc
        where type_doc in (10233) and code='2041100' and code !='FORM_STORAGE' and trim(str2)='16' and str1=v_id_oo;
        commit;
    end if;
--*/
  

    -- ����������� ���������� ���� �������� �� ���������
--/*
    for g10233 in (select * from guides where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE'  and str1=v_id_oo
        ) loop
            if trim(g10233.str2) between '05' and '13' then
                select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||g10233.str2||'01';                    
                if v_cnt = 1 then
                    select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||g10233.str2||'01';
                    update guides set str4=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;

            if trim(g10233.str2) = '14' then
                select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||'18'||'01';                    
                if v_cnt = 1 then
                    select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||'18'||'01';
                    update guides set str4=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;

--            if trim(g10233.str2) = '15' then
--DBMS_OUTPUT.PUT_LINE('6');
--                
--            end if;

            if trim(g10233.str2) = '16' then
                select count(*) into v_cnt from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||'14'||'01';                    
                if v_cnt = 1 then
                    select code into v_acc from account where code like '70606810_'||trim(global_parameters.get_param('���',v_id_oo))||'%313'||'14'||'01';
                    update guides set str4=v_acc
                    where type_doc in (10233) and code='2041101' and code !='FORM_STORAGE' and trim(str2)=g10233.str2 and str1=v_id_oo;
                    commit;
                end if;
            end if;
        end loop;   
--*/    

commit;
end;
