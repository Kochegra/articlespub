--guides_10233

--begin ptools2.short_init_user(1403); end;
SELECT
universe.NameDepart(c.subdepartment),
c.subdepartment,
firma_contracts_446_tools.get_type_cb(c.refer_client,c.branch_client) cde_cb,
universe.GUIDE(9922,firma_contracts_446_tools.get_type_cb(c.refer_client,c.branch_client))
,firma_contracts_446_tools.Get_Expenses_Account(nRef_Contract => c.reference,nBr_Contract => c.branch,dDate => sysdate,cKind_Account => 'deposit')
--universe.oborot_collector(c.branch,c.reference,'C+201800',c.currency,c.date_open,sysdate)
--P_6776.account2account_field(c.assist,'reference'),
--assist,
--universe.VARIABLE_CONTRACT(c.branch,c.reference,'rgpercent'),
--universe.VARIABLE_CONTRACT(c.branch,c.reference,'receivers_bik'),
--universe.VARIABLE_CONTRACT(c.branch,c.reference,'receivers_coracc'),
--universe.VARIABLE_CONTRACT(c.branch,c.reference,'receivers_bank'),
--pledger.saldo('A',c.account,c.currency,c.date_open) s,
--p_6776.check_contract4auto_close(c.reference,c.branch,sysdate),
--universe.VARIABLE_CONTRACT(c.branch,c.reference,'auto_close_message') ps,
--C.*
FROM CONTRACTS C WHERE C.TYPE_DOC IN (3709,3710,4184,6774,3853,5901,6776) AND C.STATUS=50
and c.date_work<=trunc(sysdate)
--and not p_6776.check_contract4auto_close(c.reference,c.branch,sysdate) is null
--and exists (select 1 from variable_contracts vc where vc.reference=c.reference and vc.branch=c.branch and vc.subnumber=-1)
and c.subdepartment in
(
 49118,
 49152,
 49155,
 49156,
785076,
785101,
780589,
785152,
780310,
49118,
780613,
49155,
780589
)
--and universe.oborot_collector(c.branch,c.reference,'C+201800',c.currency,c.date_open,sysdate)>0

