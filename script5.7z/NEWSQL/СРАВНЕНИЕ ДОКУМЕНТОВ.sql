--���������� 2 ��������� � ���������
--�������������� ��������� ����� ����������� ����

select * from documents where reference in (1041580362,1041566937)
or refer_from in (1041580362,1041566937)

union all

select * from archive where reference in (974663990)

select * from variable_documents where --reference in ()
name = 'VID_CODE' and value='4'

union all

select * from variable_archive where reference in (974663990)

-- ����� ������� �� ������ ���������� ���������
select * from documents where reference=1041566937
union all
select * from documents where --reference=1040321565
--select * from archive where --reference=1040321565
    (branch,
    folder,
    type_doc,
    date_work,
    date_value,
    payers_account,
    --receivers_account,
    --real_receivers,
    --receivers_operation, 
    substr(payers_account,1,5),
--    substr(receivers_account,1,5),
--    substr(real_receivers,1,5),
    receivers_operation) = 
(select 
    branch,
    folder,
    type_doc,
    date_work - 1,
    date_value - 1,
    payers_account,
    --receivers_account,
    --real_receivers,
    --receivers_operation, 
    substr(payers_account,1,5),
--    substr(receivers_account,1,5),
--    substr(real_receivers,1,5),
    receivers_operation
from documents where reference=1041566937)

-- ��������� 2-� ����� � VARIABLE_ARCHIVE
select a1.name,a1.reference,a1.value,
a2.name,a2.reference,a2.value 
from variable_archive a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
union all 
select c1.name,c1.reference,c1.value,'NULL',0,'NULL'
from variable_archive c1
where c1.reference=:arch_ref1 and
c1.name not in (
select a1.name 
from variable_archive a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
) 
union all
select d1.name,d1.reference,d1.value,'NULL',0,'NULL'
from variable_archive d1
where d1.reference=:arch_ref2 and
d1.name not in (
select a1.name 
from variable_archive a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
) 


-- ��������� 2-� ����� � VARIABLE_DOCUMENTS
select a1.name,a1.reference,a1.value,
a2.name,a2.reference,a2.value 
from variable_documents a1 
inner join variable_documents a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
union all 
select c1.name,c1.reference,c1.value,'NULL',0,'NULL'
from variable_documents c1
where c1.reference=:arch_ref1 and
c1.name not in (
select a1.name 
from variable_documents a1 
inner join variable_documents a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
) 
union all
select d1.name,d1.reference,d1.value,'NULL',0,'NULL'
from variable_documents d1
where d1.reference=:arch_ref2 and
d1.name not in (
select a1.name 
from variable_documents a1 
inner join variable_documents a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
)


-- ��������� 2-� ����� (���� �� VARIABLE_DOCUMENTS. ������ �� VARIABLE_ARCHIVE)
select a1.name,a1.reference,a1.value,
a2.name,a2.reference,a2.value 
from variable_documents a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
union all 
select c1.name,c1.reference,c1.value,'NULL',0,'NULL'
from variable_documents c1
where c1.reference=:arch_ref1 and
c1.name not in (
select a1.name 
from variable_documents a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
) 
union all
select d1.name,d1.reference,d1.value,'NULL',0,'NULL'
from variable_archive d1
where d1.reference=:arch_ref2 and
d1.name not in (
select a1.name 
from variable_documents a1 
inner join variable_archive a2
on a1.name=a2.name
where a1.reference in (:arch_ref1) 
and a2.reference in (:arch_ref2)
) 