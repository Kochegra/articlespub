  SELECT DISTINCT
         a.is_group_perevod �,
         SUBSTR (
            NVL (
               mbank.global_parameters.get_param (a.id,
                                                  '���',
                                                  TRUNC (SYSDATE)),
               CONCAT (b.user_name, ' �� ����� ���')),
            1,
            40)
            ���,
         a.date_s �,
         a.date_po ��,
         a.subdepartment_otkyda,
         a.subdepartment_kyda,
         a.job_otkyda,
         a.job_kyda,
         a.number_kassir_otkyda,
         a.number_kassir_kyda,
         SUBSTR (
            CONCAT (
               CONCAT (DECODE (d.name, '���� ������', ' ', d.name),
                       ' '),
               CONCAT (
                  CONCAT (
                     DECODE (e.job,
                             '�������������', ' ',
                             CONCAT ('/ ', e.job)),
                     ' '),
                  a.number_kassir_otkyda)),
            1,
            50)
            ������,
         SUBSTR (
            CONCAT (
               CONCAT (DECODE (c.name, '���� ������', ' ', c.name),
                       ' '),
               CONCAT (
                  CONCAT (
                     DECODE (f.job,
                             '�������������', ' ',
                             CONCAT ('/ ', f.job)),
                     ' '),
                  a.number_kassir_kyda)),
            1,
            50)
            ����,
         a.activated,
         a.owner,
         a.id
    FROM tmp_perevod a,
         users b,
         subdepartments c,
         subdepartments d,
         jobs e,
         jobs f
   WHERE     b.user_id = a.id
         AND c.id = NVL (a.subdepartment_kyda, 0)
         AND d.id = NVL (a.subdepartment_otkyda, 0)
         AND e.job_id =
                DECODE (NVL (a.job_otkyda, 1), 0, 1, NVL (a.job_otkyda, 1))
         AND f.job_id = DECODE (NVL (a.job_kyda, 1), 0, 1, NVL (a.job_kyda, 1))
         AND (   INSTR (
                    UPPER (
                       NVL (
                          mbank.global_parameters.get_param (a.id,
                                                             '���',
                                                             TRUNC (SYSDATE)),
                          CONCAT (b.user_name, ' �� ����� ���'))),
                    UPPER (' ')) <> 0
              OR INSTR (TO_CHAR (a.date_s, 'dd.mm.yy'), ' ') <> 0)
         AND (a.is_group_perevod = :var2 OR :var2 = ' ')
ORDER BY TO_DATE (SUBSTR (activated, 1, 10), 'dd.mm.yyyy'),
         SUBSTR (activated, 12, 8)


:VAR1=[' ']
:VAR2=['*']


select (select logon_time from V$session where username=u.user_),
a.is_group_perevod,u.user_name,U.USER_, a.id,a.date_s,a.date_po,a.activated,a.owner 
from tmp_perevod a, users u  
where a.is_group_perevod='*'
and a.id=u.user_id

select v.logon_time,v.status,v.program,v.module,v.client_info,
a.is_group_perevod,u.user_name,U.USER_, a.id,a.date_s,a.date_po,a.activated,a.owner 
from tmp_perevod a, users u, V$session v  
where a.is_group_perevod='*'
and a.id=u.user_id
and v.username=u.user_



select logon_time,username,status,schemaname,osuser,machine,terminal,program,module,client_info,client_identifier,state --* 
FROM  V$session --S, 
--V$process --P, 
--Sys.V_$sess_io --Si
where username='GORODNOV_DM'
and schemaname='MBANK'
--and upper(program) like '%RETAIL%'