-- create table for stat

create table gdm_eid_human as
select 
1 num_pp,
h.eid current_eid, --eid.p_eid_tools.search_new_eid(h.eid) current_eid,
h.address all_eid, --eid.p_eid_tools3.get_eid_list(h.eid, 1) all_eid,  
h.eid,h.date_modify,trim(h.last_name)||' '||trim(h.first_name)||' '||trim(h.second_name) FIO,h.birthday,h.doc_number,h.inn
,(select count(*) from EID.EID_HUMAN_MODIFY where eid=h.eid and date_modify>h.date_modify) EID_H_MODIFY
,(select count(*) from EID.EID_PRODUCTS where eid=h.eid and pr_status not in (60) and pr_type in 
        (select code from mbank.guides where type_doc = 2486 and num1 in (0,1) and code in ('0','10','2','3','4','5','6','7','8','9') and code!='FORM_STORAGE')) EID_PRODUCTS
,(select count(*) from EID.EID_ACCOUNT where eid=h.eid and close_date is null) EID_ACCOUNT
,(select count(*) from EID.EID_CARD where eid=h.eid and date_destroy is null) EID_CARD
,(select count(*) from eid.eid_products where eid=h.eid and pr_type = '0' and pr_status not in (60)) pr_vklad
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type in (select code from mbank.guides where type_doc = 2486 and num1=1 and code!='FORM_STORAGE')) pr_pk
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='2' ) pr_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='3' ) pr_cr_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='4' ) pr_zp_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='5' ) pr_skm
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='6' ) pr_DCLUB
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='7' ) pr_Virtuon
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='8' ) pr_corp_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='9' ) pr_ServCard
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='10' ) pr_pens_card
,(select count(*) from eid.eid_firma where inn=h.inn) INN_IP
,h.address info_1
,h.address info_2
,h.address info_3
--,h.* 
from EID.EID_HUMAN h where 
--reference is not null
--nvl(subdepartment,0) in (200)
--eid in (1841282,34752874)
eid in (2565)--10702844)
and 
h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid)
and nvl(h.inn,'0')<>'0'
and rownum<=100
/

grant select,insert,update,delete on gdm_eid_human to MBANK