-- ����� ����� ����� 30 090 311
-- �����
select count(*)
                    --h.eid 
                    from EID.EID_HUMAN h where --h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid) -- �������� ��� ������� �����
                    (h.eid, h.date_modify) IN
                              (SELECT /*+NO_MERGE*/
                                     *
                                 FROM (  SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE hh.eid=h.eid
                                       GROUP BY hh.EID))
                                       


select count(distinct h.eid)
                    --h.eid 
                    from EID.EID_HUMAN h 
                    
                    

select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          --WHERE hh.eid=h.eid
                                       GROUP BY hh.EID
)                                       


select count(*) into nAllProd from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785);                                       


--�� ���, ���-�� ��������, ������� ����� ������� 19 420 275
select count(*)
                    --h.eid 
                    from EID.EID_HUMAN h where --h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid) -- �������� ��� ������� �����
                    (h.eid, h.date_modify) IN
                              (SELECT /*+NO_MERGE*/
                                     *
                                 FROM (  SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE hh.eid=h.eid
                                       GROUP BY hh.EID))
and exists (select null from EID.EID_PRODUCTS where eid=h.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))

select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
                                       GROUP BY hh.EID
)


-- �� ���, ���-�� ��������, � ������� ������� ���������,  ������� �� ��������� 10 548 651
select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                and nvl(pr_type_id,0) not in (1785)
            )
                                       GROUP BY hh.EID
)


-- �� ���, ����� ���  1 601 573
select count(*) from tmp_tables.gdm_eid_human -- ��� ��� � ���, ���� ��� ���������


--186 072 
select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                and nvl(pr_type_id,0) not in (1785)
            )
and exists (select null from eid.eid_human where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0')            
                                       GROUP BY hh.EID
)


--1 609 044
select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
--exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
--and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
--                and nvl(pr_type_id,0) not in (1785)
--            )
--and
exists (select null from eid.eid_human where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0')            
                                       GROUP BY hh.EID
)


--�� ���, ������� �������� ��
--24 799
select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                and nvl(pr_type_id,0) not in (1785)
            )
and exists (select a.inn from eid.eid_human a where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0'
                and exists (select null from eid.eid_firma where inn=trim(a.inn)))
                                       GROUP BY hh.EID
)


--400 161
select count(*) from (
SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
--exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
--and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
--                and nvl(pr_type_id,0) not in (1785)
--            )
exists (select a.inn from eid.eid_human a where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0'
                and exists (select null from eid.eid_firma where inn=trim(a.inn)))
                                       GROUP BY hh.EID
)



-- ������� ���������� � �� ����������� ��������
 
/
declare
sResult varchar2(2000);
nCliAcc number :=0;
nCliCard number :=0;
nCliCorpCard number :=0;
nCliOther number :=0;
nResult number; 
nCntCli number;
nCntFl number :=0;
 function f_ip_inn(p_eid eid.eid_human.eid%type,p_date_modify eid.eid_human.date_modify%type) return number is
    nRes number;
    --nFirmEid number :=0;
    nProd number :=0;
    nAllProd number :=0;
    sInfo varchar2(2000) := null;
 begin
    for r_inn in (select * from eid.eid_human where eid=p_eid and date_modify=p_date_modify)
    loop
        if nvl(r_inn.inn,'0')<>'0' then 
            for r_ip in (select * from eid.eid_firma where inn=trim(r_inn.inn))
            loop
                --nFirmEid:=nFirmEid+1;
                select count(*) into nProd from eid.eid_firma_products where eid=r_ip.eid and status=50
                and pr_type=0; -- �� �������, 1 - ��� �������
                nAllProd:=nAllProd+nProd;
            end loop;
        end if;
        --dbms_output.put_line(r_inn.inn||' '||nAllProd);
    end loop;
    
    if nAllProd>0 then
        nRes:=1;
    else        
        nRes:=0;
    end if; 
    return nRes;
 end;
 Function f_get_product(p_eid eid.eid_human.eid%type,p_date_modify eid.eid_human.date_modify%type) return varchar2 is
    --sRes varchar2(2000);
    nCnt number :=0;
    sInfo varchar2(2000) := null;
 begin
    -- �����
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type=0 -- �����
        and nvl(pr_type_id,0) not in (1785); -- ������� ����
    sInfo:=sInfo||'[A��='||nCnt||']';

    -- ����� ���� ��
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type in (10,2,4,5,7); -- �����
    sInfo:=sInfo||'[CARD='||nCnt||']';
    
    -- ���� �����
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type in (8); 
    sInfo:=sInfo||'[CORP_CARD='||nCnt||']';

    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status not in (60,0) and pr_type in (3,7)
                        and nvl(pr_type_id,0) not in (1785);
    sInfo:=sInfo||'[OTHER='||nCnt||']';

    return sInfo;    
    
 end;

begin
    nCntCli:=0;
    for rec in (
                
                SELECT hh.eid, MAX (hh.date_modify) max_date
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
                    exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
                    and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                        and nvl(pr_type_id,0) not in (1785)
                    )
                    and exists (select a.inn from eid.eid_human a where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0'
                        and exists (select null from eid.eid_firma where inn=trim(a.inn)))
                                           --and eid in (107748,108308,110421,111042,111294)
                                           GROUP BY hh.EID
                
                )
    loop
        nResult:=f_ip_inn(p_eid => rec.eid,p_date_modify => rec.max_date);
        nCntFl:=nCntFl+1;
        nCntCli:=nCntCli+nResult;
        
        if nResult>0 then
            sResult:=f_get_product(p_eid => rec.eid,p_date_modify => rec.max_date);
            
            if to_number(PTOOLS5.READ_PARAM(sResult,'ACC'))>0 then
                nCliAcc:=nCliAcc+1;    
            end if; 
            if to_number(PTOOLS5.READ_PARAM(sResult,'CARD'))>0 then
                nCliCard:=nCliCard+1;    
            end if; 
            if to_number(PTOOLS5.READ_PARAM(sResult,'CORP_CARD'))>0 then
                nCliCorpCard:=nCliCorpCard+1;    
            end if; 
            if to_number(PTOOLS5.READ_PARAM(sResult,'OTHER'))>0 then
                nCliOther:=nCliOther+1;    
                DBMS_OUTPUT.PUT_LINE(rec.eid);
            end if; 
            
        end if;
        
    end loop;
    DBMS_OUTPUT.PUT_LINE(nCntFl||' '||nCntCli);
    DBMS_OUTPUT.PUT_LINE('���: '||nCntFl||' ��������� �: '||nCliAcc||' ���� �: '||nCliCard||' ���� ���� �: '||nCliCorpCard||' ��������. OTHER='||nCliOther);

end;

/



-- ������� ���������� �� 186 072


SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                and nvl(pr_type_id,0) not in (1785)
            )
and exists (select null from eid.eid_human where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0')            
                                       GROUP BY hh.EID


/
declare
sResult varchar2(2000);
nResult number; 
nCntCli number;
nCntFl number :=0;
nCliAcc number :=0;
nCliCard number :=0;
nCliCorpCard number :=0;
 Function f_get_product(p_eid eid.eid_human.eid%type,p_date_modify eid.eid_human.date_modify%type) return varchar2 is
    --sRes varchar2(2000);
    nCnt number :=0;
    sInfo varchar2(2000) := null;
 begin
    -- �����
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type=0 -- �����
        and nvl(pr_type_id,0) not in (1785); -- ������� ����
    sInfo:=sInfo||'[A��='||nCnt||']';

    -- ����� ���� ��
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type in (10,2,4,5,7); -- �����
    sInfo:=sInfo||'[CARD='||nCnt||']';
    
    -- ���� �����
    select count(*) into nCnt from EID.EID_PRODUCTS where eid in (p_eid) and pr_status<>60 and pr_type in (8); 
    sInfo:=sInfo||'[CORP_CARD='||nCnt||']';

    return sInfo;    
    
 end;
--
-- function f_ip_inn(p_eid eid.eid_human.eid%type,p_date_modify eid.eid_human.date_modify%type) return number is
--    nRes number;
--    --nFirmEid number :=0;
--    nProd number :=0;
--    nAllProd number :=0;
--    sInfo varchar2(2000) := null;
-- begin
--    for r_inn in (select * from eid.eid_human where eid=p_eid and date_modify=p_date_modify)
--    loop
--        if nvl(r_inn.inn,'0')<>'0' then 
--            for r_ip in (select * from eid.eid_firma where inn=trim(r_inn.inn))
--            loop
--                --nFirmEid:=nFirmEid+1;
--                select count(*) into nProd from eid.eid_firma_products where eid=r_ip.eid and status=50
--                and pr_type=0; -- �� �������, 1 - ��� �������
--                nAllProd:=nAllProd+nProd;
--            end loop;
--        end if;
--        --dbms_output.put_line(r_inn.inn||' '||nAllProd);
--    end loop;
--    
--    if nAllProd>0 then
--        nRes:=1;
--    else        
--        nRes:=0;
--    end if; 
--    return nRes;
-- end;

begin
    nCntCli:=0;
    for rec in (
                
                --186 072
--                SELECT hh.eid, MAX (hh.date_modify) max_date
--                                           FROM EID.EID_HUMAN hh
--                                          WHERE --hh.eid=h.eid
--                exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
--                and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
--                    and nvl(pr_type_id,0) not in (1785)
--                        )
--                and exists (select null from eid.eid_human where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0')            
--                                       --and eid in (107748,108308,110421,111042,111294)
--                                       GROUP BY hh.EID

                SELECT hh.eid, MAX (hh.date_modify) max_date
                                           FROM EID.EID_HUMAN hh
                                          WHERE --hh.eid=h.eid
                exists (select null from EID.EID_PRODUCTS where eid=hh.eid and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785))
                and exists (select null from EID.EID_PRODUCTS where eid=hh.eid and pr_status not in (60,0) and pr_type in (0,10,2,3,4,5,6,7)
                        and nvl(pr_type_id,0) not in (1785)
                    )
                and exists (select a.inn from eid.eid_human a where eid=hh.eid and date_modify=hh.date_modify and nvl(inn,'0')<>'0'
                    and exists (select null from eid.eid_firma where inn=trim(a.inn)))
                                       GROUP BY hh.EID

                )
    loop
        sResult:=f_get_product(p_eid => rec.eid,p_date_modify => rec.max_date);
        
        if to_number(PTOOLS5.READ_PARAM(sResult,'ACC'))>0 then
            nCliAcc:=nCliAcc+1;    
        end if; 
        if to_number(PTOOLS5.READ_PARAM(sResult,'CARD'))>0 then
            nCliCard:=nCliCard+1;    
        end if; 
        if to_number(PTOOLS5.READ_PARAM(sResult,'CORP_CARD'))>0 then
            nCliCorpCard:=nCliCorpCard+1;    
        end if; 
        
        nCntFl:=nCntFl+1;
        --nCntCli:=nCntCli+nResult;
    end loop;
    DBMS_OUTPUT.PUT_LINE('���: '||nCntFl||' ��������� �: '||nCliAcc||' ���� �: '||nCliCard||' ���� ���� �: '||nCliCorpCard||' ��������.');
end;

/

���: 186072 ��������� �: 0 ���� �: 156103 ���� ���� �: 2896 ��������.
���: 24799 ��������� �: 0 ���� �: 20643 ���� ���� �: 1410 ��������.

���: 186072 ��������� �: 0 ���� �: 156103 ���� ���� �: 2896 ��������.
���: 24799 ��������� �: 0 ���� �: 20643 ���� ���� �: 1410 ��������.
24799 10879
���: 24799 ��������� �: 0 ���� �: 9488 ���� ���� �: 1080 ��������.