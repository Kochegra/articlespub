-- ��������� �������
select rowid,a.* from tmp_tables.gdm_eid_human a

-- �������� �������� ������ � ���
--insert into tmp_tables.gdm_eid_human
select /*+ PARALLEL(4) */
1 num_pp,
eid.p_eid_tools.search_new_eid(h.eid) current_eid,
eid.p_eid_tools3.get_eid_list(h.eid, 1) all_eid,  
h.eid,h.date_modify,trim(h.last_name)||' '||trim(h.first_name)||' '||trim(h.second_name) FIO,h.birthday,h.doc_number,h.inn
,(select count(*) from EID.EID_HUMAN_MODIFY where eid=h.eid and date_modify>h.date_modify) EID_H_MODIFY
,(select count(*) from EID.EID_PRODUCTS where eid=h.eid and pr_status not in (60) and pr_type in 
        (select code from mbank.guides where type_doc = 2486 and num1 in (0,1) and code in ('0','10','2','3','4','5','6','7','8','9') and code!='FORM_STORAGE')) EID_PRODUCTS
,(select count(*) from EID.EID_ACCOUNT where eid=h.eid and close_date is null) EID_ACCOUNT
,(select count(*) from EID.EID_CARD where eid=h.eid and date_destroy is null) EID_CARD
,(select count(*) from eid.eid_products where eid=h.eid and pr_type = '0' and pr_status not in (60)) pr_vklad
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type in (select code from mbank.guides where type_doc = 2486 and num1=1 and code!='FORM_STORAGE')) pr_pk
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='2' ) pr_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='3' ) pr_cr_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='4' ) pr_zp_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='5' ) pr_skm
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='6' ) pr_DCLUB
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='7' ) pr_Virtuon
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='8' ) pr_corp_card
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='9' ) pr_ServCard
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='10' ) pr_pens_card
,(select count(*) from eid.eid_firma where inn=h.inn) INN_IP
,null --h.address info_1
,null --h.address info_2
,null --h.address info_3
--,h.* 
from EID.EID_HUMAN h where 
--reference is not null
--nvl(subdepartment,0) in (200)
--eid in (1841282,34752874)
--eid in (2565)--10702844)
--and 
--h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid) -- �������� ��� ������� �����
(h.eid, h.date_modify) IN
                              (SELECT /*+NO_MERGE*/
                                     *
                                 FROM (  SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE hh.eid=h.eid
                                       GROUP BY hh.EID))
and nvl(h.inn,'0')<>'0'
and not exists(select null from tmp_tables.gdm_eid_human where eid=h.eid) --�����
--and rownum<=100
/



-- ������ ����� �������� ����������
declare 
nNum number :=0;
begin
    for rec in (select /*+ PARALLEL(4) */
                    h.eid from EID.EID_HUMAN h where --h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid) -- �������� ��� ������� �����
                    (h.eid, h.date_modify) IN
                              (SELECT /*+NO_MERGE*/
                                     *
                                 FROM (  SELECT hh.eid, MAX (hh.date_modify)
                                           FROM EID.EID_HUMAN hh
                                          WHERE hh.eid=h.eid
                                       GROUP BY hh.EID))
                    and nvl(h.inn,'0')<>'0'
                    and not exists(select null from tmp_tables.gdm_eid_human where eid=h.eid)
                    )
    loop
        nNum:=nNum+1;
        insert into tmp_tables.gdm_eid_human
            select nNum num_pp,
            eid.p_eid_tools.search_new_eid(h.eid) current_eid,
            -1 all_eid, --eid.p_eid_tools3.get_eid_list(h.eid, 1) all_eid,  
            h.eid,h.date_modify,trim(h.last_name)||' '||trim(h.first_name)||' '||trim(h.second_name) FIO,h.birthday,h.doc_number,h.inn
            ,(select count(*) from EID.EID_HUMAN_MODIFY where eid=h.eid and date_modify>h.date_modify) EID_H_MODIFY
            ,(select count(*) from EID.EID_PRODUCTS where eid=h.eid and pr_status not in (60) and pr_type in 
                        (select code from mbank.guides where type_doc = 2486 and num1 in (0,1) and code in ('0','10','2','3','4','5','6','7','8','9') and code!='FORM_STORAGE')) EID_PRODUCTS
            ,(select count(*) from EID.EID_ACCOUNT where eid=h.eid and close_date is null) EID_ACCOUNT
            ,(select count(*) from EID.EID_CARD where eid=h.eid and date_destroy is null) EID_CARD
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_type = '0' and pr_status not in (60)) pr_vklad
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type in (select code from mbank.guides where type_doc = 2486 and num1=1 and code!='FORM_STORAGE')) pr_pk
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='2' ) pr_card
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='3' ) pr_cr_card
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='4' ) pr_zp_card
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='5' ) pr_skm
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='6' ) pr_DCLUB
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='7' ) pr_Virtuon
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='8' ) pr_corp_card
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='9' ) pr_ServCard
            ,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='10' ) pr_pens_card
            ,(select count(*) from eid.eid_firma where inn=h.inn) INN_IP
            ,null --h.address info_1
            ,null --h.address info_2
            ,null --h.address info_3
            --,h.* 
            from EID.EID_HUMAN h where 
                eid=rec.eid
                and h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid)
                and nvl(h.inn,'0')<>'0'
                --and not exists(select null from tmp_tables.gdm_eid_human where eid=h.eid)
                ;
            commit; 
    end loop;
    --dbms_output.put_line(nNum);
end;
/

-- ��������� ��������� �� �������
declare 
nNum number :=0;
begin
    for rec in (select * from tmp_tables.gdm_eid_human)
    loop
        nNum:=nNum+1;
        update tmp_tables.gdm_eid_human set num_pp = nNum
            where eid=rec.eid;
        commit; 
    end loop;
end;
/

-- �� ����� �� ��������� eid.p_eid_tools3.get_eid_list(h.eid, 1) all_eid,
-- ���������� �����������
select rowid,a.* from tmp_tables.gdm_eid_human a where all_eid='-1'

/
declare 
nNum number :=0;
begin
    for rec in (select a.* from tmp_tables.gdm_eid_human a where all_eid='-1')
    loop
        update tmp_tables.gdm_eid_human set all_eid = eid.p_eid_tools3.get_eid_list(eid, 1)
            where eid=rec.eid;
        commit; 
    end loop;
end;
/


-- �������� � �������
select rowid,a.* from tmp_tables.gdm_eid_human a where --eid<>current_eid 
eid_products>0 and inn_ip>0 and pr_vklad>0 and pr_pk>0

/
declare
 procedure p_get_product(p_eid eid.eid_human.eid%type,p_cur_eid eid.eid_human.eid%type,p_num number) as
    nAllProd number :=0;
    nAllCard number :=0;
    nBaseCard number :=0;
    nAcc number :=0;
    nGuiCard number :=0;
    sInfo varchar2(2000) := null;
 begin
    -- ����� ��������� ������ � ��������� ������������ � �.�. ��� �������� ���� �� � ������� ������ �������� 
    select count(*) into nAllProd from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and (pr_type>1 or pr_type=0) and nvl(pr_type_id,0) not in (1785);
    sInfo:=sInfo||'[PRODUCTS='||nAllProd||']';
        
    -- ����� ����
    select count(*) into nAllCard from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type>1; -- �����
    -- ����� ������� ����
    select count(*) into nBaseCard from ( 
        select distinct card_basic from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type>1 and card_basic is not null); -- �����
    --select count(*) into nBaseCard from ( 
    --    select distinct GetMainCard(sCard => a.account,nCloseLink => 0) from EID.EID_PRODUCTS a where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type>1); -- �����
 
    sInfo:=sInfo||'[ALL_CARD='||nAllCard||']';
    sInfo:=sInfo||'[BASE_CARD='||nBaseCard||']';
    
    --�������� ���� �� ����������� 2486
    for r_gui in (select * from mbank.guides where type_doc = 2486 and num1=1
                    and code in ('10','2','3','4','5','6','7','8','9')
                    and code!='FORM_STORAGE')
    loop
        select count(*) into nGuiCard from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type=to_number(r_gui.code); -- �����
        --sInfo:=sInfo||'[ALL_'||trim(r_gui.code)||'_'||trim(upper(r_gui.name))||'='||nGuiCard||']';
        sInfo:=sInfo||'[AGUI_'||trim(r_gui.code)||'='||nGuiCard||']';
        
        select count(*) into nGuiCard from ( 
            select distinct card_basic from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type=to_number(r_gui.code) and card_basic is not null); -- �����
        --sInfo:=sInfo||'[BASE_'||trim(r_gui.code)||'_'||trim(upper(r_gui.name))||'='||nGuiCard||']';
        sInfo:=sInfo||'[BGUI_'||trim(r_gui.code)||'='||nGuiCard||']';
    end loop; 

    -- ��������� �����
    select count(*) into nAcc from EID.EID_PRODUCTS where eid in (p_eid,p_cur_eid) and pr_status<>60 and pr_type=0 -- �����
        and nvl(pr_type_id,0) not in (1785); -- ������� ����
    sInfo:=sInfo||'[A��='||nAcc||']';
    
--    for r_prod in (select 
--                    case 
--                        when pr_type>1 then GetMainCard(sCard => a.account,nCloseLink => 0) 
--                    end card_b, -- ����� �������� �����
--                    case 
--                        when pr_type>1 then get_fss_account_way(a.account) 
--                    end acc_40817, -- ��������� 40817 � ������� p
--                    case 
--                        when pr_type>1 then PKG_FNO.GET_BASE_CONTRACT_SVODNY_SKS(a.account) 
--                    end  svod, -- ������ �������� ���
--                    rowid,a.* 
--                    from EID.EID_PRODUCTS a 
--                        where eid in (p_eid,p_cur_eid)
--                        and pr_status<>60
--                        and pr_type>1 -- �����
--                   ) 
--    loop
--        
--    end loop;                   
    update tmp_tables.gdm_eid_human set info_1 = sInfo where num_pp=p_num and current_eid=p_cur_eid and eid=p_eid;
    commit;
 end;
 procedure p_ip_inn(p_inn eid.eid_human.inn%type,p_eid eid.eid_human.eid%type,p_cur_eid eid.eid_human.eid%type,p_num number) as
    nFirmEid number :=0;
    nProd number :=0;
    nAllProd number :=0;
    sInfo varchar2(2000) := null;
 begin
    for r_ip in (select * from eid.eid_firma where inn=trim(p_inn))
    loop
        nFirmEid:=nFirmEid+1;
        select count(*) into nProd from eid.eid_firma_products where eid=r_ip.eid and status=50
            and pr_type=0; -- �� �������, 1 - ��� �������
        nAllProd:=nAllProd+nProd;
    end loop;

 
    sInfo:=sInfo||'[FIRMA_COUNT='||nFirmEid||']';
    sInfo:=sInfo||'[PRODUCT_COUNT='||nAllProd||']';
    
    update tmp_tables.gdm_eid_human set info_2 = sInfo where num_pp=p_num and current_eid=p_cur_eid and eid=p_eid;
    commit;
 end;

-- procedure p_fns_info(p_inn eid.eid_human.inn%type,p_eid eid.eid_human.eid%type,p_cur_eid eid.eid_human.eid%type,p_num number) as
--    nNoFile number :=0;
--    nInkp number :=0;
--    nZno number :=0;
--    nInkpWait number :=0;
--    sInfo varchar2(2000) := null;
-- begin
--    for r_ip in (select * from eid.eid_firma where inn=trim(p_inn))
--    loop
--        nFirmEid:=nFirmEid+1;
--        select count(*) into nProd from eid.eid_firma_products where eid=r_ip.eid and status=50
--            and pr_type=0; -- �� �������, 1 - ��� �������
--        nAllProd:=nAllProd+nProd;
--    end loop;
--
-- 
--    sInfo:=sInfo||'[FIRMA_COUNT='||nFirmEid||']';
--    sInfo:=sInfo||'[PRODUCT_COUNT='||nAllProd||']';
--    
--    update tmp_tables.gdm_eid_human set info_2 = sInfo where num_pp=p_num and current_eid=p_cur_eid and eid=p_eid;
--    commit;
-- end;

begin
    -- ����� ������ ��
    for rec in (
    
    select /*+ PARALLEL(4) */
    a.* from tmp_tables.gdm_eid_human a--where eid in (6395892,4926074,5691046,4108868)
    
    )
    loop
        -- �������� ����������
        
        -- ������� �������� ��
        p_get_product(p_eid => rec.eid,p_cur_eid => rec.current_eid,p_num=>rec.num_pp);
        
        -- ������� ���� �� ������� � ������ ��� 
        p_ip_inn(p_inn => rec.inn, p_eid => rec.eid,p_cur_eid => rec.current_eid,p_num=>rec.num_pp);
        
    end loop;
end;
/

-- EID_PRODUCTS
select 
--case 
--    when pr_type>1 then GetMainCard(sCard => a.account,nCloseLink => 0) 
--end card_b, -- ����� �������� �����
--case 
--    when pr_type>1 then get_fss_account_way(a.account) 
--end acc_40817, -- ��������� 40817 � ������� p
--case 
--    when pr_type>1 then PKG_FNO.GET_BASE_CONTRACT_SVODNY_SKS(a.account) 
--end  svod, -- ������ �������� ���
rowid,a.* 
from EID.EID_PRODUCTS a 
where 
eid in (4926074)
--and pr_status<>60
--and pr_type>1 -- �����
--and pr_type=0 -- �����

--EID_ACCOUNT
select rowid,a.* 
from EID.EID_ACCOUNT a 
where 
eid in (9994829)
--and close_date is null
and header<>'p'

--
and header='p'
and assist is not null
and assist in (select distinct card_basic from EID.EID_PRODUCTS where eid=a.eid and pr_status<>60 and pr_type>1)

--EID_CARD -- �� �����
select rowid,a.* 
from EID.EID_CARD a 
where 
eid in (9994829)


-- ������� �� ��������� ����������� 2486

-- ����� �����
-- �������� ��������� �� �� (�����������/�� �����������/�����������)
select * from eid.eid_firma where inn='772337604504'

select * from eid.eid_firma_products --where eid=5820989
where status=50 -- not in (60,50,70,0)

select * from eid.eid_firma_account --where eid=5820989

-- �������� ������� �������� �� ��� (�������, �������, ����������)
select * from no_file where inn='772337604504'




-- num1=0 - �������
-- num1=1 - ��
select * from mbank.guides where type_doc = 2486 --and num1=0


select * from mbank.guides where type_doc = 2486 and num1=0 --and code='5'
--and code in ('0')

select * from mbank.guides where type_doc = 2486 
and num1=1 --and code='5'
and code in ('10','2','3','4','5','6','7','8','9')
and code!='FORM_STORAGE'



--p_fssp
--            for recs in (select eid, account code, subdepartment, pr_type, reference , branch, pr_currency
--                                from eid.eid_products
--                                where eid = l_Eids(i)
--                                  and pr_type <> 8 -- ��� ������������� ����
--                                  and pr_type <> 0.8 --���������� ������ paa3 07.04.2015
--                                  and pr_type <> 9 -- ��������� ����� Priority Pass #AAM 26.05.2016
--                                  and ((pr_type = 5 AND nvl(type_skm, 0) <> 4) OR pr_type <> 5) --��� ��� ����� c ���� (SUPACOPINT-42)
--                                  and pr_status <> 60 -- ��������
--                                  and nvl(Additional, 0) <> 1 -- ������ ��� �����������
--                                  and ( length(account) > 16 --����� ����� CashCarry
--                                         or (length(account) = 16 and coalesce(eid.P_PRODUCTS_VARIABLE.GetParam(reference,null,'SUBTYPECODE'),'0') not in ('CC3RUR','CC2RUR') )
--                                       )
--                         )



select rowid,
--pkg_fno.get_filial_id(a.subdepartment, a.account) div,
a.* from EID.EID_PRODUCTS a 
where --pr_type=5 and pr_status not in (60)
eid in (2565)--10702844)
--1884245,794048,20956670,34654543)
--and account='4291580038604758'
--pr_type in (5) and nvl(date_close,trunc(sysdate)+1)>=trunc(sysdate)
--and exists (select null from eid.eid_products where eid=a.eid and pr_type=0 and nvl(date_close,trunc(sysdate)+1)>=trunc(sysdate))
--and exists (select null from eid.eid_products where eid=a.eid and pr_type=4 and nvl(date_close,trunc(sysdate)+1)>=trunc(sysdate))
--account in ('40817810200000000225','40817810500000004002','40817810982293854179')

select * from EID.EID_CARD 
where 
--pk in ('4291580046395118','4291580058377251','4291580045907699','6270850100008604')
eid in (2565)

select 
--pkg_fno.get_filial_id(a.subdepartment, a.code) div,
rowid,a.* 
--distinct contract
from EID.EID_ACCOUNT a where 
--length(code)=16-- in ('4291580046395118')
--a.code in (select account_code from fno_accounts where FNO_id = 202031)--FNO_rec.id)
--code='40817810880000380145'
--assist='4652061131753647'
--and 
eid in (2565)

select * from eid.eid_firma where inn='111111'

select 
eid.p_eid_tools.search_new_eid(h.eid) current_eid,
h.eid,h.date_modify,h.last_name||' '||h.first_name||' '||h.second_name FIO,h.birthday,h.doc_number,h.inn
,(select count(*) from EID.EID_HUMAN_MODIFY where eid=h.eid and date_modify>h.date_modify) EID_H_MODIFY
,(select count(*) from EID.EID_PRODUCTS where eid=h.eid and pr_status not in (60) and pr_type in 
        (select code from mbank.guides where type_doc = 2486 and num1 in (0,1) and code in ('0','10','2','3','4','5','6','7','8','9') and code!='FORM_STORAGE')) EID_PRODUCTS
,(select count(*) from EID.EID_ACCOUNT where eid=h.eid and close_date is null) EID_ACCOUNT
,(select count(*) from EID.EID_CARD where eid=h.eid and date_destroy is null) EID_CARD
,(select count(*) from eid.eid_products where eid=h.eid and pr_type = '0' and pr_status not in (60)) "�����"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type in (select code from mbank.guides where type_doc = 2486 and num1=1 and code!='FORM_STORAGE')) "�������"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='2' ) "�����"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='3' ) "��. �����"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='4' ) "�/�����"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='5' ) "���"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='6' ) "DCLUB"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='7' ) "Virtuon"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='8' ) "����.��"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='9' ) "ServCard"
,(select count(*) from eid.eid_products where eid=h.eid and pr_status not in (60) and pr_type='10' ) "����.�����"
,(select count(*) from eid.eid_firma where inn=h.inn) INN_IP
--,h.* 
from EID.EID_HUMAN h where 
--reference is not null
--nvl(subdepartment,0) in (200)
--eid in (1841282,34752874)
--eid in (2565)--10702844)
--and 
h.date_modify = (select max(date_modify) from EID.EID_HUMAN where eid = h.eid)
and nvl(h.inn,'0')<>'0'
and rownum<=100

order by date_modify desc

select rowid,
h.* 
from EID.EID_HUMAN h where 
--reference is not null
--nvl(subdepartment,0) in (200)
--eid in (1841282,34752874)
eid in (2565)--10702844)
order by date_modify desc

select h.subdepartment,h.reference,h.branch,h.* from EID.EID_HUMAN_modify h where 
eid=2565
order by date_modify desc

nvl(inn,'0')<>'0'
and exists(select null from EID.EID_PRODUCTS where eid=h.eid and pr_type=5 and pr_status not in (60))
order by eid,date_modify desc