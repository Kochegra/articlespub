select * from users where user_id=978489

select * from users where lower(user_name) like '%�����%'

/
declare 
  -- Local variables here
  i integer;
  tmp_v varchar2(300);
  v_RefChar varchar2(300);
  upDel number;
begin
   -- Test statements here                      
   dbms_application_info.set_client_info('MBANK-0Kernel');
   ptools2.short_init_user(1403);--978489);--1403);

    for rec in (select rowid,doc.*
                from documents doc 
                where reference in (4969006818)
                --and status=14
                )
    loop
          
        tmp_v:= start_process.WORKING(1, 5,  rec.branch, rec.reference, null, i);
            -- 11 - ��������, 5 - ��������
        DBMS_OUTPUT.PUT_LINE(rec.reference||' - done'||'  '||tmp_v);  
        commit;
    end loop;
end;
/


select 4132346111,to_char(4132346111) from dual