
BEGIN
   :doa__value :=
      START_PROCESS.WORKING (nType        => :nType,
                             nTYPEWORKS   => :nTYPEWORKS,
                             nBRANCH      => :nBRANCH,
                             nREFERENCE   => :nREFERENCE,
                             cParam       => :cParam,
                             TYPEMSG      => :TYPEMSG);
END;


:DOA__VALUE=[NULL]
:NTYPE=[1]
:NTYPEWORKS=[5]
:NBRANCH=[0.191000000e+003]
:NREFERENCE=[0.262107346e+009]
:CPARAM=['']
:TYPEMSG=[0.0e+2147483647]


Elapsed time: 1.154

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
Timestamp: 26.02.2020 12:16:32

BEGIN
   :doa__value :=
      START_PROCESS.WORKING (nType        => :nType,
                             nTYPEWORKS   => :nTYPEWORKS,
                             nBRANCH      => :nBRANCH,
                             nREFERENCE   => :nREFERENCE,
                             cParam       => :cParam,
                             TYPEMSG      => :TYPEMSG);
END;


:DOA__VALUE=[NULL]
:NTYPE=[1]
:NTYPEWORKS=[5]
:NBRANCH=[0.191000000e+003]
:NREFERENCE=[0.262107346e+009]
:CPARAM=['']
:TYPEMSG=[0.0e+2147483647]



