select * from users 
where user_id in (978489,1002235)
--where lower(user_name) like '%������%'

'COMPDOC_STATUS',
'DATEPLAT',
'DATE_PAYERSBANK',
'KBK',
'OKATO',
'PAYERS_KPP',
'PAYMENT_ID',
'RECEIVERS_KPP',
'SCHEMA', 
'TAX_DATEDOC',
'TAX_DOCNUMBER',
'TAX_MEMO',
'TAX_PERIOD',
'IN WAY4'

40702840000000000047

/
declare
   doa__value DOCUMENTS.REFERENCE%type;
   vUSER number := 978489;
   vFOLDER number := 0;  
   vTYPEDOC number := 226;  
   vREFER_FROM number := 0;  
   vBRANCH_FROM number := 0;  
   vN_Group number := 0;
   vRefCont number := 22072186;--4545923;--4547300; -- �������
   vBrCont number := 770;
   res number;
   vDocBr number;
   vDATEPLAT varchar(2000) := '31.05.2025';
   vDATE_PAYERSBANK varchar(2000) := '31.05.2021';
   vTAX_PERIOD varchar(2000) := '21.03.2021';
   v_Summ number := 100; -- ����� ����   
BEGIN
   ptools2.short_init_user(vUSER);
   doa__value :=
      GLOBAL_FUNCTION.ADD_DOCUMENT (USER          => vUSER,
                                    FOLDER        => vFOLDER,
                                    TYPEDOC       => vTYPEDOC,
                                    REFER_FROM    => vREFER_FROM,
                                    BRANCH_FROM   => vBRANCH_FROM,
                                    N_Group       => vN_Group);
   DBMS_OUTPUT.PUT_LINE(doa__value);

    select branch into vDocBr from documents WHERE REFERENCE = doa__value;

   for rec in (select * from contracts where reference=vRefCont and branch=vBrCont
   )loop
    DBMS_OUTPUT.PUT_LINE(rec.reference);

    UPDATE DOCUMENTS
       SET REFER_FROM = 0,
       BRANCH_FROM = 0,
       RELATED = 0,
       BRANCH_RELATED = 0,
       FOLDER = 0,
       STATUS = 10,
       CHILD = 0,
       owner = vUSER,
       REFER_OFFICE = '',
       Payers = (select full_name from clients where reference=rec.refer_client and branch=rec.branch_client),--'��� "������-�"',
       Payers_inn = (select inn from clients where reference=rec.refer_client and branch=rec.branch_client),--'7723180887',
       Payers_account = rec.account,--'40702810200009004586',
       Summa = v_Summ,
       Memo = '���� ������ ��',
       Payment = '3',
       Doc_Number = '10',
       ShifrOper = '310006',
       Num_Group = 0,
       Receivers_BIK = '011012100',
       Receivers_coracc = '',
       Receivers_bank =
          '��������� ������������ ����� ������//��� �� �������� ������� �.������������',
       Receivers_Account = '03100643000000012300', 
       Receivers_inn = '2801888889',
       Receivers = '��� 10'
    WHERE REFERENCE = doa__value AND BRANCH = vDocBr;


        for rec_var in (select 'COMPDOC_STATUS' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'04' VALUE, null SUBFIELD from dual
                        union all
                        select 'DATEPLAT' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,vDATEPLAT VALUE, null SUBFIELD from dual
                        union all
                        select 'DATE_PAYERSBANK' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,vDATE_PAYERSBANK VALUE, null SUBFIELD from dual
                        union all
                        select 'KBK' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'18210301000011000110' VALUE, null SUBFIELD from dual
                        union all
                        select 'OKATO' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'10701000' VALUE, null SUBFIELD from dual
                        union all
                        select 'PAYERS_KPP' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'500801001' VALUE, null SUBFIELD from dual --772801001
                        union all
                        select 'PAYMENT_ID' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'RECEIVERS_KPP' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'280101001' VALUE, null SUBFIELD from dual
                        union all
                        select 'SCHEMA' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'1' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_DATEDOC' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_DOCNUMBER' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_MEMO' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'��' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_PERIOD' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'31.06.2021' VALUE, null SUBFIELD from dual
                        -- ���� ���
                        --union all
                        --select 'IN WAY4' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'1' VALUE, null SUBFIELD from dual

        )loop 
    
--            res :=
--            variable.updatetable ('VARIABLE_DOCUMENTS',
--                            doa__value,
--                            vDocBr,
--                            :FIELDTYPE,  !!!!!!
--                            rec_var.name,
--                            rec_var.value,
--                            rec_var.subnumber,
--                            rec_var.subfield,
--                            rec_var.rownumber,
--                            rec_var.colnumber);
            UNIVERSE.Input_var_doc(vDocBr, doa__value, rec_var.name, rec_var.value);
        end loop;
    end loop;

commit;
END;
/


