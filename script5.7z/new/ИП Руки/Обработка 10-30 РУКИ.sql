KATRACH_SY Zz12345

select * from users whe

select nvl(GLOBAL_PARAMETERS.GET_PARAM_CFG('WAY4_ARREST_24_ALGORITHM'), '1') from dual

select * from config where name='WAY4_ARREST_24_ALGORITHM'

select * from doc_state1 WHERE reference = 263274626

Select d.reference
                from documents d, variable_documents vd
              where d.reference = 263274626 --rec_doc.reference
                    and d.branch = 191 --rec_doc.branch
                    and vd.reference = d.related
                    and vd.branch = d.branch_related
                    and vd.name = 'IP_SKS'
                    and vd.value = '1'

select rowid,a.* from contracts a 
where --reference=5283491 
--type_doc=590 and 
sub_type=1 --and status=50
--and UNIVERSE.VARIABLE_CONTRACT(branch, reference,'CARD_CORP_CONTRACT')='0191-C-601790'
and account = (select payers_account from documents where reference=4141590578)

select rowid,aa.* from variable_contracts aa where (reference,branch) in 
(select reference,branch from contracts a where account='40702810200009004599')

select rowid,a.* from contracts a where account='40702810200009004599'
 

263292951
263292990
263293008


-- ������ ������ �������� 262107347,262107343

select rowid,doc.* from documents 
--as of timestamp (systimestamp - interval '4' minute)
doc where  reference in (264089024)
or refer_from in (264089024)
or related in (264089024)

select level,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (263314624))--
--262298063))--262295900))
            --reference=262295295 and branch=191
order by level

--======= VARIABLE_DOCUMENTS

select 
(select status from documents where reference=doc.reference and branch=doc.branch) status,
rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (--262298063))--
263314624
))
and name not in ('COMPDOC_STATUS',
'DATEPLAT',
'DATE_PAYERSBANK',
--'KBK',
'OKATO',
'PAYERS_KPP',
'PAYMENT_ID',
'RECEIVERS_KPP',
'SCHEMA', 
'TAX_DATEDOC',
'TAX_DOCNUMBER',
'TAX_MEMO',
'TAX_PERIOD',
'IN WAY4'
) 

UNIVERSE.VARIABLE_PART(

--======= JOURNAL
select rowid,j.*  from journal 
--as of timestamp (systimestamp - interval '4' minute)
j where docnum in (263314636)

select * from mbank_audit.audit_table where reference=262295295

--DISTR

--1 eid.distrib_features
--select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where --task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and 
value in (
'263314637'--,
--'263314556',
--'263309163'
)
--and name='DOCEXTID'
--and 
--tran_id in (28061776)

--2 eid.distrib_transactions
select t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where --task_kind='M_FILIAL' and 
tran_id in  (195994,195995,195996)
order by tran_id,run_order                                                        --� ��������� ������ ������� - ����������� �������� � DONE =1


select 
rowid,a.*
,(select t.comments from eid.distrib_transactions t where tran_id=a.tran_id and filial=a.filial) tr
from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
and tran_id in (195986)
--and name='DOCEXTID'
--and name='DELETED'



--CARD_OPER
select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('262295295')
order by id desc


insert into eid.eid_card_oper
(CARD_NUMBER,WORK_DATE,CLOSE_DATE,OP_NAME,OP_CODE,OP_STATUS,OP_PAR,REFERENCE,BRANCH,DATE_MODIFY,OWNER_MODIFY)
select
universe.VARIABLE_CONTRACT(191, 5283491, 'CARD_CORP_CONTRACT') card_number,
trunc(sysdate),
sysdate,
'���������� ������� �� ��������� �����',
'INKASSO_ON', 
60,
'[AMOUNT='||summa||'][TAX_NUMBER='||doc_number||';'||reference||'_'||branch||'][TAX_DATE='||to_char(trunc(sysdate),'dd.mm.yyyy')
||'][CARD=0][ADD_TYPE=IP_LOCK][WRK][NOT_FOUND=][RESPONSE=]' op_par,
reference,branch,sysdate,1403
--d.* 
from documents d where reference in (262295295)


