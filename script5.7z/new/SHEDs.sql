-- ������ �� �����
select rowid,a.* 
--task_name,job_name,disabled
from shed_jobs a
where --task_name in ('SUPPORT') 
--and job_name in ('RPO_CHECK_DOP','ZNO_CHECK_DOP','INKP_CHECK_DOP','INKP_ANSWER48_STANDART_ERR')
--job_name in ('SHED_PC_SYNC','E_INKP','E_INKP_DISTRIB','POST_EXEC_INCASSO_DOC')--
--lower(job_name) like lower('%E_INKP%')
--lower(text) like lower('%AUTOEXECUTED%')
--lower(text1) like lower('%IP_LOCK%')
--lower(text2) like lower('%IP_LOCK%')
lower(job_name) like lower('%monitor_WAY24%')

impex_impufd.post_exec_incasso_doc
