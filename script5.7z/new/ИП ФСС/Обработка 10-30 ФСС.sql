-- ������ F5
declare
     doc_ref    number;
     doc_br     number;
     j          NUMBER;
     tmp1       VARCHAR2(2000);
     tmp2       VARCHAR2(2000);
     v_owner    NUMBER;
     v_status   NUMBER;
begin
   doc_ref := 262355611;
   v_owner := 1403;
   doc_br  := 191;
   mbank.ptools2.short_init_user (v_owner);
   
   select nvl(status,0) into v_status from documents where reference=doc_ref and branch=doc_br;
   if v_status=10 then
        delete 
        from variable_documents  
        where reference=doc_ref and doc_br=191 and name like 'IP_SKS%'; 
        commit; 
   end if;
     
   j := NULL; tmp1 := NULL; tmp2 := NULL;
   dbms_output.put_line(DOCALGO.EXECDOC(doc_br, doc_ref, v_owner, j, tmp1, tmp2));
   commit;                 
   impex_cv.input_var_doc(nBranch=>doc_br, nReference=>doc_ref, cName=>'AUTOEXECUTED', cValue=>'1');
   commit;                 
end;  
/



select rowid,doc.* from documents 
--as of timestamp (systimestamp - interval '4' minute)
doc where  reference in (262355611)
or refer_from in (262355611)
or related in (262355611)

select level,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (262355611))--
--262298063))--262295900))
            --reference=262295295 and branch=191
order by level


--======= VARIABLE_DOCUMENTS

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262355611))
and name not in ('DATE_PAYERSBANK','EDAUTHOR','EDDATE','GROUP_SEND','INITIALED_EDAUTHOR','INITIALED_EDDATE','INITIALED_EDNO','PAYERS_KPP',
'PAYMENT_ID','RECEIVERS_KPP','SCHEMA','SEANSI','SEND','SOURCE_EDNO','TYPEIMPORT','VID_CODE','WORK_DATE'
--'#IP_SKS'--'#IP_SKS_STATUS'--'#IP_SKS_STEP'
) 


--======= JOURNAL
select rowid,j.*  from journal 
--as of timestamp (systimestamp - interval '4' minute)
j where docnum in (262189777)

select * from mbank_audit.audit_table where reference=262189777

--DISTR
select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('262107347')
order by id desc


--1 eid.distrib_features
--select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where --task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and 
value in ('4002523386')
--and 
--tran_id in (28061776)

--2 eid.distrib_transactions
select t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where --task_kind='M_FILIAL' and 
tran_id in  (270148422,270199019,270212491)
order by tran_id,run_order                                                        --� ��������� ������ ������� - ����������� �������� � DONE =1


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
and tran_id in (270199019)






