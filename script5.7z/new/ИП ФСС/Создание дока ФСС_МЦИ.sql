-- �������� 
select rowid,doc.* from documents 
--as of timestamp (systimestamp - interval '4' minute)
doc where  reference in (2165138161)

select --rowid,doc.* 
NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD
from variable_documents 
--as of timestamp (systimestamp - interval '4' minute)
doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (2165138161))

select * from contracts


/
declare
   doa__value DOCUMENTS.REFERENCE%type;
   vRefDoc number;
   vUSER number := 1403;
   vFOLDER number := 878;  
   vTYPEDOC number := 226;  
   vREFER_FROM number := 0;  
   vBRANCH_FROM number := 0;  
   vN_Group number := 882;
   vSUMMA number := 200;
   vPAYERS_ACCOUNT documents.PAYERS_ACCOUNT%type;
   vPAYERS_CURRENCY documents.PAYERS_CURRENCY%type;
   vInn clients.inn%type;
   vFullName clients.full_name%type;
   vTaxCode variable_clients.name%type;
   vRefCont number := 5283486; -- �������
   vBrCont number := 191;
   res number;
BEGIN
   ptools2.short_init_user(vUSER);
   vRefDoc:=doc_reference.nextval;
   DBMS_OUTPUT.PUT_LINE(vRefDoc);
    
--vRefDoc:=262189777;
--   select branch into vDocBr from documents WHERE REFERENCE = doa__value;
   select
   account,currency, 
   (select inn from clients where reference=refer_client and branch=branch_client) inn,
   (select full_name from clients where reference=refer_client and branch=branch_client) full_name,
   UNIVERSE.VARIABLE_CLIENT(BRANCH_client, REFER_client, 'TAXCODE') TaxCode
   into vPAYERS_ACCOUNT,vPAYERS_CURRENCY,vInn,vFullName,vTaxCode from contracts where reference=vRefCont and branch=vBrCont;

Insert into DOCUMENTS
   (REFERENCE, REFER_FROM,RELATED, 
    BRANCH, BRANCH_FROM,BRANCH_RELATED, 
    FOLDER, TYPE_DOC, SUB_TYPE, 
    STATUS, DOC_NUMBER, DATE_CREATE, DATE_WORK, DATE_DOCUMENT, 
    NUM_GROUP, PAYERS_ACCOUNT, REAL_PAYERS, PAYERS_CURRENCY, PAYERS_BIK,PAYERS_INN, 
    PAYERS_CORACC, PAYERS_BANK, PAYERS, 
    RECEIVERS_ACCOUNT,REAL_RECEIVERS, RECEIVERS_CURRENCY, RECEIVERS_BIK, RECEIVERS_INN, 
    RECEIVERS_CORACC,RECEIVERS_BANK, RECEIVERS, 
    SUMMA, MEMO, PAYMENT,OWNER, REFER_OFFICE, /*VERSION,*/ CHILD, 
    REAL_PAYERS_CONTRACT,REAL_RECEIVERS_CONTRACT, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, PAYERS_CONTRACT, RECEIVERS_CONTRACT, 
    BRANCH_PAYERS, BRANCH_RECEIVERS, PAYERS_RELATED, RECEIVERS_RELATED, DEPART_PAYERS, 
    SHIFROPER, XSUMMACREDIT, XSUBDEPARTMENT)
Values
   (vRefDoc,0,0,
    (select subdepartment from users where user_id=vUSER),0,0,
    vFOLDER,vTYPEDOC,0,
    10,'11',sysdate,trunc(sysdate),trunc(sysdate),
    vN_Group,vPAYERS_ACCOUNT, vPAYERS_ACCOUNT, vPAYERS_CURRENCY, '044525411',vInn,
    '30101810145250000411','������ "�����������" ����� ��� (���) � �. ������, �. ������',vFullName,
    '40702810303240904661','30102810000810000411', '810', '042202837', '5260148520', 
    '30101810200000000837','������ ����� ��� (���) � �.������ ��������� �.������ ��������', '��� "��� ������ ������ ��������"',
    vSUMMA,'���� W4. � ��� ����� ��� 18.00', '5',vUSER,'IMPORT_MCI',/*1095268054,*/0,
    0,0,0,0,0,0,
    0,0,0,0,191,
    '310001', vSUMMA, 191);
    
    commit;
   
--Insert into DOCUMENTS
--   (REFERENCE, REFER_FROM, ID, BRANCH, BRANCH_FROM, 
--    BRANCH_RELATED, RELATED, FOLDER, TYPE_DOC, SUB_TYPE, 
--    STATUS, DOC_NUMBER, DATE_CREATE, DATE_WORK, DATE_DOCUMENT, 
--    NUM_GROUP, PAYERS_ACCOUNT, REAL_PAYERS, PAYERS_CURRENCY, PAYERS_BIK, 
--    PAYERS_INN, PAYERS_CORACC, PAYERS_BANK, PAYERS, RECEIVERS_ACCOUNT, 
--    REAL_RECEIVERS, RECEIVERS_CURRENCY, RECEIVERS_BIK, RECEIVERS_INN, RECEIVERS_CORACC, 
--    RECEIVERS_BANK, RECEIVERS, SUMMA, MEMO, PAYMENT, 
--    OWNER, REFER_OFFICE, VERSION, CHILD, REAL_PAYERS_CONTRACT, 
--    REAL_RECEIVERS_CONTRACT, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, PAYERS_CONTRACT, RECEIVERS_CONTRACT, 
--    BRANCH_PAYERS, BRANCH_RECEIVERS, PAYERS_RELATED, RECEIVERS_RELATED, DEPART_PAYERS, 
--    SHIFROPER, XSUMMACREDIT, XSUBDEPARTMENT)
-- Values
--   (vRefDoc, 
--   0, 1095268054, 
--   191, 
--   0, 
--    0, 0, 878, 226, 0, 
--    23, '100', TO_DATE('02/26/2020 17:07:31', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/26/2020 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/26/2020 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 
--    882, '40702810100009004589', '40702810100009004589', '810', '044525411', 
--    '7728465491', '30101810145250000411', '������ "�����������" ����� ��� (���) � �. ������, �. ������', '"��� �������1"', '40702810303240904661', 
--    '30102810000810000411', '810', '042202837', '5260148520', '30101810200000000837', 
--    '������ ����� ��� (���) � �.������ ��������� �.������ ��������', '��� "��� ������ ������ ��������"',110, '���� W4. � ��� ����� ��� 18.00', '5', 
--    1403, 'IMPORT_MCI', 1095268054, 0, 0, 
--    0, 0, 0, 0, 0, 
--    0, 0, '0', '0', 191, 
--    '310001', 110, 191);
--COMMIT;
--
--update documents set status=10 where reference=vRefDoc and branch=191; 
--commit;

Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('SEANSI', vRefDoc, 191, 0, 0, 
    0, '12009658');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('EDAUTHOR', vRefDoc, 191, 0, 0, 
    0, '2202837000');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('EDDATE', vRefDoc, 191, 0, 0, 
    0, to_char(trunc(sysdate),'dd.mm.yyyy'));--'26.02.2020');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('PAYERS_KPP', vRefDoc, 191, 0, 0, 
    0, vTaxCode);--'772801001');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('RECEIVERS_KPP', vRefDoc, 191, 0, 0, 
    0, '526201001');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('PAYMENT_ID', vRefDoc, 191, 0, 0, 
    0, '0');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('WORK_DATE', vRefDoc, 191, 0, 0, 
    0, to_char(trunc(sysdate),'dd.mm.yyyy'));--'26.02.2020');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('DATE_PAYERSBANK', vRefDoc, 191, 0, 0, 
    0, to_char(trunc(sysdate),'dd.mm.yyyy'));--'26.02.2020');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('INITIALED_EDNO', vRefDoc, 191, 0, 0, 
    0, '11');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('INITIALED_EDDATE', vRefDoc, 191, 0, 0, 
    0, to_char(trunc(sysdate),'dd.mm.yyyy'));--'26.02.2020');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('INITIALED_EDAUTHOR', vRefDoc, 191, 0, 0, 
    0, '2202837000');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('SOURCE_EDNO', vRefDoc, 191, 0, 0, 
    0, '12177');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('VID_CODE', vRefDoc, 191, 0, 0, 
    0, '3');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('TYPEIMPORT', vRefDoc, 191, 0, 0, 
    0, 'E');
--Insert into MBANK.VARIABLE_DOCUMENTS
--   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
--    COLNUMBER, VALUE)
-- Values
--   ('IP_SKS', vRefDoc, 191, 0, 0, 
--    0, '1');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('SCHEMA', vRefDoc, 191, 0, 0, 
    0, '22202837');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('SEND', vRefDoc, 191, 0, 0, 
    0, '11');
Insert into MBANK.VARIABLE_DOCUMENTS
   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
    COLNUMBER, VALUE)
 Values
   ('GROUP_SEND', vRefDoc, 191, 0, 0, 
    0, '�');
--Insert into MBANK.VARIABLE_DOCUMENTS
--   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
--    COLNUMBER, VALUE)
-- Values
--   ('IP_SKS_STATUS', vRefDoc, 191, 0, 0, 
--    0, '10');
--Insert into MBANK.VARIABLE_DOCUMENTS
--   (NAME, REFERENCE, BRANCH, SUBNUMBER, ROWNUMBER, 
--    COLNUMBER, VALUE)
-- Values
--   ('IP_SKS_STEP', vRefDoc, 191, 0, 0, 
--    0, '1');
COMMIT;

update variable_documents set name='#'||name 
where reference=vRefDoc and branch=191 and name like 'IP_SKS%'; 
commit; 

END;
/



-- ������ F5
declare
     doc_ref    number;
     doc_br     number;
     j          NUMBER;
     tmp1       VARCHAR2(2000);
     tmp2       VARCHAR2(2000);
     v_owner    NUMBER;
begin
   doc_ref := 262083419;
   v_owner := 1403;
   doc_br  := 191;
   mbank.ptools2.short_init_user (v_owner);  
   j := NULL; tmp1 := NULL; tmp2 := NULL;
   dbms_output.put_line(DOCALGO.EXECDOC(doc_br, doc_ref, v_owner, j, tmp1, tmp2));
   commit;                 
end;  
/

