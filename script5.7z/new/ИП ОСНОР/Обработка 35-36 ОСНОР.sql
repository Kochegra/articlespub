select rowid,doc.* from documents doc where  reference in (262296686,262298210 )
or refer_from in (262296686,262298210)
or related in (262296686,262298210)

select level,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (262296716))
            --reference=262295295 and branch=191
order by level


--======= VARIABLE_DOCUMENTS

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262296716 ))
and name not in ('ACC_TYPE','CB_ARREST_NO','COMPDOC_STATUS','DATE_PAYERSBANK','DIRECTION','DOCUM','INKP_REF','KBK','OKATO','PAYERS_KPP','PAYMENT_ID',
'QID','RECEIVERS_KPP','TAX_DATEDOC','TAX_DOCNUMBER','TAX_MEMO','TAX_PERIOD','TYPEIMPORT','TYPE_PLAT')

--��������
select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262298210 ))
and name not in ('ACC_TYPE','CARD_ACCOUNT','CB_ARREST_NO','COMPDOC_STATUS','DATE_PAYERSBANK','DIRECTION','DOCUM','EXEC_DISTR','FROM_CRT','IN WAY4',
'INKP_REF','IP_SKS_SUMCD [111451:75]','KBK','OKATO','PAYERS_KPP','PAYMENT_ID','QID','RECEIVERS_KPP','SCHEMA','TAX_DATEDOC','TAX_DOCNUMBER',
'TAX_MEMO','TAX_PERIOD','TO CATALOGUE2','TYPEIMPORT')



--======= JOURNAL
select rowid,j.*  from journal j where docnum in (262296716,262298210)

--select rowid,doc.* from variable_documents doc where (reference,branch) in 
--(select reference,branch from documents doc where reference in (262079156))
--and name not in ('COMPDOC_STATUS','DATEPLAT','KBK','OKATO','PAYERS_KPP','PAYMENT_ID','RECEIVERS_KPP','ROLLBACKTOEMITENT','TAX_DOCNUMBER','TAX_MEMO','TAX_PERIOD') 


--DISTR
select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('262296716')
order by id desc


--1 eid.distrib_features
--select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where --task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and 
value in ('262296716')--,'262298210')
--and 
--tran_id in (28061776)

--2 eid.distrib_transactions
select t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where --task_kind='M_FILIAL' and 
tran_id in  (195610,195636)
order by tran_id,run_order                                                        --� ��������� ������ ������� - ����������� �������� � DONE =1


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
and tran_id in (195491)
