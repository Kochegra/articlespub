        select
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS,
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2,
        (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
        (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
        doc.SUMMA sumK2,doc.xSUMMAcredit xsumK2,
        p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
        doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
        doc.xsummacredit-p_k2.Get_Rest_K2(doc.reference, doc.branch) xostK2,
        p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => 191, pRefer_Contract => 29812115, pSumma => doc.summa, pCard_Type => 2) sum_related,
        p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,6582577340,631,trunc(sysdate)) spisK2_m,
        --p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
        doc.* 
        from documents doc
        where payers_account in ('40702978210190000114')--'40802810600250000004') 
        and status in (35,38) --and type_doc=2 
        and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
        --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,6582577340,631,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
        and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => 191, pRefer_Contract => 29812115, pSumma => doc.summa, pCard_Type => 2)=0
        --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
        --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
        --and  
        --and reference=5893504259

select * from k2_multi where reference=5228086521

40802810205030001055
40702978210190000114
40802810244420001231
40802810512182006798
40802810512182006798
40802810512182006798
40802810512182006798
40802810512182006798
40802810512182006798
40802810512182006798
40702810711440000447
40702810900000093553
40702810910554208143
40702810910554208143
40702810223210000974
40702810223210000974
40702810400180002980
40802810411520001113
40702810000004209816
40702810000004209816
40702810000004209816
40702810000004209816
40802810101280005390
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810600510004329
40702810910064200958
40702810910064200958
40702810910064200958
40702810910064200958
40703810700020001096
 
/ 
declare 
bResult boolean;
nDoc35 number;
 function f_stat_35to36(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pCntFind out number,pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
        select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account=pAcc  
            and status in (35,38) --and type_doc=2 
            and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,pRefCont,pBrCont,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit) -- �� ����� ��� ��������
            --and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => doc.summa, pCard_Type => 2)=0 --���������
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa  
            and doc.type_doc=226  
    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
                --nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;
            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)=0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
            if rDoc.status = 38 then
                delete from k2
                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
            end if;

            update documents set status = 36
            where reference = rDoc.reference and branch = rDoc.branch;
        
            commit;

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_35to36; 
begin
    ptools2.short_init_user(1403); -- ��� �������
    bResult:=f_stat_35to36('40802810710434204532',16939808,544,nDoc35,0);
    dbms_output.put_line('������� � �������� 35 �������: '||nvl(nDoc35,0)||' ����������.');
end;
/

16939808	544	40802810710434204532


select * from contracts where account='40802810817550009763'

select * from k2 where --refer_contract=20218737 and 
reference=6172049702

        select
        (doc.summa-p_k2.get_rest_k2(Doc.reference, Doc.branch)) ost,
        p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => doc.summa, pCard_Type => 2) GetRest4Cursor,
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account='40802810710434204532'  
            and status in (35,38) --and type_doc=2 
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,20218737,631,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa    
