select rowid,a.* from tmp_tables.tmp_gdm_k2 a where refer_contract in (22325421) --status>-400 and status<0

select rowid,a.* from tmp_tables.tmp_gdm_90901 a where contract in (15654718,15735005)

select rowid,a.* from account a where contract in (15654718,15735005) and code like '90901%'

select a.* from tmp_tables.tmp_gdm_90902 a where client=113461345 --contract=22325421 

code='90902810800917022088'

select a.* from tmp_tables.tmp_gdm_vc a where value='90901810003800003734'

select rowid,a.* from contracts /*as of timestamp (systimestamp - interval '20' minute)*/ a where account in (
'40702840028050000008'--,'40502810301880000002'
)

select 
rowid,a.* from contracts a where --assist='90902810300220201041' --
reference=534429 and branch=354005 
--(reference,branch) in (select reference,branch from contracts where account in (
--'40703840010380000002'--,'40502810301880000002'
--))

select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.value), a.value,substr(a.value,6,3), sysdate) saldo,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
rowid,a.* from variable_contracts a where --reference=534429 and branch=354005 
(reference,branch) in (select reference,branch from contracts where account in (
'40702840028050000008'--,'40502810301880000002'
))
and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)

select * from k2 where refer_contract=22325421 --reference=5232587219

select 
--sum(a.summa-p_k2.Get_Rest_K2(a.reference, a.branch)) aaa
--to_char(summa),
a.status,2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number,a.date_document
                    ,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
                    ,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
                    ,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
                    --distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
                        --Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
                from V_documents a, k2
                where a.reference = k2.reference
                      and a.branch    = k2.branch
                      and k2.refer_contract     = 17685511 --17685288 
                      and k2.branch_contract    = 780
                      and k2.what_is = 2
                      --and a.status in (35,38)
                      --and a.payers_account='90901810003800003734'
                      --and a.payers_account='40702810125050100530'

and a.reference=6869158913                      

select 4727.49 acc90902810755102100530,164413.86+627574.37 acc90902810525050000530 from dual

select 632301.86-627574.37 from dual

select rowid,aa.* from k2 aa where (reference,branch) in (select a.reference,a.branch from documents a, k2
                                                where a.reference = k2.reference
                                                and a.branch    = k2.branch
                                                and k2.refer_contract     = 17685288 
                                                and k2.branch_contract    = 780
                                                and k2.what_is = 2
                                                and a.status in (35,38)
                                                and a.payers_account='40702810320380012782'
                                                --and a.payers_account='40702810125050100530'
                                             ) 

Select rowid,a.* from account a 
where header='C' and code in ('90901810200321000404')--,'90901810630261001175')

where 
--and 
contract=534429 and bal in ('90901','40702','90902')

select 
reference||'/'||branch,
--reference,doc_number,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
Universe.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT,
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(doc.payers_account), doc.payers_account,substr(doc.payers_account,6,3), sysdate) saldo,
summa,xsummacredit,
p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
--(select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) waycnt,
--UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'WAY4_DOCEXTID',null) WAY4_DOCEXTID,
(select count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
--UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'FSSP_DOC_ID',null) FSSP_DOC_ID,
--UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'INKP_REF',null) INKP_REF,
rowid,doc.* from documents doc
--doc.* from v_documents doc
--rowid,doc.* from archive doc 
--update documents doc set status=1000
where 
--payers_account='40802810900490012743' 
--and 
--substr(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT',null),1,5) in ('90901')
--and UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT',null)  in ('90901810003800003734')
----where  
--and
(reference in (
--6297333258,
--6304115481,
--6389460667,
--6484966193,
--6582576674,
--6678249777,
6775713034,
6873011844,
6967767286
)
----union all
----select rowid,doc.* from archive doc where (reference in (4180141790)
----or (refer_from in (6063542431,4525887162,5537839268))-- and branch_from=191)
--or related in (
--3994526847 )
) and branch=780424

and status<1000 --=30 and status>15

90901840408800000001
90901840408800000001

--======= VARIABLE_DOCUMENTS
select rowid,doc.* 
,-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(doc.value), doc.value,substr(doc.value,6,3), sysdate) saldo
from variable_documents 
---as of timestamp (systimestamp - interval '20' minute)

update variable_documents set value='90902978820380000782'
--doc 
where (reference,branch) in 
(select reference,branch from documents doc where reference in (
6873011844,
6967767286
))
and instr(name,'CARD_ACCOUNT')>0 

90901810119121001833

and value--='90901810900491007776'

--and name in ('CARD_ACCOUNT')
and name in ('IP_SKS','WAY4_DOCEXTID','IGNORE_TECH_MSG','CARD_ACCOUNT')


--insert into collector_contracts
select rowid,a.* from collector_contracts a where reference=
--select a.* from collector_contracts a where reference=
--15971686
18680149 
and branch=296 and name='CARDLIST_2'
and docnum in (
6094450224
)













      select d.reference||',',d.*
             ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   documents           d
            ,collector_contracts c
      where  1 = 1
                --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
                and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40703810701220000003'))
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             --and c.reference = 17795596 --17741941 --cpRefCont
             --and c.branch = 780 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36)--, 38)
             and d.status >= 30
             and d.status < 1000
             --and d.status <= -30
             --and d.status > -1000

and substr(d.payers_account,6,3)<>'810'             





select --docnum||',',
rowid,a.* from collector_contracts a where (reference,branch) in (select reference,branch from contracts where account in (
--'40702810627060000160',
'40702810800008001168'
--'40702840500600008088'
))

and instr(name,'CARDLIST')>0
and exists (select null from documents where reference=docnum and branch=zbranch_docnum and status<>36)

and docnum in (4132151053,5130452537)

90902840933060000027

select
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code,substr(a.code,6,3), sysdate) saldo, 
rowid,a.* from account a where (contract,branch_contract) in (select reference,branch from contracts where account in (
--'40702810129260000028'
'90902840129260000372'
--'40702978329260000029'
))


select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code,substr(a.code,6,3), sysdate) saldo,
rowid,a.* from account a where code in (--'90902840129260000372',
'90902840129260000372')


      select d.reference||',',d.*
             ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   documents           d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             --and c.reference = 17795596 --17741941 --cpRefCont
             --and c.branch = 780 --cpBranchCont
                --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4064532)))--3854900)))--,
                and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810953000007677'))
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36)--, 38)
             and d.status >= 30
             and d.status < 1000
             --and d.status <= -30
             --and d.status > -1000
--and substr(d.payers_account,6,3)<>'810'             
-- �������� 17.12.2013 �������� ������� ��������
--             and ((d.payment IS NULL) OR
--                  (d.payment IN (5,6)) OR
--                  ((d.payment IN (3,4)) AND
--                   (universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)))
-- 11.04.2019 �������� ��������� ������ � ����������.
--             AND NVL(d.payment,5) IN (5)
--             AND(universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)
--             and substr(d.receivers_account,1,5) <> '40101'
--<<<<

select rowid,doc.* from documents doc 
--update documents set status=status*(-1)
where  reference in (
4999000,
5003023,
5003075,
5003430,
5083643,
4996874,
4822470,
4800016,
4747155,
4747113,
4747054,
4746654,
4720250,
4742744) ��� 

      
      union all
      select d.*
            ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.VARIABLE_ARCH(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   archive             d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             and c.reference = 17795596 --17741941 --cpRefCont
             and c.branch = 780 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36, 38)
             and d.status >= 30
             and d.status < 1000;


--======= DOCUMENTS ARCHIVE
select rowid,doc.* from documents doc 
--update documents set status=status*(-1)
where  reference in (4158656062,
4158659135,
4158665639,
4158680134,
4158689343,
4158692076,
5366329115,
5599184230)

--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (1207012554)
or related in (1207012554)

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (5773021814))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch)=

select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (1207012554))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=
