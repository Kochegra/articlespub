create table TMP_TABLES.TMP_GDM_90901 as
    select * from mbank.account a where header='C' and code like '90901%' and close_date is null and nvl(client,0)=0

create table TMP_TABLES.TMP_GDM_90902 as
    select * from mbank.account a where header='C' and code like '90902%' and close_date is null and nvl(client,0)=0 and code='90902810106280000680'

/    

grant select,insert,update,delete on TMP_GDM_90901 to MBANK

grant select,insert,update,delete on TMP_GDM_90902 to MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_90901 a

select rowid,a.* from TMP_TABLES.TMP_GDM_90902 a


delete from TMP_TABLES.TMP_GDM_90901

delete from TMP_TABLES.TMP_GDM_90902

/

alter table TMP_GDM_90901
    add (--f_contract        number,
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --var_card_acc_1        VARCHAR2(4000 BYTE),--
         --var_card_acc_15        VARCHAR2(4000 BYTE),
         --var_card_acc_2         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
         status number
        )
/        
alter table TMP_GDM_90902
    add (--f_contract        number,
--         f_branch_contract number,
--         log_contract   varchar2(4000 BYTE),
--         var_card_acc_1        VARCHAR2(4000 BYTE),--
--         var_card_acc_15        VARCHAR2(4000 BYTE),
--         var_card_acc_2         VARCHAR2(4000 BYTE),
--         var_card_acc_3         VARCHAR2(4000 BYTE),
--         info_1                 VARCHAR2(4000 BYTE)
         status number
        )

/

select * from mbank.account


/

-- VARIABLE_CONTRACTS
create table TMP_TABLES.TMP_GDM_VC as
    select * from mbank.variable_contracts a where reference=1 and branch=1
    
/    
grant select,insert,update,delete on TMP_GDM_VC to MBANK
/
select rowid,a.* from TMP_TABLES.TMP_GDM_VC a
/
delete from TMP_TABLES.TMP_GDM_VC

/

