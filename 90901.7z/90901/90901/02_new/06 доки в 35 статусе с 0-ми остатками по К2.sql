-- ����� ����� ��������� � ���������� ������
MULTIK2
MULTIK2_BR
MULTIK2_CARD_ACCOUNT
MULTIK2_REF

-- ����� ������ �� ���� ������
TO_ALL_ACCOUNTS


with tab as (

select
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2,
(select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
(select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
--distinct type_doc
doc.SUMMA sumK2,
doc.xSUMMAcredit sumK2_2,
p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
--p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,21943928,770,trunc(sysdate)) spisK2_m,
--p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
doc.xsummacredit-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2_2,
----elect count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
doc.* 
from documents doc
--doc.* from v_documents doc
--doc.* from archive doc 
--update documents doc set status=1000
--where payers_account='40702810410574209389'
where date_work between to_date('01.01.2021','dd.mm.yyyy') and to_date('15.11.2021','dd.mm.yyyy')  
--and 
--payers_account in ('40702978901150000036')
and status in (35,38) --and type_doc=2 
--and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
--and doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) = 0
and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(payers_currency,'810',summa,xsummacredit)
and ((nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')<>0 or nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')<>'0'))
--and exists(select null from k2_multi where reference=doc.reference and branch=doc.branch)
--and exists (select null from account where header=paccount.HEADER_ACCOUNT(doc.payers_account) and code=doc.payers_account and currency=substr(doc.payers_account,6,3) and bal)
and doc.payers_account not like '421%'

        

)
select distinct date_work, count(*) cnt 
from tab --where ostK2_2<=0
where p_k2.Get_Rest_K2(reference, branch) >= summa
group by date_work


select d.* from k2 k,documents d
where k.reference=d.reference and k.branch=d.branch and d.date_work>=to_date('01.11.2021','dd.mm.yyyy')
and  d.xsummacredit-p_k2.Get_Rest_K2(d.reference, d.branch) <= 0

where exists(select null from documents where reference=k.reference and branch=k.branch and date_work>=to_date('01.11.2021','dd.mm.yyyy') and xsummacredit-p_k2.Get_Rest_K2(reference, branch) = 0)

/
-- ��������� 35 � ������� �������� �� �2 � 36 ������
-- �����, �� �������� �������� ��� ������, ���� � �2 ��� ����, �������� � �� �������� ���� 
declare 
bRes boolean;
 function f_stat_35to36(pRef number,pBr number, pAcc account.code%type, pType varchar2 default 'DOC', pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
 begin
    bExec:=FALSE;
    -- �� ���������
    if pType='DOC' and nvl(pRef,0)<>0 and nvl(pBr,0)<>0 then
        -- ����� ��������
        -- ������� ������
        -- ������� ������� �� ������
        --
        if UNIVERSE.GET_DOCUMENT_REC(pRef, pBr, nArch, 1, rDoc) then
            if rDoc.payers_currency='810' then
                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                    bExec:=TRUE;
                end if;
            else
                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
                    bExec:=TRUE;
                end if;
            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
            if rDoc.status = 38 then
                delete from k2
                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
            end if;

            update documents set status = 36
            where reference = rDoc.reference and branch = rDoc.branch;
        
            commit;

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            nOstK2:=rDoc.summa-nSpisK2;
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            nOstK2:=rDoc.summa-nSpisK2;
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            --dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end if;
    -- �� ����� �������
    if pType='ACC' and pAcc is not null then
        --dbms_output.put_line('� ������');
        --return false;
        for rDocAcc in (
            select doc.* 
                from documents doc
                where --date_work between to_date('11.01.2021','dd.mm.yyyy') and to_date('11.01.2021','dd.mm.yyyy')
                payers_account=pAcc  
                and status in (35,38) --and type_doc=2 
                and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
                --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
                --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa    
        ) loop
            bExec:=FALSE;
            if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
                if rDoc.payers_currency='810' then
                    if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                        bExec:=TRUE;
                    end if;
                else
                    if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
                        bExec:=TRUE;
                    end if;
                end if;
            end if;
            if bExec and pUpd=1 then
                --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
                if rDoc.status = 38 then
                    delete from k2
                    where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
                end if;

                update documents set status = 36
                where reference = rDoc.reference and branch = rDoc.branch;
        
                commit;

                nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
                nOstK2:=rDoc.summa-nSpisK2;
                nXOstK2:=rDoc.xsummacredit-nSpisK2;
                if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
                dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');

            else
                nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
                nOstK2:=rDoc.summa-nSpisK2;
                nXOstK2:=rDoc.xsummacredit-nSpisK2;
                if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
                dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
            end if;
        end loop;
        bExec:=TRUE;
    end if;

    return bExec;
   
 end f_stat_35to36;
begin
    for rec in (
    
        select
        doc.SUMMA sumK2,doc.xSUMMAcredit xsumK2,
        p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
        doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
        doc.xsummacredit-p_k2.Get_Rest_K2(doc.reference, doc.branch) xostK2,
        --p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
        doc.* 
        from documents doc
        where date_work between to_date('11.01.2021','dd.mm.yyyy') and to_date('11.11.2021','dd.mm.yyyy')  
        and status in (35,38) --and type_doc=2 
        --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
        and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
        and payers_account in ('40702978901150000036') 
        --and reference=5893504259
    
    )loop
--        bRes:=f_stat_35to36(pRef=>rec.reference,pBr=>rec.branch,pType=>'ACC',pUpd=>0);
        --bRes:=f_stat_35to36(rec.reference,rec.branch,rec.Payers_account,'DOC',1);
        bRes:=f_stat_35to36(rec.reference,rec.branch,rec.Payers_account,'ACC',1);
        if bRes then
            dbms_output.put_line('������ ������ � 35 �� 36');
        end if;
    end loop;
end;
/

-- ��������
        select
        doc.SUMMA sumK2,doc.xSUMMAcredit xsumK2,
        p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
        doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
        doc.xsummacredit-p_k2.Get_Rest_K2(doc.reference, doc.branch) xostK2,
        --p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
        doc.* 
        from documents doc
        where --date_work between to_date('11.01.2021','dd.mm.yyyy') and to_date('11.01.2021','dd.mm.yyyy')  
        --and 
        status in (35,38,36) --and type_doc=2
        --status in (36) --and type_doc=2 
        --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
        --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
        and payers_account in ('40702978901150000036') 

select * from k2 where account in ('40702978901150000036')

select * from k2_multi where (reference,branch) in (select reference,branch from documents where reference in (
5599180515,
5893504259,
5901763973
)) 