update tmp_tables.TMP_GDM_90901 set log_contract=null 

update tmp_tables.TMP_GDM_90901 a set info_1=log_contract
where instr(nvl(a.log_contract,'#'),'DEL')>0

select count(*) from tmp_tables.TMP_GDM_90901 where instr(log_contract,'DEL')>0

select
-- �������
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2, 
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--(select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2,
-- �������� ref/br ���������
--greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
--a.*
a.bal,a.code,a.open_date,A.CLOSE_DATE,a.name,a.log_contract
--,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
,c.status stat_cont,c.date_close date_close_cont
,c.account acc_rko,(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
,c.type_doc
--,c.*
from tmp_tables.TMP_GDM_90901 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
-- ������ �������� 90901
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
--and 
--and a.code in ('90901810400151001279')
--and (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate))=0
and c.account is not null and c.account not like '421%'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
and not exists(select null from tmp_tables.tmp_gdm_k2 where refer_contract=c.reference and branch_contract=c.branch)
--and not exists(select null from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)

        and(
            (COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY'))
            )=to_date('01.01.1900','dd.mm.yyyy'))




-- �������� � �������� 1000
/
declare 
nCnt number :=0;
begin
    for rec in (
    
select
-- �������
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2, 
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--a.*
a.reference,a.branch,a.bal,a.code,a.open_date,A.CLOSE_DATE,a.name,a.log_contract,a.info_1
,c.status stat_cont,c.date_close date_close_cont
,c.account acc_rko,(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
,c.type_doc
--,c.*
from tmp_tables.TMP_GDM_90901 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
-- ������ �������� 90901
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
and c.account is not null and c.account not like '421%'
and not exists(select null from tmp_tables.tmp_gdm_k2 where refer_contract=c.reference and branch_contract=c.branch)
and instr(nvl(a.info_1,'#'),'DEL')=0
--and a.code='90901810601090000143'
    
    )
    loop
        if rec.sum_acc_k2=0 and rec.last_ledger='01.01.1900' and rec.sal=0 and nCnt<=10000 then
            update tmp_tables.TMP_GDM_90901 set info_1='DEL'
                where reference=rec.reference and branch=rec.branch;
            commit;
            nCnt:=nCnt+1;
        end if;
    end loop;
end;
/

select count(*) from tmp_tables.TMP_GDM_90901 where instr(nvl(info_1,'#'),'DEL')>0

-- �������� � ���������� ������ ��������� + ������ ��������
select * from tmp_tables.TMP_GDM_vc
where value in (select code from tmp_tables.TMP_GDM_90901 where instr(info_1,'DEL')>0)
and not exists (select null from contracts where (reference,branch) in (select contract,branch_contract from tmp_tables.TMP_GDM_90901 where instr(info_1,'DEL')>0))
and not exists (select null from contracts where (refer_client,branch_client) in (select client,branch_client from tmp_tables.TMP_GDM_90901 where instr(info_1,'DEL')>0))

