select --d.reference||','
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS,
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2,
        (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
        (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
        doc.SUMMA sumK2,doc.xSUMMAcredit xsumK2,
        p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
        doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
        doc.xsummacredit-p_k2.Get_Rest_K2(doc.reference, doc.branch) xostK2,
        p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => 191, pRefer_Contract => 29812115, pSumma => doc.summa, pCard_Type => 2) sum_related,
        p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,6582577340,631,trunc(sysdate)) spisK2_m,
        --p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
        doc.* 
        ,c.reference,c.branch
--UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
--,UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
--,d.*
--,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
----,d_3363.SumRelated(d.reference
----                  ,d.branch) sum_related
----, universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
from   v_documents           doc
       ,collector_contracts c
where  1 = 1
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
    and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810400000120861'))
    --and (c.reference,c.branch) = (select nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from account a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    and doc.branch = c.zbranch_docnum
    and doc.reference = c.docnum
    --and c.reference = 17795596 --17741941 --cpRefCont
    --and c.branch = 780 --cpBranchCont
    and c.name = 'CARDLIST_2'
    and c.summa in (0, 1)
    and rownum > 0
    and doc.status in (36)--, 38)
    and doc.status >= 30
    and doc.status < 1000
    --and d.status <= -30
    --and d.status > -1000
    --and substr(d.payers_account,6,3)<>'810'  
   and doc.reference=5228350918
   
select * from k2 where reference=5228350918


 
/ 
declare 
bResult boolean;
nDoc36 number;
 function f_stat_36to35(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pCntFind out number, pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
            select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from   v_documents           doc
            ,collector_contracts c
            where  1 = 1
            and c.reference=pRefCont and c.branch=pBrCont
            and doc.branch = c.zbranch_docnum
            and doc.reference = c.docnum
            and c.name = 'CARDLIST_2'
            and c.summa in (0, 1)
            and rownum > 0
            and doc.status in (36)
            and doc.status >= 30
            and doc.status < 1000
            and doc.payers_account=pAcc
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'  
            --and doc.reference=5228350918
            and doc.type_doc=226

    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
            --    nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) < rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;

            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)>0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
--            if rDoc.status = 36 then
--                delete from k2
--                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
--            end if;

            -- ��� ��� ��� ���������, 35 ��� 38 �������
            -- � �� ������ ����� � ���� ���
            insert into documents select * from archive where reference = rDoc.reference and branch = rDoc.branch;
            insert into variable_documents select * from variable_archive where reference = rDoc.reference and branch = rDoc.branch;
            delete archive where reference = rDoc.reference and branch = rDoc.branch;
            commit;

            update documents set status = 35
            where reference = rDoc.reference and branch = rDoc.branch;
            commit;
            
            if nvl(Universe.VARIABLE_PART(rDoc.reference,rDoc.branch,'CARD_ACCOUNT_WAIT',null),'0')<>'0' then
                update documents set status = 38
                where reference = rDoc.reference and branch = rDoc.branch;
                commit;
            end if;
            

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_36to35;
begin
    ptools2.short_init_user(1403); -- ��� �������
    bResult:=f_stat_36to35('40702810300810006220',15799841,191002,nDoc36,0);
    dbms_output.put_line('������� � �������� 36 �������: '||nvl(nDoc36,0)||' ����������.');
end;
/

15799841	191002	40702810300810006220


select * from contracts where account='40802810817550009763'

select * from k2 where --refer_contract=20218737 and 
reference in (5295103599,5295103734)

        select
        doc.summa sum,p_k2.Get_Rest_K2(doc.reference, doc.branch) spis,
         doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ost,
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account='40702810300810006220'  
            and status in (35,38) --and type_doc=2 
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,20218737,631,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa
            and reference in (5295103599,5295103734)    
