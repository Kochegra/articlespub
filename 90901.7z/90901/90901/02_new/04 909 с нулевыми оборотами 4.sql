update tmp_tables.TMP_GDM_90901 aa set info_1='DEL2'
--select * from tmp_tables.TMP_GDM_90901 aa where
where exists(
select null 
from tmp_tables.TMP_GDM_90901 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
and instr(nvl(a.info_1,'#'),'DEL')>0
and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0
and rownum<=10000
and a.reference=aa.reference and a.branch=aa.branch and a.code=aa.code)
and instr(nvl(aa.info_1,'#'),'DEL')>0
and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(aa.code), aa.code, substr(aa.code,6,3), sysdate)*pledger.WCOURSE(substr(aa.code,6,3), SysDate)=0
and rownum<=10000



select a.*
from tmp_tables.TMP_GDM_90901 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
and instr(nvl(a.info_1,'#'),'DEL2')>0
and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0
and instr(log_contract,'��������')=0

and rownum<=10000


delete from tmp_tables.TMP_GDM_90901 where instr(nvl(info_1,'#'),'DEL2')>0 and nvl(log_contract,'#')<>'#'