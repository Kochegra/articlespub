update tmp_tables.TMP_GDM_90901 set log_contract=null 

update tmp_tables.TMP_GDM_90902 a set info_1=null --log_contract
where instr(nvl(a.info_1,'#'),'DEL')>0

select count(*) from tmp_tables.TMP_GDM_90901 where instr(log_contract,'DEL')>0

select distinct status from tmp_tables.TMP_GDM_90901 

delete from tmp_tables.TMP_GDM_90902 where  instr(info_1,'DEL')>0

select rowid,a.* from tmp_tables.TMP_GDM_90901 a where code='90901810000011010027' --instr(info_1,'DEL')>0 and instr(log_contract,'��������')=0

select
-- �������
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo
--p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2, 
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--(select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2,
-- �������� ref/br ���������
--greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
--a.*
--a.status,
a.bal,a.code,to_char(a.open_date,'dd.mm.yyyy') open_date,to_char(A.CLOSE_DATE,'dd.mm.yyyy') CLOSE_DATE,a.name--,a.log_contract
--,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
,c.status stat_cont,to_char(c.date_close,'dd.mm.yyyy') date_close_cont
,c.account acc_rko,(select to_char(close_date,'dd.mm.yyyy') from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
--,(select open_date from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3)) open_date_909
,c.type_doc, universe.nametype(c.type_doc)
,a.subdepartment subdep,universe.namedepart(a.subdepartment ) subdep_name 
--,c.*
--from tmp_tables.TMP_GDM_90901 a, contracts c
from tmp_tables.TMP_GDM_90902 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
--c.reference=a.contract and c.branch=a.branch_contract
--and nvl(a.status,0) not in (103)
and instr(nvl(a.info_1,'#'),'DEL')>0
--and nvl(a.log_contract,'#')<>'#'
-- ������ �������� 90901
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
--and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
--and 
--and a.code in ('90902810310248020058')
--and (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate))=0
--and c.account is not null and substr(c.account,1,3) not in ('421') and substr(c.account,1,5) not in ('40506','40606','40706','40825') 
--and not exists(select null from TMP_TABLES.TMP_GDM_VC where value=a.code) --reference=a.contract and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_1')>0 and value=a.code)
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
--and not exists(select null from tmp_tables.tmp_gdm_k2 where refer_contract=c.reference and branch_contract=c.branch)
--and not exists(select null from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)
--and not exists (select null from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0)
--and exists(select null from contracts)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.BRANCH, c.REFERENCE, 'CARD_ACCOUNT_1'),'0')=a.code
--and a.code in ('90902978619000008398')
--and c.account='40703840010380000002'
--        and(
--            (COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
--                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY'))
--            )=to_date('01.01.1900','dd.mm.yyyy'))
--and c.type_doc=590

and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and open_date < to_date('01.11.2021','dd.mm.yyyy'))



-- �������� � �������� 1000
/
declare 
nCnt number :=0;
rAcc account%rowtype;
begin
    for rec in (
    
select
a.status,
-- �������
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate+7)) sal, -- saldo
--p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2, 
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--a.*
a.reference,a.branch,a.bal,a.code,a.open_date,A.CLOSE_DATE,a.name,a.log_contract,a.info_1
,c.status stat_cont,c.date_close date_close_cont
,c.account acc_rko,(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
,c.type_doc
--,c.*
--from tmp_tables.TMP_GDM_90901 a, contracts c
from tmp_tables.TMP_GDM_90902 a, contracts c
where 
c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
and open_date<to_date('01.01.2021','dd.mm.yyyy')
--and nvl(a.status,0)<100 -- not in (103)
and c.account is not null and substr(c.account,1,3) not in ('421') and substr(c.account,1,5) not in ('40506','40606','40706','40825')
--and (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate))=0
-- ������ �������� 90901
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
--and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
--and not exists(select null from tmp_tables.tmp_gdm_k2 where refer_contract=c.reference and branch_contract=c.branch)
and instr(nvl(a.info_1,'#'),'DEL')=0
--and 
--a.code in (
--'90901810205240000690'
--)
    
    )
    loop
--        -- �������� ������
        if nCnt>20000 then
            return;
        end if;

----        if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.code), cd => rec.code, cr=>substr(rec.code,6,3),account_rec => rAcc) then
            if --rec.sum_acc_k2=0 and 
----        to_date(rec.last_ledger,'dd.mm.yyyy')<to_date('01.01.2017','dd.mm.yyyy') and rec.sal=0 and nCnt<=10000 then  -- �� 90901
----            update tmp_tables.TMP_GDM_90901 set info_1='DEL'
----                where reference=rec.reference and branch=rec.branch;
----            commit;
----            nCnt:=nCnt+1;
----        end if;
            to_date(rec.last_ledger,'dd.mm.yyyy')<to_date('01.01.2021','dd.mm.yyyy') and rec.open_date<to_date('01.01.2021','dd.mm.yyyy') and rec.sal=0 and nCnt<20000 then  -- �� 90902
--                update tmp_tables.TMP_GDM_90901 set info_1='DEL'
                update tmp_tables.TMP_GDM_90902 set info_1='DEL'
                    where reference=rec.reference and branch=rec.branch;
                commit;
                nCnt:=nCnt+1;
            end if;
--        end if;

    --������������ ����
--                update tmp_tables.TMP_GDM_90901 set info_1=null
----                update tmp_tables.TMP_GDM_90902 set info_1=null
--                    where reference=rec.reference and branch=rec.branch;
--                commit;
    
    end loop;
end;
/


select count(*) from tmp_tables.TMP_GDM_90902 where instr(nvl(info_1,'#'),'DEL')>0

-- �������� � ���������� ������ ��������� + ������ ��������
select * from tmp_tables.TMP_GDM_vc
where value in (select code from tmp_tables.TMP_GDM_90901 where instr(nvl(info_1,'#'),'DEL')>0)
and not exists (select null from contracts where (reference,branch) in (select contract,branch_contract from tmp_tables.TMP_GDM_90901 where instr(nvl(info_1,'#'),'DEL')>0))
and not exists (select null from contracts where (refer_client,branch_client) in (select client,branch_client from tmp_tables.TMP_GDM_90901 where instr(nvl(info_1,'#'),'DEL')>0))

