-- ������ ��������� ����� (��� �������� ������). ������� � STATUS_ACCOUNT
-- 1 - ����������, 0 - �� ����������
-- ptools_account2.IsCodeTranzit(p_Account)
select ptools_account2.IsCodeTranzit('40702156300070002508') a1, ptools_account2.IsCodeTranzit('40702156600071002508') a2 from dual


/
-- �������
-- ��������� ��������
-- ������� �����������

--select 
--case ptools_account2.IsCodeTranzit(q.acc_rko)
--    when '1' then '����������' 
--    when '0' then ''
--    else '#'
--end transit,
--q.* from (
select 
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) saldo, -- �������
p_k2.get_Rest_K2_Acc(c.account) saldo_K2,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                    ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger, -- ���� ���������� �������
--(select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2, -- ���� ���������� �������
--case (select ptools_account2.IsCodeTranzit(account) from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) --            and ptools_account2.IsCodeTranzit(account)=1 
case ptools_account2.IsCodeTranzit(c.account) 
    when '1' then '����������' 
    when '0' then ''
    else '#'
end transit,
a.bal,a.code,a.currency,to_date(a.open_date,'dd.mm.yyyy') open_date,a.name,
greatest(nvl(a.contract,0),nvl(a.f_contract,0)) ref_cont,
greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0)) br_cont,
--a.*,
--(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
c.account acc_rko,
(select to_char(close_date,'dd.mm.yyyy') from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
--
--count(*)
--decode(nvl(a.contract,0),0,decode(nvl(a.f_contract,0),0,0,a.f_contract),a.contract) decode_conract, 
--nvl(coalesce(a.f_contract,a.contract),0) coalesce_contract,
--greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
--nvl2(a.f_contract,a.f_contract,a.contract) nvl2_contract,       
--rowid,a.*
from TMP_TABLES.TMP_GDM_90901 a, contracts c
where
greatest(nvl(a.contract,0),nvl(a.f_contract,0))=c.reference and greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))=c.branch
--(nvl(contract,0)!=0 or nvl(f_contract,0)!=0) -- �������� ��������� vers1 
and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
and ptools_account2.IsCodeTranzit(c.account)=1
--and exists(select null from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) 
--            and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
--            and ptools_account2.IsCodeTranzit(account)=1)
----exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
--and rownum<100
--and code in ('90901156600071002508','90901810704240005853','90901840100231020084','90901840900111020074','90901978100321500218','90901810809020840243')-- �������� � �����������
--and exists(select null from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) 
--            and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
--            and ptools_account2.IsCodeTranzit(account)=1)
--) q
union all
select 
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) saldo, -- �������
p_k2.get_Rest_K2_Acc(c.account) saldo_K2,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                    ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger, -- ���� ���������� �������
--(select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2, -- ���� ���������� �������
--case (select ptools_account2.IsCodeTranzit(account) from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) --            and ptools_account2.IsCodeTranzit(account)=1 
case ptools_account2.IsCodeTranzit(c.account) 
    when '1' then '����������' 
    when '0' then ''
    else '#'
end transit,
a.bal,a.code,a.currency,to_date(a.open_date,'dd.mm.yyyy') open_date,a.name,
greatest(nvl(a.contract,0),nvl(a.f_contract,0)) ref_cont,
greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0)) br_cont,
--a.*,
--(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
c.account acc_rko,
(select to_char(close_date,'dd.mm.yyyy') from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
--
--count(*)
--decode(nvl(a.contract,0),0,decode(nvl(a.f_contract,0),0,0,a.f_contract),a.contract) decode_conract, 
--nvl(coalesce(a.f_contract,a.contract),0) coalesce_contract,
--greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
--nvl2(a.f_contract,a.f_contract,a.contract) nvl2_contract,       
--rowid,a.*
from TMP_TABLES.TMP_GDM_90902 a, contracts c
where
greatest(nvl(a.contract,0),nvl(a.f_contract,0))=c.reference and greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))=c.branch
--(nvl(contract,0)!=0 or nvl(f_contract,0)!=0) -- �������� ��������� vers1 
and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
and ptools_account2.IsCodeTranzit(c.account)=1



/

with 
t_90902 as
(select 
    (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) saldo, -- �������
    (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                    and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                         ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger, -- ���� ���������� �������
    (select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2, -- ���� ���������� �������
    --case (select ptools_account2.IsCodeTranzit(account) from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) --            and ptools_account2.IsCodeTranzit(account)=1 
    --    when '1' then '����������' 
    --    when '0' then ''
    --    else '#'
    --end transit,
    greatest(nvl(a.contract,0),nvl(a.f_contract,0)) ref_cont,
    greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0)) br_cont,
    a.*,
    (select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
    from TMP_TABLES.TMP_GDM_90902 a
    where
    --(nvl(contract,0)!=0 or nvl(f_contract,0)!=0) -- �������� ��������� vers1 
    greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
    and exists(select null from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) 
                and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
                and ptools_account2.IsCodeTranzit(account)=1)
    --exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
)
select 
case ptools_account2.IsCodeTranzit(a.acc_rko)
    when '1' then '����������' 
    when '0' then ''
    else '#'
end transit,
a.* 
,(select close_date from account where  
from t_90902 a

/

(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko