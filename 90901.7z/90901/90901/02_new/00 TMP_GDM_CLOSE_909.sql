create table TMP_TABLES.TMP_GDM_CLOSE_909 as
    select * from TMP_TABLES.tmp_gdm_90901 a where instr(nvl(info_1,'#'),'DEL')>0 
    
/    

grant select,insert,update,delete on TMP_GDM_CLOSE_909 to MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_CLOSE_909 a where instr(log_contract,'03.12.2021')>0

select count(*) from TMP_TABLES.TMP_GDM_CLOSE_909 a 

/

insert into TMP_TABLES.TMP_GDM_CLOSE_909
select * from TMP_TABLES.tmp_gdm_90901_2 a where instr(nvl(info_1,'#'),'DEL')>0 and not exists(select null from TMP_TABLES.TMP_GDM_CLOSE_909 where code=a.code)


select rowid,a.* from TMP_TABLES.tmp_gdm_90901_2 a where  instr(nvl(info_1,'#'),'DEL')>0 --and instr(log_contract,'��������')=0


delete from tmp_tables.TMP_GDM_90901_2 where  instr(info_1,'DEL')>0