�� ��������

0. ��������� ���� � �������� ��������� � ���������� � �2 (not exists k2)
1. �������� � �������� �������� �� �2 (��� �� �����)
2. ��������� ������� ��������� (�1 �2 �3 �15)
3. �������� ����� �� ���������� 
4. �����������, ���������� �����, ��� ��� ���� ���������, ��������� ������ ��� ������.


-- 0. ���� �� ���� 
select d.* from documents d where status in (35,38) and not exists (select null from k2 where reference=d.reference and branch=d.branch)
and exists(select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and code=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)
order by status

-- 1.
select --refer_contract,branch_contract,account, account acc_rko
--(select status from v_documents where reference=a.reference and branch=a.branch) st,
--a.*
distinct refer_contract,branch_contract,account
from k2 a where nvl(what_is,0)=2
order by refer_contract

insert into TMP_TABLES.TMP_GDM_K2 (refer_contract,branch_contract,account)
    select distinct refer_contract,branch_contract,account from k2 a where nvl(what_is,0)=2 order by refer_contract

-- 2.
select * from TMP_TABLES.TMP_GDM_K2 order by refer_contract

update TMP_TABLES.TMP_GDM_K2 set status=0

select * from (select distinct refer_contract,branch_contract, count(*) cnt from TMP_TABLES.TMP_GDM_K2 where status>=0 group by refer_contract,branch_contract) where cnt>1

-- ��� �� 0 ���������
update TMP_TABLES.TMP_GDM_K2 set status=-1
--select 
--(select count(*) from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3)) acc_cnt,
--a.* from TMP_TABLES.TMP_GDM_K2 a 
where refer_contract=0 or branch_contract=0

-- ��� �� ������ ����� � ������ ��������
select rowid,
(select count(*) from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3) and close_date is null) acc_cnt_open,
(select count(*) from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3) and close_date is not null) acc_cnt_close,
a.* from TMP_TABLES.TMP_GDM_K2 a 
where status>=0
and exists(select null from (select distinct refer_contract,branch_contract, count(*) cnt from TMP_TABLES.TMP_GDM_K2 where status>=0 group by refer_contract,branch_contract) where cnt>1 and refer_contract=a.refer_contract and branch_contract=a.branch_contract)
order by refer_contract

select rowid,a.* from TMP_TABLES.TMP_GDM_K2 a 
where refer_contract in (33611,40319,95330,2252231,27395836,27411582,27461393,27508222) -- ����� ���������� ���
--account in ('40702810125050100530','40702810225050000530')

-- ������� acc_rko �� ���/�� ���������
select a.*,c.* --c.account u_acc 
from TMP_TABLES.TMP_GDM_K2 a
left join contracts c
on a.refer_contract=c.reference and a.branch_contract=c.branch
where a.status>=0
--and c.reference is null -- ����� ���������� ���
--and a.refer_contract=c.reference and a.branch_contract=c.branch

update TMP_TABLES.TMP_GDM_K2 a set acc_rko=(select account from contracts where reference=a.refer_contract and branch=a.branch_contract)
where a.status>=0 and acc_rko is null

/
-- ������� ������ �� ���������� ��������, � �������� � ������� ���������� �� ������ ������� ������ ������
select
a.* from TMP_TABLES.TMP_GDM_K2 a where status>=0
and account<>acc_rko

-- ������ 421 �����
--update TMP_TABLES.TMP_GDM_K2 set status=to_number(substr(coalesce(account,acc_rko),1,3))*-1/*-421*/
select a.* from TMP_TABLES.TMP_GDM_K2 a 
--where status>=0 and (acc_rko like '421%' or (account like '421%' and nvl(acc_rko,'0')='0')) -- -421
where status>=0 and nvl(acc_rko,'0')='0'

select a.* from TMP_TABLES.TMP_GDM_K2 a 
where status>=0 


select * from k2 where account in ('40702810100494011417','40702810000494011417')


-- 2.
--��� ������ ������� �������� ���������

/
declare 
rCont contracts%rowtype;
 procedure p_get_vc(pRef number,pBr number) as
  sK2 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK2v varchar2(2000);
  sK3v varchar2(2000);
  sK3v_3 varchar2(2000);
  sK15v varchar2(2000);
  sKOth varchar2(2000);
  sKAll varchar2(2000);
  nFl number;
 begin
    if Universe.get_contract_rec(rf => pRef, br => pBr, stat => null, acc => null, tp => null, contracts_rec => rCont) then
        if substr(rCont.account,6,3)='810' then
            sK2:=rCont.assist;
        end if; 
        for varCont in (select * from variable_contracts where reference=pRef and branch=pBr and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and instr(name,'OLD')=0 and substr(name,1,1)<>'_')
        loop
            nFl:=1;
            if substr(rCont.account,6,3)='810' then 
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            else
                -- �����
                if varCont.name='CARD_ACCOUNT_2' then
                    sK2:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_RUR' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                -- ������
                if varCont.name='CARD_ACCOUNT_2_'||substr(rCont.account,6,3) then
                    sK2v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_'||substr(rCont.account,6,3) then
                    sK3v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3v_3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15_'||substr(rCont.account,6,3) then
                    sK15v:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            end if;
            sKAll:=sKAll||'['||varCont.name||'='||varCont.value||']';
        end loop;
        
        update TMP_TABLES.TMP_GDM_K2 set k2=sK2,k3=sK3,k15=sK15,k2v=sK2v,k3v=sK3v,k3v_3=sK3v_3,k15v=sK15v,kOther=sKOth,kAll=sKAll
            where refer_contract=pRef and branch_contract=pBr;
        commit;
        
    end if;
 end p_get_vc;
begin
    for rec in (select a.* from TMP_TABLES.TMP_GDM_K2 a where status>=0 and refer_contract=28688)
    loop
        p_get_vc(rec.refer_contract,rec.branch_contract);
    end loop;
end;
/

select a.* from TMP_TABLES.TMP_GDM_K2 a where status>=0 and refer_contract=28688

--select a.* from TMP_TABLES.TMP_GDM_K2 a where status>=0
--and not exists(select null from contracts where reference=a.refer_contract and branch=a.branch_contract and substr(account,6,3)=currency)

select distinct name from TMP_TABLES.TMP_GDM_VC where name like 'CARD_ACCOUNT_15%'

select * from TMP_TABLES.TMP_GDM_VC where name = 'CARD_ACCOUNT_15' and substr(value,6,3)!='810'


-- 3. 
/
--update TMP_TABLES.TMP_GDM_K2 set status=0
select * from TMP_TABLES.TMP_GDM_K2 
where status=1

/
declare
 procedure p_get_doc(pRef number, pBr number) as
  sK2 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK3old varchar2(2000);
  sK15old varchar2(2000);
  sK3K15old varchar2(2000);
  sAccDoc varchar2(2000);
 begin
    for rec in (select --a.status,2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number,a.date_document
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
                    distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
                from documents a, k2
                where a.reference = k2.reference
                      and a.branch    = k2.branch
                      and k2.refer_contract     =pRef
                      and k2.branch_contract    = pBr
                      and k2.what_is = 2
                      and a.status in (35,38))
    loop
        if instr('#'||sAccDoc,rec.payers_account)=0 then
            sAccDoc:=sAccDoc||rec.payers_account||',';
        end if;

        if rec.status=38 and nvl(rec.card_accout,'0')<>'0' then
           if instr('#'||sK15,rec.card_account)=0 then
              sK15:=sK15||rec.card_account||',';
           end if;
           if instr('#'||sK2old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90902' then
              sK2old:=sK2old||rec.card_account_old||',';
           end if;
           if instr('#'||sK3old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90901' then
              sK3old:=sK3old||rec.card_account_old||',';
           end if;
        end if;
        if rec.status=35 and nvl(rec.card_accout,'0')<>'0' and  then
           if instr('#'||sK2,rec.card_account)=0 and substr(rec.card_account,1,5)='90902' then
              sK2:=sK2||rec.card_account||',';
           end if;
           if instr('#'||sK3,rec.card_account)=0 and substr(rec.card_account,1,5)='90901' then
              sK3:=sK3||rec.card_account||',';
           end if;
           if instr('#'||sK3K15old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90901' then
              sK3K15old:=sK3K15old||rec.card_account_old||',';
           end if;
           if instr('#'||sK2old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90902' then
              sK2old:=sK2old||rec.card_account_old||',';
           end if;
        end if;
    end loop;
 end p_get_doc;
begin
    for rec in (select a.* from TMP_TABLES.TMP_GDM_K2 a where status=0 and refer_contract=28688)
    loop
        p_get_doc(rec.refer_contract,rec.branch_contract);
    end loop;
end;
/

