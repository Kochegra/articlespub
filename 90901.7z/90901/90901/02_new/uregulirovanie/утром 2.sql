9438
556460
558276
558831
565045
565206
566205
566586
579051
579995
580966
1315474
8039523
8403399
15971686
22071845


select rowid,
(select count(*) from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3)) cnt,
a.* 
from tmp_tables.tmp_gdm_k2 a
where --status=1
--and 
refer_contract in 
(24094153,21983381,26491330,26492952,20230769,26479738)
--(1315474)--,15971634)
order by 1


select rowid,
--(select count(*) from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3)) cnt,
a.* 
from k2 a
where --status=1
--and 
refer_contract in 
(24094153,21983381,26491330,26492952,20230769,26479738)
--(1315474)--,15971634)
order by 1