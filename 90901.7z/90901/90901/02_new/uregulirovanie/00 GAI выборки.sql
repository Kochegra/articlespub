select a.* from tmp_tables.tmp_gdm_k2 a where status>-400 and status<0

select a.* from tmp_tables.tmp_gdm_90901 a

select a.* from tmp_tables.tmp_gdm_90902 a where contract=5019854 --code='90902810800917022088'

select a.* from tmp_tables.tmp_gdm_vc a where value='40702810900910001088'

select a.* from tmp_tables.tmp_gdm_close_909 a

select a.* from tmp_tables.tmp_gdm_k2 a
where exists(select null from tmp_tables.tmp_gdm_close_909 where contract=a.refer_contract and branch_contract=a.BRANCH_CONTRACT)
--where (refer_contract,branch_contract) in (select distinct contract,branch_contract from tmp_tables.tmp_gdm_close_909)
and status=1

-- ����� �� ���������� - ������ �������� � k2, �������� status=-10, ��� a.acc_rko<>a.account
select * from (
select distinct refer_contract,branch_contract, count(*) cnt 
from tmp_tables.tmp_gdm_k2
where status=1
group by refer_contract,branch_contract
) where cnt>1



select rowid,a.* from tmp_tables.tmp_gdm_k2 a
where a.status=1
--and nvl(a.k2,'0')='0' and nvl(a.k2assist,'0')<>'0' and substr(a.acc_rko,6,3)='810'
--and acc_rko is null
--and substr(acc_rko,6,3)='810'
--and instr (acc_doc,',')>0
--and a.acc_rko!=a.account
 


-- ������ = 103 ��������� � ��������������� ��������, ��� ������ �3 � ��� ������.
select 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null) acc_rko_cl,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) and close_date is null) k3_cl,
(select count(*) from tmp_tables.tmp_gdm_90901 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90901' and code<>a.k3) cnt90901,
(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k3) cnt90901_2,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k3), a.k3, substr(a.k3,6,3), sysdate)*pledger.WCOURSE(substr(a.k3,6,3), SysDate)) sal,
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k3) and code = a.k3 and currency = substr(a.k3,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
a.*,c.* 
from tmp_tables.tmp_gdm_k2 a, contracts c
where a.status=1
and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
and substr(acc_rko,6,3)='810'
--and a.acc_rko<>c.account -- ����� �� ������ ����
--and instr (acc_doc,',')>0
--and a.refer_contract in (28874)
and nvl(a.kother,'#')='#'
and a.k3=a.k3_doc and nvl(a.k2,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k2_doc,'0')='0' and nvl(a.k15_doc,'0')='0' and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
and a.acc_rko=c.account and a.acc_doc=c.account  
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) and close_date is null)
and rownum<=100

-- � ������� ��������� ��������� � ������ ���������
-- �������� tmp_tables.tmp_gdm_90901 ��� ���������� ������ � ����
/
declare 
bExec boolean;
nCnt number;
--rAcc909 account%rowtype;
--rAccRko account%rowtype;
begin
    for rec in (
    
        select /*+ PARALLEL(4) */
            (select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null) acc_rko_cl,
            (select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) and close_date is null) k3_cl,
            --(select count(*) from tmp_tables.tmp_gdm_90901 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90901' and code<>a.k3) cnt90901,
            --(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k3) cnt90901_2,
            (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k3), a.k3, substr(a.k3,6,3), sysdate)*pledger.WCOURSE(substr(a.k3,6,3), SysDate)) sal,
            -- ���� ��������� ��������
            (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k3) and code = a.k3 and currency = substr(a.k3,6,3) and rest_id = 0 
                                    and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                                        ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
            a.*,--c.*
            c.reference,c.branch,c.REFER_CLIENT,c.BRANCH_CLIENT,c.status status_cont,c.date_close, c.account account_cont
            from tmp_tables.tmp_gdm_k2 a, contracts c
            where a.status=1
            and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
            and substr(acc_rko,6,3)='810'
            --and instr (acc_doc,',')>0
            --and a.refer_contract in (28874)
            and nvl(a.kother,'#')='#'
            and a.k3=a.k3_doc and nvl(a.k2,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k2_doc,'0')='0' and nvl(a.k15_doc,'0')='0' and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
            and a.acc_rko=c.account and a.acc_doc=c.account  
            and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) and close_date is null)
            --and rownum<=100
    
    )
    loop
        bExec:=TRUE;
        -- ���������, ��� 90901 ������ 
        --if not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.k3), cd => rec.k3, cr=>substr(rec.k3,6,3),account_rec => rAcc909) then
            --bExec:=FALSE;
        --end if;
        --if rAcc909.close_date is not null then
            --bExec:=FALSE;
        --end if;
        -- ���������, ��� ���� ��� ������
        --if not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.k3), cd => rec.k3, cr=>substr(rec.k3,6,3),account_rec => rAccRko) then
            --bExec:=FALSE;
        --end if;
        --if rAccRko.close_date is not null then
            --bExec:=FALSE;
        --end if;
        -- ��������� ��������� ������ ���������
        select count(*) into nCnt from tmp_tables.tmp_gdm_vc where reference<>rec.REFER_CONTRACT and branch<>rec.BRANCH_CONTRACT and value=rec.k3;
        if bExec and nCnt>0 then
            bExec:=FALSE;
        end if; 
        -- ��������� ������� ������ 90901 � ������� ��������
        select count(*) into nCnt from tmp_tables.tmp_gdm_90901 where contract=rec.REFER_CONTRACT and branch_contract=rec.BRANCH_CONTRACT and bal='90901' and code<>rec.k3;
        if bExec and nCnt>0 then
            bExec:=FALSE;
        end if; 
        if bExec then
            update tmp_tables.tmp_gdm_k2 set status=103
                where refer_contract=rec.refer_contract and branch_contract=rec.branch_contract and status=1 and acc_rko=rec.acc_rko;
            commit;
        end if;
    end loop;
end;
/ 
select * from tmp_tables.tmp_gdm_k2 where status=103
/
-- �������� tmp_tables.tmp_gdm_90901 ��� ���������� ������ � ����
select a.* from tmp_tables.tmp_gdm_90901 a where status=103

update tmp_tables.tmp_gdm_90901 a set status=103
--select a.* from tmp_tables.tmp_gdm_90901 a
where exists(select * from tmp_tables.tmp_gdm_k2 where status=103 and k3=a.code)
and nvl(a.status,0)<>103
/



-- ������ = 102 ��������� � ��������������� ��������, ��� ������ �3 � ��� ������.
select 
PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null) acc_rko_cl,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null) k3_cl,
--(select count(*) from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2) cnt90902,
--(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2) cnt90902_2,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k2), a.k2, substr(a.k2,6,3), sysdate)*pledger.WCOURSE(substr(a.k2,6,3), SysDate)) sal,
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k2) and code = a.k2 and currency = substr(a.k2,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
a.*,c.* 
from tmp_tables.tmp_gdm_k2 a, contracts c
where a.status=1
and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
and substr(acc_rko,6,3)='810'
--and a.acc_rko<>c.account -- ����� �� ������ ����
--and instr (acc_doc,',')>0
and a.refer_contract in (17713539)
-- 3 ��������
--and nvl(a.kother,'#')='#'
        --and instr(a.kother,'CARD_ACCOUNT_2_810')>0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810')
        --3
        and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2')
--and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0
--
and a.k2=a.k2assist
and a.k2=a.k2_doc and nvl(a.k3,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k3_doc,'0')='0' and nvl(a.k15_doc,'0')='0' --and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
and a.acc_rko=c.account and a.acc_doc=c.account  
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null)
        -- ��� �������
        --and exists(select null from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2)
        --and not exists(select null from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2)
--and rownum<=100


/
declare 
bExec boolean;
nCnt number;
--rAcc909 account%rowtype;
--rAccRko account%rowtype;
begin
    for rec in (
    
        select /*+ PARALLEL(4) */
            --PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
            --PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
            --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null) acc_rko_cl,
            --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null) k2_cl,
            --(select count(*) from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2) cnt90902,
            --(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2) cnt90902_2,
            --(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k2), a.k2, substr(a.k2,6,3), sysdate)*pledger.WCOURSE(substr(a.k2,6,3), SysDate)) sal,
            -- ���� ��������� ��������
            --(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k2) and code = a.k2 and currency = substr(a.k2,6,3) and rest_id = 0 
            --                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
            --                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
            a.*,--c.*
            c.reference,c.branch,c.REFER_CLIENT,c.BRANCH_CLIENT,c.status status_cont,c.date_close, c.account account_cont 
        from tmp_tables.tmp_gdm_k2 a, contracts c
        where a.status=1
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        and substr(acc_rko,6,3)='810'
        --and a.acc_rko<>c.account -- ����� �� ������ ����
        --and instr (acc_doc,',')>0
        --and a.refer_contract in (28874)
        -- 3 ��������
        --1
        --and nvl(a.kother,'#')='#'
        --2
        --and instr(a.kother,'CARD_ACCOUNT_2_810')>0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810')
        --3
        and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2')
        --
        and a.k2=a.k2assist
        and a.k2=a.k2_doc and nvl(a.k3,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k3_doc,'0')='0' and nvl(a.k15_doc,'0')='0' --and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
        and a.acc_rko=c.account and a.acc_doc=c.account  
        --and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null)
        --and rownum<=100
    
    )
    loop
        bExec:=TRUE;
        -- ���������, ��� 90901 ������ 
        --if not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.k3), cd => rec.k3, cr=>substr(rec.k3,6,3),account_rec => rAcc909) then
            --bExec:=FALSE;
        --end if;
        --if rAcc909.close_date is not null then
            --bExec:=FALSE;
        --end if;
        -- ���������, ��� ���� ��� ������
        --if not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.k3), cd => rec.k3, cr=>substr(rec.k3,6,3),account_rec => rAccRko) then
            --bExec:=FALSE;
        --end if;
        --if rAccRko.close_date is not null then
            --bExec:=FALSE;
        --end if;
        -- ��������� ��������� ������ ���������
        select count(*) into nCnt from tmp_tables.tmp_gdm_vc where reference<>rec.REFER_CONTRACT and branch<>rec.BRANCH_CONTRACT and value=rec.k2;
        if bExec and nCnt>0 then
            bExec:=FALSE;
        end if; 
        -- ��������� ������� ������ 90902 � ������� ��������
        select count(*) into nCnt from tmp_tables.tmp_gdm_90902 where contract=rec.REFER_CONTRACT and branch_contract=rec.BRANCH_CONTRACT and bal='90902' and code<>rec.k2;
        if bExec and nCnt>0 then
            bExec:=FALSE;
        end if; 
        if bExec then
            update tmp_tables.tmp_gdm_k2 set status=102
                where refer_contract=rec.refer_contract and branch_contract=rec.branch_contract and status=1 and acc_rko=rec.acc_rko;
            commit;
        end if;
    end loop;
end;
/ 
select * from tmp_tables.tmp_gdm_k2 where status=102
/
-- �������� tmp_tables.tmp_gdm_90901 ��� ���������� ������ � ����
select a.* from tmp_tables.tmp_gdm_90902 a where status=102

update tmp_tables.tmp_gdm_90902 a set status=102
--select a.* from tmp_tables.tmp_gdm_90902 a
where exists(select null from tmp_tables.tmp_gdm_k2 b where status=102 and b.k2=a.code)
and nvl(a.status,0)<>102
/

-- ��������� ������ ����� ���������
update tmp_tables.tmp_gdm_k2 aa set status=102
where (aa.refer_contract,aa.branch_contract,aa.k2) in ( select a.refer_contract,a.branch_contract,a.k2 
--        select --count(*)
--            PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
--            PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
--            (select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null) acc_rko_cl,
--            (select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null) k2_cl,
--            --(select count(*) from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2) cnt90902,
--            --(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2) cnt90902_2,
--            (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k2), a.k2, substr(a.k2,6,3), sysdate)*pledger.WCOURSE(substr(a.k2,6,3), SysDate)) sal,
--            -- ���� ��������� ��������
--            (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k2) and code = a.k2 and currency = substr(a.k2,6,3) and rest_id = 0 
--                                    and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
--                                                        ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--            a.*,--c.*
--            c.reference,c.branch,c.REFER_CLIENT,c.BRANCH_CLIENT,c.status status_cont,c.date_close, c.account account_cont 
        from tmp_tables.tmp_gdm_k2 a, contracts c
        where a.status=1
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        and substr(acc_rko,6,3)='810'
        --and a.acc_rko<>c.account -- ����� �� ������ ����
        --and instr (acc_doc,',')>0
        -- 3 ��������
        --1
        --and nvl(a.kother,'#')='#'
        --2
        --and instr(a.kother,'CARD_ACCOUNT_2_810')>0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810')
        --3
        and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2')
        --
        and a.k2=a.k2assist
        and a.k2=a.k2_doc and nvl(a.k3,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k3_doc,'0')='0' and nvl(a.k15_doc,'0')='0' --and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
        and a.acc_rko=c.account and a.acc_doc=c.account  
        -- ��� �������
        and not exists(select null from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2)
        and not exists(select null from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2)
        -- ��� ��������
        and a.refer_contract in (20230769)
        --and rownum<=100
)  

 --- ���� ������� !!!!!!!!!!! ������������� � ��������� ����������



-- ������ = ??? ��������� � ��������������� ��������, ��� ������ �3 � ��� ������.
select 
--PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
--PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
--(select count(*) from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2) cnt90902,
--(select count(*) from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2) cnt90902_2,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k2), a.k2, substr(a.k2,6,3), sysdate)*pledger.WCOURSE(substr(a.k2,6,3), SysDate)) sal_k2,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.k3), a.k3, substr(a.k3,6,3), sysdate)*pledger.WCOURSE(substr(a.k3,6,3), SysDate)) sal_k3,
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2,
(select count(*) from k2 where refer_contract=a.refer_contract and branch_contract=a.branch_contract) cnt_k2, 
-- ���� ��������� ��������
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.k2) and code = a.k2 and currency = substr(a.k2,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
a.*,c.* 
from tmp_tables.tmp_gdm_k2 a, contracts c
where a.status=1
and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
and substr(acc_rko,6,3)='810'
and substr(a.k2,6,3)='810'
--and a.acc_rko<>c.account -- ����� �� ������ ����
--and instr (acc_doc,',')>0
and a.refer_contract in (29379)
-- 3 ��������
and nvl(a.kother,'#')='#'
--and instr(a.kother,'CARD_ACCOUNT_2_810')>0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2_810')
        --3
        --and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0 and regexp_count(a.kother,'=')=1 and a.k2=PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2') --and a.k2<>PTOOLS5.READ_PARAM(kother,'CARD_ACCOUNT_2')
--and instr(a.kother,'CARD_ACCOUNT_2')>0 and instr(a.kother,'CARD_ACCOUNT_2_810')=0
--
and a.k2=a.k2assist --and a.k2=nvl(a.k2_doc,a.k2) and a.k2=nvl(a.k2old_doc,a.k2)
--and a.k3=nvl(a.k3_doc,a.k3) and a.k3=nvl(a.k3old_doc,a.k3) 
and nvl(a.k2,'0')<>'0' and nvl(a.k3,'0')<>'0' and nvl(a.k15,'0')='0'
and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0'
--and a.acc_doc is not null and a.acc_doc=a.acc_rko 
--and not exists(select null from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) and close_date is null)
--and not exists(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null)
--and not exists(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) and close_date is null)
--and exists(select null from k2 where refer_contract=a.refer_contract and branch_contract=a.branch_contract)
--and c.status=60
--and a.k2=a.k2_doc and nvl(a.k3,'0')='0' and nvl(a.k15,'0')='0' and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0' and nvl(a.k3_doc,'0')='0' and nvl(a.k15_doc,'0')='0' --and nvl(a.k2old_doc,'0')='0' and nvl(a.k3old_doc,'0')='0'
--and a.acc_rko=c.account and a.acc_doc=c.account  
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) and close_date is null)
        -- ��� �������
        --and exists(select null from tmp_tables.tmp_gdm_90902 where contract=a.REFER_CONTRACT and branch_contract=a.BRANCH_CONTRACT and bal='90902' and code<>a.k2)
        --and not exists(select null from tmp_tables.tmp_gdm_vc where reference<>a.REFER_CONTRACT and branch<>a.BRANCH_CONTRACT and value=a.k2)
--and rownum<=100

select
rowid, 
(select status from v_documents where reference=a.reference and branch=a.branch) st,
a.* from k2 a 
--where refer_contract in (9363643,20385283,20385581,16934359,54444)
where (refer_contract,branch_contract) in (select refer_contract,branch_contract from tmp_tables.tmp_gdm_k2 where status=99)


update tmp_tables.tmp_gdm_k2 aa set status=100
where (aa.refer_contract,aa.branch_contract,aa.k2) in ( select a.refer_contract,a.branch_contract,a.k2 
        from tmp_tables.tmp_gdm_k2 a, contracts c
        where a.status=1
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        and substr(acc_rko,6,3)='810'
        and substr(a.k2,6,3)='810'
        and nvl(a.kother,'#')='#'
and a.k2=a.k2assist and a.k2=nvl(a.k2_doc,a.k2) and a.k2=nvl(a.k2old_doc,a.k2)
and a.k3=nvl(a.k3_doc,a.k3) and a.k3=nvl(a.k3old_doc,a.k3) 
and nvl(a.k2,'0')<>'0' and nvl(a.k3,'0')<>'0' and nvl(a.k15,'0')='0'
and nvl(a.k2v,'0')='0' and nvl(a.k3v,'0')='0' and nvl(a.k15v,'0')='0'
and a.acc_doc is not null and a.acc_doc=a.acc_rko 
)  

/ -- ���������� �� assista �������� 90902
declare
rCont contracts%rowtype;
begin
    for rec in (
    
            select /*+ PARALLEL(4) */ a.* from TMP_TABLES.TMP_GDM_K2 a where status=1 --and refer_contract in (17713539)
                and refer_contract in (16140518,17821449,17822290,17825279,17825324,17822525,18837374,17825215,17822289,17823540,17823848)

    ) loop
        if Universe.get_contract_rec(rf => rec.refer_contract, br => rec.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rCont) then
            UNIVERSE.INPUT_VAR_CONTR(rCont.branch, rCont.reference, '#GDM_ASSIST_CLOSE', rCont.assist);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            update contracts set assist=null,assist_currency=null where reference=rCont.reference and branch=rCont.branch and status=50 and date_close is null;
            commit;
        end if;
    end loop;
end;
/
select rowid,a.* from contracts a where (reference,branch) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_K2 a where status=1 and refer_contract in (16140518,17821449,17822290,17825279,17825324,17822525,18837374,17825215,17822289,17823540,17823848))

select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.value), a.value,substr(a.value,6,3), sysdate) saldo,
rowid,a.* from variable_contracts a where (reference,branch) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_K2 a where status=1 and refer_contract in (16140518,17821449,17822290,17825279,17825324,17822525,18837374,17825215,17822289,17823540,17823848))
and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)

/




















select rowid,a.* from k2 a where refer_contract=13336









select rowid,a.* 
--count(*) 
from tmp_tables.tmp_gdm_k2 a where refer_contract in (45537,422963) --status=0

select
(select assist from contracts where branch=a.BRANCH_contract and reference=a.REFER_contract) assist,
UNIVERSE.VARIABLE_CONTRACT(BRANCH_contract, REFER_contract, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(BRANCH_contract, REFER_contract, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(BRANCH_contract, REFER_contract, 'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
UNIVERSE.VARIABLE_CONTRACT(BRANCH_contract, REFER_contract, 'CARD_ACCOUNT_2_RUR') CARD_ACCOUNT_2_RUR,
a.* 
from tmp_tables.tmp_gdm_k2 a 
where status=1
--and substr(acc_rko,6,3)='810'
--and UNIVERSE.VARIABLE_CONTRACT(BRANCH_contract, REFER_contract, 'CARD_ACCOUNT_2_810') is not null 
and k2v is not null

select * from tmp_tables.tmp_gdm_vc where 
--name='CARD_ACCOUNT_2_RUR'
--name like 'CARD_ACCOUNT_15_%' and substr(value,6,3)='810'
name ='CARD_ACCOUNT_15' and substr(value,6,3)!='810'


select rowid,
--(select count(*) from tmp_tables.tmp_gdm_90901 where contract=a.refer_contract and branch_contract=a.branch_contract) t90901,
a.acc_rko,a.acc_doc,
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.k2), a.k2,substr(a.k2,6,3), sysdate) saldo,
a.* 
from tmp_tables.tmp_gdm_k2 
--as of timestamp (systimestamp - interval '20' minute)
a
where status=1
--and acc_rko<>nvl(acc_doc,'#') and nvl(acc_doc,'#')<>'#'
--and substr(a.acc_rko,6,3)!='810' and nvl(a.k2,'0')!='0' --and nvl(a.k2assist,'0')!='0'
and refer_contract=37327 

and nvl(k2,'0')=nvl(k2_doc,'0') and nvl(k3,'0')=nvl(k3_doc,'0') and nvl(k15,'0')=nvl(k15_doc,'0') and nvl(k2v,'0')=0  and nvl(k3v,'0')=0  and nvl(k15v,'0')=0 and nvl(k3v_3,'0')=0 

and k2v is not null

select substr(c.account,6,3),c.* from contracts c where (reference,branch) in (select refer_contract,branch_contract from tmp_tables.tmp_gdm_k2 a where status=1 and substr(acc_rko,6,3)='810' and nvl(k2,'0')='0' and nvl(k2assist,'0')<>'0')

select substr(c.account,6,3),c.* from contracts c where (reference,branch) in (select refer_contract,branch_contract from tmp_tables.tmp_gdm_k2 a where status=1 and substr(acc_rko,6,3)='810' and refer_contract=26827)

select * 
from variable_contracts
where (reference,branch) in (select 26827,341000 from dual)
and instr(name,'CARD_ACCOUNT')>0-- and instr(name,'#')=0 and instr(name,'OLD')=0 and substr(name,1,1)<>'_'

select * from account where header='C' and code='90902810700958020081'