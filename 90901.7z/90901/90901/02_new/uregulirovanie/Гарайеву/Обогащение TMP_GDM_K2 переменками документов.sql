declare
 procedure p_get_doc(pRef number, pBr number) as
  sK2 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK2old varchar2(2000);
  sK3old varchar2(2000);
  sAccDoc varchar2(2000);
 begin
    for rec in (select --a.status,2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number,a.date_document
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
                    distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
                        Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
                from documents a, k2
                where a.reference = k2.reference
                      and a.branch    = k2.branch
                      and k2.refer_contract     =pRef
                      and k2.branch_contract    = pBr
                      and k2.what_is = 2
                      and a.status in (35,38))
    loop
        if instr('#'||sAccDoc,rec.payers_account)=0 then
            sAccDoc:=sAccDoc||rec.payers_account||',';
        end if;

        if rec.status=38 --and nvl(rec.card_account_wait,'0')<>'0' 
        then
           if instr('#'||sK15,rec.card_account_wait)=0 and nvl(rec.card_account_wait,'0')<>'0' then
              sK15:=sK15||rec.card_account_wait||',';
           end if;
           if instr('#'||sK2,rec.card_account)=0 and substr(rec.card_account,1,5)='90902' and nvl(rec.card_account,'0')<>'0' then
              sK2:=sK2||rec.card_account||',';
           end if;
           if instr('#'||sK3,rec.card_account)=0 and substr(rec.card_account,1,5)='90901' and nvl(rec.card_account,'0')<>'0' then
              sK3:=sK3||rec.card_account||',';
           end if;
        end if;
        if rec.status=35 --and nvl(rec.card_account,'0')<>'0'  
        then
           if instr('#'||sK2,rec.card_account)=0 and substr(rec.card_account,1,5)='90902' and nvl(rec.card_account,'0')<>'0' then
              sK2:=sK2||rec.card_account||',';
           end if;
           if instr('#'||sK3,rec.card_account)=0 and substr(rec.card_account,1,5)='90901' and nvl(rec.card_account,'0')<>'0' then
              sK3:=sK3||rec.card_account||',';
           end if;
           if instr('#'||sK3old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90901' and nvl(rec.card_account_old,'0')<>'0' then
              sK3old:=sK3old||rec.card_account_old||',';
           end if;
           if instr('#'||sK2old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90902' and nvl(rec.card_account_old,'0')<>'0' then
              sK2old:=sK2old||rec.card_account_old||',';
           end if;
        end if;
    end loop;

    sK2:=substr(sK2,1,length(sK2)-1);
    sK3:=substr(sK3,1,length(sK3)-1);
    sK15:=substr(sK15,1,length(sK15)-1);
    sK2old:=substr(sK2old,1,length(sK2old)-1);
    sK3old:=substr(sK3old,1,length(sK3old)-1);
    sAccDoc:=substr(sAccDoc,1,length(sAccDoc)-1);

    update TMP_TABLES.TMP_GDM_K2 set k2_doc=sK2, k3_doc=sK3, k15_doc=sK15, k3old_doc=sK3old, k2old_doc=sK2old, acc_doc=sAccDoc, status=1
        where refer_contract=pRef and branch_contract=pBr;
    commit;

 end p_get_doc;
begin
    for rec in (select /*+ PARALLEL(4) */ a.* from TMP_TABLES.TMP_GDM_K2 a where status=0 /*and refer_contract=22160474*/)
    loop
        p_get_doc(rec.refer_contract,rec.branch_contract);
    end loop;
end;
/
