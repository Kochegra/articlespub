declare 
rCont contracts%rowtype;
 procedure p_get_vc(pRef number,pBr number) as
  sK2 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK2v varchar2(2000);
  sK3v varchar2(2000);
  sK3v_3 varchar2(2000);
  sK15v varchar2(2000);
  sKOth varchar2(2000);
  sKAll varchar2(2000);
  nFl number;
 begin
    if Universe.get_contract_rec(rf => pRef, br => pBr, stat => null, acc => null, tp => null, contracts_rec => rCont) then
        if substr(rCont.account,6,3)='810' then
            sK2:=rCont.assist;
        end if; 
        for varCont in (select * from variable_contracts where reference=pRef and branch=pBr and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and instr(name,'OLD')=0 and substr(name,1,1)<>'_')
        loop
            nFl:=1;
            if substr(rCont.account,6,3)='810' then 
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            else
                -- �����
                if varCont.name='CARD_ACCOUNT_2' then
                    sK2:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_RUR' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                -- ������
                if varCont.name='CARD_ACCOUNT_2_'||substr(rCont.account,6,3) then
                    sK2v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_'||substr(rCont.account,6,3) then
                    sK3v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3v_3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15_'||substr(rCont.account,6,3) then
                    sK15v:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            end if;
            sKAll:=sKAll||'['||varCont.name||'='||varCont.value||']';
        end loop;
        
        update TMP_TABLES.TMP_GDM_K2 set k2=sK2,k3=sK3,k15=sK15,k2v=sK2v,k3v=sK3v,k3v_3=sK3v_3,k15v=sK15v,kOther=sKOth,kAll=sKAll
            where refer_contract=pRef and branch_contract=pBr;
        commit;
        
    end if;
 end p_get_vc;
begin
    for rec in (select a.* from TMP_TABLES.TMP_GDM_K2 a where status>=0 and refer_contract=28688)
    loop
        p_get_vc(rec.refer_contract,rec.branch_contract);
    end loop;
end;
/