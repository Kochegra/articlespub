select rowid,a.* from tmp_tables.tmp_gdm_k2 a where status=1

--k2assist='90902840800000003890'
refer_contract in (
21977942
)

select rowid,a.* from tmp_tables.tmp_gdm_90902 a where contract in (21977942)

select 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3)) cl,
rowid,
            (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal,
            -- ���� ��������� ��������
            (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                                    and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                                        ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--a.* from tmp_tables.tmp_gdm_90902 a where 
a.* from tmp_tables.tmp_gdm_90901 a where 
--contract in (17713539)--,21983381,26491330,26492952,20230769,26479738)
--client=114644916
--and 
code in ('90901810601881500001','90901810901881500002')
order by contract

select a.* from tmp_tables.tmp_gdm_vc a where value='90902810010090002617'

90902978100910001088
90902840500910001088
90902810800917022088
90902356900910001088
90902376100910001088



select * from contracts where --refer_client=101764906 and type_doc=94
reference in (20290793,20293987) and branch=631

--and 
account=
'40702810411020000141'
--'40702840200910001088' --
----'40702840500911001088'
--'40702978800910001088'
--'40702978100911001088'


select 
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal,
rowid,a.* from account a where header=paccount.HEADER_ACCOUNT(a.code) and currency=substr(a.code,6,3)
and a.code in ('90902978029060000188','90902810529060008188')