select --d.reference||','
a.code,
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT,
--PLEDGER.SALDO (paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null)), UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null),substr(UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null),6,3), sysdate) saldo_909,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null)), UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null), substr(UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null),6,3), sysdate)
                *pledger.WCOURSE(substr(UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null),6,3), SysDate)) saldo_909, -- ������� 909
universe.variable_part(d.reference,d.branch, 'CARD_ACCOUNT1') CARD_ACCOUNT1,
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS,
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'MULTIK2',null) MULTIK2,
(select count(*) from k2 where reference=d.reference and branch=d.branch) cnt_k2,
(select count(*) from k2_multi where reference=d.reference and branch=d.branch) cnt_k2m,
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(d.payers_account), d.payers_account,substr(d.payers_account,6,3), sysdate) saldo,
(-PLEDGER.SALDO(paccount.HEADER_ACCOUNT(d.payers_account), d.payers_account, substr(d.payers_account,6,3), sysdate)*pledger.WCOURSE(substr(d.payers_account,6,3), SysDate)) kurs, -- �������
(-PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) kurs, -- �������
summa,xsummacredit,
p_k2.Get_Rest_K2(d.reference, d.branch) spisK2,
d.summa-p_k2.Get_Rest_K2(d.reference, d.branch) ostK2,
p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => d.summa, pCard_Type => 2) sum_related, -- ��� �������� ��������� �������
p_k2.get_Rest_K2_Acc(d.payers_account, sysdate) get_Rest_K2_Acc,
p_k2.Get_Rest_K2_multi(d.reference, d.branch,null,null,sysdate) Get_Rest_K2_multi,
P_K2.GET_K2_INFO(d.payers_account,0) GET_K2_INFO, -- 0-�2, 1-�1 
P_K2.GET_CARTOTEQUE_NUMBER(d.reference,d.branch) GET_CARTOTEQUE_NUMBER,
d.*
--,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
--,d_3363.SumRelated(d.reference
--                  ,d.branch) sum_related
--, universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
from   documents d, account a
where  1 = 1
    and a.code=d.payers_account and a.header=paccount.HEADER_ACCOUNT(d.payers_account) and a.currency=substr(d.payers_account,6,3)
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810900000004791'))
    --and (c.reference,c.branch) = (select nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from account a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    and d.payers_account='40702810900000002188'
    --and d.status in (22)    
    --and d.status in (30)
    and d.status in (35,38)
    --and substr(d.payers_account,6,3)<>'810'

    and nvl(universe.variable_part(d.reference,d.branch, 'CARD_ACCOUNT1'),'0')<>'0' 
    
    
select * from journal where docnum=6701342669 and branch=191     