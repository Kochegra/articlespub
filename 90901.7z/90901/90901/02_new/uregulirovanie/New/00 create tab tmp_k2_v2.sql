create table TMP_TABLES.TMP_GDM_K2 as
    select refer_contract,branch_contract,account, account acc_rko
        from mbank.k2 a where nvl(what_is,0)=2 and account='40702810120060000654'
/    

grant select,insert,update,delete on TMP_GDM_K2 to MBANK

/

delete from TMP_TABLES.TMP_GDM_K2
  
select rowid,a.* from TMP_TABLES.TMP_GDM_k2 a

/

alter table TMP_GDM_K2_v2
    add (--status  number
--         k2Assist varchar2(2000)
--         k2 varchar2(2000),
         k1_acc varchar2(2000)
--         k3 varchar2(2000),
--         k15 varchar2(2000),
--         k2v varchar2(2000),
--         k3v varchar2(2000),
--           k3v_3 varchar2(2000)
--         k15v varchar2(2000),
--         kOther varchar2(2000),
--         kAll varchar2(2000),
--        k2_doc varchar2(2000),
--        k3_doc varchar2(2000),
--        k15_doc varchar2(2000),
--        k3k15old_doc  varchar2(2000),
        --k3old_doc  varchar2(2000)
--        log varchar2(2000)
--        k2old_doc varchar2(2000),
--        acc_doc varchar2(2000)
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --vc_k2_810        VARCHAR2(4000 BYTE),--
         --vc_k3_810        VARCHAR2(4000 BYTE),
         --vc_k15_810         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
        )
/        



create table TMP_TABLES.TMP_GDM_K2_v2 as
    select refer_contract,branch_contract,acc_rko,k2assist,k2 k2_acc,k2 k2_2,k2 k2_810,k3 k3_acc,k15 k15_acc,k2v k2v_acc,k3v k3v_acc,k3 k3v_3,k15v k15v_acc,kOther,kALL,k2_doc,k2old_doc,k3_doc,k3old_doc,k15_doc,status,log
        from TMP_TABLES.TMP_GDM_K2 a where acc_rko='40702840800390000106'
/
grant select,insert,update,delete on TMP_GDM_K2_v2 to MBANK

/

delete from TMP_TABLES.TMP_GDM_K2_v2
  
select rowid,a.* from TMP_TABLES.TMP_GDM_k2_v2 a


--- �������� ��� �������

create table TMP_TABLES.TMP_GDM_909_tmp as
select info_1 IMP,bal,code from TMP_TABLES.TMP_GDM_90901 a where code='90901810000001024421'


alter table TMP_GDM_909_tmp
    add (status  number,
--         k2Assist varchar2(2000)
--         k2 varchar2(2000),
--         k3 varchar2(2000),
--         k15 varchar2(2000),
--         k2v varchar2(2000),
--         k3v varchar2(2000),
--           k3v_3 varchar2(2000)
--         k15v varchar2(2000),
--         kOther varchar2(2000),
--         kAll varchar2(2000),
--        k2_doc varchar2(2000),
--        k3_doc varchar2(2000),
--        k15_doc varchar2(2000),
--        k3k15old_doc  varchar2(2000),
        --k3old_doc  varchar2(2000)
        log varchar2(2000)
--        k2old_doc varchar2(2000),
--        acc_doc varchar2(2000)
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --vc_k2_810        VARCHAR2(4000 BYTE),--
         --vc_k3_810        VARCHAR2(4000 BYTE),
         --vc_k15_810         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
        )
        
grant select,insert,update,delete on TMP_GDM_909_tmp to MBANK

select * from TMP_TABLES.TMP_GDM_909_tmp
        

