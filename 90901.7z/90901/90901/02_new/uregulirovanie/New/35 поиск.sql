select 
d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,
p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => d.summa, pCard_Type => 2) sum_related,
d.* from documents d
where type_doc in (226) and status in (35,38)
and exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)
and d.summa=p_k2.Get_Rest_K2(d.Reference, d.Branch)
and d.payers_account='40702810000330002305'

and reference in (6637522895,2670231675,2670231831,2670231849,1397495546,6795359272,2750711219,3800570530,5193603663,5199546386,3768801384,5202795999,2509798796,3187846121,6184954025,6184954063,6184954099,5193602457,5193602960,2964527993,2519358631,5917797442,6628619485)


/
declare 
begin
   for rec in (

select 
'ALL_DOC_35' metod,d.summa, d.XSUMMACREDIT, p_k2.Get_Rest_K2(d.Reference, d.Branch) f_Get_Rest_K2,d.reference,d.branch,d.status,d.date_value,d.PAYERS_ACCOUNT,
d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,
p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => d.summa, pCard_Type => 2) sum_related
--d.* 
from documents d
where type_doc in (226) and status in (35,38)
and exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)
and d.summa=p_k2.Get_Rest_K2(d.Reference, d.Branch)
--and d.payers_account='40703810901980000020'
and not exists(select null from tmp_tables.tmp_gdm_d35_d36 where metod='ALL_DOC_35' and reference=d.reference and branch=d.branch)
and rownum<=10
   
--       select 'ALL_DOC_35' metod,d.summa, d.XSUMMACREDIT, p_k2.Get_Rest_K2(d.Reference, d.Branch) f_Get_Rest_K2,d.reference,d.branch,d.status,d.date_value,d.PAYERS_ACCOUNT 
--       from v_documents d
--       --where date_work >= trunc (SYSDATE, 'Y') -- 2021 ���
--       where date_work between to_date('01.01.2020','dd.mm.yyyy') and  to_date('31.12.2020','dd.mm.yyyy') -- 
--       and type_doc=226 and status=36
--       and exists (select null from v_documents where related=d.reference and branch=d.branch and type_doc in (3317,8275)) -- AND (status >= 30 AND d.status < 1000))
   
   )loop
        --if rec.summa<>p_k2.Get_Rest_K2(rec.Reference, rec.Branch) then
            insert into tmp_tables.tmp_gdm_d35_d36(metod,summa,XSUMMACREDIT,f_Get_Rest_K2,reference,branch,status,date_value,PAYERS_ACCOUNT)
                values(rec.metod,rec.summa, rec.XSUMMACREDIT, rec.f_Get_Rest_K2,rec.reference,rec.branch,rec.status,rec.date_value,rec.PAYERS_ACCOUNT);
            commit;
        --end if;
   end loop;
end;
/

select * from TMP_TABLES.TMP_GDM_d35_d36 where nvl(no_upd,0)=0 and metod='ALL_DOC_35'

-- ����� 
with d_find as (select distinct reference,branch from TMP_TABLES.TMP_GDM_d35_d36 where nvl(no_upd,0)=10 and  metod='ALL_DOC_35'),
d36 as (
        select a.*,d.type_doc,d.status,d.date_value,d.payers_account,d.payers_currency,d.summa,d.xsummacredit,p_k2.Get_Rest_K2(d.Reference, d.Branch) spis,d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,p_k2.get_Rest_K2_Acc(d.payers_account) saldo_K2
        from d_find a, v_documents d
        where a.reference=d.reference and a.branch=d.branch
        )
select d.*,
(select close_date from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_CLOSE_DATE
,(select contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_ref_CONT
,(select branch_contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_br_CONT
,(select type_doc from contracts where account=d.payers_account and status=50 and type_doc in (94,590)) RKO_type_CONT
--select reference||'/'||branch from contracts where account=d.payers_account and status=50 /*and type_doc in (94,590)*/) RKO_CONT 
--,(select sum(summa_cancel*100) from MBANK.INKP_WAIT_STAGING_DET i where doc_reference=d.reference and doc_branch=d.branch and acc_poruch=d.payers_account) sum_apz
from d36 d --,account acc where acc.header=paccount.HEADER_ACCOUNT(d.payers_account) and ACC.CODE=d.payers_account and currency=substr(d.payers_account,6,3)
where exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)  
--and d.payers_account='40702810408510000460'      
--and substr(d.payers_account,1,5) not in ('40702','40802','40703')  
--and not exists(select null from contracts where account=d.payers_account and status=50 and type_doc in (94,590))    
--and d.status=36
--and d.spis<>0
and d.reference in (6813680267,6836526790)