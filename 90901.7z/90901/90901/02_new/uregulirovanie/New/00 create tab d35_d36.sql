create table TMP_TABLES.TMP_GDM_d35_d36 as
       select 'ALL_DOC_36' metod,d.summa, d.XSUMMACREDIT, mbank.p_k2.Get_Rest_K2(d.Reference, d.Branch) f_Get_Rest_K2,d.reference,d.branch,d.status,d.date_value,d.PAYERS_ACCOUNT 
       from mbank.v_documents d
       where date_work >= trunc (SYSDATE, 'Y')
       and d.reference=5738093901
       and type_doc=226 and status=36
       and exists (select null from mbank.v_documents where related=d.reference and branch=d.branch and type_doc in (3317,8275)) -- AND (status >= 30 AND d.status < 1000))



/    

grant select,insert,update,delete on TMP_TABLES.TMP_GDM_d35_d36 to MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_d35_d36 a

delete from TMP_TABLES.TMP_GDM_d35_d36

/

alter table TMP_TABLES.TMP_GDM_d35_d36
    add (--f_contract        number,
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --var_card_acc_1        VARCHAR2(4000 BYTE),--
         --var_card_acc_15        VARCHAR2(4000 BYTE),
         --var_card_acc_2         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
         --status number
         --RKO_close number
         NO_UPD number
        )
/        
