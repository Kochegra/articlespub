        select 
        (select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
        a.*,--c.*
        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
        where a.status>=1000 and a.status<10000 
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        --and a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)--787) 
        --and a.refer_contract in (486,1277,1485,1616,2766,2768,3081,3086,3174,3313,3425,4954,5127,5646,5744,5780,5797,5806,5875,5900)

/
declare
bResult boolean;
rContRko contracts%rowtype;
rAccRko account%rowtype;
bExec boolean;
sErr varchar2(2000);
nDoc36 number;
nDoc35 number;
 function f_stat_36to35(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pRefDoc number,pBrDoc number,pCntFind out number, pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
--    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
            select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from   v_documents           doc
            ,collector_contracts c
            where  1 = 1
            and c.reference=pRefCont and c.branch=pBrCont
            and doc.branch = c.zbranch_docnum
            and doc.reference = c.docnum
            and c.name = 'CARDLIST_2'
            and c.summa in (0, 1)
            and rownum > 0
            and doc.status in (36)
            and doc.status >= 30
            and doc.status < 1000
            and doc.payers_account=pAcc
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'  
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'ROLLBACKTOEMITENT',null),'0')='0'
            and doc.reference=pRefDoc and doc.branch=pBrDoc
            and doc.type_doc=226

    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
            --    nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) < rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;

            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)>0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
--            if rDoc.status = 36 then
--                delete from k2
--                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
--            end if;

            -- ��� ��� ��� ���������, 35 ��� 38 �������
            -- � �� ������ ����� � ���� ���
            insert into documents select * from archive where reference = rDoc.reference and branch = rDoc.branch;
            insert into variable_documents select * from variable_archive where reference = rDoc.reference and branch = rDoc.branch;
            delete archive where reference = rDoc.reference and branch = rDoc.branch;
            commit;

            update documents set status = 35
            where reference = rDoc.reference and branch = rDoc.branch;
            commit;
            
            if nvl(Universe.VARIABLE_PART(rDoc.reference,rDoc.branch,'CARD_ACCOUNT_WAIT',null),'0')<>'0' then
                update documents set status = 38
                where reference = rDoc.reference and branch = rDoc.branch;
                commit;
            end if;
            

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            if sRes='UPD' then
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
            end if;
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            if sRes='UPD' then
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
            end if;
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_36to35;
 
 function f_stat_35to36(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pCntFind out number,pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
        select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account=pAcc  
            and status in (35,38) --and type_doc=2 
            and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,pRefCont,pBrCont,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit) -- �� ����� ��� ��������
            --and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => doc.summa, pCard_Type => 2)=0 --���������
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
            and doc.type_doc=226 
    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
                --nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;
            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)=0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
            if rDoc.status = 38 then
                delete from k2
                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
            end if;

            update documents set status = 36
            where reference = rDoc.reference and branch = rDoc.branch;
        
            commit;

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_35to36; 
begin
    for rec in (
    
with d_find as (select distinct reference,branch from TMP_TABLES.TMP_GDM_d35_d36 where nvl(no_upd,0)=0),
d36 as (
        select a.*,d.type_doc,d.status,d.date_value,d.payers_account,d.payers_currency,d.summa,d.xsummacredit,p_k2.Get_Rest_K2(d.Reference, d.Branch) spis,d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,p_k2.get_Rest_K2_Acc(d.payers_account) saldo_K2
        from d_find a, v_documents d
        where a.reference=d.reference and a.branch=d.branch
        )
select d.*,
(select close_date from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_CLOSE_DATE 
,(select contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_ref_CONT
,(select branch_contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_br_CONT
from d36 d --,account acc where acc.header=paccount.HEADER_ACCOUNT(d.payers_account) and ACC.CODE=d.payers_account and currency=substr(d.payers_account,6,3)
where exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)  
--and d.payers_account='40702810408510000460'      
--and d.status=36
and d.spis<>0
--and d.reference in (32087612,42783252,2520967603,2702200968,2900409575,2900409850,2901850838,2901850847,3024160905)
--and d.reference in (3087205711,3270278315,3362920211,3393473111,3516714250,3526878233,3550710698,3638835598,3762626323,3816978873,3816979045,3816979352,3816989254,3840105550,3842218682,3994503061,3994503097,3994503106,3994503145,4374112972,4374112989,4374122846,4374123539,4374123604,
--4374126045,4374130451,4374130540,4374130732,4374130747,4374134992,4374156884,4374172554,4374179750,4374182910,4374207439,4374238514)
--and d.reference in (4374241653,4374309724,4374317924,4374334451,4374340401,4374409980,4374410009,4506278259,4525812344,4525835009,4525861992,4525864588,4525864601,4525864632,4525868049,4525881157,4525883780,4525901134,4525908615,4525910811,4525910819,4525916119,4525927353,4525934093,
--4525956380,4525959935,4525962821,4525962861,4525970869,4526004468,4526011684,4526020061,4526025415,4528406173,4528406176,4531815668,4531830756,5058136773,5058136811,5069255968,5190754755,5191044087,5191048783,5193978420,5194006106,5194007727,5194074032,5199619386,5202770380,5202779457,
--5202779503,5202780627,5202781108,5202798689,5202821847,5208260704,5228093600,5228093611,5228122517,5228122536,5228174589,5228233690,5228285411,5228285458,5228334039,5232494066,5232688940,5232688950,5232688960,5232688964,5257587650,5270425619,5270425628,5270425643,5270425778,5270426406,5270426413,
--5270426994,5270428771,5277384643,5277435465,5277435650,5278465689,5279294529,5282513008,5289288961,5295590962,5298778056,5298778068,5308658417,5334103847,5344429337,5366492614,5366494888,5388890197,5455927261,5455931641,5461888842,5461895225,5550339488)
--and d.reference in (5551176263,5553758809,5553758818,5554105966,5554107569,5570038499,5573573403,5578945621,5581372554,5583009773,5703641293,5741078029,5741078061,5743282813,5743282902,5743283395,5745025835,5745025859,5759353005,5759413631,5764468260,5788063790,5886199104,5886199131,5886584687,5977819087,5988750275,
--5994638347,6004490090,6009187339,6009187536,6054255468,6060784007,6063532486,6063533596,6063533681,6063540210,6063540269,6063544730,6064351562,6070496511,6070497024,6074630542,6077894222,6077990418,6077990465,6085634672,6085634693,6085635597,6085636227,6086103241,6086172942,6086417415,6086491683,
--6089379017,6089379024,6089379037,6089379052,6089810369,6089810396,6090016575,6090085245,6090085834,6090093449,6094412100,6101281437,6101724966,6101725131,6101739646,6101745013,6101745146,6101745196,6101746152,6101881780,6101882290,6101882816,6101891258,6101972834,6102121177,6102192066,6102193279,
--6102334976,6102401249,6102402345,6102402963,6102411487,6102433994,6102440402,6102440575,6103353932,6103355874,6103357343,6124763175,6124923664,6125098233,6125111280,6125169188,6125169374,6128080909,6131997331)
--and d.reference in (6142225203,6142327334,6143288321,6164445907,6164471482,6184970956,6184974727,6185352434,6185925544,6185925888,6209098535,6209107443,6258325757,6258364064,6258446496,6258480740,6258531923,6258540098,6272882154,6279631544,6279778148,6283067451,6283067665,6283703885,6304300778,6305098354,6305098709,
--6322710621,6322710661,6322711412,6341384546,6341482562,6341795594,6349574108,6349574209,6352724543,6352724554,6352724724,6352724822,6366940805,6384982403,6389693160,6395489526,6408457837,6411422158,6432425506,6432425549,6433847314,6436752563,6445449277,6445449948,6451182869,6451184014,6451675087,
--6466647384,6472398802,6472398992,6472406491,6472413743,6473053238,6473092385,6521680354,6533014817,6533015403,6539028051,6539030861,6539031286,6539032664,6539048250,6539048267,6539049317,6542774083,6560967249,6564450930,6567343589,6568012067,6571040033,6571040093,6571631336,6575216655,6615826009,
--6615839241,6627411302,6634801795,6634952312,6637516733,6637522895,6637925273,6637981076,6659555758,6675319504,6679047375,6682109618,6718877701,6718877987,6718878169,6727209164,6741932626,6795409792,6795410764)

    
    )loop
        bExec:=TRUE;
        sErr:=null;
        -- ������� �������
        if not Universe.get_contract_rec(rf => rec.rko_ref_cont, br => rec.rko_br_cont, stat => null, acc => null, tp => null, contracts_rec => rContRko) then
            bExec:=FALSE;
            --sErr:=sErr||'ERR1 �� ������ ��������! ';
            dbms_output.put_line(rec.payers_account||' ERR1 �� ������ ��������!');
        end if;
        if bExec and not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.payers_account), cd => rec.payers_account, cr=>substr(rec.payers_account,6,3),account_rec => rAccRko) then
            bExec:=FALSE;
            --sErr:=sErr||'ERR4 �� ������ ���� ���! ';
            dbms_output.put_line(rec.payers_account||' ERR4 �� ������ ���� ���!');
        end if;

        if bExec then
            
            bResult:=f_stat_36to35(rAccRko.code,rContRko.reference,rContRko.branch,rec.reference,rec.branch,nDoc36,1); -- �������� 36 �������� � ���������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � �����������
            
            --if not bResult then
            --    bExec:=FALSE;
            --    sErr:=sErr||'ERR7 ������ ���������� 36 TO 35! ';
            --end if;
            if bResult and nDoc36>0 then
                --bExec:=FALSE;
                --sErr:=sErr||'ERR7 ������� ���� � 36 � ���������� ���������('||nvl(nDoc36,0)||' ��.)! ';
                dbms_output.put_line('������� � �������� 36 �������: '||nvl(nDoc36,0)||' ����������.');
            end if;
        
--            bResult:=f_stat_35to36(rAccRko.code,rContRko.reference,rContRko.branch,nDoc35,0); -- �������� 35,38 �������� � �������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � ����������� 
            --if not bResult then
            --    bExec:=FALSE;
            --    sErr:=sErr||'ERR6 ������ ���������� 35 TO 36! ';
            --end if;
--            if bResult and nDoc35>0 then
--                --bExec:=FALSE;
--                sErr:=sErr||'ERR6 ������� ���� � 35 � �������� ���������('||nvl(nDoc35,0)||' ��.)! ';
--                --dbms_output.put_line('������� � �������� 35 �������: '||nvl(nDoc35,0)||' ����������.');
--            end if;
            dbms_output.put_line('36='||nvl(nDoc36,0)||' 35='||nvl(nDoc35,0));
        end if;

--        if nvl(sErr,'#')<>'#' then
--            update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
--            commit;
--        else
--            update TMP_TABLES.TMP_GDM_K2_v2 a set log=null where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
--            commit;
--        end if;
--        sErr:=null;
    end loop;

end;
/



6823054,
32087612,
42783252,
2520967603,
2702200968,
2900409575,
2900409850,
2901850838,
2901850847,
3024160905,
3087205711,
3270278315,
3362920211,
3393473111,
3516714250,
3526878233,
3550710698,
3638835598,
3762626323,
3816978873,
3816979045,
3816979352,
3816989254,
3840105550,
3842218682,
3994503061,
3994503097,
3994503106,
3994503145,
4374112972,
4374112989,
4374122846,
4374123539,
4374123604,
4374126045,
4374130451,
4374130540,
4374130732,
4374130747,
4374134992,
4374156884,
4374172554,
4374179750,
4374182910,
4374207439,
4374238514,
4374241653,
4374309724,
4374317924,
4374334451,
4374340401,
4374409980,
4374410009,
4506278259,
4525812344,
4525835009,
4525861992,
4525864588,
4525864601,
4525864632,
4525868049,
4525881157,
4525883780,
4525901134,
4525908615,
4525910811,
4525910819,
4525916119,
4525927353,
4525934093,
4525956380,
4525959935,
4525962821,
4525962861,
4525970869,
4526004468,
4526011684,
4526020061,
4526025415,
4528406173,
4528406176,
4531815668,
4531830756,
5058136773,
5058136811,
5069255968,
5190754755,
5191044087,
5191048783,
5193978420,
5194006106,
5194007727,
5194074032,
5199619386,
5202770380,
5202779457,
5202779503,
5202780627,
5202781108,
5202798689,
5202821847,
5208260704,
5228093600,
5228093611,
5228122517,
5228122536,
5228174589,
5228233690,
5228285411,
5228285458,
5228334039,
5232494066,
5232688940,
5232688950,
5232688960,
5232688964,
5257587650,
5270425619,
5270425628,
5270425643,
5270425778,
5270426406,
5270426413,
5270426994,
5270428771,
5277384643,
5277435465,
5277435650,
5278465689,
5279294529,
5282513008,
5289288961,
5295590962,
5298778056,
5298778068,
5308658417,
5334103847,
5344429337,
5366492614,
5366494888,
5388890197,
5455927261,
5455931641,
5461888842,
5461895225,
5550339488,
5551176263,
5553758809,
5553758818,
5554105966,
5554107569,
5570038499,
5573573403,
5578945621,
5581372554,
5583009773,
5703641293,
5741078029,
5741078061,
5743282813,
5743282902,
5743283395,
5745025835,
5745025859,
5759353005,
5759413631,
5764468260,
5788063790,
5886199104,
5886199131,
5886584687,
5977819087,
5988750275,
5994638347,
6004490090,
6009187339,
6009187536,
6054255468,
6060784007,
6063532486,
6063533596,
6063533681,
6063540210,
6063540269,
6063544730,
6064351562,
6070496511,
6070497024,
6074630542,
6077894222,
6077990418,
6077990465,
6085634672,
6085634693,
6085635597,
6085636227,
6086103241,
6086172942,
6086417415,
6086491683,
6089379017,
6089379024,
6089379037,
6089379052,
6089810369,
6089810396,
6090016575,
6090085245,
6090085834,
6090093449,
6094412100,
6101281437,
6101724966,
6101725131,
6101739646,
6101745013,
6101745146,
6101745196,
6101746152,
6101881780,
6101882290,
6101882816,
6101891258,
6101972834,
6102121177,
6102192066,
6102193279,
6102334976,
6102401249,
6102402345,
6102402963,
6102411487,
6102433994,
6102440402,
6102440575,
6103353932,
6103355874,
6103357343,
6124763175,
6124923664,
6125098233,
6125111280,
6125169188,
6125169374,
6128080909,
6131997331,
6142225203,
6142327334,
6143288321,
6164445907,
6164471482,
6184970956,
6184974727,
6185352434,
6185925544,
6185925888,
6209098535,
6209107443,
6258325757,
6258364064,
6258446496,
6258480740,
6258531923,
6258540098,
6272882154,
6279631544,
6279778148,
6283067451,
6283067665,
6283703885,
6304300778,
6305098354,
6305098709,
6322710621,
6322710661,
6322711412,
6341384546,
6341482562,
6341795594,
6349574108,
6349574209,
6352724543,
6352724554,
6352724724,
6352724822,
6366940805,
6384982403,
6389693160,
6395489526,
6408457837,
6411422158,
6432425506,
6432425549,
6433847314,
6436752563,
6445449277,
6445449948,
6451182869,
6451184014,
6451675087,
6466647384,
6472398802,
6472398992,
6472406491,
6472413743,
6473053238,
6473092385,
6521680354,
6533014817,
6533015403,
6539028051,
6539030861,
6539031286,
6539032664,
6539048250,
6539048267,
6539049317,
6542774083,
6560967249,
6564450930,
6567343589,
6568012067,
6571040033,
6571040093,
6571631336,
6575216655,
6615826009,
6615839241,
6627411302,
6634801795,
6634952312,
6637516733,
6637522895,
6637925273,
6637981076,
6659555758,
6675319504,
6679047375,
6682109618,
6718877701,
6718877987,
6718878169,
6727209164,
6741932626,
6795409792,
6795410764,
