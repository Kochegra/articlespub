declare
nRef number :=   7073096818  ;
nBr number :=191;
nRefRel number :=6054443965;
nBrRel number :=775;
dDt date := to_date('17.12.2020','dd.mm.yyyy');
sAcc909 account.code%type :='90902810716800000528';
rAcc account%rowtype;
st varchar2(2000);
begin
    for rec in (select * from documents where reference=nRef and branch=nBr)
    loop
        dDt:=rec.date_document;
        
        universe.INPUT_VAR_DOC(nBranch => rec.branch, nREFERENCE => rec.reference, cName => 'CARD_ACCOUNT', cValue => sAcc909);
        commit;
       
        UNIVERSE.Input_var_doc(rec.branch, rec.reference,'ACC_TYPE', '94');
        commit;
        
        UNIVERSE.Input_var_doc(rec.branch, rec.reference,'TO CATALOGUE2', '');
        commit;
        
        update documents set date_work=dDt,date_value=dDt,date_document=dDt,status=35 
        where reference=rec.reference and branch=rec.branch;
        commit; 

        update archive set refer_from=nRef,branch_from=nBr 
        where reference=nRefRel and branch=nBrREL;
        commit; 

        if universe.get_account_rec(paccount.HEADER_ACCOUNT(rec.payers_account), rec.payers_account, substr(rec.payers_account, 6, 3), rAcc) then
            st := universe.ADD_COLLECTOR(nBranch => rAcc.branch_contract, nReference => rAcc.contract, cName => 'CARDLIST_2', cCurrency => substr(rAcc.code, 6, 3), 
                    dwDate => dDt, nSumma => 1, cDocNum => rec.reference, cUser => rec.owner, nBranch_Docnum => rec.branch);
            commit;
        else
            dbms_output.put_line('�����');
        end if;

    end loop;
end;
/

select * from k2 where reference in (7073127449, 7073128180) 