select * --payers_account 
from v_documents 
where date_work >= trunc (SYSDATE, 'Q')
and type_doc=3317 and status=30




select d.summa,p_k2.Get_Rest_K2(d.Reference, d.Branch),d.* --payers_account 
from v_documents d
where date_work >= trunc (SYSDATE, 'Q')
and type_doc=226 and status=36
and exists (select null from v_documents where related=d.reference and branch=d.branch and type_doc in (3317,8275)) -- AND (status >= 30 AND d.status < 1000))
--and d.summa<>p_k2.Get_Rest_K2(d.Reference, d.Branch)


 AND (d.status >= 30 AND d.status < 1000)
 
/
declare 
begin
   for rec in (
   
       select 'ALL_DOC_36' metod,d.summa, d.XSUMMACREDIT, p_k2.Get_Rest_K2(d.Reference, d.Branch) f_Get_Rest_K2,d.reference,d.branch,d.status,d.date_value,d.PAYERS_ACCOUNT 
       from v_documents d
       --where date_work >= trunc (SYSDATE, 'Y') -- 2021 ���
       where date_work between to_date('01.01.2020','dd.mm.yyyy') and  to_date('31.12.2020','dd.mm.yyyy') -- 
       and type_doc=226 and status=36
       and exists (select null from v_documents where related=d.reference and branch=d.branch and type_doc in (3317,8275)) -- AND (status >= 30 AND d.status < 1000))
   
   )loop
        if rec.summa<>p_k2.Get_Rest_K2(rec.Reference, rec.Branch) then
            insert into tmp_tables.tmp_gdm_d35_d36(metod,summa,XSUMMACREDIT,f_Get_Rest_K2,reference,branch,status,date_value,PAYERS_ACCOUNT)
                values(rec.metod,rec.summa, rec.XSUMMACREDIT, rec.f_Get_Rest_K2,rec.reference,rec.branch,rec.status,rec.date_value,rec.PAYERS_ACCOUNT);
            commit;
        end if;
   end loop;
end;
/


/
-- ����� ����� ��������� ��� �������
declare 
begin
   for rec in (
   
    with apz
     as (select distinct d.doc_reference, d.doc_branch, d.summa_poruch
         from   inkp_wait_staging a, inkp_wait_staging_det d
         where      a.id = d.parent_id
                --and a.date_load >= trunc (SYSDATE, 'Y') -- 2021
                and a.date_load between to_date('01.01.2020','dd.mm.yyyy') and  to_date('31.12.2020','dd.mm.yyyy') --
                --and a.date_load >= trunc (SYSDATE, 'MM')
                and substr ( a.file_name, 1, 3) = 'APZ'
                and d.summa_poruch != 100 * d.summa_cancel
                --AND d.doc_reference  IS NOT NULL
                and exists
                      (select 1
                       from   v_docum dd
                       where  dd.reference = d.doc_reference and dd.branch = d.doc_branch and dd.status = 36)),
     --SELECT d.REFERENCE, d.branch, d.related, d.branch_related, d.type_doc, d.status, d.doc_number, d.date_create, d.date_work,d.payers_account, d.summa, d.memo,d.*
     --FROM v_docum d, apz WHERE d.reference = apz.doc_reference AND d.branch = apz.doc_branch
     --UNION all
     d
     as (select   apz.summa_poruch, sum (d.summa) summa_otz, d.related, d.branch_related
         from     v_docum d, apz
         where    d.related = apz.doc_reference and d.branch_related = apz.doc_branch and d.type_doc NOT IN (8275, 3317) and d.status>=30 and d.status<1000 --and apz.doc_reference=6466265994
         group by d.related, d.branch_related, apz.summa_poruch
         order by d.related)
select d.*
from   d
where      d.summa_poruch != d.summa_otz --��. 
--d.summa_poruch <= d.summa_otz  --14 �� (������ ��������� 198)
  AND  EXISTS (SELECT * FROM variable_documents vd WHERE vd.REFERENCE = d.related AND vd.branch = d.branch_related AND vd.NAME = 'DATE_ENDWORK'
                UNION ALL
                 SELECT * FROM variable_archive vd WHERE vd.REFERENCE = d.related AND vd.branch = d.branch_related AND vd.NAME = 'DATE_ENDWORK')   
   
   
   )loop
        if rec.summa<>p_k2.Get_Rest_K2(rec.Reference, rec.Branch) then
            insert into tmp_tables.tmp_gdm_d35_d36(metod,summa,f_Get_Rest_K2,reference,branch)
                values('APZ_YGN',rec.summa_PORUCH, rec.summa_otz,rec.related,rec.branch_related);
            commit;
        end if;
   end loop;
end;
/

--update TMP_TABLES.TMP_GDM_d35_d36 set no_upd=-1
select * from TMP_TABLES.TMP_GDM_d35_d36 
--where payers_account='40702810606300004698'
--where metod='ALL_DOC_36'
--where metod='APZ_YGN'
--where reference in (2194431560,2808085266,2883784107,2999244007,3025753776,3171325871,3200835731,3441407577,3781322616,3855282045,4375156428,4375156557,4506471774,4528399277,4528413990,5196440399,5276632206,5278917567,5283621135,5283621355,5763824027,6663528315)
--where reference in (5228107511,5228107914,5228107928,5228167162,5228291446,6109196869,6279610057,6352976190,6701003646,6701004230)
--where reference in (5595539209,6063534650,6063556389,6322778375)
--where reference in (6063759301,6063759442,6064340622,6142235713,6142235853,6142235973)



update TMP_TABLES.TMP_GDM_d35_d36 a set payers_account=(select distinct payers_account from v_documents where reference=a.reference and branch=a.branch)
where metod='APZ_YGN'

/
declare
begin
    for rec in (

        select a.*,d.* 
        from TMP_TABLES.TMP_GDM_d35_d36 a,v_documents d
        --where payers_account='40702810300430018355'
        --where metod='ALL_DOC_36'
        where a.metod='APZ_YGN'
        and a.reference=d.reference and a.branch=d.branch

    ) loop
        
        
    
    end loop;

end;
/


select rowid,aa.* from TMP_TABLES.TMP_GDM_d35_d36 aa where (reference,branch) in (
select reference,branch from (
select distinct reference,branch,count(*) cnt
from TMP_TABLES.TMP_GDM_d35_d36
where metod='APZ_YGN'
group by reference,branch
) where cnt>1)

select rowid,aa.* from TMP_TABLES.TMP_GDM_d35_d36 aa where (reference,branch) in (
select reference,branch from (
select distinct reference,branch,count(*) cnt
from TMP_TABLES.TMP_GDM_d35_d36
where metod='APZ_YGN'
group by reference,branch
) where cnt>1)


select
a.log,
(select count(*) from TMP_TABLES.TMP_GDM_d35_d36 where payers_account=a.acc_rko and metod='APZ_YGN') cnt_apz,
(select count(*) from TMP_TABLES.TMP_GDM_d35_d36 where payers_account=a.acc_rko and metod='ALL_DOC_36') cnt_all,
a.*,--c.*
c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
from tmp_tables.tmp_gdm_k2_v2 a, contracts c
where --a.status=0 --and a.status<100
--and 
a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch 
and instr(log,'ERR7')>0 


        --select distinct reference,branch,count(*)  cnt from ( 
 select a.*--,d.* 
        from TMP_TABLES.TMP_GDM_d35_d36 a,v_documents d
        --where payers_account='40702810300430018355'
        --where metod='ALL_DOC_36'
        where a.metod='APZ_YGN'
        and a.reference=d.reference and a.branch=d.branch
        --and a.reference=4374120386 
        --and d.status=35
        --) group by reference,branch

 select  d.*   from v_documents d     where d.reference=4374120386
        
 
-- ����� 
with d_find as (select distinct reference,branch from TMP_TABLES.TMP_GDM_d35_d36 where nvl(no_upd,0)=0),
d36 as (
        select a.*,d.type_doc,d.status,d.date_value,d.payers_account,d.payers_currency,d.summa,d.xsummacredit,p_k2.Get_Rest_K2(d.Reference, d.Branch) spis,d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,p_k2.get_Rest_K2_Acc(d.payers_account) saldo_K2
        from d_find a, v_documents d
        where a.reference=d.reference and a.branch=d.branch
        )
select d.*,
(select close_date from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_CLOSE_DATE
,(select contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_ref_CONT
,(select branch_contract from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3)) RKO_br_CONT
--select reference||'/'||branch from contracts where account=d.payers_account and status=50 /*and type_doc in (94,590)*/) RKO_CONT 
,(select sum(summa_cancel*100) from MBANK.INKP_WAIT_STAGING_DET i where doc_reference=d.reference and doc_branch=d.branch and acc_poruch=d.payers_account) sum_apz
from d36 d --,account acc where acc.header=paccount.HEADER_ACCOUNT(d.payers_account) and ACC.CODE=d.payers_account and currency=substr(d.payers_account,6,3)
where exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)  
--and d.payers_account='40702810408510000460'      
--and d.status=36
--and d.spis<>0
--and reference in (2194431560,2808085266,2883784107,2999244007,3025753776,3171325871,3200835731,3441407577,3781322616,3855282045,4375156428,4375156557,4506471774,4528399277,4528413990,5196440399,5276632206,5278917567,5283621135,5283621355,5763824027,6663528315)
and d.reference in 
(
6823054,
32087612,
42783252,
2520967603,
2702200968,
2900409575,
2900409850,
2901850838,
2901850847,
3024160905,
3087205711,
3270278315,
3362920211,
3393473111,
3516714250,
3526878233,
3550710698,
3638835598,
3762626323,
3816978873,
3816979045,
3816979352,
3816989254,
3840105550,
3842218682,
3994503061,
3994503097,
3994503106,
3994503145,
4374112972,
4374112989,
4374122846,
4374123539,
4374123604,
4374126045,
4374130451,
4374130540,
4374130732,
4374130747,
4374134992,
4374156884,
4374172554,
4374179750,
4374182910,
4374207439,
4374238514,
4374241653,
4374309724,
4374317924,
4374334451,
4374340401,
4374409980,
4374410009,
4506278259,
4525812344,
4525835009,
4525861992,
4525864588,
4525864601,
4525864632,
4525868049,
4525881157,
4525883780,
4525901134,
4525908615,
4525910811,
4525910819,
4525916119,
4525927353,
4525934093,
4525956380,
4525959935,
4525962821,
4525962861,
4525970869,
4526004468,
4526011684,
4526020061,
4526025415,
4528406173,
4528406176,
4531815668,
4531830756,
5058136773,
5058136811,
5069255968,
5190754755,
5191044087,
5191048783,
5193978420,
5194006106,
5194007727,
5194074032,
5199619386,
5202770380,
5202779457,
5202779503,
5202780627,
5202781108,
5202798689,
5202821847,
5208260704,
5228093600,
5228093611,
5228122517,
5228122536,
5228174589,
5228233690,
5228285411,
5228285458,
5228334039,
5232494066,
5232688940,
5232688950,
5232688960,
5232688964,
5257587650,
5270425619,
5270425628,
5270425643,
5270425778,
5270426406,
5270426413,
5270426994,
5270428771,
5277384643,
5277435465,
5277435650,
5278465689,
5279294529,
5282513008,
5289288961,
5295590962,
5298778056,
5298778068,
5308658417,
5334103847,
5344429337,
5366492614,
5366494888,
5388890197,
5455927261,
5455931641,
5461888842,
5461895225,
5550339488,
5551176263,
5553758809,
5553758818,
5554105966,
5554107569,
5570038499,
5573573403,
5578945621,
5581372554,
5583009773,
5703641293,
5741078029,
5741078061,
5743282813,
5743282902,
5743283395,
5745025835,
5745025859,
5759353005,
5759413631,
5764468260,
5788063790,
5886199104,
5886199131,
5886584687,
5977819087,
5988750275,
5994638347,
6004490090,
6009187339,
6009187536,
6054255468,
6060784007,
6063532486,
6063533596,
6063533681,
6063540210,
6063540269,
6063544730,
6064351562,
6070496511,
6070497024,
6074630542,
6077894222,
6077990418,
6077990465,
6085634672,
6085634693,
6085635597,
6085636227,
6086103241,
6086172942,
6086417415,
6086491683,
6089379017,
6089379024,
6089379037,
6089379052,
6089810369,
6089810396,
6090016575,
6090085245,
6090085834,
6090093449,
6094412100,
6101281437,
6101724966,
6101725131,
6101739646,
6101745013,
6101745146,
6101745196,
6101746152,
6101881780,
6101882290,
6101882816,
6101891258,
6101972834,
6102121177,
6102192066,
6102193279,
6102334976,
6102401249,
6102402345,
6102402963,
6102411487,
6102433994,
6102440402,
6102440575,
6103353932,
6103355874,
6103357343,
6124763175,
6124923664,
6125098233,
6125111280,
6125169188,
6125169374,
6128080909,
6131997331,
6142225203,
6142327334,
6143288321,
6164445907,
6164471482,
6184970956,
6184974727,
6185352434,
6185925544,
6185925888,
6209098535,
6209107443,
6258325757,
6258364064,
6258446496,
6258480740,
6258531923,
6258540098,
6272882154,
6279631544,
6279778148,
6283067451,
6283067665,
6283703885,
6304300778,
6305098354,
6305098709,
6322710621,
6322710661,
6322711412,
6341384546,
6341482562,
6341795594,
6349574108,
6349574209,
6352724543,
6352724554,
6352724724,
6352724822,
6366940805,
6384982403,
6389693160,
6395489526,
6408457837,
6411422158,
6432425506,
6432425549,
6433847314,
6436752563,
6445449277,
6445449948,
6451182869,
6451184014,
6451675087,
6466647384,
6472398802,
6472398992,
6472406491,
6472413743,
6473053238,
6473092385,
6521680354,
6533014817,
6533015403,
6539028051,
6539030861,
6539031286,
6539032664,
6539048250,
6539048267,
6539049317,
6542774083,
6560967249,
6564450930,
6567343589,
6568012067,
6571040033,
6571040093,
6571631336,
6575216655,
6615826009,
6615839241,
6627411302,
6634801795,
6634952312,
6637516733,
6637522895,
6637925273,
6637981076,
6659555758,
6675319504,
6679047375,
6682109618,
6718877701,
6718877987,
6718878169,
6727209164,
6741932626,
6795409792,
6795410764)



6823054,
32087612,
42783252,
2194431560,
2520967603,
2702200968,
2808085266,
2883784107,
2900409575,
2900409850,
2901850838,
2901850847,
2999244007,
3024160905,
3025753776,
3087205711,
3171325871,
3200835731,
3270278315,
3362920211,
3393473111,
3441407577,
3516714250,
3526878233,
3550710698,
3638835598,
3762626323,
3781322616,
3816978873,
3816979045,
3816979352,
3816989254,
3840105550,
3842218682,
3855282045,
3994503061,
3994503097,
3994503106,
3994503145,
4374112972,
4374112989,
4374122846,
4374123539,
4374123604,
4374126045,
4374130451,
4374130540,
4374130732,
4374130747,
4374134992,
4374156884,
4374172554,
4374179750,
4374182910,
4374207439,
4374238514,
4374241653,
4374309724,
4374317924,
4374334451,
4374340401,
4374409980,
4374410009,
4375156428,
4375156557,
4506278259,
4506471774,
4525812344,
4525835009,
4525861992,
4525864588,
4525864601,
4525864632,
4525868049,
4525881157,
4525883780,
4525901134,
4525908615,
4525910811,
4525910819,
4525916119,
4525927353,
4525934093,
4525956380,
4525959935,
4525962821,
4525962861,
4525970869,
4526004468,
4526011684,
4526020061,
4526025415,
4528399277,
4528406173,
4528406176,
4528413990,
4531815668,
4531830756,
5058136773,
5058136811,
5069255968,
5190754755,
5191044087,
5191048783,
5193978420,
5194006106,
5194007727,
5194074032,
5196440399,
5199619386,
5202770380,
5202779457,
5202779503,
5202780627,
5202781108,
5202798689,
5202821847,
5208260704,
5228093600,
5228093611,
5228107511,
5228107914,
5228107928,
5228122517,
5228122536,
5228167162,
5228174589,
5228233690,
5228285411,
5228285458,
5228291446,
5228334039,
5232494066,
5232688940,
5232688950,
5232688960,
5232688964,
5257587650,
5270425619,
5270425628,
5270425643,
5270425778,
5270426406,
5270426413,
5270426994,
5270428771,
5276632206,
5277384643,
5277435465,
5277435650,
5278465689,
5278917567,
5279294529,
5282513008,
5283621135,
5283621355,
5289288961,
5295590962,
5298778056,
5298778068,
5308658417,
5334103847,
5344429337,
5366492614,
5366494888,
5388890197,
5455927261,
5455931641,
5461888842,
5461895225,
5550339488,
5551176263,
5553758809,
5553758818,
5554105966,
5554107569,
5570038499,
5573573403,
5578945621,
5581372554,
5583009773,
5595539209,
5703641293,
5741078029,
5741078061,
5743282813,
5743282902,
5743283395,
5745025835,
5745025859,
5759353005,
5759413631,
5763824027,
5764468260,
5788063790,
5886199104,
5886199131,
5886584687,
5977819087,
5988750275,
5994638347,
6004490090,
6009187339,
6009187536,
6054255468,
6060784007,
6063532486,
6063533596,
6063533681,
6063534650,
6063540210,
6063540269,
6063544730,
6063556389,
6063759301,
6063759442,
6064340622,
6064351562,
6070496511,
6070497024,
6074630542,
6077894222,
6077990418,
6077990465,
6085634672,
6085634693,
6085635597,
6085636227,
6086103241,
6086172942,
6086417415,
6086491683,
6089379017,
6089379024,
6089379037,
6089379052,
6089810369,
6089810396,
6090016575,
6090085245,
6090085834,
6090093449,
6094412100,
6101281437,
6101724966,
6101725131,
6101739646,
6101745013,
6101745146,
6101745196,
6101746152,
6101881780,
6101882290,
6101882816,
6101891258,
6101972834,
6102121177,
6102192066,
6102193279,
6102334976,
6102401249,
6102402345,
6102402963,
6102411487,
6102433994,
6102440402,
6102440575,
6103353932,
6103355874,
6103357343,
6109196869,
6124763175,
6124923664,
6125098233,
6125111280,
6125169188,
6125169374,
6128080909,
6131997331,
6142225203,
6142235713,
6142235853,
6142235973,
6142327334,
6143288321,
6164445907,
6164471482,
6184970956,
6184974727,
6185352434,
6185925544,
6185925888,
6209098535,
6209107443,
6258325757,
6258364064,
6258446496,
6258480740,
6258531923,
6258540098,
6272882154,
6279610057,
6279631544,
6279778148,
6283067451,
6283067665,
6283703885,
6304300778,
6305098354,
6305098709,
6322710621,
6322710661,
6322711412,
6322778375,
6341384546,
6341482562,
6341795594,
6349574108,
6349574209,
6352724543,
6352724554,
6352724724,
6352724822,
6352976190,
6366940805,
6384982403,
6389693160,
6395489526,
6408457837,
6411422158,
6432425506,
6432425549,
6433847314,
6436752563,
6445449277,
6445449948,
6451182869,
6451184014,
6451675087,
6466647384,
6472398802,
6472398992,
6472406491,
6472413743,
6473053238,
6473092385,
6521680354,
6533014817,
6533015403,
6539028051,
6539030861,
6539031286,
6539032664,
6539048250,
6539048267,
6539049317,
6542774083,
6560967249,
6564450930,
6567343589,
6568012067,
6571040033,
6571040093,
6571631336,
6575216655,
6615826009,
6615839241,
6627411302,
6634801795,
6634952312,
6637516733,
6637522895,
6637925273,
6637981076,
6659555758,
6663528315,
6675319504,
6679047375,
6682109618,
6701003646,
6701004230,
6718877701,
6718877987,
6718878169,
6727209164,
6741932626,
6795409792,
6795410764
)


