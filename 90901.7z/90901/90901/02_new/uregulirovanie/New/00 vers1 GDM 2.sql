declare 
nStep number;
nSt number;
bExec boolean;
rContRko contracts%rowtype;
rAccRko account%rowtype;
rAcc909 account%rowtype;
--nSaldo number;
sErr varchar2(2000);
sResF varchar2(2000);
bResult boolean;
nDoc35 number;
nDoc36 number;
-- ��� ���������
sAccK2 account.code%type;
nCnt909 number;

 procedure p_get_vc(pRef number,pBr number) as
  rCont contracts%rowtype;
  sK2assist varchar2(2000);
  sK2 varchar2(2000);
  sK2_2 varchar2(2000); -- ������ ��� ������
  sK2_810 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK2v varchar2(2000);
  sK3v varchar2(2000);
  sK3v_3 varchar2(2000);
  sK15v varchar2(2000);
  sKOth varchar2(2000);
  sKAll varchar2(2000);
  nFl number;
  -- ������� k1
  sK1 varchar2(2000);
 begin
    if Universe.get_contract_rec(rf => pRef, br => pBr, stat => null, acc => null, tp => null, contracts_rec => rCont) then
        dbms_output.put_line(rCont.assist);
        sK2assist:=rCont.assist;
        if substr(rCont.account,6,3)='810' then
            sK2:=rCont.assist;
        end if; 
        dbms_output.put_line(sK2||' '||sK2assist);
        for varCont in (select * from variable_contracts where reference=pRef and branch=pBr and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and instr(name,'OLD')=0 and substr(name,1,1)<>'_')
        loop
            nFl:=1;
            if substr(rCont.account,6,3)='810' then 
                if varCont.name='CARD_ACCOUNT_2' then
                    sK2_2:=varCont.value; -- ������ ��� ������
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_2_810' then
                    sK2_810:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_1' then
                    sK1:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            else
                -- �����
                if varCont.name='CARD_ACCOUNT_2' then
                    sK2:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_2_810' then
                    sK2_810:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_RUR' then
                    sK3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15' then
                    sK15:=varCont.value;
                    nFl:=0;
                end if;
                -- ������
                if varCont.name='CARD_ACCOUNT_2_'||substr(rCont.account,6,3) then
                    sK2v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3_'||substr(rCont.account,6,3) then
                    sK3v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_3' then
                    sK3v_3:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_15_'||substr(rCont.account,6,3) then
                    sK15v:=varCont.value;
                    nFl:=0;
                end if;
                if varCont.name='CARD_ACCOUNT_1' then
                    sK1:=varCont.value;
                    nFl:=0;
                end if;
                if nFl=1 --not (varCont.name='CARD_ACCOUNT_3' or varCont.name='CARD_ACCOUNT_15') 
                then
                    sKOth:=sKOth||'['||varCont.name||'='||varCont.value||']';
                end if; 
            end if;
            sKAll:=sKAll||'['||varCont.name||'='||varCont.value||']';
        end loop;
        
        update TMP_TABLES.TMP_GDM_K2_v2 a set a.k2assist=sK2assist,a.k2_acc=sK2,a.k2_2=sK2_2,a.k2_810=sK2_810,a.k3_acc=sK3,a.k15_acc=sK15,a.k2v_acc=sK2v,a.k3v_acc=sK3v,a.k3v_3=sK3v_3,a.k15v_acc=sK15v,a.kOther=sKOth,a.kAll=sKAll,a.k1_acc=sK1,a.status=1
            where a.refer_contract=pRef and a.branch_contract=pBr;
        commit;
        
    end if;
 end p_get_vc;
 procedure p_get_doc(pRef number, pBr number) as
  sK2 varchar2(2000);
  sK3 varchar2(2000);
  sK15 varchar2(2000);
  sK2old varchar2(2000);
  sK3old varchar2(2000);
  sAccDoc varchar2(2000);
 begin
    for rec in (select --a.status,2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number,a.date_document
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
                    --,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
                    distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
                        Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
                from documents a, k2
                where a.reference = k2.reference
                      and a.branch    = k2.branch
                      and k2.refer_contract     =pRef
                      and k2.branch_contract    = pBr
                      and k2.what_is = 2
                      and a.status in (35,38))
    loop
        if instr('#'||sAccDoc,rec.payers_account)=0 then
            sAccDoc:=sAccDoc||rec.payers_account||',';
        end if;

        if rec.status=38 --and nvl(rec.card_account_wait,'0')<>'0' 
        then
           if instr('#'||sK15,rec.card_account_wait)=0 and nvl(rec.card_account_wait,'0')<>'0' then
              sK15:=sK15||rec.card_account_wait||',';
           end if;
           if instr('#'||sK2,rec.card_account)=0 and substr(rec.card_account,1,5)='90902' and nvl(rec.card_account,'0')<>'0' then
              sK2:=sK2||rec.card_account||',';
           end if;
           if instr('#'||sK3,rec.card_account)=0 and substr(rec.card_account,1,5)='90901' and nvl(rec.card_account,'0')<>'0' then
              sK3:=sK3||rec.card_account||',';
           end if;
        end if;
        if rec.status=35 --and nvl(rec.card_account,'0')<>'0'  
        then
           if instr('#'||sK2,rec.card_account)=0 and substr(rec.card_account,1,5)='90902' and nvl(rec.card_account,'0')<>'0' then
              sK2:=sK2||rec.card_account||',';
           end if;
           if instr('#'||sK3,rec.card_account)=0 and substr(rec.card_account,1,5)='90901' and nvl(rec.card_account,'0')<>'0' then
              sK3:=sK3||rec.card_account||',';
           end if;
           if instr('#'||sK3old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90901' and nvl(rec.card_account_old,'0')<>'0' then
              sK3old:=sK3old||rec.card_account_old||',';
           end if;
           if instr('#'||sK2old,rec.card_account_old)=0 and substr(rec.card_account_old,1,5)='90902' and nvl(rec.card_account_old,'0')<>'0' then
              sK2old:=sK2old||rec.card_account_old||',';
           end if;
        end if;
    end loop;

    sK2:=substr(sK2,1,length(sK2)-1);
    sK3:=substr(sK3,1,length(sK3)-1);
    sK15:=substr(sK15,1,length(sK15)-1);
    sK2old:=substr(sK2old,1,length(sK2old)-1);
    sK3old:=substr(sK3old,1,length(sK3old)-1);
    sAccDoc:=substr(sAccDoc,1,length(sAccDoc)-1);

    update TMP_TABLES.TMP_GDM_K2_v2 set k2_doc=sK2, k3_doc=sK3, k15_doc=sK15, k3old_doc=sK3old, k2old_doc=sK2old, acc_doc=sAccDoc, status=1
        where refer_contract=pRef and branch_contract=pBr;
    commit;
 end p_get_doc;
 
 function f_check_other_cont(pAcc account%rowtype,pCont contracts%rowtype) return number is
    nRes number;
    nCnt number;
 begin
    nRes:=0;
    if pAcc.bal='90902' then
        select count(*) into nCnt from contracts where assist=pAcc.code and not (reference=pCont.reference and branch=pCont.branch);
        nRes:=nRes+nCnt;
    end if;
    select count(*) into nCnt from tmp_tables.tmp_gdm_vc where value=pAcc.code and not (reference=pCont.reference and branch=pCont.branch);
    nRes:=nRes+nCnt;
    return nRes;
 end f_check_other_cont;
 function f_check_909(pAcc account%rowtype,pCont contracts%rowtype) return varchar2 is
    sRes varchar2(2000);
    nRes number;
    nSaldo number;
 begin
    if not (pAcc.contract=pCont.reference and pAcc.branch_contract=pCont.branch) then
        sRes:=sErr||'�� ��������� ��������.';
    end if;
    if pAcc.close_date is null then
        nSaldo:=PLEDGER.SALDO(paccount.HEADER_ACCOUNT(pAcc.code), pAcc.code, substr(pAcc.code,6,3), sysdate)*pledger.WCOURSE(substr(pAcc.code,6,3), SysDate);
        --if nSaldo<>0 then
            --sRes:=sRes||'�� ������ - ���� �������.';
        --end if;
    else
        sRes:=sRes||'���� '||pAcc.code||' ������! ';
    end if;
    -- ��������� ���������� ������ � �������� ???
    -- ��������� � ������ ���������
    nRes:=f_check_other_cont(pAcc,pCont);
    if nRes>0 then
        sRes:=sRes||'���� ���������� �� ������ ���������.';
    end if;
    return sRes;
 end f_check_909;

 function f_stat_36to35(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pCntFind out number, pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
            select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from   v_documents           doc
            ,collector_contracts c
            where  1 = 1
            and c.reference=pRefCont and c.branch=pBrCont
            and doc.branch = c.zbranch_docnum
            and doc.reference = c.docnum
            and c.name = 'CARDLIST_2'
            and c.summa in (0, 1)
            and rownum > 0
            and doc.status in (36)
            and doc.status >= 30
            and doc.status < 1000
            and doc.payers_account=pAcc
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'  
            and doc.type_doc=226
            --and doc.reference=5228350918

    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
            --    nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) < rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;

            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)>0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
--            if rDoc.status = 36 then
--                delete from k2
--                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
--            end if;

            -- ��� ��� ��� ���������, 35 ��� 38 �������
            -- � �� ������ ����� � ���� ���
            insert into documents select * from archive where reference = rDoc.reference and branch = rDoc.branch;
            insert into variable_documents select * from variable_archive where reference = rDoc.reference and branch = rDoc.branch;
            delete archive where reference = rDoc.reference and branch = rDoc.branch;
            commit;

            update documents set status = 35
            where reference = rDoc.reference and branch = rDoc.branch;
            commit;
            
            if nvl(Universe.VARIABLE_PART(rDoc.reference,rDoc.branch,'CARD_ACCOUNT_WAIT',null),'0')<>'0' then
                update documents set status = 38
                where reference = rDoc.reference and branch = rDoc.branch;
                commit;
            end if;
            

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_36to35;
 
 function f_stat_35to36(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pCntFind out number,pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
        select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account=pAcc  
            and status in (35,38) --and type_doc=2 
            and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,pRefCont,pBrCont,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit) -- �� ����� ��� ��������
            --and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => doc.summa, pCard_Type => 2)=0 --���������
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa  
            and doc.type_doc=226  
    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
                --nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;
            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)=0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
            if rDoc.status = 38 then
                delete from k2
                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
            end if;

            update documents set status = 36
            where reference = rDoc.reference and branch = rDoc.branch;
        
            commit;

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_35to36; 

 procedure p_ins_data(pRefCont number,pBrCont number) as
 begin
    -- ������ ���������
    delete from tmp_tables.tmp_gdm_909_tmp;
    commit;
    -- �������� ��� ����� �������� 90901 � 90902
    insert into tmp_tables.tmp_gdm_909_tmp(imp,bal,code)
    select 'ACC',bal,code from tmp_tables.tmp_gdm_90901 where contract=pRefCont and branch_contract=pBrCont;
    commit;
    insert into tmp_tables.tmp_gdm_909_tmp(imp,bal,code)
    select 'ACC',bal,code from tmp_tables.tmp_gdm_90902 where contract=pRefCont and branch_contract=pBrCont;
    commit;

 end p_ins_data;
begin
    ptools2.short_init_user(1403); -- ��� �������
    --nStep:=1;
    --nStep:=2;
    --nStep:=3;
    
    for recTmp in (
    
        select --/*+ PARALLEL(4) */ 
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
        a.*,--c.*
        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
        where a.status=0 --and a.status<100
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        and nvl(log,'#')<>'CHECK'
        and substr(a.acc_rko,6,3)<>'810'
        and rownum <=10000
        --and a.refer_contract not in (971,998,1005,1018,1021,1061,1072,1083,1086,1089) 
        --and a.refer_contract in (17810422)

    
    )loop

        update tmp_tables.tmp_gdm_k2_v2 set log=null where refer_contract=recTmp.refer_contract and branch_contract=recTmp.branch_contract;
        commit;

        -- ��������� tmp_tables.tmp_gdm_k2_v2
        for rec in (select 
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
                        a.*,--c.*
                        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
                        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
                        where a.status>=recTmp.status
                        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
                        and a.refer_contract=recTmp.refer_contract and a.branch_contract=recTmp.branch_contract 
)
        loop
            p_get_vc(rec.refer_contract,rec.branch_contract); -- ��������� ������ ���������
            p_get_doc(rec.refer_contract,rec.branch_contract); -- ��������� ������ �� ���������� ���������
        end loop;

        -- �������� ������ �� �������� � �������
        for rec in (select 
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
                        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
                        a.*,--c.*
                        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
                        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
                        where a.status>=recTmp.status
                        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
                        and a.refer_contract=recTmp.refer_contract and a.branch_contract=recTmp.branch_contract 
)
        loop
            nSt:=0;
            bExec:=TRUE;
            sResF:=null;
            sErr:=null;

            -- ������� �������
            if not Universe.get_contract_rec(rf => rec.refer_contract, br => rec.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rContRko) then
                bExec:=FALSE;
                sErr:=sErr||'ERR1 �� ������ ��������! ';
            end if;
            if bExec and rContRko.account is null then
                bExec:=FALSE;
                sErr:=sErr||'ERR2 �� ������ ACCOUNT � ���������! ';
            end if;
            if bExec and rContRko.account is not null and (substr(rContRko.account,1,3) in ('421','420','301','302') or substr(rContRko.account,1,5) in ('40506','40606','40706','40825')) then  -- ����� �� ������ ����, �.�. �������� ��� ������������
                bExec:=FALSE;
                sErr:=sErr||'ERR3 ������ ����� �� �������� ��� ��������������! ';
            end if;
            if bExec and not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rContRko.account), cd => rContRko.account, cr=>substr(rContRko.account,6,3),account_rec => rAccRko) then
                bExec:=FALSE;
                sErr:=sErr||'ERR4 �� ������ ���� ���! ';
            end if;
            if bExec and rAccRko.close_date is not null then
                bExec:=FALSE;
                sErr:=sErr||'ERR5 ���� ��� ������! ';
            end if;

            if bExec then
                bResult:=f_stat_35to36(rAccRko.code,rContRko.reference,rContRko.branch,nDoc35,0); -- �������� 35,38 �������� � �������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � ����������� 
                if not bResult then
                    bExec:=FALSE;
                    sErr:=sErr||'ERR6 ������ ���������� 35 TO 36! ';
                end if;
                if bResult and nDoc35>0 then
                    bExec:=FALSE;
                    sErr:=sErr||'ERR6 ������� ���� � 35 � �������� ���������('||nvl(nDoc35,0)||' ��.)! ';
                    dbms_output.put_line('������� � �������� 35 �������: '||nvl(nDoc35,0)||' ����������.');
                end if;
            end if;

            if bExec then
                bResult:=f_stat_36to35(rAccRko.code,rContRko.reference,rContRko.branch,nDoc36,0); -- �������� 36 �������� � ���������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � �����������
                if not bResult then
                    bExec:=FALSE;
                    sErr:=sErr||'ERR7 ������ ���������� 36 TO 35! ';
                end if;
                if bResult and nDoc36>0 then
                    bExec:=FALSE;
                    sErr:=sErr||'ERR7 ������� ���� � 36 � ���������� ���������('||nvl(nDoc36,0)||' ��.)! ';
                    dbms_output.put_line('������� � �������� 36 �������: '||nvl(nDoc36,0)||' ����������.');
                end if;
            end if;

            -- ������ �����
            if bExec then
                if substr(rec.acc_rko,6,3)<>'810' then
                    sAccK2:=coalesce(rec.k2assist,rec.k2v_acc);
                    --dbms_output.put_line(sAccK2||'---');
                    -- ������� ������� 1 ���
                    if 1=1 and nvl(sAccK2,'#')<>'#' and nvl(rec.k2assist,sAccK2)=sAccK2 and nvl(rec.k2v_acc,sAccK2)=sAccK2 
                        and nvl(rec.k3v_acc,'#')='#' and nvl(rec.k3v_3,'#')='#' and nvl(rec.k15v_acc,'#')='#'
                        and nvl(rec.k2_acc,'#')='#' and nvl(rec.k2_2,'#')='#' and nvl(rec.k2_810,'#')='#' and nvl(rec.k3_acc,'#')='#' and nvl(rec.k15_acc,'#')='#'
                        and nvl(rec.kOther,'#')='#' and (nvl(rec.k2_doc,'#')='#' or nvl(rec.k2_doc,'#')=sAccK2) and (nvl(rec.acc_doc,'#')='#' or nvl(rec.acc_doc,'#')=rec.acc_rko) 
                        and substr(sAccK2,6,3)=substr(rec.acc_rko,6,3) and substr(sAccK2,6,3)<>'810'
                    then    
                        dbms_output.put_line('������� ������� 1');
                        -- ��������� ����
                        
                        if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(sAccK2), cd => sAccK2, cr=>substr(sAccK2,6,3),account_rec => rAcc909) then
                            sResF:=f_check_909(rAcc909,rContRko);
                            -- ��������� ���������� ������ 90902 � ��������
                            select count(*) into nCnt909 from (
                                select * from TMP_TABLES.TMP_GDM_90902 where contract=rContRko.reference and branch_contract=rContRko.branch and code<>rAcc909.code --and code<>rec.k1_acc
                                union all
                                select * from TMP_TABLES.TMP_GDM_90901 where contract=rContRko.reference and branch_contract=rContRko.branch /*and code<>rAcc909.code*/ and code<>rec.k1_acc
                            );
                            if nCnt909>0 then
                                sResF:=sResF||' CHECK_909 ������� ������ ����� 909 � ��������! ';
                                --bExec:=FALSE;
                            end if;
                            --
                            if sResF is not null then
                                sErr:=sErr||sResF;
                                bExec:=FALSE;
                            else
                                dbms_output.put_line('��������� ������� � ��������� ��������');
                                if nvl(rec.k2assist,'#')='#' then
                                    update contracts set assist=sAccK2,assist_currency=substr(sAccK2,6,3) where reference=rContRko.reference and branch=rContRko.branch and nvl(assist,'#')='#';
                                    commit; 
                                end if;
                                if nvl(rContRko.assist_currency,'#')<>substr(sAccK2,6,3) then
                                    update contracts set assist_currency=substr(sAccK2,6,3) where reference=rContRko.reference and branch=rContRko.branch and nvl(assist,'#')='#';
                                    commit; 
                                end if;
                                if nvl(rec.k2v_acc,'#')='#' then
                                    UNIVERSE.INPUT_VAR_CONTR(rContRko.branch, rContRko.reference, 'CARD_ACCOUNT_2_'||substr(sAccK2,6,3), rAcc909.code);
                                    commit;
                                end if;
                                p_get_vc(rec.refer_contract,rec.branch_contract); -- ��������� ������ ���������                            
                            end if;
                        else
                            sErr:=sErr||'ERR10 �� ������ '||sAccK2||'! ';
                            bExec:=FALSE;
                        end if;
                    else
                        bExec:=FALSE;
                        if nvl(rec.acc_doc,rec.acc_rko)<>rec.acc_rko then
                            sErr:=sErr||'ERR11 �������������� ����� ��� �� ������ ���������� ���������! ';
                        end if;
                    end if;

                    if nvl(sErr,'#')<>'#' then
                        update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
                        commit;
                    else
                        if bExec then
                            update TMP_TABLES.TMP_GDM_K2_v2 a set status=100 where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
                            commit;
                            nSt:=100;
                        end if;
                    end if;

                    if nSt<>100 and nvl(sErr,'#')='#' then
                        bExec:=TRUE;
                        sResF:=null;
                    end if;

                    -- ������� ������� � ������ �2
                    if nvl(rec.k2assist,'#')='#' and nvl(rec.k2v_acc,'#')='#' and nvl(rec.k3v_acc,'#')='#' and nvl(rec.k3v_3,'#')='#' and nvl(rec.k15v_acc,'#')='#' 
                        and nvl(rec.k3_acc,'#')='#' and nvl(rec.k15_acc,'#')='#' and nvl(rec.k2_2,'#')='#' and nvl(rec.k2_acc,'#')<>'#' and nvl(rec.k2_810,rec.k2_acc)=rec.k2_acc and nvl(rec.k2_2,rec.k2_acc)=rec.k2_acc and substr(rec.k2_acc,6,3)='810'
                        and nvl(rec.kOther,'#')='#' and nvl(rec.k2_doc,'#')='#' and nvl(rec.acc_doc,'#')='#' then
                        dbms_output.put_line('������� ������� 2');
                        select count(*) into nCnt909 from (
                            select * from TMP_TABLES.TMP_GDM_90902 where contract=rContRko.reference and branch_contract=rContRko.branch and code<>rec.k2_acc and code<>rec.k1_acc
                            union all
                            select * from TMP_TABLES.TMP_GDM_90901 where contract=rContRko.reference and branch_contract=rContRko.branch and code<>rec.k2_acc and code<>rec.k1_acc
                        );
                        if nCnt909>0 then
                            sErr:=sErr||' CHECK_909 ������� ������ ����� 909 � ��������! ';
                            bExec:=FALSE;
                        end if;
                    else
                        bExec:=FALSE;
                    end if;

                    if nvl(sErr,'#')<>'#' then
                        update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
                        commit;
                    else
                        if bExec then
                            if nvl(rec.k2_810,'#')='#' then
                                dbms_output.put_line('��������� ��������� ��������');
                                UNIVERSE.INPUT_VAR_CONTR(rContRko.branch, rContRko.reference, 'CARD_ACCOUNT_2_810', rec.k2_acc);
                                commit;
                                p_get_vc(rec.refer_contract,rec.branch_contract); -- ��������� ������ ���������
                            end if;                            

                            update TMP_TABLES.TMP_GDM_K2_v2 a set status=100 where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
                            commit;
                            nSt:=100;
                        end if;
                    end if;

                end if;
                -- �������� �������� �� ������ ��������
                -- p_ins_data(rContRko.reference,rContRko.branch);

                sErr:=null;

            else
                if nvl(sErr,'#')<>'#' then
                    update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
                    commit;
                end if;
                sErr:=null;
            end if;




        end loop;

--        sErr:='TST '||sErr;
--        if nvl(sErr,'#')<>'#' then
--            
--            update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=recTmp.refer_contract and branch_contract=recTmp.branch_contract;
--            commit;
--        end if;
    
    
      

    end loop;

end;
/

select rowid,a.* from tmp_tables.tmp_gdm_909_tmp a --where a.refer_contract in (29379)

        select 
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
        a.*,--c.*
        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
        where a.status>=0
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        --and a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)--787) 
        and a.refer_contract in (486,1277,1485,1616,2766,2768,3081,3086,3174,3313,3425,4954,5127,5646,5744,5780,5797,5806,5875,5900)


select * from account

select rowid,a.* from tmp_tables.tmp_gdm_k2_v2 a 
--where status=100 and k2assist is null
--where status=1 and k2assist is null and nvl(log,'#')<>'#'
--where status=100 and k2assist is not null
where status=1 and k2assist is not null and nvl(log,'#')<>'#'


select rowid,a.* from tmp_tables.tmp_gdm_k2_v2 a where a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)

select rowid,a.* from tmp_tables.tmp_gdm_k2 a where a.refer_contract in (29379) 

select * from contracts where assist='90902810900600000916'

select count(*) from tmp_tables.tmp_gdm_vc where value='90902810900600000916' and not (reference=29379 and branch=97);


select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
,a.date_document
--distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD, 
--            Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
from documents a, k2
  where a.reference = k2.reference
    and a.branch    = k2.branch
    --and k2.refer_contract     = 29379
    --and k2.branch_contract    = 97
    and (k2.refer_contract,k2.branch_contract) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    and k2.what_is = 2
    and a.status in (35,38)

select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
,a.date_document
--distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD, 
--            Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
from documents a
  where --(k2.refer_contract,k2.branch_contract) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    payers_account=(select acc_rko from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    and a.status in (35,38)
    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null),'#')='90901810000601030019'
    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null),'#')='90902810900600000916'



select * from collector_contracts where (reference,branch) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
and name='CARDLIST_2' and docnum in (1850678,
1850418,
1850168,
1849558,
1853298,
3441041,
2750308,
2669730,
3365769,
2512764,
2920704,
3276624,
3185702,
3112733,
3009225,
3446196,
2837837,
1849958
)


select * from contracts where reference in (670836,671493) and status=50


select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
,a.date_document
--distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD, 
--            Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
from documents a
  where --(k2.refer_contract,k2.branch_contract) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    payers_account in ('40702810500980091790','40702810200989091790') --(select acc_rko from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    and a.status in (35,38)
--    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null),'#')='90901810000601030019'
--    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null),'#')='90902810900600000916'
  
select rowid,a.* from variable_contracts a where (reference,branch,name,value) in (
select reference,branch,name,value from tmp_tables.tmp_gdm_vc where value in ('90901810200981002790')
)  
    

select rowid,a.* from collector_contracts a where reference=670836 and branch=354 and docnum=6792121946

