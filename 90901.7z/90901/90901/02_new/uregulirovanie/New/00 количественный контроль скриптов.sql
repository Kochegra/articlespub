select distinct status from tmp_tables.tmp_gdm_k2_v2 

10000 - �������� ��� � ��������� 90901
1000 - ������������ � ���� ��������� 35 � 36 �������
100 - ������������
1 - �� ������������ + ������ 

select 
--rowid,a.*
count(*) 
from tmp_tables.tmp_gdm_k2_v2 a --where a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)
where a.status=100 --and a.status<100
--where a.status<100 --and a.status<100
--and nvl(log,'#')<>'CHECK'
--and k2assist is not null
--and k2assist is null

--update tmp_tables.tmp_gdm_k2_v2 a set status=status*10
select 
''''||a.ACC_RKO||''','||a.refer_contract||','||a.BRANCH_CONTRACT||',' for_scr,
rowid,a.*
----count(*) 
from tmp_tables.tmp_gdm_k2_v2 a --where a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)
where a.status=100 --and a.status<100
--and k2assist is null and substr(acc_rko,6,3)='810'
--and k2assist is not null and substr(acc_rko,6,3)='810'
--and k2assist is null and substr(acc_rko,6,3)<>'810'
--and k2assist is not null and substr(acc_rko,6,3)<>'810'
--and nvl(log,'#')<>'CHECK'
--and nvl(log,'#')<>'#'
--and refer_contract in (17810000)
--and refer_contract in (23529606,17245204)
--and instr(log,'ERR6')>0
--and (instr(log,'ERR7')>0 or instr(log,'ERR6')>0)


10008263
23529606



select 
--a.*--
count(*)
from tmp_tables.TMP_GDM_90902 a
where 
instr(nvl(a.info_1,'#'),'DEL')>0
and nvl(log_contract,'#')='#'

and instr(log_contract,'��������')>0



select 
rowid,a.*
--count(*) 
from tmp_tables.tmp_gdm_k2_v2 a --where a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)
where a.status>=0 --and a.status<100
and nvl(log,'#')='CHECK'



���� ���������� �� ������ ���������.

select 
p_k2.get_Rest_K2_Acc(a.code,sysdate) sum_acc_k2, 
rowid,a.* from account a
where code in ('90902810605550001195')--,'90902810300477022837','90902810500470002007')
--where (contract,branch_contract) in (select contract,branch_contract from account where code in '90902810619120200325') and bal in ('40702','90901','90902')
--where contract in (15891428,15920441) and bal in ('40702','90901','90902')



select
p_k2.get_Rest_K2_Acc(a.account,sysdate) sum_acc_k2, 
rowid,a.*  from contracts a 
where assist='90902810605550001195' --pAcc.code and not (reference=pCont.reference and branch=pCont.branch);

where reference in (17810422)

	235409
16009076	235
)

select rowid,a.* from tmp_tables.tmp_gdm_vc a 
---where value='90902810619120200325' --pAcc.code and not (reference=pCont.reference and branch=pCont.branch);
where reference in (17810422)
 
select 
rowid,a.* from contracts a where --assist='90902810300220201041' --
reference in (18731633) and branch=365 
--(reference,branch) in (select reference,branch from contracts where account in (
--'40703840010380000002'--,'40502810301880000002'
--))

select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.value), a.value,substr(a.value,6,3), sysdate) saldo,
--rowid,a.* from tmp_tables.tmp_gdm_vc a --where reference in (16009076) and branch=235
rowid,a.* from variable_contracts a 
where reference in (17245204) and branch=235411  
--(reference,branch) in (select reference,branch from contracts where account in (
--'40703840010380000002'--,'40502810301880000002'
--))
and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)






---
select * from contracts where assist='90902810605550001195' and not (reference=15962418 and branch=235) and status not in (1001) and type_doc not in (5787,6833);

select count(*) from tmp_tables.tmp_gdm_vc a where value='90902810605550001195' and not (reference=15962418 and branch=235) and exists(select null from contracts where reference=a.reference and branch=a.branch and type_doc not in (5787,6833) );

40702810653000010744,40702810950000010744 40702810653000010744
40702810453000019343,40702810750000019343
40702810800070002577,47423810200077306624


select distinct acc_new from (
                select acc_mbank acc_new,header,'CFT' abs from acc_migr_cft_to_mbank 
                where acc_cft='47423810200077306624' -- and header=p_header --and date_migr<rAcc.open_date
                union all
                select acc_mbank acc_new,header,'CABS' abs from acc_migr_cabs_to_mbank 
                where acc_cft='47423810200077306624' --p_acc and header=p_header --and date_migr<rAcc.open_date
                union all
                select acc_new acc_new,header,'MBANK' abs from acc_closed_filial 
                where acc_old='47423810200077306624' -- and header=p_header --and date_beg<rAcc.open_date
 )