/
--����� ������
begin
--admin_util.host(username => 'PRC_LOADER', sid => 9579);
--  admin_util.host(username => 'ALESHIN_RL', sid => 8456);
--admin_util.host(username => 'MT_WEB', sid => 7393);
admin_util.host(username => 'MBANK', sid => 8807);
end;
/


with tab as (select a.* from contracts a where status between 0 and 50 and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'ACCOUNTTYPE'),'0')='14')
select a.* from tab a