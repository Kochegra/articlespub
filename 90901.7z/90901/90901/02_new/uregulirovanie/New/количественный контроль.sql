select * from contracts 
--where reference in (31284545) and branch=544 --type_doc in (1620) and status=50

select * from variable_contracts where reference in (31284545) and branch=544

select * from TMP_TABLES.TMP_GDM_VC_2 where value='90902810129430000514'


select count(*)-782 from TMP_TABLES.TMP_GDM_90902_2 where status=0

select count(*) from TMP_TABLES.TMP_GDM_90901_2 --where status<0 and code='90901810400251500670'

and nvl(info_1,'#')<>'#'


select * from TMP_TABLES.TMP_GDM_90901_2 where status=-1 --and code='90901810400251500670'


select count(*) 
from TMP_TABLES.TMP_GDM_90901 where nvl(info_1,'#') like '%DEL%' and (nvl(log_contract,'#')='#' or nvl(log_contract,'#')='K1_VC')
union all
select count(*) 
from TMP_TABLES.TMP_GDM_90902 where nvl(info_1,'#')='DEL' and nvl(log_contract,'#')='#'



select count(*) 
from TMP_TABLES.TMP_GDM_90901 where nvl(info_1,'#')<>'#' --and nvl(log_contract,'#')='#'
union all
select count(*) 
from TMP_TABLES.TMP_GDM_90902 where nvl(info_1,'#')<>'#' --='DEL' and nvl(log_contract,'#')='#'


select * 
from TMP_TABLES.TMP_GDM_90902 where nvl(info_1,'#')='DEL' and nvl(log_contract,'#')<>'#'
and instr(log_contract,'��������')=0



select * from TMP_TABLES.TMP_GDM_d35_d36 --where status=-1 --and code='90901810400251500670'


select 25378-21148 from dual
