        select 
        (select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
        a.*,--c.*
        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
        where a.status>=1000 and a.status<10000 
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        --and a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)--787) 
        --and a.refer_contract in (486,1277,1485,1616,2766,2768,3081,3086,3174,3313,3425,4954,5127,5646,5744,5780,5797,5806,5875,5900)

/
declare
bResult boolean;
rContRko contracts%rowtype;
rAccRko account%rowtype;
bExec boolean;
sErr varchar2(2000);
nDoc36 number;
nDoc35 number;
 function f_stat_36to35(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pRefDoc number,pBrDoc number,pCntFind out number, pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
--    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
            select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from   v_documents           doc
            ,collector_contracts c
            where  1 = 1
            and c.reference=pRefCont and c.branch=pBrCont
            and doc.branch = c.zbranch_docnum
            and doc.reference = c.docnum
            and c.name = 'CARDLIST_2'
            and c.summa in (0, 1)
            and rownum > 0
            and doc.status in (36)
            and doc.status >= 30
            and doc.status < 1000
            and doc.payers_account=pAcc
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'  
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'ROLLBACKTOEMITENT',null),'0')='0'
            and doc.reference=pRefDoc and doc.branch=pBrDoc
            and doc.type_doc=226

    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
            --    nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) < rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;

            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)>0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
--            if rDoc.status = 36 then
--                delete from k2
--                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
--            end if;

            -- ��� ��� ��� ���������, 35 ��� 38 �������
            -- � �� ������ ����� � ���� ���
            insert into documents select * from archive where reference = rDoc.reference and branch = rDoc.branch;
            insert into variable_documents select * from variable_archive where reference = rDoc.reference and branch = rDoc.branch;
            delete archive where reference = rDoc.reference and branch = rDoc.branch;
            commit;

            update documents set status = 35
            where reference = rDoc.reference and branch = rDoc.branch;
            commit;
            
            if nvl(Universe.VARIABLE_PART(rDoc.reference,rDoc.branch,'CARD_ACCOUNT_WAIT',null),'0')<>'0' then
                update documents set status = 38
                where reference = rDoc.reference and branch = rDoc.branch;
                commit;
            end if;
            

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            if sRes='UPD' then
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
            end if;
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            if sRes='UPD' then
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
            end if;
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_36to35;
 
 function f_stat_35to36(pAcc account.code%type,pRefCont contracts.reference%type,pBrCont contracts.branch%type,pRefDoc number,pBrDoc number,pCntFind out number,pUpd number) return boolean
 is 
    rDoc documents%rowtype;
    nArch number;
    bExec boolean;
    --bRes boolean;
    nSpisK2 number;
    nOstK2 number;
    nXOstK2 number;
    sRes varchar2(100);
    nSum number;
 begin
    bExec:=FALSE;
    pCntFind:=0;
    -- �� ����� �������
    dbms_output.put_line('� ������');
    --return false;
    for rDocAcc in (
        select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account=pAcc  
            and status in (35,38) --and type_doc=2 
            and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,pRefCont,pBrCont,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit) -- �� ����� ��� ��������
            --and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => doc.summa, pCard_Type => 2)=0 --���������
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
            and doc.type_doc=226
            and doc.reference=pRefDoc and doc.branch=pBrDoc
    ) loop
        bExec:=FALSE;
        if UNIVERSE.GET_DOCUMENT_REC(rDocAcc.reference, rDocAcc.branch, nArch, 1, rDoc) then
            --if rDoc.payers_currency='810' then
                nSum:=rDoc.summa;
            --else
                --nSum:=rDoc.xsummacredit;
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
--                    bExec:=TRUE;
--                end if;
--            else
--                if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.xsummacredit then
--                    bExec:=TRUE;
--                end if;
            --end if;
            if p_k2.get_rest_k2(rDoc.reference, rDoc.branch) = rDoc.summa then
                bExec:=TRUE;
                pCntFind:=pCntFind+1;
            end if;
            --if p_k2.Get_Rest_K2_multi(rDoc.reference,rDoc.branch,pRefCont,pBrCont,trunc(sysdate))=nSum then
--            if p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2)=0 then
--                bExec:=TRUE;
--                pCntFind:=pCntFind+1;
--            end if;
        end if;
        if bExec and pUpd=1 then
            --� K2 �������� ������ �� ������� ��(��� 35 ������� �2 ��������� � �������� DOCUMENTS)
            if rDoc.status = 38 then
                delete from k2
                where reference = rDoc.reference and branch = rDoc.branch and what_is = 2;               --��������� 2
            end if;

            update documents set status = 36
            where reference = rDoc.reference and branch = rDoc.branch;
        
            commit;

            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        else
            nSpisK2:=p_k2.get_rest_k2(rDoc.reference, rDoc.branch);
            --nSpisK2:=p_k2.Get_Rest_K2_multi(rdoc.reference, rdoc.branch,pRefCont,pBrCont,trunc(sysdate));
            --nOstK2:=rDoc.summa-nSpisK2;
            nOstK2:=p_k2.GetRest4Cursor(pBranch_Doc => rdoc.branch, pReference_Doc => rdoc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => rdoc.summa, pCard_Type => 2);
            nXOstK2:=rDoc.xsummacredit-nSpisK2;
            if bExec then sRes:='UPD'; else sRes:='NO UPD'; end if;
            dbms_output.put_line(sRes||'   '||rDoc.reference||'/'||rDoc.branch||' '||rDoc.payers_account||'/'||rDoc.payers_currency||' '||rDoc.summa||'('||rDoc.xsummacredit||') �������='||nSpisK2||' �������='||nOstK2||'('||nXOstK2||')');
        end if;
    end loop;
    bExec:=TRUE;
    return bExec;
 end f_stat_35to36; 
begin
    for rec in (
    
--select 
--d.summa-p_k2.Get_Rest_K2(d.Reference, d.Branch) ost,
--p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => d.summa, pCard_Type => 2) sum_related,
--d.* from documents d
--where type_doc in (226) --and status in (35,38)
--and exists (select null from account where header=paccount.HEADER_ACCOUNT(d.payers_account) and CODE=d.payers_account and currency=substr(d.payers_account,6,3) and close_date is null)
--and d.summa=p_k2.Get_Rest_K2(d.Reference, d.Branch)
--and d.payers_account='40702810000330002305'
--and reference in (2926326950,2670231849,3316319152,3314707316,3314683912,3316319093,2926326961,3314695149,3314683961,3316319164,3314707325,2670220252,3316319087,3316319073,3314684029,2670231831,3314695698,3316319120,2768338643,3316319100,2670231675)

select * from TMP_TABLES.TMP_GDM_d35_d36 where nvl(no_upd,0)=0 and metod='ALL_DOC_35'
--and reference in (6670290653)
    
    )loop
        bExec:=TRUE;
        sErr:=null;
        -- ������� �������
        if not universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.payers_account), cd => rec.payers_account, cr=>substr(rec.payers_account,6,3),account_rec => rAccRko) then
            bExec:=FALSE;
            --sErr:=sErr||'ERR4 �� ������ ���� ���! ';
            dbms_output.put_line(rec.payers_account||' ERR4 �� ������ ���� ���!');
        end if;
        if bExec and not Universe.get_contract_rec(rf => rAccRko.contract, br => rAccRko.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rContRko) then
            bExec:=FALSE;
            --sErr:=sErr||'ERR1 �� ������ ��������! ';
            dbms_output.put_line(rec.payers_account||' ERR1 �� ������ ��������!');
        end if;
        

        if bExec --and rContRko.type_doc in (94,590) 
        then
            
--            bResult:=f_stat_36to35(rAccRko.code,rContRko.reference,rContRko.branch,rec.reference,rec.branch,nDoc36,1); -- �������� 36 �������� � ���������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � �����������
--            
--            --if not bResult then
--            --    bExec:=FALSE;
--            --    sErr:=sErr||'ERR7 ������ ���������� 36 TO 35! ';
--            --end if;
--            if bResult and nDoc36>0 then
--                --bExec:=FALSE;
--                --sErr:=sErr||'ERR7 ������� ���� � 36 � ���������� ���������('||nvl(nDoc36,0)||' ��.)! ';
--                dbms_output.put_line('������� � �������� 36 �������: '||nvl(nDoc36,0)||' ����������.');
--            end if;
        
            bResult:=f_stat_35to36(rAccRko.code,rContRko.reference,rContRko.branch,rec.reference,rec.branch,nDoc35,0); -- �������� 35,38 �������� � �������� ��������� �� ����������, ��������� �������� 0 - ��� ����������, 1 - � ����������� 
            --if not bResult then
            --    bExec:=FALSE;
            --    sErr:=sErr||'ERR6 ������ ���������� 35 TO 36! ';
            --end if;
            if bResult and nDoc35>0 then
--                --bExec:=FALSE;
--                sErr:=sErr||'ERR6 ������� ���� � 35 � �������� ���������('||nvl(nDoc35,0)||' ��.)! ';
                dbms_output.put_line('������� � �������� 35 �������: '||nvl(nDoc35,0)||' ����������.');
            end if;
            dbms_output.put_line('36='||nvl(nDoc36,0)||' 35='||nvl(nDoc35,0));
            update TMP_TABLES.TMP_GDM_d35_d36 set no_upd=10 
            where nvl(no_upd,0)=0 and metod='ALL_DOC_35' and reference=rec.reference and branch=rec.branch and 1=1;
            commit;
        end if;

--        if nvl(sErr,'#')<>'#' then
--            update TMP_TABLES.TMP_GDM_K2_v2 a set log=sErr where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
--            commit;
--        else
--            update TMP_TABLES.TMP_GDM_K2_v2 a set log=null where a.refer_contract=rec.refer_contract and branch_contract=rec.branch_contract;
--            commit;
--        end if;
--        sErr:=null;
    end loop;

end;
/

select  rowid,
p_k2.GetRest4Cursor(pBranch_Doc => a.branch, pReference_Doc => a.reference, pBranch_Contract => null, pRefer_Contract => null, pSumma => a.summa, pCard_Type => 2) GetRest4Cursor,
a.* from TMP_TABLES.TMP_GDM_d35_d36 a 
--update TMP_TABLES.TMP_GDM_d35_d36 a set no_upd=-11
where nvl(no_upd,0)=0 and metod='ALL_DOC_35'
--and substr(payers_account,1,3)='421'
--and substr(payers_account,1,5)='40702'
--and reference in (6419393924)-- (5784469758,6670290653)--1397495546,6726617084,3693346305,5314866418,6157256528)

select * from k2 where reference=5784469758--6670290653

insert into k2
select a.reference,a.branch,ACC.CONTRACT,acc.branch_contract,acc.code,substr(acc.code,6,3),'D',2
from TMP_TABLES.TMP_GDM_d35_d36 a, account acc 
where nvl(no_upd,0)=0 and metod='ALL_DOC_35'
and a.reference in (6670290653)
and acc.code=a.payers_account and acc.header='A'

select * from account where code='42102810408030000195'


        select
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null) TO_ALL_ACCOUNTS, -- ����� ������ �� ���� ������
            UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null) MULTIK2, -- ����� ����� ��������� � ���������� ������
            (select count(*) from k2 where reference=doc.reference and branch=doc.branch) cnt_k2,
            (select count(*) from k2_multi where reference=doc.reference and branch=doc.branch) cnt_k2m,
            doc.* 
            from documents doc
            where payers_account='42102810408030000195'  
            --and status in (35,38) --and type_doc=2 
            and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit)
            --and p_k2.Get_Rest_K2_multi(doc.reference, doc.branch,pRefCont,pBrCont,trunc(sysdate))=decode(doc.payers_currency,'810',doc.summa,doc.xsummacredit) -- �� ����� ��� ��������
            --and p_k2.GetRest4Cursor(pBranch_Doc => doc.branch, pReference_Doc => doc.reference, pBranch_Contract => pBrCont, pRefer_Contract => pRefCont, pSumma => doc.summa, pCard_Type => 2)=0 --���������
            and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TO_ALL_ACCOUNTS',null),'0')='0' and nvl(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'MULTIK2',null),'0')='0'
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) = doc.summa
            --and p_k2.Get_Rest_K2(doc.reference, doc.branch) >= doc.summa   
            and doc.type_doc=226
            and doc.reference=6670290653 and doc.branch=191
