select count(*) from tmp_tables.TMP_GDM_90902 a where instr(nvl(a.info_1,'#'),'DEL')>0

select * from (
select distinct value,substr(name,1,14), count(*) cnt from TMP_TABLES.TMP_GDM_VC where value='90901810000001012802'
group by value,substr(name,1,14))
where cnt>1

with tab as
--(select distinct value,substr(name,1,14) name, reference,branch from TMP_TABLES.TMP_GDM_VC)-- where value='90901810000001012802')
(select distinct value,reference,branch from TMP_TABLES.TMP_GDM_VC)-- where value='90901810000001012802')
--select * from tab
select 
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate)) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) cl,
a.* from (
select distinct value, count(*) cnt from tab
group by value
) a where cnt>1 and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) /*and close_date is not null*/ and nvl(contract,0)<>0)
--and value='90901810600961020344'


90901810100231501630
90901810200001001985
90901810200231503826
90901810200440000343
90901810200621020812
90901810216551002004






select rowid,a.*  from TMP_TABLES.TMP_GDM_VC a 
--where value='90901810400011020006'
--where instr(name,'OLD')>0
where substr(name,1,1)='_'


select rowid,a.*  from TMP_TABLES.TMP_GDM_VC a 
where nvl(value,'#')='90901810500561001015' --value='90902810018810800005'
--where reference in (17774134,17774086)

--delete from variable_contracts
select rowid,
(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate)) sal,
(select close_date||' '||contract from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) cl,
a.* from variable_contracts a
--where (a.reference,a.branch,a.name,a.id) in (select reference,branch,name,id  from TMP_TABLES.TMP_GDM_VC where nvl(value,'#')='90902810700560003680')
--where (a.reference,a.branch) in (select reference,branch  from TMP_TABLES.TMP_GDM_VC where nvl(value,'#')='90902810145030001890')
where reference= 22325421 and branch=770
--where reference=22083103 and branch=770

and instr(name,'CARD_ACCOUNT')>0

select 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3)) clos_rko,--and contract=a.reference
a.*,b.* 
from contracts a,TMP_TABLES.TMP_GDM_VC b
where 
a.reference=b.reference and a.branch=b.branch
and nvl(b.value,'#')='90902810130240007123'
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3) and close_date is not null) --and contract=a.reference)
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(b.value) and code=b.value and currency=substr(b.value,6,3) and close_date is not null and contract=a.reference)
--and exists(select null from account where (contract,branch_contract) in (select reference,branch  from TMP_TABLES.TMP_GDM_VC where nvl(value,'#')='90901810100231500453'))

select rowid,a.* 
from contracts a
where 
assist='90902810900004201890'

40702810600004201890               1             90902810900004201890
40702810700004211890               1             90902810145030001890

90902810912250001890
90902810145030001890


select rowid,a.* 
from contracts a
where reference=  23024900 and branch=275


select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
a.* from account a where code in ('40702810600004201890','90902810900004201890') --90901810603261001461 90901810203261003461
 

90902810303260000461
90902978203260000461
90901978203261000461
90901810603261001461



select rowid,a.* from TMP_TABLES.TMP_GDM_K2 a where refer_contract in (22325421,22325660)

/
declare
rAcc account%rowtype;
rAccRko account%rowtype;
bExec boolean;
begin
    for rec in (
    
            with tab as
                (select distinct value,reference,branch from TMP_TABLES.TMP_GDM_VC)-- where value='90901810000001012802')
                --select * from tab
                select 
                (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate)) sal,
                (select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) cl,
                a.* from (
                select distinct value, count(*) cnt from tab
                group by value
                ) a where cnt>1 and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) /*and close_date is not null*/ and nvl(contract,0)<>0)
                and value='90902810700560003680'
    
    )loop
        --bExec:=TRUE;
        if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.value), cd => rec.value, cr=>substr(rec.value,6,3),account_rec => rAcc) --and rec.sal=0 
        then
            for rCont in (select a.*,b.reference ref_tmp,b.BRANCH br_tmp, b.value, b.id from contracts a,TMP_TABLES.TMP_GDM_VC b where a.reference=b.reference and a.branch=b.branch and nvl(b.value,'#')=rec.value)
            loop
                if rCont.account is not null and universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rCont.account), cd => rCont.account, cr=>substr(rCont.account,6,3),account_rec => rAccRko) then
                    if rAccRko.close_date is null then
                        bExec:=FALSE;
                        DBMS_OUTPUT.PUT_LINE('0');
                    end if;
                end if;
            end loop;
            bExec:=TRUE;
            if bExec then
                for rCont in (select a.*,b.reference ref_tmp,b.BRANCH br_tmp, b.value, b.id from contracts a,TMP_TABLES.TMP_GDM_VC b where a.reference=b.reference and a.branch=b.branch and nvl(b.value,'#')=rec.value)
                loop
                    if rCont.account is not null and universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rCont.account), cd => rCont.account, cr=>substr(rCont.account,6,3),account_rec => rAccRko) then
                        DBMS_OUTPUT.PUT_LINE('1');
                        if not (rCont.reference=rAcc.contract and rCont.branch=rAcc.branch_contract) then
                            DBMS_OUTPUT.PUT_LINE('2');
                            update variable_contracts set name='#'||name
                            where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
                            commit;
                            delete from tmp_tables.tmp_gdm_vc
                            where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
                            commit;
                            if rAcc.bal='90902' and rCont.assist=rec.value then
                                DBMS_OUTPUT.PUT_LINE('2_2');
                                UNIVERSE.INPUT_VAR_CONTR(rCont.branch, rCont.reference, '#GDM_ASSIST', rCont.assist);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
                                commit;
                                update contracts set assist=null,assist_currency=null where reference=rCont.reference and branch=rCont.branch;-- and status=50 and date_close is null;
                                commit; 
                            end if;
                        else 
                            DBMS_OUTPUT.PUT_LINE('3');
                            if rAccRko.close_date is null then
                                DBMS_OUTPUT.PUT_LINE('4');
--                                update variable_contracts set name='#'||name
--                                where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                                commit;
--                                delete from tmp_tables.tmp_gdm_vc
--                                where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                                commit;
                                if rAcc.bal='90902' and rCont.assist=rec.value then
                                    DBMS_OUTPUT.PUT_LINE('4_2');
--                                    UNIVERSE.INPUT_VAR_CONTR(rCont.branch, rCont.reference, '#GDM_ASSIST', rCont.assist);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                                    commit;
--                                    update contracts set assist=null,assist_currency=null where reference=rCont.reference and branch=rCont.branch;-- and status=50 and date_close is null;
--                                    commit; 
                                end if;
                            end if;
                        end if;
                    else
                        DBMS_OUTPUT.PUT_LINE('5');
--                                update variable_contracts set name='#'||name
--                                where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                                commit;
--                                delete from tmp_tables.tmp_gdm_vc
--                                where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                                commit;
                                if rAcc.bal='90902' and rCont.assist=rec.value then
                                    DBMS_OUTPUT.PUT_LINE('5_2');
--                                    UNIVERSE.INPUT_VAR_CONTR(rCont.branch, rCont.reference, '#GDM_ASSIST', rCont.assist);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                                    commit;
--                                    update contracts set assist=null,assist_currency=null where reference=rCont.reference and branch=rCont.branch;-- and status=50 and date_close is null;
--                                    commit; 
                                end if;

--                    update variable_contracts set name='#'||name
--                    where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                    commit;
                    --if substr(rec.value)
--                        delete from tmp_tables.tmp_gdm_vc
--                        where reference=rCont.ref_tmp and branch=rCont.br_tmp and id=rCont.id and 1=1;
--                        commit;
                    
                    end if;
                end loop; 
            end if;
        end if;
        DBMS_OUTPUT.PUT_LINE('---');
    end loop;
end;
/




5036,81		90901810500171000914	2   --- ���
0		90901810900651000296	2 --
2667,42		90901810901991001022	2 --
3367585,45		90901810906261002798	2 --
0		90901840509511000008	2--
15915,80286		90901978411091000054	2--
108404,99		90902810010190003229	2--
0		90902810010560004094	2  ----- ��������� ������� � 2 ������
1125,74		90902810027000016069	2--
11429,83		90902810100470001408	2--
0		90902810130240007123	2----- ��������� ������� � 2 ������
200		90902810203300000188	2----- ��������� ������� � 2 ������
0		90902810208560003496	2----- ��������� ������� � 2 ������
2306		90902810210030012798	2 ----- ��������� ������� � 2 ������
0		90902810213030001104	2----- ��������� ������� � 2 ������
0		90902810216450000889	2----- ��������� ������� � 2 ������
106456,48		90902810216550008545	2----- ��������� ������� � 2 ������
0		90902810239000006799	2----- ��������� ������� � 2 ������
0		90902810249100002010	2----- ��������� ������� � 2 ������
0		90902810408560001340	2----- ��������� ������� � 2 ������
0		90902810417300000592	2----- ��������� ������� � 2 ������
41381,44		90902810442050002161	2-- �������� � ����������
0		90902810524100000465	2----- ��������� ������� � 2 ������
0		90902810605550001195	2----- ��������� ������� � 2 ������
0		90902810608560000141	2----- ��������� ������� � 2 ������
0		90902810612310008091	2----- ��������� ������� � 2 ������
3812937,99		90902810613240008717	2 ----- ��������� ������� � 2 ������
0		90902810618160000476	2----- ��������� ������� � 2 ������
0		90902810621300000029	2----- ��������� ������� � 2 ������
0		90902810635560004482	2----- ��������� ������� � 2 ������
0		90902810701590000270	2
0		90902810708180004618	2
0		90902810725000006423	2
0		90902810740260000202	2
0		90902810741560003791	2
191,76		90902810745100003584	2
2642638,19		90902810800000008142	2
0		90902810817540001003	2
0		90902810841240003076	2
171031,82		90902810907030009661	2
0		90902810955000600521	2
0		90902840310310008965	2
0		90902840512022011721	2
0		90902840700010000051	2
7012,4376		90902840814030009478	2
