        select distinct contract,branch_contract 
        from (
                select a.* from tmp_tables.TMP_GDM_90901 a
                where a.close_date is null and nvl(a.contract,0)!=0 
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
                union all
                select a.* from tmp_tables.TMP_GDM_90902 a
                where a.close_date is null and nvl(a.contract,0)!=0 
                and not exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
              )
        where nvl(info_1,'0')='0'
        and contract in (17264196)
        order by contract


/
declare
bExec boolean;
bCont boolean;
rCont contracts%rowtype;
bAccRko boolean;
rAccRko account%rowtype;
nResVc number;
nResOtherVc number;
nK1doc number;
sK1doc varchar2(2000);
--sK1 varchar2(2000);
--sK2 varchar2(2000);
--sK3 varchar2(2000);
--sK15 varchar2(2000);
--nK1 number;
--nK2 number;
--nK3 number;
--nK15 number;
 function f_get_vc(pRef number,pBr number) return number
 is
    nRes number :=0;
    sK1 varchar2(2000);
    sK2 varchar2(2000);
    sK3 varchar2(2000);
    sK15 varchar2(2000);
    nK1 number;
    nK2 number;
    nK3 number;
    nK15 number;
 begin
    nK1:=0; nK2:=0; nK3:=0; nK15:=0;
    for varCont in (select * from variable_contracts where reference=pRef and branch=pBr and (instr(name,'CARD_ACCOUNT')>0 or instr(name,'ASSIST')>0) and instr(name,'#')=0)
    loop
        if instr(varCont.name,'CARD_ACCOUNT_1')>0 and instr(varCont.name,'CARD_ACCOUNT_15')=0 then
            nK1:=nK1+1;
            sK1:=sK1||varCont.name||'='||varCont.value||',';
        end if;
        if instr(varCont.name,'CARD_ACCOUNT_15')>0 then
            nK15:=nK15+1;
            sK15:=sK15||varCont.name||'='||varCont.value||',';
        end if;
        if instr(varCont.name,'CARD_ACCOUNT_2')>0 then
            nK2:=nK2+1;
            sK2:=sK2||varCont.name||'='||varCont.value||',';
        end if;
        if instr(varCont.name,'CARD_ACCOUNT_3')>0 then
            nK3:=nK3+1;
            sK3:=sK3||varCont.name||'='||varCont.value||',';
        end if;
        nRes:=nRes+1;
    end loop;
    sK1:='[CNT='||nK1||']#'||substr(sK1,1,length(sK1)-1);
    sK15:='[CNT='||nK15||']#'||substr(sK15,1,length(sK15)-1);
    sK2:='[CNT='||nK2||']#'||substr(sK2,1,length(sK2)-1);
    sK3:='[CNT='||nK3||']#'||substr(sK3,1,length(sK3)-1);
    DBMS_OUTPUT.PUT_LINE('K1 '||sK1);
    DBMS_OUTPUT.PUT_LINE('K2 '||sK2);
    DBMS_OUTPUT.PUT_LINE('K3 '||sK3);
    DBMS_OUTPUT.PUT_LINE('K15 '||sK15);
    return nRes;
 end f_get_vc;
 function f_get_tmp_909(pRef number,pBr number) return boolean
 is
 begin
    DBMS_OUTPUT.PUT_LINE('TMP_GDM_909');
    for rec in (select * from tmp_tables.TMP_GDM_90901 where nvl(contract,0)=pRef and nvl(branch_contract,0)=pBr)
    loop
        DBMS_OUTPUT.PUT_LINE(rec.bal||' '||rec.code);
    end loop;
    for rec in (select * from tmp_tables.TMP_GDM_90902 where nvl(contract,0)=pRef and nvl(branch_contract,0)=pBr)
    loop
        DBMS_OUTPUT.PUT_LINE(rec.bal||' '||rec.code);
    end loop;
    return true;
 end f_get_tmp_909;
 function f_get_tmp_vc(pAcc account.code%type,pRefCont number,pBrCont number) return number
 is
    nRes number:=0;
 begin
    for rec in (select * from TMP_TABLES.TMP_GDM_VC where value=pAcc)
    loop
        if not(pRefCont=rec.reference and pBrCont=rec.branch) then
            DBMS_OUTPUT.PUT_LINE('VC '||rec.reference||' '||rec.branch);
            nRes:=nRes+1;
        else
            DBMS_OUTPUT.PUT_LINE('VC ���������');
        end if;
    end loop;
    if substr(pAcc,1,5)='90902' then
        for rec in (select * from contracts where assist=pAcc)
        loop
            if not(pRefCont=rec.reference and pBrCont=rec.branch) then
                DBMS_OUTPUT.PUT_LINE('ASSIST '||rec.reference||' '||rec.branch);
                nRes:=nRes+1;
            else
                DBMS_OUTPUT.PUT_LINE('ASSIST ���������');
            end if;
        end loop;
    end if;
    return nRes;
 end f_get_tmp_vc;
 --function get_doc()

 function f_get_k1_doc(pAcc account.code%type,pRes out varchar2) return number
 is 
    nCnt number :=0;
    sRes varchar(2000);
 begin
        for rec in (select universe.variable_part(d.reference,d.branch, 'CARD_ACCOUNT1') CARD_ACCOUNT1,
                    d.*,j.code
                    from   documents d, journal j
                    where  1 = 1
                        and d.reference=j.docnum and d.branch=j.branch 
                        and substr(j.code,1,5)='90901'
                        and d.payers_account=pAcc
                        and d.status in (22,35,38,36,30,45)    
                        and nvl(universe.variable_part(d.reference,d.branch, 'CARD_ACCOUNT1'),'0')<>'0')
        loop
            --nCnt:=nCnt+1;
            if instr('#'||sRes,rec.code)=0 and nvl(rec.code,'0')<>'0' then
                nCnt:=nCnt+1;
                sRes:=sRes||rec.code||',';
            end if;
            if instr('#'||sRes,rec.card_account1)=0 and nvl(rec.card_account1,'0')<>'0' then
                nCnt:=nCnt+1;
                sRes:=sRes||rec.card_account1||',';
            end if;
        end loop;
        if sRes is not null then
            sRes:=substr(sRes,1,length(sRes)-1);
            sRes:='[RES='||sRes||']';
            pRes:=sRes;
        end if;
    return nCnt;
 end f_get_k1_doc;

begin
    for rec in (
    
        select distinct contract,branch_contract 
        from (
                select * from tmp_tables.TMP_GDM_90901
                where close_date is null and nvl(contract,0)!=0
                union all
                select * from tmp_tables.TMP_GDM_90902
                where close_date is null and nvl(contract,0)!=0
              )
        where nvl(info_1,'0')='0'
        and contract in (17264196)
        order by contract
    
    )loop
        bExec:=TRUE;
        -- ������� ���
        bCont:=Universe.get_contract_rec(rf => rec.contract, br => rec.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rCont);
        bAccRko:=universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rCont.account), cd => rCont.account, cr=>substr(rCont.account,6,3),account_rec => rAccRko);
        
        if not (bCont and bAccRko) then
            DBMS_OUTPUT.PUT_LINE('�� ����� �������� ��� ����');
            update tmp_tables.TMP_GDM_90901 set info_1='ERR1 �� ����� �������� ��� ����'
                where contract=rec.contract and branch_contract=rec.branch_contract;
            commit;
            update tmp_tables.TMP_GDM_90902 set info_1='ERR1 �� ����� �������� ��� ����'
                where contract=rec.contract and branch_contract=rec.branch_contract;
            commit;
            bExec:=FALSE;
        end if;
        if bCont and bAccRko and substr(rAccRko.code,1,3)='421' then
            DBMS_OUTPUT.PUT_LINE('���� 421');
            update tmp_tables.TMP_GDM_90901 set info_1='ERR2 ���� 421'
                where contract=rec.contract and branch_contract=rec.branch_contract;
            commit;
            update tmp_tables.TMP_GDM_90902 set info_1='ERR2 ���� 421'
                where contract=rec.contract and branch_contract=rec.branch_contract;
            commit;
            bExec:=FALSE;
        end if; 
        
        if bExec then
            --������� ��������
            DBMS_OUTPUT.PUT_LINE('CONTRACTS');
            DBMS_OUTPUT.PUT_LINE('�/� '||rCont.account);
            DBMS_OUTPUT.PUT_LINE('ASSIST '||rCont.assist);
            --������� ��������� ���������
            DBMS_OUTPUT.PUT_LINE('VARIABLE_CONTRACTS');
            nResVc:=f_get_vc(rCont.reference,rCont.branch);
            --����� �� ���������
            if f_get_tmp_909(rCont.reference,rCont.branch) then
                DBMS_OUTPUT.PUT_LINE('----');
            end if;
            --�������� ��������� � ������ ���������
            nResOtherVc:=f_get_tmp_vc('90902810200000028188',rCont.reference,rCont.branch);
            nResOtherVc:=f_get_tmp_vc('90901810900001027188',rCont.reference,rCont.branch);
            nResOtherVc:=f_get_tmp_vc('90901810100001500188',rCont.reference,rCont.branch);
            
            --���������� �1 �����
            --��������� ���� �� �����
            nK1doc:=f_get_k1_doc(rAccRko.code,sK1doc);
            DBMS_OUTPUT.PUT_LINE(nK1doc||' '||sK1doc);
            if nK1doc=0 then
                for vcK1 in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch and name like 'CARD_ACCOUNT_1%' and instr(name,'15')=0)
                loop
                    -- ���� ����
                end loop;
            end if;
            
            
        end if;
    end loop;
end;
/

select rowid,a.* from TMP_TABLES.TMP_GDM_90901 a where code in ('90901810100001500188')

select rowid,a.* from TMP_TABLES.TMP_GDM_90902 a where contract=17264196

-- �� ���������
select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT('90901810100001500188') and code='90901810100001500188'
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21)))
                        
select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        where (status in (35,36,38,22) or (status in (30) and type_doc in (3363)))
                                and nvl(trim(payers_account),'0')<>'0'
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference in (6652288747,6652288274)                             
                            and branch=191
                        order by level desc
    
    --select distinct(acc_new) into ret 
    --from (
          select --acc_mbank acc_new,header,'CFT' abs,acc_cft acc_old 
          *
          from acc_migr_cft_to_mbank a
          where acc_cft='40702810900000002188' and header=paccount.HEADER_ACCOUNT('40702810900000002188') 
          and exists(select null from account where header=paccount.HEADER_ACCOUNT('40702810900000002188') and code='40702810900000002188' and currency=substr('40702810900000002188',6,3) and open_date<a.date_migr)
          
          union all
          
          select --acc_mbank acc_new,header,'CABS' abs,acc_cft acc_old 
          *
          from acc_migr_cabs_to_mbank a 
          where acc_cft='40702810900000002188' and header=paccount.HEADER_ACCOUNT('40702810900000002188')
          and exists(select null from account where header=paccount.HEADER_ACCOUNT('40702810900000002188') and code='40702810900000002188' and currency=substr('40702810900000002188',6,3) and open_date<a.date_migr)
          
          union all
          
          select --acc_new acc_new,header,'MBANK' abs,acc_old acc_old 
          *
          from acc_closed_filial a 
          where acc_old='40702810900000002188' and header=paccount.HEADER_ACCOUNT('40702810900000002188')
                and exists(select null from account where header=paccount.HEADER_ACCOUNT('40702810900000002188') and code='40702810900000002188' and currency=substr('40702810900000002188',6,3) and open_date<a.date_beg)
--          );

select * from variable_account where (reference,branch) in (select reference,branch from account where header=paccount.HEADER_ACCOUNT('40702810900000002188') and code='40702810900000002188' and currency=substr('40702810900000002188',6,3))

select * from contracts where assist='90902810200000028188'