create table TMP_TABLES.TMP_GDM_K2 as
    select refer_contract,branch_contract,account, account acc_rko
        from mbank.k2 a where nvl(what_is,0)=2 and account='40702810120060000654'
/    

grant select,insert,update,delete on TMP_GDM_K2 to MBANK

/

delete from TMP_TABLES.TMP_GDM_K2
  
select rowid,a.* from TMP_TABLES.TMP_GDM_k2 a

/

alter table TMP_GDM_K2
    add (--status  number
--         k2Assist varchar2(2000)
--         k2 varchar2(2000),
--         k3 varchar2(2000),
--         k15 varchar2(2000),
--         k2v varchar2(2000),
--         k3v varchar2(2000),
--           k3v_3 varchar2(2000)
--         k15v varchar2(2000),
--         kOther varchar2(2000),
--         kAll varchar2(2000),
--        k2_doc varchar2(2000),
--        k3_doc varchar2(2000),
--        k15_doc varchar2(2000),
--        k3k15old_doc  varchar2(2000),
        --k3old_doc  varchar2(2000)
        log varchar2(2000)
--        k2old_doc varchar2(2000),
--        acc_doc varchar2(2000)
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --vc_k2_810        VARCHAR2(4000 BYTE),--
         --vc_k3_810        VARCHAR2(4000 BYTE),
         --vc_k15_810         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
        )
/        

