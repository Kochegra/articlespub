-- 1
select 'update contracts set assist='||nvl2(assist,''''||assist||'''','null')||',currency='||nvl2(assist,''''||substr(assist,6,3)||'''','null')||' where reference='||reference||' and branch='||branch||';' upd_bid
--,nvl2(assist,''''||assist||'''','null')
--a.* 
from contracts a where (reference=25215112 and branch=770427)
or (reference=19456107 and branch=660)
or (reference=18752974 and branch=365)
or (reference=26483876 and branch=270)
or (reference=25579120 and branch=665)
or (reference=25599450 and branch=665)
or (reference=25528954 and branch=635)
or (reference=26505008 and branch=245)
or (reference=28922212 and branch=770413)
--
or (reference=15998152 and branch=235)
or (reference=8772956 and branch=133)
or (reference=8915757 and branch=191)
or (reference=8915759 and branch=191)
or (reference=11461 and branch=116)
or (reference=25527676 and branch=635)
or (reference=17825328 and branch=780)
or (reference=600101 and branch=49051)
union all
select 'commit;' from dual
union all
select 'delete from variable_contracts where reference='||reference||' and branch='||branch||' and instr(name,''CARD_ACCOUNT'')>0;' upd_bid
--a.* 
from contracts a where (reference=25215112 and branch=770427)
or (reference=19456107 and branch=660)
or (reference=18752974 and branch=365)
or (reference=26483876 and branch=270)
or (reference=25579120 and branch=665)
or (reference=25599450 and branch=665)
or (reference=25528954 and branch=635)
or (reference=26505008 and branch=245)
or (reference=28922212 and branch=770413)
--
or (reference=15998152 and branch=235)
or (reference=8772956 and branch=133)
or (reference=8915757 and branch=191)
or (reference=8915759 and branch=191)
or (reference=11461 and branch=116)
or (reference=25527676 and branch=635)
or (reference=17825328 and branch=780)
or (reference=600101 and branch=49051)
union all
select 'commit;' from dual
union all
select 'insert into variable_contracts(name,reference,branch,subnumber,rownumber,colnumber,value,subfield,id) values('''||name||''','||reference||','||branch||','||subnumber||','||rownumber||','||colnumber||','''||value||''','||nvl2(subfield,''''||subfield||'''','null')||','||id||');' upd_bid
--,nvl2(subfield,''''||subfield||'''','null')
--,a.* 
from variable_contracts a where ((reference=25215112 and branch=770427)
or (reference=19456107 and branch=660)
or (reference=18752974 and branch=365)
or (reference=26483876 and branch=270)
or (reference=25579120 and branch=665)
or (reference=25599450 and branch=665)
or (reference=25528954 and branch=635)
or (reference=26505008 and branch=245)
or (reference=28922212 and branch=770413)
--
or (reference=15998152 and branch=235)
or (reference=8772956 and branch=133)
or (reference=8915757 and branch=191)
or (reference=8915759 and branch=191)
or (reference=11461 and branch=116)
or (reference=25527676 and branch=635)
or (reference=17825328 and branch=780)
or (reference=600101 and branch=49051)
)
and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0
union all
select 'commit;' from dual

--select * from variable_contracts where value='90902810055001300209'


select rowid,a.* from TMP_TABLES.TMP_GDM_BID a where reference=127918

--2
select 'update contracts set assist='||nvl2(assist,''''||assist||'''','null')||',currency='||nvl2(assist,''''||substr(assist,6,3)||'''','null')||' where reference='||reference||' and branch='||branch||';' upd_bid
--,nvl2(assist,''''||assist||'''','null')
--a.* 
from contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_BID where from_table='contracts')
union all
select 'commit;' from dual
union all
select 'delete from variable_contracts where reference='||reference||' and branch='||branch||' and instr(name,''CARD_ACCOUNT'')>0;' upd_bid
--a.* 
from contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_BID where from_table='contracts')
union all
select 'commit;' from dual
union all
select 'insert into variable_contracts(name,reference,branch,subnumber,rownumber,colnumber,value,subfield,id) values('''||name||''','||reference||','||branch||','||subnumber||','||rownumber||','||colnumber||','''||value||''','||nvl2(subfield,''''||subfield||'''','null')||','||id||');' upd_bid
--,nvl2(subfield,''''||subfield||'''','null')
--,a.* 
from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_BID where from_table='contracts')
and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0
union all
select 'commit;' from dual
