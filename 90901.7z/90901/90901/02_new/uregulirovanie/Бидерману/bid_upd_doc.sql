begin
    update variable_documents set value='90902810877100000523'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008234291))
    and name='CARD_ACCOUNT'; 
    
    update variable_documents set value='90902810177100000524'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008234091))
    and name='CARD_ACCOUNT'; 

    update variable_documents set value='90902810377100000531'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008223169))
    and name='CARD_ACCOUNT'; 

    update variable_documents set value='90902810677100000532'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008224905))
    and name='CARD_ACCOUNT'; 

    update variable_documents set value='90902810277100000534'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008225015))
    and name='CARD_ACCOUNT'; 

    update variable_documents set value='90902810577100000535'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008227403))
    and name='CARD_ACCOUNT'; 

    update variable_documents set value='90902810877100000536'
    where (reference,branch) in (select reference,branch from documents doc where reference in (7008232666))
    and name='CARD_ACCOUNT';

    commit;
end;
/
     

