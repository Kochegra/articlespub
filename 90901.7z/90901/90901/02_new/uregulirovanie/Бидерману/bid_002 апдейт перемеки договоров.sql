select * from tmp_tables.tmp_gdm_bid where from_table='ACC_UPD_K1'

Insert into tmp_tables.tmp_gdm_bid(reference,branch,value,from_table)
Select 
reference,branch,code,'ACC_UPD_K1' -- ��� ���������
from TMP_TABLES.TMP_GDM_90901 
where code='90902810406260104798'


with tab as (
    select a.*,acc.open_date,acc.close_date,acc.bal,acc.header,acc.code,acc.currency,acc.name,acc.client,acc.branch_client,acc.contract,acc.branch_contract,c.type_doc,c.status,c.account,c.assist
    from tmp_tables.tmp_gdm_bid a 
    left join account acc
        on a.reference=acc.reference and a.branch=acc.branch
            left join contracts c
                on acc.contract=c.reference and acc.branch_contract=c.branch
    where a.from_table='ACC_UPD_K1'
    )
--select 'update contracts set assist='||nvl2(assist,''''||assist||'''','null')||',currency='||nvl2(assist,''''||substr(assist,6,3)||'''','null')||' where reference='||reference||' and branch='||branch||';' upd_bid,a.* from tab a    
select 'delete from variable_contracts where reference='||contract||' and branch='||branch_contract||' and instr(name,''CARD_ACCOUNT'')>0;' upd_bid, a.* from tab a
union all
select 'commit;' upd_bid, a.* from tab a
union all
select 
'insert into variable_contracts(name,reference,branch,subnumber,rownumber,colnumber,value,subfield,id) values('''||vc.name||''','||vc.reference||','||vc.branch||','||vc.subnumber||','||vc.rownumber||','||vc.colnumber||','''||vc.value||''','
    ||nvl2(vc.subfield,''''||vc.subfield||'''','null')||','||vc.id||');' upd_bid, 
a.*--,vc.* 
from tab a, variable_contracts vc where a.contract=vc.reference and a.branch_contract=vc.branch and instr(vc.name,'CARD_ACCOUNT')>0 and instr(vc.name,'#')=0 and substr(vc.name,1,1)<>'_' and substr(vc.name,1,1)<>'-' and instr(vc.name,'OLD')=0 and instr(vc.name,'MIGR')=0
union all
select 'commit;' upd_bid, a.* from tab a



select 'insert into variable_contracts(name,reference,branch,subnumber,rownumber,colnumber,value,subfield,id) values('''||name||''','||reference||','||branch||','||subnumber||','||rownumber||','||colnumber||','''||value||''','||nvl2(subfield,''''||subfield||'''','null')||','||id||');' upd_bid
--,nvl2(subfield,''''||subfield||'''','null')
--,a.* 
from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_BID where from_table='contracts')
and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0
union all
select 'commit;' from dual





