select rowid,a.* from tmp_tables.TMP_GDM_90901 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
and a.code='90901810900001027188'

select rowid,a.* from tmp_tables.TMP_GDM_90902 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)


-- ������� ���������� ��� ��������������
select distinct contract,branch_contract 
from (
select a.* from tmp_tables.TMP_GDM_90901 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
union all
select a.* from tmp_tables.TMP_GDM_90902 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
)
where nvl(info_1,'0')='0'
order by contract



select distinct contract,branch_contract 
from tmp_tables.TMP_GDM_90901 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)


union all
select a.* from tmp_tables.TMP_GDM_90902 a
where a.close_date is null and nvl(a.contract,0)!=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
)
where nvl(info_1,'0')='0'
order by contract
