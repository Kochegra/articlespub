-- ��� ���������
--and exists(select null from account where he--Insert into tmp_tables.tmp_gdm_bid(reference,branch,value,from_table)
Select 
--reference,branch,assist,'contracts' -- ��� ���������
--'reference='||reference||' and branch='||branch upd,
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2,
(select sum(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)--*pledger.WCOURSE(substr(a.code,6,3), SysDate)
    ) from account a where contract=c.reference and branch_contract=c.branch and bal in ('90902','90901') and close_date is null) sum_sal_acc909,
(select count(*) from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3)) cnt_90902,    
c.* 
from contracts c where assist like '90902%' 
and status=50
and substr(c.account,1,3) not in ('421') and substr(c.account,1,5) not in ('40506','40606','40706','40825')
and exists(select null from account where header='C' and code=c.assist and close_date is not null)
--and type_doc in (94,590)
and type_doc not in (976,5787,5788,6833,7302,12575,12579,12580,12582,13913)
--and not exists(select null from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3))
--header='C' and code=c.assist and bal='90902' and nvl(contract,0)=0 and nvl(branch_contract,0)=0 and close_date is not null)
--and assist='90902810400630003946'


Select 
--reference,branch,assist,'contracts' -- ��� ���������
--'reference='||reference||' and branch='||branch upd,
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2,
(select sum(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)--*pledger.WCOURSE(substr(a.code,6,3), SysDate)
    ) from account a where contract=c.reference and branch_contract=c.branch and bal in ('90902','90901') and close_date is null) sum_sal_acc909,
(select count(*) from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3)) cnt_90902,    
c.* 
from contracts c where assist like '90902%' 
and status=50
and substr(c.account,1,3) not in ('421') and substr(c.account,1,5) not in ('40506','40606','40706','40825')
and exists(select null from account where header='C' and code=c.assist and close_date is not null)
and type_doc in (94,590)
and type_doc not in (976,5787,5788,6833,7302,12575,12579,12580,12582,13913)
--and not exists(select null from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3))
--header='C' and code=c.assist and bal='90902' and nvl(contract,0)=0 and nvl(branch_contract,0)=0 and close_date is not null)
--and assist='90902810400630003946'


select * from types where type_id in (94,590,976,5787,5788,6833,7302,12575,12579,12580,12582,13913)

select rowid,a.* from TMP_TABLES.TMP_GDM_BID a



-- ������ ������ �� �������� ������
/
declare
rCont contracts%rowtype;
begin
    for rec in (
    
Select 
--'reference='||reference||' and branch='||branch upd,
p_k2.get_Rest_K2_Acc(c.account,sysdate) sum_acc_k2,
(select sum(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)--*pledger.WCOURSE(substr(a.code,6,3), SysDate)
    ) from account a where contract=c.reference and branch_contract=c.branch and bal in ('90902','90901') and close_date is null) sum_sal_acc909,
(select count(*) from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3)) cnt_90902,    
c.* from contracts c where assist like '90902%' 
and status=50
and substr(c.account,1,3) not in ('421') and substr(c.account,1,5) not in ('40506','40606','40706','40825')
and exists(select null from account where header='C' and code=c.assist and close_date is not null)
and type_doc in (94,590)
and type_doc not in (976,5787,5788,6833,7302,12575,12579,12580,12582,13913)
--and not exists(select null from account where header='C' and code<>c.assist and bal='90902' and contract=c.reference and branch_contract=c.branch and close_date is null and substr(code,6,3)=substr(c.assist,6,3))
--and exists(select null from account where header='C' and code=c.assist and bal='90902' and nvl(contract,0)=0 and nvl(branch_contract,0)=0 and close_date is not null)    
--and assist='90902810200437026737'
--and rownum<101
   
    
    )loop
        if Universe.get_contract_rec(rf => rec.reference, br => rec.branch, stat => null, acc => null, tp => null, contracts_rec => rCont) then
            dbms_output.put_line(rCont.assist);
            UNIVERSE.INPUT_VAR_CONTR(rCont.branch, rCont.reference, '#GDM_ASSIST', rCont.assist);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            update contracts set assist=null,assist_currency=null where reference=rCont.reference and branch=rCont.branch; -- and status=50 and date_close is null;
            commit;
            -- ������ variable_contracts
            update variable_contracts set name='#GDM_'||name where reference=rCont.reference and branch=rCont.branch
                and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0 and value=rCont.assist;
            commit;
            delete from tmp_tables.tmp_gdm_vc where reference=rCont.reference and branch=rCont.branch
                and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0 and value=rCont.assist;
            commit;
            delete from tmp_tables.tmp_gdm_vc_2 where reference=rCont.reference and branch=rCont.branch
                and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0 and value=rCont.assist;
            commit;
          
        end if;

    end loop;

end;

/
