select 
p_k2.get_Rest_K2_Acc(a.account,sysdate) sum_acc_k2,
--UNIVERSE.VARIABLE_CONTRACT(a.branch,a.reference, 'CARD_ACCOUNT_2_840') aaa,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.assist) and code=a.assist and currency=substr(a.assist,6,3)) acc_909_close,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
--(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--rowid,a.* from contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902810912060009024'))
--rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902810912060009024'))
--rowid,a.* from contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('90901840500551000025')) --and assist='90902810310248020058'
--rowid,a.* from contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc where value in ('90902810800760002909')) --and assist='90902810310248020058'
--rowid,a.* from contracts a where assist='90901978411091000054' --or related=27453017--account in ('42102810219800000022')
--rowid,a.* from contracts a where account in ('40802810606260004175','40802810010380004175')
--where reference in (17701643,17726673)
rowid,a.* from contracts a where account in ('40702978306800000318')--'40702810320380012782','40702978620380052782')



select 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)/**pledger.WCOURSE(substr(a.value,6,3), SysDate)*/ sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840410510000016'))
--rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840600004300016'))
--rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in (
--'90902810400390000014'
--))
--rowid,a.* from tmp_tables.tmp_gdm_vc a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902 where code in ('90901840500551000025'))
--rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from account where header='A' and code in ('40702810211090000054','40702978111090000054'))
--rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from account where header='C' and code in ('90902978920380007782'))
--rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('90902840710510001016')) --and assist='90902810310248020058'
--rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc where value in ('90901810200321000404')) --and assist='90902810310248020058'
--rowid,a.* from tmp_tables.tmp_gdm_vc a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc where value in ('90902840103300002382')) --and assist='90902810310248020058'
--rowid,a.* from variable_contracts a where reference in (17701643) and branch=780
rowid,a.* from variable_contracts a where reference in (23634519,23634579,23634601) and branch=240
and (instr(name,'CARD_ACCOUNT')>0 or instr(name,'ASSIST')>0) 

23634519
23634579
23634601


select 
abs(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--rowid,a.* from account a where code in ('90901810200321000404') --and header='C'
--rowid,a.* from account a where code in ('90901810825360000002','90901810125360000003','90902810006260004175','90902810410380004175') and header='C'
--rowid,a.* from account a where code in ('90902978820380000782','90902978920380007782') and header='C'
--rowid,a.* from account a where (contract,branch_contract) in (select contract,branch_contract from account a where code in ('90901978411091000054') and header='C') --and bal in ('90902','90901','40702') --order by code
--rowid,a.* from account a where (contract,branch_contract) in (select contract,branch_contract from account a where code in ('40702810211090000054','40702978111090000054') and header='A') --and bal in ('90902','90901','40702','40701') 
----and code in ('90901978411091000054')
--and close_date is null
--order by code
--rowid,a.* from account a where contract in (25527676) and branch_contract=635 and bal in ('90902','90901','40702')
rowid,a.* from account a where (client,branch_client) in (select client,branch_client from account a where code in ('40702810211090000054','40702978111090000054') and header='A')

90902810077100000514

select * from users where user_id=61648

select rowid,a.* from tmp_tables.tmp_gdm_90901 a where code in ('90902840410510000016')

select * from contracts 
where reference in (31279740) and branch=360 --type_doc in (1620) and status=50

select rowid,a.* from variable_contracts a where reference in (31279740) and branch=360

select 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
rowid,a.* from TMP_TABLES.TMP_GDM_VC_2 a 
--where trim(value) in ('90902810801950001010')
where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('90902156202000100001'))


select count(*) 
from TMP_TABLES.TMP_GDM_90902_2 
where status=0 

90902810310248020058





