-- �������� �������
select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a

delete from TMP_TABLES.TMP_GDM_90902_2

/
-- ������ �� ��������
insert into TMP_TABLES.TMP_GDM_90902_2(HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT)
    select HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT 
    from account a 
    where header='C' and code like '90902%'
        and close_date is null
        --and nvl(client,0)<>0 
        --and nvl(contract,0)<>0
        --and code='90901124023461000172'

/


-- ������������, �������� ������
select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a

-- ���� ������ 0
-- ������ -1 �������������� �� ��������� 
--update TMP_TABLES.TMP_GDM_90902_2 set status=0
update TMP_TABLES.TMP_GDM_90902_2 set status=-1
--select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
where nvl(contract,0)=0


-- ��������� ��������� ���������
insert into TMP_TABLES.TMP_GDM_VC_2
select * from variable_contracts 
where
instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0


select distinct type_doc,type_cont from (
select 
universe.nametype(a.type_doc) type_cont,
a.* from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0) 
)

94           ��������-�������� ������������
----326         ������� �� ����� ���� 
590         ����.����.����
--1620      ��������� ����������
--3709      ������� �� ��� ���������� � ���������� ������
5787      ���.����.����� ������. ������
5788      ���.����.����� ������. ����������
--6771      ������ �������� (�������� ����)
--6774      ������ ��������
--6776      ����������� ���������� �� ��������� ��
--6777      ����������� ���������� �� ������������� ���������
6833      ���.����.����� ������.������.������
7298      ���. ����� ���. ������� ���
7302      ���. ����� ���. ������� ��
7323      ���.����.����� ������.���������
7621      ������� �� ������������ ���/��/��(185-��)
-------------12306    ���. �������� �� ������ ���
12457    ������� �������� �� � ��� (44��)
12575    ��� ����������� - �����������
12579    ���. ��������� ����
12580    ���. ����������� ����
12581    ���. ������. ���������� ���� ����� � ���� �������
12582    ���. ���� �������������� ����������
12583    ���. ����������� ������������ ����
12606    ���. ���� ������
--13472    ������� �/�. �������������
13913    ���. ����������� ���������� ���� ��������
13952    ���. ����.���� ��� 1 (���������� �����)
13953    ���. ����.���� ��� 2(���� �����-� �����.������-�)
----14116    ����������� ������ ��������
--14390    ������������� ���� "������� ��� �������"

-- �������� ������ ����� � �������� ���������
-- ��� ��� ����� �������, �� ������� �� ����� 100% ��������
select 
universe.nametype(a.type_doc) type_cont,
a.* from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0)
and type_doc in (12306)--326,1620,3709,6771,6774,6776,6777,12306,13472,14116,14390) 

delete from TMP_TABLES.TMP_GDM_90902_2 a where status=0
--update TMP_TABLES.TMP_GDM_90902_2 a set status=-2 where status=0
--select * from TMP_TABLES.TMP_GDM_90902_2 a where status=0 
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and type_doc in (326,1620,3709,6771,6774,6776,6777,13472,14116,14390))
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and type_doc in (12306))
    and not exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code)
    and not exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

-- �������� �� ������� ����� ���
delete from TMP_TABLES.TMP_GDM_90902_2 a where status=0
--select * from TMP_TABLES.TMP_GDM_90902_2 a where status=0 
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and substr(account,1,3) in (/*'421',*/'303','301','302'))
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and substr(account,1,3) in ('421'))
    and not exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code)
    and not exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

delete from TMP_TABLES.TMP_GDM_90902_2 a where status=0
--select * from TMP_TABLES.TMP_GDM_90902_2 a where status=0 
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and substr(account,1,3) in ('303','301','302'))
    --and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and substr(account,1,3) in ('303','301','302'))
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and substr(account,1,3) in ('421'))
    and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and substr(account,1,3) in ('421'))
    and exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

--delete from TMP_TABLES.TMP_GDM_90902_2 a where status=0
select * from TMP_TABLES.TMP_GDM_90902_2 a where status=0 
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 a where status=0 ) and substr(account,1,5) in ('40506','40606','40706','40825'))
    --and not exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code)
    --and not exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

-- �������� ����������� �� ���/�� 
-- � ����������, ��� �������� � �������� ������ ���������

-- ������� ���� (�� ��� ��������)
select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
where status=0
and exists(select null from contracts where reference=a.CONTRACT and branch=a.branch_contract and assist=a.code and status not in (1001))
and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and status not in (1001,60) and type_doc not in (8402,7957,30171))

select ''''||a.code||'''',a.*,c.* from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and exists(select null from contracts where reference=a.CONTRACT and branch=a.branch_contract and assist=a.code and status not in (1001))
and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and status not in (1001,60) )--and type_doc not in (8402,7957,30171))


select rowid, 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.account) and code=a.account and currency=substr(a.account,6,3)) acc_rko_close,-- and close_date is not null)
a.* from contracts a where assist in (
--'90902810404240002090'
--'90902810500727022824'
--'90902810510610008220'
--'90902810627000000161'
--'90902810777010001770'
)
order by assist

select rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from contracts a where assist in ('90902810100000201759'))
and instr(name,'CARD_ACCOUNT')>0 

select rowid,a.* from account a where code in ('90902810100000201759','90902810600020000384')

select rowid,a.* from tmp_tables.tmp_gdm_90902_2 a where code in ('90902810404240002090','90902810500727022824','90902810510610008220','90902810627000000161','90902810777010001770') -- ������

select rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where value in ('90902810404240002090','90902810500727022824','90902810510610008220','90902810627000000161','90902810777010001770') 

--�������� ��� �������� � ������� � ��� � ���������� ������ ���������
delete from TMP_TABLES.TMP_GDM_90902_2 a
--select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
where status=0
and exists(select null from contracts where reference=a.CONTRACT and branch=a.branch_contract and assist=a.code and status not in (1001,60) and type_doc not in (8402,7957,30171))
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)


-- �������, ��� ��������
--select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
--where status=0
--and code in (
select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,c.assist,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902124030000000224'
--1
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')<>a.code--='#'--<>a.code - 2 ��������
--and nvl(c.assist,'#')=a.code--=a.code--='#' --<>'#' -- 3 �������
--2
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(c.assist,'#')='#'--=a.code
--3
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(c.assist,'#')<>a.code
--4
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'--<>a.code
--and nvl(c.assist,'#')='#'--<>a.code
--5
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')<>a.code
--and nvl(c.assist,'#')<>'#'
--6 ���������� � ������� ����������� (� name �� ��������� ������)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--7
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3_')>0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')='#'-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'
--8
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3_')>0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')='#'-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'
--and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0
--9 ������ ��������
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3_')>0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')='#'-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'
--and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0
--10 ��� � ���������
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
----and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2' and substr(value,6,3)='810')-- and instr(name,'CARD_ACCOUNT_2_')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_2_')>0 and substr(value,6,3)=substr(a.code,6,3))
----and nvl(c.assist,'#')<>a.code --
--and substr(nvl(c.assist,'#'),6,3)='810'--<>substr(a.code,6,3) --'810'
--11 �����������
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2')-- and substr(value,6,3)='810')-- and instr(name,'CARD_ACCOUNT_2_')=0)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2_'||substr(a.code,6,3) and value=a.code)--and instr(name,'CARD_ACCOUNT_2_810')=0)-- and value<>a.code)--and substr(value,6,3)=substr(a.code,6,3))
--and nvl(c.assist,'#')<>a.code --
--and substr(nvl(c.assist,'#'),6,3)='810'--<>substr(a.code,6,3) --'810'
--and a.code not in ()
--and p_k2.get_Rest_K2_Acc(c.account,sysdate)=0
--and instr(name,'CARD_ACCOUNT_2')=0
--)

select 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840801540000022'))
and instr(name,'CARD_ACCOUNT')>0 


-- �������� ��������, ��� ��������� ��������� � ��� ����� � ���������� ������ ���������, ��� �������� ������, � � ��������� ��� � ������ ���� ���������
delete from TMP_TABLES.TMP_GDM_90902_2 a
--select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
where status=0
and code in (
select --''''||a.code||'''',
a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--old
--and a.code='90902978011030001316'
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2')-- and substr(value,6,3)='810')-- and instr(name,'CARD_ACCOUNT_2_')=0)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2_'||substr(a.code,6,3) and value=a.code)--and instr(name,'CARD_ACCOUNT_2_810')=0)-- and value<>a.code)--and substr(value,6,3)=substr(a.code,6,3))
)

select --''''||a.code||'''',
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902124030000000224'
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2')-- and substr(value,6,3)='810')-- and instr(name,'CARD_ACCOUNT_2_')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2_'||substr(a.code,6,3) )--and instr(name,'CARD_ACCOUNT_2_810')=0)-- and value<>a.code)--and substr(value,6,3)=substr(a.code,6,3))
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)

-- ��� �� ���������� ������ ������ CARD_ACCOUNT_2, ��������� ������ � CARD_ACCOUNT_2_���
-- ������ ����� ���������
/
declare 
begin
    for rec in (
    
            select --''''||a.code||'''',
            --a.code
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
            --PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
            a.*,c.account,c.assist assist_c
            from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
            where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
            and substr(a.code,6,3)<>'810'
            --and a.code='90902978642260000019'
            --and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
            --and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
            --and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code
            --and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2')-- and substr(value,6,3)='810')-- and instr(name,'CARD_ACCOUNT_2_')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_2_'||substr(a.code,6,3) )--and instr(name,'CARD_ACCOUNT_2_810')=0)-- and value<>a.code)--and substr(value,6,3)=substr(a.code,6,3))
    
    )loop
--            update contracts set assist=rec.code,assist_currency=rec.currency where reference=rec.contract and branch=rec.branch_contract and assist is null;
                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
            -- ��� ����������� ����� ������ CARD_ACCOUNT_2 � CARD_ACCOUNT_2_val
            --delete from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --
            
--            update variable_contracts set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;

            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.code,6,3), rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code
                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code));
            commit;
--            -- �� ������� � ��������� � �������� ������
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3), rec.assist_c);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c));
--            commit;
--            update contracts set assist=null,assist_currency=null where reference=rec.contract and branch=rec.branch_contract;
--            commit;
            

            
    end loop;
end;
/
/
declare
begin
    for rec in (
    
    select rowid,vc.* from variable_contracts vc where (reference,branch,value) in (
select 
c.reference,c.branch,a.code
----a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902124030000000224'
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3_')>0 and instr(name,'CARD_ACCOUNT_1')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')='#'-- not in ('#',a.code)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)
)
and not exists(select null from variable_contracts where reference=vc.reference and branch=vc.branch and instr(name,'CARD_ACCOUNT_2_')>0)

    )loop
        update variable_contracts set name='CARD_ACCOUNT_2_'||substr(rec.value,6,3) where reference=rec.reference and branch=rec.branch and name='CARD_ACCOUNT_3_RUR' and value=rec.value
            and not exists(select null from variable_contracts where reference=rec.reference and branch=rec.branch and name='CARD_ACCOUNT_2_'||substr(rec.value,6,3));
        commit;
        -- �������� ������ ��������
        update tmp_tables.tmp_gdm_vc_2 set name='CARD_ACCOUNT_2_'||substr(rec.value,6,3) where reference=rec.reference and branch=rec.branch and name='CARD_ACCOUNT_3_RUR' and value=rec.value
            and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.reference and branch=rec.branch and name='CARD_ACCOUNT_2_'||substr(rec.value,6,3));
        commit;
        dbms_output.put_line(rec.name||' '||rec.value);
    
    end loop;

end;

/

-- ������ ������

select vc.* from variable_contracts vc where (reference,branch,value) in (

select 
--c.reference,c.branch,a.code
----a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902124030000000224'
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')='#'--a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'--a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1'),'#')=a.code
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)

)
and not exists(select null from variable_contracts where reference=vc.reference and branch=vc.branch and instr(name,'CARD_ACCOUNT_2_')>0)

-- ������� ������� � ��������� ����������  'CARD_ACCOUNT_1' + ��������� ������� �� �2

select 
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840312250000212'))
--rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840312250000212'))
and instr(name,'CARD_ACCOUNT')>0 

select rowid,a.* from account a where code in ('90902840008030000005','90902840809030000864')

select rowid,a.* from tmp_tables.tmp_gdm_90902 a where code in ('90902840008030000005','90902840809030000864')



---------------

select --''''||a.code||'''',
--a.code
nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#') CARD_ACCOUNT_2,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902124030000000224'
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')<>a.code-- ='#'
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)

/
declare
begin
    for rec in (
    
select --''''||a.code||'''',
--a.code
nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#') CARD_ACCOUNT_2,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.account,c.assist assist_c 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
--and a.code='90902156100020009077'
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')='#'--<>a.code
--and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3))-- and close_date is null)

    )loop
        UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.code,6,3), rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
        commit;
        insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code
            and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code));
        commit;
        
    
    end loop;

end;

/

-- ������� �������� ��� ��������
-- + ������ �������������

select --''''||a.code||'''',
--a.code
nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#') CARD_ACCOUNT_2,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810' and c.assist is not null
and a.code='90902810209240000310'





-----******************
-- ��������� � ������
--delete from TMP_TABLES.TMP_GDM_90902_2 a
select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,
(select close_date from account where header='C' and code=c.assist) close_909,
c.assist,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)) CARD_ACCOUNT_2_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.assist,6,3)) CARD_ACCOUNT_2_val,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
(select close_date from account where header='C' and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2')) close_909,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_RUR') CARD_ACCOUNT_2_RUR,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810'
--and a.code='90902124030000000224'
--1
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code or nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)
--and nvl(c.assist,'#')=a.code
--2
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
----and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code or nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
--and nvl(c.assist,'#')='#' --a.code--=a.code--='#' --<>'#' -- 3 �������
--and substr(c.ACCOUNT,6,3)='810'
--3 
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
--and nvl(c.assist,'#')='#' --a.code--=a.code--='#' --<>'#' -- 3 �������
--and substr(c.ACCOUNT,6,3)<>'810'
--3 
and  not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and name<>'CARD_ACCOUNT_2' and name<>'CARD_ACCOUNT_2_810')
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)),'#')<>c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code 
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)<>substr(a.code,6,3)
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)=substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#'),6,3)='#' --substr(c.account,6,3)
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')='#' and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
and nvl(c.assist,'#')<>a.code--=a.code--='#' --<>'#' -- 3 �������
--and substr(c.ACCOUNT,6,3)<>'810'
--and exists(select null from account where header='C' and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') and close_date is not null)
--and exists(select null from account where header='C' and code=c.assist and close_date is not null)
--and exists(select null from account where header='C' and code=a.code and close_date is not null)
--)



-- �������� ��������
delete from TMP_TABLES.TMP_GDM_90902_2 a
--select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a
where status=0
and code in (
select --''''||a.code||'''',
a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
--and substr(a.code,6,3)='810'
--old
and a.code in ('90901810400051000066')
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
----and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code or nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
--and nvl(c.assist,'#')=a.code--=a.code--='#' --<>'#' -- 3 �������
)

/
declare
begin
    for rec in (
    
    select a.* from TMP_TABLES.TMP_GDM_90902_2 a
where status=0
and code in (
select --''''||a.code||'''',
a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810'
--old
--and a.code='90902978011030001316'
--3 
and  not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and name<>'CARD_ACCOUNT_2' and name<>'CARD_ACCOUNT_2_810')
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)),'#')<>c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code 
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)<>substr(a.code,6,3)
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)=substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#'),6,3)='#' --substr(c.account,6,3)
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')='#' and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
and nvl(c.assist,'#')='#'--a.code--=a.code--='#' --<>'#' -- 3 �������
and substr(c.ACCOUNT,6,3)<>'810'
)

    
    )loop
        delete from TMP_TABLES.TMP_GDM_90902_2 a where code=rec.code and reference=rec.reference and branch=rec.branch;
        commit;
        dbms_output.put_line(rec.code); 
    end loop;

end;


/


declare 
begin
    for rec in (
    
            select --''''||a.code||'''',
            --a.code
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val,
            --PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
            a.*,c.account,c.assist assist_c
            from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
            where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
            and substr(a.code,6,3)='810'
            --and a.code='90902810300000013844'
and  not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and name<>'CARD_ACCOUNT_2' and name<>'CARD_ACCOUNT_2_810')
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)),'#')<>c.assist --substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=c.assist --substr(c.account,6,3)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')='#'--a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code 
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)<>substr(a.code,6,3)
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#'),6,3)=substr(c.account,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#'),6,3)='#' --substr(c.account,6,3)
--and (nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')='#' and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810'),'#')=a.code)--='#'--<>a.code - 2 ��������
and nvl(c.assist,'#')='#'--a.code--=a.code--='#' --<>'#' -- 3 �������
and substr(c.ACCOUNT,6,3)<>'810'


    
    )loop
--            update contracts set assist=rec.code,assist_currency='810' /*substr(rec.assist_c,6,3)*/ where reference=rec.contract and branch=rec.branch_contract;-- and assist_currency is null;
                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update variable_contracts set name=name||'_'||substr(rec.card_account_2,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.card_account_2
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.card_account_2,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.card_account_2,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.card_account_2
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.card_account_2,6,3));
--            commit;


--            update contracts set assist=rec.code,assist_currency=rec.currency where reference=rec.contract and branch=rec.branch_contract and assist is null;
--                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
           -- ��� ����������� ����� ������ CARD_ACCOUNT_2 � CARD_ACCOUNT_2_val
            --delete from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --
            
--            update variable_contracts set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;

--            update variable_contracts set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value=rec.code);
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810'  and value=rec.code);
--            commit;

            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value = rec.code
                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value = rec.code));
            commit;
--
            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_810', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code
                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code));
            commit;

--            -- �� ������� � ��������� � �������� ������
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3), rec.assist_c);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c));
--            commit;
--            update contracts set assist=null,assist_currency=null where reference=rec.contract and branch=rec.branch_contract;
--            commit;
            

            
    end loop;
end;
/




-- ���
select 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a where instr(name,'CARD_ACCOUNT_2')>0 and substr(value,1,5)<>'90902'


-- �������� � ���� � ����
select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)='90902'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is not null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)

--delete from variable_contracts aa where (reference,branch,value,id) in
--delete from tmp_tables.tmp_gdm_vc_2 aa where (reference,branch,value,id) in
select aa.* from variable_contracts aa where (reference,branch,value,id) in 
 (select reference,branch,value,id 
--rowid,
--(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
--                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
--                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
--(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--a.* 
from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)='90902'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is not null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)
)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where name like 'CARD_ACCOUNT_2%' and value=aa.value)


-- �������
--delete from variable_contracts aa where (reference,branch,value,id) in
--select aa.* from variable_contracts aa where (reference,branch,value,id) in 
 --(
 select --reference,branch,value,id 
rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* 
from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)='90902'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is not null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)
--)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where name like 'CARD_ACCOUNT_2%' and value=aa.value)



-- **********************
-- ��������� ������������� � ���������

select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,
(select close_date from account where header='C' and code=c.assist) close_909,
c.assist,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)) CARD_ACCOUNT_2_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.assist,6,3)) CARD_ACCOUNT_2_val,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
(select close_date from account where header='C' and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2')) close_909,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_RUR') CARD_ACCOUNT_2_RUR,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=-2 and a.contract=c.reference and a.branch_contract=c.branch

-- ������ ������������� � �������� ���������
select rowid,--''''||a.code||''',',
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
(select close_date from account where header='C' and code=a.code) close_909,
(select count(*) from tmp_tables.tmp_gdm_vc_2 where value=a.code) cnt_vc,
a.* 
from TMP_TABLES.TMP_GDM_90902_2 a
where a.status=-1 
--        and(
--            (COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
--                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY'))
--            )=to_date('01.01.1900','dd.mm.yyyy'))



-- ��������
select rowid,--''''||a.code||''',',
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
(select close_date from account where header='C' and code=a.code) close_909,
(select count(*) from tmp_tables.tmp_gdm_vc_2 where value=a.code) cnt_vc,
a.* 
from TMP_TABLES.TMP_GDM_90902_2 a
where a.status=-2 
--        and(
--            (COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
--                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY'))
--            )=to_date('01.01.1900','dd.mm.yyyy'))
