select ''''||a.code||''',',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,--c.assist,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1') CARD_ACCOUNT_1,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1_'||substr(a.code,6,3)) CARD_ACCOUNT_1_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15_'||substr(a.code,6,3)) CARD_ACCOUNT_15_val,
''''||UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3')||''',' CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810') CARD_ACCOUNT_3_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)) CARD_ACCOUNT_3_val,
----UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)) CARD_ACCOUNT_3_val,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal_code,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate+17)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal_code_7,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and nvl(a.info_1,'#')<>'#'
and nvl(a.info_1,'#')=' �15_������'
--and nvl(a.info_1,'#')='�1_������_2'
--and nvl(a.info_1,'#')='�1_������_2 �15_������'
--and UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3')=a.code


and substr(a.code,6,3)='810'
--and substr(a.code,6,3)<>'810'
and substr(c.account,6,3)='810'

--1 ������� ���������, ��� ���� ������ � ��������� ��� �1������ � �1�����. �������� �������� �1, ��������� �� ���� �������, �������� ������
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)





















-- ������ 90902
select ''''||a.code||''',',
(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) acc_RKO_close,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,c.assist,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val_CODE,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)) CARD_ACCOUNT_2_val_ACCOUNT,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal_ass,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal_code,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate+17)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal_code_7,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
--and code='90902840829430006875'
--and substr(a.code,6,3)<>'810'
and a.code<>nvl(c.assist,'#')
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and c.status<>60

-- 
--and c.assist is null
and substr(a.code,6,3)<>'810'
and substr(c.account,6,3)<>'810'
and substr(a.code,6,3)=substr(c.account,6,3)
--and UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) is null
--and UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3))=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2')
--and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0
--and PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate+7)*pledger.WCOURSE(substr(a.code,6,3), SysDate)=0


/


declare 
begin
    for rec in (
    
select --''''||a.code||'''',
(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) acc_RKO_close,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,c.assist assist_c,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2') CARD_ACCOUNT_2,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_810') CARD_ACCOUNT_2_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val_CODE,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.account,6,3)) CARD_ACCOUNT_2_val_ACCOUNT,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(c.assist,6,3)) CARD_ACCOUNT_2_val_ASSIST,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*--,c.* 
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and code in ('90902810801140023251')
----and substr(a.code,6,3)<>'810'
--and a.code<>nvl(c.assist,'#')
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and c.status<>60
---- 
--and c.assist is null
--and substr(a.code,6,3)='810'
--and substr(c.account,6,3)='810'


    
    )loop
            update contracts set assist=rec.code,assist_currency=substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract;-- and assist_currency is null;
               --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
            commit;
--            update variable_contracts set name=name||'_'||substr(rec.card_account_2,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.card_account_2
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.card_account_2,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.card_account_2,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.card_account_2
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.card_account_2,6,3));
--            commit;


--            update contracts set assist=rec.code,assist_currency=rec.currency where reference=rec.contract and branch=rec.branch_contract and assist is null;
--                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
           -- ��� ����������� ����� ������ CARD_ACCOUNT_2 � CARD_ACCOUNT_2_val
            --delete from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --
            
--            update variable_contracts set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;

--            update variable_contracts set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value=rec.code);
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810'  and value=rec.code);
--            commit;

--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.code,6,3), rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3) and value = rec.code));
--            commit;
          --UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_840', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_840' and value = rec.code
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_840' and value = rec.code));
--            commit;
--
            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_810', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code
                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code));
            commit;
--
----            -- �� ������� � ��������� � �������� ������
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3), rec.assist_c);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c));
--            commit;
--            update contracts set assist=null,assist_currency=null where reference=rec.contract and branch=rec.branch_contract;
--            commit;
            

            
    end loop;
end;
/
