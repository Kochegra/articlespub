-- ����������� ���������

select rowid,a.* from TMP_TABLES.TMP_GDM_VC a 
where exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)


        select
            (select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
            a.* 
        from TMP_TABLES.TMP_GDM_VC a
        where 
        exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
        and exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
        --and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
        --and value='90902810300087021257'
        --and rownum<=500

-- ��� ���������
Insert into tmp_tables.tmp_gdm_bid(reference,branch,value,from_table)
select
reference,branch,value,'vc_2' -- for bider
--(select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
--a.* 
from TMP_TABLES.TMP_GDM_VC a
--,contracts c
where 
        exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
        and exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
        --and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
        --and value='90902810300087021257'
        --and rownum<=500
        
--������
/
declare 
rCont contracts%rowtype;
begin   
    for rec in (
    
        select
            (select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
            a.* 
        from TMP_TABLES.TMP_GDM_VC a
        where 
        exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
        and exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
        --and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
        --and value='90902810300087021257'
        --and rownum<=500
    
    )loop
        if Universe.get_contract_rec(rf => rec.reference, br => rec.branch, stat => null, acc => null, tp => null, contracts_rec => rCont) then
            -- ������ variable_contracts
            update variable_contracts set name='#GDM_'||name where reference=rCont.reference and branch=rCont.branch
                --and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0 and value=rec.value;
                and name=rec.name and value=rec.value and id=rec.id;
            commit;
            delete from TMP_TABLES.TMP_GDM_VC where reference=rec.reference and branch=rec.branch and name=rec.name and value=rec.value and id=rec.id;
            commit;
            delete from TMP_TABLES.TMP_GDM_VC_2 where reference=rec.reference and branch=rec.branch and name=rec.name and value=rec.value and id=rec.id;
            commit;
            dbms_output.put_line(rec.value||' '||rCont.reference||' '||rCont.branch);
        else
            dbms_output.put_line('�� ������� '||rec.value);
        end if;
    end loop;

end;
/


-- ���� �� ������ � ���� ����
select
--reference,branch,value,'vc_1' -- for bider
(select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
a.* 
from TMP_TABLES.TMP_GDM_VC_2 a
--,contracts c
where
exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and currency=substr(a.value,6,3) and (nvl(contract,0)=0 or nvl(branch_contract,0)=0)) 
--a.reference=c.reference and a.branch=c.branch and c.account is not null 
--and C.STATUS=50
--and 
--exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
--and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
and exists(select null from contracts where reference=a.reference and branch=a.branch and status=50)