-- �������� �1������
/
declare
nIsK1 number;

 function isK1(p_acc account.code%type) return number is
  rAcc account%rowtype;
  bCont boolean;
  rCont contracts%rowtype;
  nResCont number;
  nResContOther number;
  rDoc documents%rowtype;
  nJou number; -- ���-�� ��������
  nJou22 number; -- ���-�� ����� � 22 �������. ���� ����, �� ���������� �2
  nJouNo22 number; -- ���-�� ��������� ����� �� � 22 �������.
  nResJou number;
  nArch   number;
  nRes number;
 begin
    nRes:=0;
    --DBMS_OUTPUT.PUT_LINE(p_acc);
    
    -- �� ��������
    nResCont := 0;
    nResContOther := 0;

    if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(p_acc), cd => p_acc, cr=>substr(p_acc,6,3),account_rec => rAcc) then
        bCont:= Universe.get_contract_rec(rf => rAcc.contract, br => rAcc.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rCont);
        if bCont then
            -- K1 �� ��������
            for varCont in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch 
                                    and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=rAcc.code)
            loop
                nResCont:=1;
                exit;    
            end loop;
            
            -- ������ � �� �������� � ����� �� �����
            for varCont in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch 
                                    and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and instr(name,'#')=0 and value=rAcc.code)
            loop
                nResContOther:=1;
                exit;    
            end loop;
        end if;
    end if;
    
    --DBMS_OUTPUT.PUT_LINE('nResCont = '||nResCont||' nResContOther = '||nResContOther);    
    
    -- �� ���������
    -- �� ����������� ���������� � 22 �������
    nJou :=0; -- ���-�� ��������
    nJou22 :=0; -- ���-�� ����� � 22 �������. ���� ����, �� ���������� �2
    nJouNo22 :=0;
    for doc in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_acc) and code=p_acc
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(doc.reference, doc.branch, nArch, 1, rDoc) then
            for dK1 in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                        where payers_account is not null and type_doc in (225)
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                nJou:=nJou+1;
                if dK1.status=22 then
                    nJou22:=nJou22+1;
                else
--                    if nvl(UNIVERSE.VARIABLE_PART(rDoc.REFERENCE, rDoc.BRANCH, 'CARD_ACCOUNT1'),'#')=trim(p_acc) then
--                        nJouNo22 := nJouNo22+1;
--                    end if;
                    if nvl(UNIVERSE.VARIABLE_PART(rDoc.REFERENCE, rDoc.BRANCH, 'CARD_ACCOUNT1'),'#')<>'#' then
                        nJouNo22 := nJouNo22+1;
                    end if;

--                    for vDoc in (select * from v_variable_documents where reference=dK1.reference and branch=dK1.branch 
--                    and name in ('CARD_ACCOUNT1') and value='' 
--                    )
                end if;                
            end loop;
       end if;
    end loop;
   DBMS_OUTPUT.PUT_LINE(p_acc||'   nResCont = '||nResCont||' nResContOther = '||nResContOther||'    nJou = '||nJou||' nJou22 = '||nJou22||' nJouNo22 = '||nJouNo22);    
   --DBMS_OUTPUT.PUT_LINE('nJou22 = '||nJou22);    
   --DBMS_OUTPUT.PUT_LINE('nJouNo22 = '||nJouNo22);    
   
    if nJou=0 then
        if nResCont=1 and nResContOther=0 then
            nRes:=1;
        end if;
    end if;
    if nJou>0 then
        if nJou22>0 or nJouNo22>0 then
            nRes:=1;
        end if;
    end if;
    return nRes;
 end isK1;
begin
    for rec in (
    
select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,--c.assist,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1') CARD_ACCOUNT_1,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1_'||substr(a.code,6,3)) CARD_ACCOUNT_1_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15_'||substr(a.code,6,3)) CARD_ACCOUNT_15_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)) CARD_ACCOUNT_3_val,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.type_doc 
from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810'
--and a.code='90901810900530000595'--90901810600530000595
--1
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
and nvl(info_1,'#')='#'
    
    )loop
        nIsK1:=isK1(rec.code);
        if nIsK1=1 and 1=1 then -- ���� �1
            DBMS_OUTPUT.PUT_LINE('��� �1 - ��������');
            --DBMS_OUTPUT.PUT_LINE('-----');
            update tmp_tables.TMP_GDM_90901_2 set info_1='�1_������_2'
            where reference=rec.reference and branch=rec.branch and code=rec.code;
            commit;
        end if;
    end loop;

end;

/