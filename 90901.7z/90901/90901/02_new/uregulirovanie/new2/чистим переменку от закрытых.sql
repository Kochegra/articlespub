-- ����������� ���������

select rowid,a.* from TMP_TABLES.TMP_GDM_VC_2 a 
where length(value)<>20

--Insert into tmp_tables.tmp_gdm_bid(reference,branch,value,from_table)
Select 
reference,branch,value,'TMP_GDM_VC_2' -- ��� ���������
from TMP_TABLES.TMP_GDM_VC_2 
where length(value)<>20


select 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--rowid,a.* from variable_contracts a where (reference,branch,value) in (select reference,branch,value from tmp_tables.tmp_gdm_bid where from_table='TMP_GDM_VC_2')
rowid,a.* from variable_contracts a where reference in (20251968) and branch=631
--rowid,a.* from TMP_TABLES.TMP_GDM_VC_2 a where reference in (10151411) and branch=3
and (instr(name,'CARD_ACCOUNT')>0 or instr(name,'ASSIST')>0) 


select 
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--rowid,a.* from account a where code in ('90902810705250001162') and header='C'
--rowid,a.* from account a where code in ('90902810400720000244') and header='C'
rowid,a.* from account a where (contract,branch_contract) in (select contract,branch_contract from account a where code in ('90902840818000107416') and header='C') and bal in ('90902','90901','40702')
--rowid,a.* from account a where contract in (37860) and branch_contract=114 and bal in ('90902','90901','40702')


-- ��� ���������
--Insert into tmp_tables.tmp_gdm_bid(reference,branch,value,from_table)
select
--reference,branch,value,'vc_1' -- for bider
(select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
a.* 
from TMP_TABLES.TMP_GDM_VC_2 a
--,contracts c
where 
--a.reference=c.reference and a.branch=c.branch and c.account is not null 
--and C.STATUS=50
--and 
exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
--and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
and exists(select null from contracts where reference=a.reference and branch=a.branch and status=50)

--������
/
declare 
rCont contracts%rowtype;
begin   
    for rec in (
    
        select
            (select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
            a.* 
        from TMP_TABLES.TMP_GDM_VC_2 a
        where 
        exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
        --and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
        and exists(select null from contracts where reference=a.reference and branch=a.branch and status=50)
        --and value='90902810300087021257'
        --and rownum<=500
    
    )loop
        if Universe.get_contract_rec(rf => rec.reference, br => rec.branch, stat => null, acc => null, tp => null, contracts_rec => rCont) then
            -- ������ variable_contracts
            update variable_contracts set name='#GDM_'||name where reference=rCont.reference and branch=rCont.branch
                --and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0 and value=rec.value;
                and name=rec.name and value=rec.value and id=rec.id;
            commit;
            delete from TMP_TABLES.TMP_GDM_VC_2 where reference=rec.reference and branch=rec.branch and name=rec.name and value=rec.value and id=rec.id;
            commit;
            dbms_output.put_line(rec.value||' '||rCont.reference||' '||rCont.branch);
        else
            dbms_output.put_line('�� ������� '||rec.value);
        end if;
    end loop;

end;
/


-- ���� �� ������ � ���� ����
select
--reference,branch,value,'vc_1' -- for bider
(select close_date from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3)) cl_909,
a.* 
from TMP_TABLES.TMP_GDM_VC_2 a
--,contracts c
where
exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and currency=substr(a.value,6,3) and (nvl(contract,0)=0 or nvl(branch_contract,0)=0)) 
--a.reference=c.reference and a.branch=c.branch and c.account is not null 
--and C.STATUS=50
--and 
--exists(select null from account where header='C' and code=a.value and bal in ('90902','90901') and close_date is not null and currency=substr(a.value,6,3))
--and exists(select null from account where header='A' and code=c.account and close_date is null and currency=substr(c.account,6,3))
and exists(select null from contracts where reference=a.reference and branch=a.branch and status=50)