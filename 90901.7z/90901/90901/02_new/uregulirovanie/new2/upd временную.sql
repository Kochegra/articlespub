declare 
rContRko contracts%rowtype;
begin
    for rec in (
    
select 
abs(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
rowid,a.* from account a where code in (
--'90902810801250002230'
--'90902810211300000248'
--'90902810208020008313'
--'90902810756300103435'
--'90902810800760002909'-- 90901810100761003909
'90902810726241000067' --90901810132641000388
--'90902978800002500001'
--'90902810112490004020'
) and header='C'
    
    
    )loop
        if Universe.get_contract_rec(rf => rec.contract, br => rec.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rContRko) then
            -- �������� ��������
            delete from TMP_TABLES.TMP_GDM_VC where reference=rContRko.reference and branch=rContRko.branch;
            commit;
            insert into TMP_TABLES.TMP_GDM_VC
                select * from variable_contracts where reference=rContRko.reference and branch=rContRko.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0
                and instr(name,'NOT_OPEN')=0;
            commit;
        else
            dbms_output.put_line('����');
        end if;
    end loop;
end;
/


90902810801250002230
90902810211300000248
40702810908020008313 -- 90902810208020008313
90902810756300103435
90902810800760002909-- 90901810100761003909
90902810726241000067 --90901810132641000388
90902978800002500001
90902810112490004020
