-- �������� ���������, ��� ���� �������� �� ���/��, �� ��� �������� �� ���������, �.�. ��� ��������� ������ ����� � CARD_ACCOUNT_2_���
select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
c.reference,c.branch,c.account,c.assist,
a.code,UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)<>'810'
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)

-- �������� ���������, ��� ���� �������� �� ���/��, �� ��� �������� �� ���������, �.�. ��� ��������� ������ ����� � CARD_ACCOUNT_2_���
select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
c.reference,c.branch,c.account,c.assist,
a.code,UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2_val
from TMP_TABLES.TMP_GDM_90902_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810'
and  not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)



-- ��� �����-��
select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)='90902'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is not null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)


-- �������������, ���� � ���������
select rowid,--''''||a.code||''',',
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
(select close_date from account where header='C' and code=a.code) close_909,
(select count(*) from tmp_tables.tmp_gdm_vc_2 where value=a.code) cnt_vc,
a.* 
from TMP_TABLES.TMP_GDM_90902_2 a
where a.status=-1 