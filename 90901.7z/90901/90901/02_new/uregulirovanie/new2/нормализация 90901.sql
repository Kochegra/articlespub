-- �������� �������
select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a

delete from TMP_TABLES.TMP_GDM_90901_2

/
-- ������ �� ��������
insert into TMP_TABLES.TMP_GDM_90901_2(HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT)
    select HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT 
    from account a 
    where header='C' and code like '90901%'
        and close_date is null
        --and nvl(client,0)<>0 
        --and nvl(contract,0)<>0
        --and code='90901124023461000172'

/


-- ������������, �������� ������
select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a

-- ���� ������ 0
-- ������ -1 �������������� �� ��������� 
update TMP_TABLES.TMP_GDM_90901_2 set status=0
--update TMP_TABLES.TMP_GDM_90901_2 set status=-1
--select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a
--where nvl(contract,0)=0


delete from TMP_TABLES.TMP_GDM_VC_2

-- ��������� ��������� ���������
/
declare
begin
    insert into TMP_TABLES.TMP_GDM_VC_2
    select * from variable_contracts 
    where
    instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and substr(name,1,1)<>'_' and substr(name,1,1)<>'-' and instr(name,'OLD')=0 and instr(name,'MIGR')=0;
    commit;
end;
/

select count(*) from TMP_TABLES.TMP_GDM_VC_2

select distinct type_doc,type_cont from (
select 
universe.nametype(a.type_doc) type_cont,
a.* from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0) 
)

94           ��������-�������� ������������
----326         ������� �� ����� ���� 
590         ����.����.����
--1620      ��������� ����������
--3709      ������� �� ��� ���������� � ���������� ������
5787      ���.����.����� ������. ������
5788      ���.����.����� ������. ����������
--6771      ������ �������� (�������� ����)
--6774      ������ ��������
--6776      ����������� ���������� �� ��������� ��
--6777      ����������� ���������� �� ������������� ���������
6833      ���.����.����� ������.������.������
7298      ���. ����� ���. ������� ���
7302      ���. ����� ���. ������� ��
7323      ���.����.����� ������.���������
7621      ������� �� ������������ ���/��/��(185-��)
-------------12306    ���. �������� �� ������ ���
12457    ������� �������� �� � ��� (44��)
12575    ��� ����������� - �����������
12579    ���. ��������� ����
12580    ���. ����������� ����
12581    ���. ������. ���������� ���� ����� � ���� �������
12582    ���. ���� �������������� ����������
12583    ���. ����������� ������������ ����
12606    ���. ���� ������
--13472    ������� �/�. �������������
13913    ���. ����������� ���������� ���� ��������
13952    ���. ����.���� ��� 1 (���������� �����)
13953    ���. ����.���� ��� 2(���� �����-� �����.������-�)
----14116    ����������� ������ ��������
--14390    ������������� ���� "������� ��� �������"

-- �������� ������ ����� � �������� ���������
-- ��� ��� ����� �������, �� ������� �� ����� 100% ��������
select 
universe.nametype(a.type_doc) type_cont,
a.* from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0)
and type_doc in (12306)--326,1620,3709,6771,6774,6776,6777,12306,13472,14116,14390) 

delete from TMP_TABLES.TMP_GDM_90901_2 a where status=0
--update TMP_TABLES.TMP_GDM_90901_2 a set status=-2 where status=0
--select * from TMP_TABLES.TMP_GDM_90901_2 a where status=0 
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and type_doc in (326,1620,3709,6771,6774,6776,6777,13472,14116,14390))
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and type_doc in (12306))
    and not exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code)
    and not exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

-- �������� �� ������� ����� ���
--delete from TMP_TABLES.TMP_GDM_90901_2 a where status=0
select * from TMP_TABLES.TMP_GDM_90901_2 a where status=0 
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and substr(account,1,3) in (/*'421',*/'303','301','302'))
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and substr(account,1,3) in ('421'))
    and not exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code)
    and not exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

--delete from TMP_TABLES.TMP_GDM_90901_2 a where status=0
select * from TMP_TABLES.TMP_GDM_90901_2 a where status=0 
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and substr(account,1,3) in ('303','301','302'))
    --and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and substr(account,1,3) in ('303','301','302'))
    --and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and substr(account,1,3) in ('421'))
    --and exists(select null from contracts where reference<>a.CONTRACT and branch<>a.branch_contract and assist=a.code and substr(account,1,3) in ('421'))
    and exists(select null from TMP_TABLES.TMP_GDM_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
    --and code='90901810216031000005'

--delete from TMP_TABLES.TMP_GDM_90901_2 a where status=0
select * from TMP_TABLES.TMP_GDM_90901_2 a where status=0 
    and (contract,branch_contract) in (select reference,branch from contracts a where (reference,branch)  in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90901_2 a where status=0 ) and substr(account,1,5) in ('40506','40606','40706','40825'))

-- ������� ��������� �� ���������
select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a where instr(name,'CARD_ACCOUNT_1')>0 and substr(value,1,5)='90902'

select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a where exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)



-- �������� � ���� � ����
select rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)<>'90901'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3))-- and close_date is null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)

--delete from variable_contracts aa where (reference,branch,value,id) in
--delete from tmp_tables.tmp_gdm_vc_2 aa where (reference,branch,value,id) in
select aa.* from variable_contracts aa where (reference,branch,value,id) in 
 (select reference,branch,value,id 
--rowid,
--(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
--                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
--                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
--(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--a.* 
from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)<>'90901'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)
)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where name like 'CARD_ACCOUNT_2%' and value=aa.value)

-- �������
--delete from variable_contracts aa where (reference,branch,value,id) in
--select aa.* from variable_contracts aa where (reference,branch,value,id) in 
 --(
 select --reference,branch,value,id 
rowid,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
a.* 
from tmp_tables.tmp_gdm_vc_2 a 
--delete from tmp_tables.tmp_gdm_vc_2 a
where name like 'CARD_ACCOUNT_1%' and substr(value,1,5)='90902'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) )--and close_date is not null)
--and exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)
--)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where name like 'CARD_ACCOUNT_2%' and value=aa.value)


-- �������
-- �������, ��� ��������

select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a
--where status=0 and code in ('90901978000071000113')


select --''''||a.code||'''',
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
c.account,--c.assist,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.assist), c.assist, substr(c.assist,6,3), sysdate)*pledger.WCOURSE(substr(c.assist,6,3), SysDate) sal,
--a.code
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1') CARD_ACCOUNT_1,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_1_'||substr(a.code,6,3)) CARD_ACCOUNT_1_val,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_15_'||substr(a.code,6,3)) CARD_ACCOUNT_15_val,
''''||UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3')||''',' CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810') CARD_ACCOUNT_3_810,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)) CARD_ACCOUNT_3_val,
----UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)) CARD_ACCOUNT_3_val,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
a.*,c.* 
from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
and substr(a.code,6,3)='810'
--and substr(a.code,6,3)<>'810'
and substr(c.account,6,3)='810'
--1 ������� ���������, ��� ���� ������ � ��������� ��� �1������ � �1�����. �������� �������� �1, ��������� �� ���� �������, �������� ������
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)

-------
--2
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'||substr(a.code,6,3)),'#')<>'#'
----and nvl(info_1,'#')<>'#'
----and a.code='90901810900530000595'
--2 ��� ����������, ��� ���� �������� � 15 � 3
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_15')>0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (name='CARD_ACCOUNT_3' or instr(name,'CARD_ACCOUNT_3_')>0) and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3' and value=a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3_')>0 and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--3 ����������� � 15
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_15')>0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0))
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and (name='CARD_ACCOUNT_3' or instr(name,'CARD_ACCOUNT_3_')>0) and value=a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3' and value<>a.code)
----and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3')>0 and value<>a.code)
----and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3')-- and value<>a.code)
----and substr(c.account,6,3)<>'810'
--4
--and a.assist=1
--and a.code='90901978010061000919'
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
-------------and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3_'||substr(a.code,6,3) and value<>a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_15')>0)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'CARD_ACCOUNT_3')=0)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3')>0 and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3')>0 and value<>a.code and substr(value,6,3)='810')
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3_')>0 and value=a.code )--and substr(value,6,3)<>'810')
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3_000' and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3_RUR' and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name like 'CARD_ACCOUNT_3_%' and value<>a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3' and value<>a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3')>0 and value<>a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and name='CARD_ACCOUNT_3')-- and value<>a.code)
--and substr(c.account,6,3)=substr(a.code,6,3)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')<>a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#')<>a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#')=nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810'),'#')
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)),'#')=a.code
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810'),'#'),6,3)='810'--substr(a.code,6,3)
and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#'),6,3)<>'810'

--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810'),'#'),6,3)='810'
----and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#'),6,3)=substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)),'#'),6,3)
--and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)),'#'),6,3)=substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)),'#'),6,3)
and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)),'#'),6,3)=substr(c.account,6,3)
and substr(nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#'),6,3)=substr(c.account,6,3)
----and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')=nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#')
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')=nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)),'#')


--and nvl(info_1,'#')<>'#'
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3')=0)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and instr(name,'CARD_ACCOUNT_3_')>0 and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'||substr(a.code,6,3)),'#')<>'#'
--and nvl(info_1,'#')<>'#'
--and a.code='90901810900530000595'
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(c.assist,'#')='#'--=a.code
--3
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_3')=0 and instr(name,'CARD_ACCOUNT_1')=0)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2'),'#')=a.code-- not in ('#',a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)),'#')=a.code
--and nvl(c.assist,'#')<>a.code
--)


-- �������� ��������
delete from TMP_TABLES.TMP_GDM_90901_2 a
--select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a
where status=0
and code in (
select --''''||a.code||'''',
a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
--and a.code in ('90901810400051000066')
and a.assist=1
--old
--and substr(a.code,6,3)<>'810'
--and substr(c.account,6,3)<>'810'
--
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
)

/
declare
begin
    for rec in (
    
    select a.* from TMP_TABLES.TMP_GDM_90901_2 a
where status=0
and code in (
select --''''||a.code||'''',
a.code
--UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_2_'||substr(a.code,6,3)) CARD_ACCOUNT_2,
--a.*,c.* 
from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
--and substr(a.code,6,3)='810'
--old
and a.code in ('90901810400051000066')
--3 
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
--and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code and instr(name,'CARD_ACCOUNT_15')>0)
--and nvl(info_1,'#')<>'#'
)

    
    )loop
        delete from TMP_TABLES.TMP_GDM_90901_2 a where code=rec.code and reference=rec.reference and branch=rec.branch;
        commit;
        dbms_output.put_line(rec.code); 
    end loop;

end;


/


declare 
nsal number;
nsal_rur number;
nsal_810 number;
begin
    for rec in (
    
            select --''''||a.code||'''',
                (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
            --a.code
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3') CA_3,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR') CA_RUR,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810') CA_810,
            --UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)) CA_3_val,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_'||substr(c.account,6,3)) CA_3_val,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_978') CA_3_978,
            UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_840') CA_3_840,
            --PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
            (select close_date from account where header='C' and code = UNIVERSE.VARIABLE_CONTRACT(a.branch_contract,a.contract, 'CARD_ACCOUNT_3_'||substr(a.code,6,3)) and currency = substr(a.code,6,3)) close_ca_3_val,
            a.*,c.account,c.assist assist_c
            from TMP_TABLES.TMP_GDM_90901_2 a, contracts c
            where a.status=0 and a.contract=c.reference and a.branch_contract=c.branch
--and a.code='90901810012491007020'
--and a.assist=1
and substr(a.code,6,3)='810'
and substr(c.account,6,3)<>'810'
--
and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=a.CONTRACT and branch=a.branch_contract and value=a.code)
and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference<>a.CONTRACT and branch<>a.branch_contract and value=a.code)
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3'),'#')<>a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_RUR'),'#')<>a.code
--and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference, 'CARD_ACCOUNT_3_810'),'#')=a.code
    
    )loop
--        if rec.info_1='�1_������' then
--            dbms_output.put_line('�1_������');
--            update variable_contracts set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code
--                    and exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code);
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code
--                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code);
--            commit;
--        else
--            dbms_output.put_line('�1_�����');
--            update variable_contracts set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code
--                    and exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code);
--            commit;
----            update tmp_tables.tmp_gdm_vc_2 set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code
----                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code);
----            commit;
--            delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code
--                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code);
--            commit;
--        end if;

--        if rec.info_1='�15_������' then
--            dbms_output.put_line('�15_������ ������ �������');
----            update variable_contracts set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code
----                    and exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code);
----            commit;
----            update tmp_tables.tmp_gdm_vc_2 set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code
----                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_3%' or name like 'CARD_ACCOUNT_15%') and value=rec.code);
----            commit;
--        else
--            dbms_output.put_line('�3');
--            update variable_contracts set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_15%' and value=rec.code
--                    and exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_15%' and value=rec.code);
--            commit;
----            update tmp_tables.tmp_gdm_vc_2 set name='#GDM_'||name where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code
----                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and (name like 'CARD_ACCOUNT_1%' and instr(name,'CARD_ACCOUNT_15')=0) and value=rec.code);
----            commit;
--            delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_15%' and value=rec.code
--                    and exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_15%' and value=rec.code);
--            commit;
--        end if;
--
    
--            update contracts set assist=rec.code,assist_currency='810' /*substr(rec.assist_c,6,3)*/ where reference=rec.contract and branch=rec.branch_contract;-- and assist_currency is null;
                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update variable_contracts set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value=rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3_'||substr(rec.code,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;


--            update contracts set assist=rec.code,assist_currency=rec.currency where reference=rec.contract and branch=rec.branch_contract and assist is null;
--                --and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
           -- ��� ����������� ����� ������ CARD_ACCOUNT_2 � CARD_ACCOUNT_2_val
            --delete from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code;
            --commit;
            --
            
--            update variable_contracts set name='_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_'||substr(rec.code,6,3) where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2' and value=rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.code,6,3));
--            commit;

--            update variable_contracts set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value=rec.code);
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set value=rec.code where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value<>rec.code
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810'  and value=rec.code);
--            commit;
--            if rec.ca_3 is null then
----                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_'||substr(rec.code,6,3), rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
----                commit;
--                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                commit;
----                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_RUR', rec.ca_3);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
----                commit;
----                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_810', rec.ca_3);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
----                commit;
--            else
--                if substr(rec.ca_3,6,3)='978' and rec.ca_3_978 is null then
--                    UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_978', rec.ca_3);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                    commit;
--                    UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                    commit;
--                end if;

--                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                commit;
--                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_RUR', rec.ca_3);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                commit;
--                UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_810', rec.ca_3);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--                commit;
--            end if;
--            nsal := PLEDGER.SALDO(paccount.HEADER_ACCOUNT(rec.code), rec.code, substr(rec.code,6,3), sysdate)*pledger.WCOURSE(substr(rec.code,6,3), SysDate);
--            nsal_rur := PLEDGER.SALDO(paccount.HEADER_ACCOUNT(rec.ca_rur),rec.ca_rur, substr(rec.ca_rur,6,3), sysdate)*pledger.WCOURSE(substr(rec.ca_rur,6,3), SysDate);
--            if nsal<> 0 and then
--            
--            else
--            
--            end if;
            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_RUR', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            commit;
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.ca_3_val);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;

--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3_RUR' and value = rec.ca_3
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3_RUR' and value = rec.ca_3));
--            commit;

--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            update variable_contracts set name=name||'_810' where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value=rec.ca_3
--                    and not exists(select null from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3_810' and value=rec.ca_3);
--            commit;
--            update tmp_tables.tmp_gdm_vc_2 set name=name||'_810' where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value=rec.ca_3
--                    and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3_810' and value=rec.ca_3);
--            commit;
            --UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3', rec.ca_3_978);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
            --commit;
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_3_'||substr(rec.code,6,3), rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;

--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value = rec.code
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value = rec.code));
--            commit;

--            delete from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_3%';
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name like 'CARD_ACCOUNT_3%');
--            commit;

            update TMP_TABLES.TMP_GDM_90901_2 set assist=1 where code=rec.code;
            commit;

--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value = rec.code
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_3' and value = rec.code));
--            commit;
----
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_810', rec.code);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_810' and value = rec.code));
--            commit;

--            -- �� ������� � ��������� � �������� ������
--            UNIVERSE.INPUT_VAR_CONTR(rec.branch_contract, rec.contract,'CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3), rec.assist_c);  -- �� ������ �������� ��������� � �������� �������� ���������� ������
--            commit;
--            insert into tmp_tables.tmp_gdm_vc_2 (select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c
--                and not exists(select null from tmp_tables.tmp_gdm_vc_2 where reference=rec.contract and branch=rec.branch_contract and name='CARD_ACCOUNT_2_'||substr(rec.assist_c,6,3) and value = rec.assist_c));
--            commit;
--            update contracts set assist=null,assist_currency=null where reference=rec.contract and branch=rec.branch_contract;
--            commit;
            

            
    end loop;
end;
/


CA_3	CA_RUR	CA_810	CA_3_VAL	CLOSE_CA_3_VAL	HEADER	BAL	BRANCH	CODE
90901810500001012454	90901978000001001454		90901978700001000454	11/10/2021	C	90901	191	90901978000001001454
90901810703800000008	90901978003800000064		90901978500031000064	05/05/2021	C	90901	775	90901978003800000064
90901810939001000024	90901978139001001024		90901978839001000024	10/10/2021	C	90901	191	90901978139001001024
90901810115001000369	90901978315001001369		90901978015001000369	11/10/2021	C	90901	191	90901978315001001369
90901810100001015657	90901978400001000657		90901978700001001657		C	90901	191	90901978400001000657

