        select 
        (select close_date from account where header=paccount.HEADER_ACCOUNT(a.acc_rko) and code=a.acc_rko and currency=substr(a.acc_rko,6,3) /*and close_date is null*/) acc_rko_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k2) and code=a.k2 and currency=substr(a.k2,6,3) /*and close_date is null*/) k2_cl,
        --(select close_date from account where header=paccount.HEADER_ACCOUNT(a.k3) and code=a.k3 and currency=substr(a.k3,6,3) /*and close_date is null*/) k3_cl,
        a.*,--c.*
        c.reference,c.branch,c.ACCOUNT acc_cont,c.assist,c.type_doc,c.date_open,c.DATE_CLOSE,c.subdepartment,c.REFER_CLIENT,c.BRANCH_CLIENT 
        from tmp_tables.tmp_gdm_k2_v2 a, contracts c
        where a.status>=1000 and a.status<10000 
        and a.refer_contract=c.reference and a.BRANCH_CONTRACT=c.branch
        --and a.refer_contract in (971,998,1005,1018,1021,1061,1072,1083,1086,1089)--787) 
        --and a.refer_contract in (486,1277,1485,1616,2766,2768,3081,3086,3174,3313,3425,4954,5127,5646,5744,5780,5797,5806,5875,5900)

/
declare
nArch number;
rDoc documents%rowtype;
begin
    for rec in (
    
SELECT 6823054 reference,405 branch from dual union all
SELECT 2520967603 reference,191 branch from dual union all
SELECT 2702200968 reference,191 branch from dual union all
SELECT 2900409575 reference,191 branch from dual union all
SELECT 2900409850 reference,191 branch from dual union all
SELECT 2901850838 reference,191 branch from dual union all
SELECT 2901850847 reference,191 branch from dual union all
SELECT 3024160905 reference,191 branch from dual union all
SELECT 3087205711 reference,191 branch from dual union all
SELECT 3393473111 reference,191 branch from dual union all
SELECT 3526878233 reference,191 branch from dual union all
SELECT 3638835598 reference,191 branch from dual union all
SELECT 3819074452 reference,191 branch from dual union all
SELECT 3840105550 reference,191 branch from dual union all
SELECT 3842218682 reference,191 branch from dual union all
SELECT 3862063166 reference,191 branch from dual union all
SELECT 3994525281 reference,235 branch from dual union all
SELECT 3994525323 reference,235 branch from dual union all
SELECT 4158652004 reference,544 branch from dual union all
SELECT 4374112972 reference,780 branch from dual union all
SELECT 4374112989 reference,780 branch from dual union all
SELECT 4374120386 reference,780 branch from dual union all
SELECT 4374122846 reference,780 branch from dual union all
SELECT 4374123539 reference,780 branch from dual union all
SELECT 4374123604 reference,780 branch from dual union all
SELECT 4374126045 reference,780 branch from dual union all
SELECT 4374130451 reference,780 branch from dual union all
SELECT 4374134992 reference,780 branch from dual union all
SELECT 4374156884 reference,780 branch from dual union all
SELECT 4374172554 reference,780 branch from dual union all
SELECT 4374179750 reference,780 branch from dual union all
SELECT 4374182910 reference,780 branch from dual union all
SELECT 4374207439 reference,780 branch from dual union all
SELECT 4374238514 reference,780 branch from dual union all
SELECT 4374241653 reference,780 branch from dual union all
SELECT 4374317924 reference,780 branch from dual union all
SELECT 4374334451 reference,780 branch from dual union all
SELECT 4374340401 reference,780 branch from dual union all
SELECT 4506278259 reference,191 branch from dual union all
SELECT 4525835009 reference,365 branch from dual union all
SELECT 4525861992 reference,365 branch from dual union all
SELECT 4525864588 reference,365 branch from dual union all
SELECT 4525864601 reference,365 branch from dual union all
SELECT 4525864632 reference,365 branch from dual union all
SELECT 4525868049 reference,365 branch from dual union all
SELECT 4525881157 reference,365 branch from dual union all
SELECT 4525883780 reference,365 branch from dual union all
SELECT 4525901134 reference,365 branch from dual union all
SELECT 4525910811 reference,365 branch from dual union all
SELECT 4525910819 reference,365 branch from dual union all
SELECT 4525916119 reference,365 branch from dual union all
SELECT 4525927353 reference,365 branch from dual union all
SELECT 4525934093 reference,365 branch from dual union all
SELECT 4525956380 reference,365 branch from dual union all
SELECT 4525970869 reference,365 branch from dual union all
SELECT 4526004468 reference,365 branch from dual union all
SELECT 4526011684 reference,365 branch from dual union all
SELECT 4526020061 reference,365 branch from dual union all
SELECT 4526025415 reference,365 branch from dual union all
SELECT 4528406173 reference,365 branch from dual union all
SELECT 4528406176 reference,365 branch from dual union all
SELECT 4531815668 reference,191 branch from dual union all
SELECT 5058136773 reference,631 branch from dual union all
SELECT 5058136811 reference,631 branch from dual union all
SELECT 5190754755 reference,191 branch from dual union all
SELECT 5191044087 reference,191 branch from dual union all
SELECT 5191048783 reference,191 branch from dual union all
SELECT 5193670472 reference,191 branch from dual union all
SELECT 5193674366 reference,191 branch from dual union all
SELECT 5193677782 reference,191 branch from dual union all
SELECT 5193978420 reference,191 branch from dual union all
SELECT 5194006106 reference,191 branch from dual union all
SELECT 5194007727 reference,191 branch from dual union all
SELECT 5194074032 reference,191 branch from dual union all
SELECT 5199619386 reference,191 branch from dual union all
SELECT 5202779457 reference,191 branch from dual union all
SELECT 5202779503 reference,191 branch from dual union all
SELECT 5202780627 reference,191 branch from dual union all
SELECT 5202781108 reference,191 branch from dual union all
SELECT 5202821847 reference,191 branch from dual union all
SELECT 5208260704 reference,191 branch from dual union all
SELECT 5228093600 reference,770 branch from dual union all
SELECT 5228093611 reference,770 branch from dual union all
SELECT 5228122517 reference,770 branch from dual union all
SELECT 5228122536 reference,770 branch from dual union all
SELECT 5228174589 reference,770 branch from dual union all
SELECT 5228178962 reference,770 branch from dual union all
SELECT 5228194375 reference,770 branch from dual union all
SELECT 5228233690 reference,770 branch from dual union all
SELECT 5228285411 reference,770 branch from dual union all
SELECT 5228285458 reference,770 branch from dual union all
SELECT 5228291401 reference,770 branch from dual union all
SELECT 5228334039 reference,770 branch from dual union all
SELECT 5228350918 reference,770 branch from dual union all
SELECT 5228376378 reference,770 branch from dual union all
SELECT 5232494066 reference,770 branch from dual union all
SELECT 5232688940 reference,770 branch from dual union all
SELECT 5232688950 reference,770 branch from dual union all
SELECT 5232688960 reference,770 branch from dual union all
SELECT 5232688964 reference,770 branch from dual union all
SELECT 5257587650 reference,191 branch from dual union all
SELECT 5263353330 reference,191 branch from dual union all
SELECT 5263354207 reference,191 branch from dual union all
SELECT 5270425619 reference,191 branch from dual union all
SELECT 5270425628 reference,191 branch from dual union all
SELECT 5270425643 reference,191 branch from dual union all
SELECT 5270425778 reference,191 branch from dual union all
SELECT 5270426406 reference,191 branch from dual union all
SELECT 5270426413 reference,191 branch from dual union all
SELECT 5270426994 reference,191 branch from dual union all
SELECT 5270428771 reference,191 branch from dual union all
SELECT 5277384643 reference,191 branch from dual union all
SELECT 5278465689 reference,191 branch from dual union all
SELECT 5278472738 reference,191 branch from dual union all
SELECT 5278472779 reference,191 branch from dual union all
SELECT 5278472847 reference,191 branch from dual union all
SELECT 5278472927 reference,191 branch from dual union all
SELECT 5279294529 reference,191 branch from dual union all
SELECT 5279432571 reference,191 branch from dual union all
SELECT 5282513008 reference,191 branch from dual union all
SELECT 5289288961 reference,191 branch from dual union all
SELECT 5295590962 reference,191 branch from dual union all
SELECT 5295676914 reference,191 branch from dual union all
SELECT 5295677137 reference,191 branch from dual union all
SELECT 5295678119 reference,191 branch from dual union all
SELECT 5298778056 reference,191 branch from dual union all
SELECT 5298778068 reference,191 branch from dual union all
SELECT 5308658417 reference,191 branch from dual union all
SELECT 5315090908 reference,191 branch from dual union all
SELECT 5315092361 reference,191 branch from dual union all
SELECT 5315093212 reference,191 branch from dual union all
SELECT 5334103847 reference,191 branch from dual union all
SELECT 5344132607 reference,191 branch from dual union all
SELECT 5344429337 reference,191 branch from dual union all
SELECT 5366492614 reference,191 branch from dual union all
SELECT 5366494888 reference,191 branch from dual union all
SELECT 5388890197 reference,191 branch from dual union all
SELECT 5449062080 reference,540 branch from dual union all
SELECT 5451961116 reference,540 branch from dual union all
SELECT 5455927261 reference,191 branch from dual union all
SELECT 5455931641 reference,191 branch from dual union all
SELECT 5458315020 reference,540 branch from dual union all
SELECT 5461888842 reference,191 branch from dual union all
SELECT 5461895225 reference,191 branch from dual union all
SELECT 5550339488 reference,360 branch from dual union all
SELECT 5551176263 reference,360 branch from dual union all
SELECT 5553758809 reference,360 branch from dual union all
SELECT 5553758818 reference,360 branch from dual union all
SELECT 5554105966 reference,360 branch from dual union all
SELECT 5554107569 reference,360 branch from dual union all
SELECT 5570038499 reference,191 branch from dual union all
SELECT 5573573403 reference,540 branch from dual union all
SELECT 5578945621 reference,191 branch from dual union all
SELECT 5581372554 reference,191 branch from dual union all
SELECT 5583009773 reference,191 branch from dual union all
SELECT 5596216333 reference,191 branch from dual union all
SELECT 5596216416 reference,191 branch from dual union all
SELECT 5629752016 reference,665 branch from dual union all
SELECT 5630067638 reference,665 branch from dual union all
SELECT 5714382032 reference,191 branch from dual union all
SELECT 5743282813 reference,191 branch from dual union all
SELECT 5743282902 reference,191 branch from dual union all
SELECT 5743283395 reference,191 branch from dual union all
SELECT 5745025835 reference,191 branch from dual union all
SELECT 5759353005 reference,191 branch from dual union all
SELECT 5764468260 reference,191 branch from dual union all
SELECT 5788063790 reference,191 branch from dual union all
SELECT 5886584687 reference,245 branch from dual union all
SELECT 5977819087 reference,191 branch from dual union all
SELECT 5988750275 reference,775 branch from dual union all
SELECT 5994638347 reference,191 branch from dual union all
SELECT 6004490090 reference,775 branch from dual union all
SELECT 6009080128 reference,191 branch from dual union all
SELECT 6009187339 reference,191 branch from dual union all
SELECT 6009187536 reference,191 branch from dual union all
SELECT 6054255468 reference,775 branch from dual union all
SELECT 6060784007 reference,191 branch from dual union all
SELECT 6063516296 reference,191 branch from dual union all
SELECT 6063532486 reference,191 branch from dual union all
SELECT 6063533596 reference,191 branch from dual union all
SELECT 6063533681 reference,191 branch from dual union all
SELECT 6063540210 reference,191 branch from dual union all
SELECT 6063540269 reference,191 branch from dual union all
SELECT 6063544730 reference,191 branch from dual union all
SELECT 6064351562 reference,191 branch from dual union all
SELECT 6070496511 reference,191 branch from dual union all
SELECT 6070497024 reference,191 branch from dual union all
SELECT 6074468866 reference,191 branch from dual union all
SELECT 6074468905 reference,191 branch from dual union all
SELECT 6074630542 reference,191 branch from dual union all
SELECT 6074639992 reference,191 branch from dual union all
SELECT 6074640026 reference,191 branch from dual union all
SELECT 6077894222 reference,191 branch from dual union all
SELECT 6077990418 reference,191 branch from dual union all
SELECT 6077990465 reference,191 branch from dual union all
SELECT 6085634672 reference,191 branch from dual union all
SELECT 6085634693 reference,191 branch from dual union all
SELECT 6085635597 reference,191 branch from dual union all
SELECT 6085636227 reference,191 branch from dual union all
SELECT 6086103241 reference,191 branch from dual union all
SELECT 6086172942 reference,191 branch from dual union all
SELECT 6086417415 reference,191 branch from dual union all
SELECT 6086491683 reference,191 branch from dual union all
SELECT 6089379017 reference,191 branch from dual union all
SELECT 6089379024 reference,191 branch from dual union all
SELECT 6089379037 reference,191 branch from dual union all
SELECT 6089379052 reference,191 branch from dual union all
SELECT 6089810369 reference,191 branch from dual union all
SELECT 6089810396 reference,191 branch from dual union all
SELECT 6090016575 reference,191 branch from dual union all
SELECT 6090085245 reference,191 branch from dual union all
SELECT 6090085834 reference,191 branch from dual union all
SELECT 6090093449 reference,191 branch from dual union all
SELECT 6094412100 reference,191 branch from dual union all
SELECT 6101276418 reference,191 branch from dual union all
SELECT 6101281437 reference,191 branch from dual union all
SELECT 6101724966 reference,191 branch from dual union all
SELECT 6101725131 reference,191 branch from dual union all
SELECT 6101739646 reference,191 branch from dual union all
SELECT 6101745013 reference,191 branch from dual union all
SELECT 6101745146 reference,191 branch from dual union all
SELECT 6101745196 reference,191 branch from dual union all
SELECT 6101746152 reference,191 branch from dual union all
SELECT 6101779455 reference,191 branch from dual union all
SELECT 6101779559 reference,191 branch from dual union all
SELECT 6101779617 reference,191 branch from dual union all
SELECT 6101881780 reference,191 branch from dual union all
SELECT 6101882290 reference,191 branch from dual union all
SELECT 6101882816 reference,191 branch from dual union all
SELECT 6101891258 reference,191 branch from dual union all
SELECT 6101972834 reference,191 branch from dual union all
SELECT 6102121177 reference,191 branch from dual union all
SELECT 6102192066 reference,191 branch from dual union all
SELECT 6102193279 reference,191 branch from dual union all
SELECT 6102334976 reference,191 branch from dual union all
SELECT 6102401249 reference,191 branch from dual union all
SELECT 6102402345 reference,191 branch from dual union all
SELECT 6102402963 reference,191 branch from dual union all
SELECT 6102411487 reference,191 branch from dual union all
SELECT 6102433994 reference,191 branch from dual union all
SELECT 6102440402 reference,191 branch from dual union all
SELECT 6102440575 reference,191 branch from dual union all
SELECT 6103353932 reference,191 branch from dual union all
SELECT 6103355874 reference,191 branch from dual union all
SELECT 6103357343 reference,191 branch from dual union all
SELECT 6124763175 reference,191 branch from dual union all
SELECT 6124923664 reference,191 branch from dual union all
SELECT 6125098233 reference,191 branch from dual union all
SELECT 6125111280 reference,191 branch from dual union all
SELECT 6125169188 reference,191 branch from dual union all
SELECT 6125169374 reference,191 branch from dual union all
SELECT 6128080909 reference,191 branch from dual union all
SELECT 6131997331 reference,191 branch from dual union all
SELECT 6142225203 reference,191 branch from dual union all
SELECT 6142327334 reference,191 branch from dual union all
SELECT 6143288321 reference,191 branch from dual union all
SELECT 6164471482 reference,191 branch from dual union all
SELECT 6185352434 reference,191 branch from dual union all
SELECT 6185925544 reference,191 branch from dual union all
SELECT 6185925888 reference,191 branch from dual union all
SELECT 6209098535 reference,191 branch from dual union all
SELECT 6209107443 reference,191 branch from dual union all
SELECT 6258325757 reference,191 branch from dual union all
SELECT 6258364064 reference,191 branch from dual union all
SELECT 6258446496 reference,191 branch from dual union all
SELECT 6258480740 reference,191 branch from dual union all
SELECT 6258531923 reference,191 branch from dual union all
SELECT 6258540098 reference,191 branch from dual union all
SELECT 6272882154 reference,191 branch from dual union all
SELECT 6279631544 reference,191 branch from dual union all
SELECT 6279987025 reference,191 branch from dual union all
SELECT 6283067451 reference,191 branch from dual union all
SELECT 6283067665 reference,191 branch from dual union all
SELECT 6283703885 reference,191 branch from dual union all
SELECT 6304300778 reference,191 branch from dual union all
SELECT 6305098354 reference,191 branch from dual union all
SELECT 6305098709 reference,191 branch from dual union all
SELECT 6322710621 reference,191 branch from dual union all
SELECT 6322710661 reference,191 branch from dual union all
SELECT 6322711412 reference,191 branch from dual union all
SELECT 6341384546 reference,191 branch from dual union all
SELECT 6341482562 reference,191 branch from dual union all
SELECT 6341795594 reference,191 branch from dual union all
SELECT 6342103319 reference,191 branch from dual union all
SELECT 6349574108 reference,191 branch from dual union all
SELECT 6349574209 reference,191 branch from dual union all
SELECT 6352724543 reference,191 branch from dual union all
SELECT 6352724554 reference,191 branch from dual union all
SELECT 6352724724 reference,191 branch from dual union all
SELECT 6352724822 reference,191 branch from dual union all
SELECT 6352911276 reference,191 branch from dual union all
SELECT 6356502518 reference,191 branch from dual union all
SELECT 6366940805 reference,191 branch from dual union all
SELECT 6384982403 reference,191 branch from dual union all
SELECT 6389693160 reference,191 branch from dual union all
SELECT 6395489526 reference,191 branch from dual union all
SELECT 6408457837 reference,191 branch from dual union all
SELECT 6411422158 reference,191 branch from dual union all
SELECT 6433284337 reference,191 branch from dual union all
SELECT 6433847314 reference,191 branch from dual union all
SELECT 6436752563 reference,191 branch from dual union all
SELECT 6445449277 reference,191 branch from dual union all
SELECT 6445449948 reference,191 branch from dual union all
SELECT 6451156743 reference,191 branch from dual union all
SELECT 6451182869 reference,191 branch from dual union all
SELECT 6451184014 reference,191 branch from dual union all
SELECT 6451683283 reference,191 branch from dual union all
SELECT 6472398802 reference,191 branch from dual union all
SELECT 6472398992 reference,191 branch from dual union all
SELECT 6472406491 reference,191 branch from dual union all
SELECT 6472413743 reference,191 branch from dual union all
SELECT 6473053238 reference,191 branch from dual union all
SELECT 6473092385 reference,191 branch from dual union all
SELECT 6521680354 reference,191 branch from dual union all
SELECT 6533014817 reference,191 branch from dual union all
SELECT 6533015403 reference,191 branch from dual union all
SELECT 6539028051 reference,191 branch from dual union all
SELECT 6539030861 reference,191 branch from dual union all
SELECT 6539031286 reference,191 branch from dual union all
SELECT 6539032664 reference,191 branch from dual union all
SELECT 6539048250 reference,191 branch from dual union all
SELECT 6539048267 reference,191 branch from dual union all
SELECT 6539049317 reference,191 branch from dual union all
SELECT 6560967249 reference,191 branch from dual union all
SELECT 6561284709 reference,191 branch from dual union all
SELECT 6564450930 reference,191 branch from dual union all
SELECT 6567343589 reference,191 branch from dual union all
SELECT 6568012067 reference,191 branch from dual union all
SELECT 6571040033 reference,191 branch from dual union all
SELECT 6571040093 reference,191 branch from dual union all
SELECT 6571631336 reference,191 branch from dual union all
SELECT 6575216655 reference,191 branch from dual union all
SELECT 6615839241 reference,191 branch from dual union all
SELECT 6627411302 reference,191 branch from dual union all
SELECT 6634801795 reference,191 branch from dual union all
SELECT 6637516733 reference,191 branch from dual union all
SELECT 6637522895 reference,191 branch from dual union all
SELECT 6637925273 reference,191 branch from dual union all
SELECT 6637981076 reference,191 branch from dual union all
SELECT 6659555758 reference,191 branch from dual union all
SELECT 6659613248 reference,191 branch from dual union all
SELECT 6675319504 reference,191 branch from dual union all
SELECT 6679047375 reference,191 branch from dual union all
SELECT 6682109618 reference,191 branch from dual union all
SELECT 6726644425 reference,191 branch from dual union all
SELECT 6727209164 reference,191 branch from dual union all
SELECT 6741932626 reference,191 branch from dual union all
SELECT 6767973160 reference,191 branch from dual union all
SELECT 6795409792 reference,191 branch from dual union all
SELECT 6795410764 reference,191 branch from dual 
    
    )loop
        if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 0, rDoc) then
            if nArch=1 then
                insert into documents select * from archive where reference = rDoc.reference and branch = rDoc.branch;
                insert into variable_documents select * from variable_archive where reference = rDoc.reference and branch = rDoc.branch;
                delete archive where reference = rDoc.reference and branch = rDoc.branch;
                commit;
            end if;
            if rDoc.status=36 then
            
                --delete from k2 where reference=rDoc.reference and branch=rDoc.branch and where_is='D' and what_is=2;
                --commit;
                
                update documents set status = 35
                where reference = rDoc.reference and branch = rDoc.branch;
                commit;
                
                if nvl(Universe.VARIABLE_PART(rDoc.reference,rDoc.branch,'CARD_ACCOUNT_WAIT',null),'0')<>'0' then
                    update documents set status = 38
                    where reference = rDoc.reference and branch = rDoc.branch;
                    commit;
                end if;
            
            end if;
        end if;
    end loop;
end;
/


select * from k2
