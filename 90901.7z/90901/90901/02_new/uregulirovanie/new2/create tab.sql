create table TMP_TABLES.TMP_GDM_90902_2 as
    select * from TMP_TABLES.TMP_GDM_90902 a where header='C' and code like '90902%' and close_date is null and nvl(client,0)=0 and code='90902810106280000680'

/    

grant select,insert,update,delete on TMP_GDM_90902_2 to MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_90902_2 a



create table TMP_TABLES.TMP_GDM_vc_2 as
    select * from TMP_TABLES.TMP_GDM_vc a where value='90902810106280000680'

/    

grant select,insert,update,delete on TMP_GDM_vc_2 to MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_vc_2 a




create table TMP_TABLES.TMP_GDM_90901_2 as
    select * from TMP_TABLES.TMP_GDM_90901 a where header='C' and code like '90902%' and close_date is null and nvl(client,0)=0 and code='90902810106280000680'

/    

grant select,insert,update,delete on TMP_GDM_90901_2 to MBANK

select rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a

/
create table TMP_TABLES.TMP_GDM_BID as
    select reference,branch,value from TMP_TABLES.TMP_GDM_vc a where reference=15998152
/
grant select,insert,update,delete on TMP_GDM_BID to MB_GORODNOV_DM--MBANK

/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_BID a
/
alter table TMP_TABLES.TMP_GDM_bid
    add (from_table VARCHAR2(4000 BYTE)
    --f_contract        number,
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --var_card_acc_1        VARCHAR2(4000 BYTE),--
         --var_card_acc_15        VARCHAR2(4000 BYTE),
         --var_card_acc_2         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         --info_1                 VARCHAR2(4000 BYTE)
         --status number
         --RKO_close number
         --NO_UPD number
        )
/        
