select rowid,a.* from TMP_TABLES.TMP_GDM_VC a 

select distinct name from TMP_TABLES.TMP_GDM_VC a
where exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)




-- ���������� ����� ���������
select rowid,a.* from TMP_TABLES.TMP_GDM_VC a
where 
exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
and name='CARD_ACCOUNT_810'

-- ��������� ��� 90901 <> 90901

select
--''''||value||''',', 
rowid,a.* from TMP_TABLES.TMP_GDM_VC_2 a
where 
exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
--and instr(name,'CARD_ACCOUNT_1')>0 and substr(value,1,5)<>'90901'
--and instr(name,'CARD_ACCOUNT_1')>0 and not exists(select null from account where header='C' and code=a.value)
--and instr(name,'CARD_ACCOUNT_3')>0 and substr(value,1,5)<>'90901'
--and instr(name,'CARD_ACCOUNT_3')>0 and not exists(select null from account where header='C' and code=a.value)
--and instr(name,'CARD_ACCOUNT_2')>0 and substr(value,1,5)<>'90902'
and instr(name,'CARD_ACCOUNT_2')>0 and not exists(select null from account where header='C' and code=a.value)


select rowid,aa.* from variable_contracts aa 
--update variable_contracts set name=name||'_NOT_OPEN'
--update variable_contracts set name='#'||name
--delete from variable_contracts
--where (reference,branch,name,value) in 
--        (select a.reference,a.branch,a.name/*||'_NOT_OPEN'*/,a.value from TMP_TABLES.TMP_GDM_VC a where exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
--            and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'_NOT_OPEN')=0 and not exists(select null from account where header='C' and code=a.value))
--where (reference,branch,name,'#') in --value) in 
--where (reference,branch,name,value) in 
--        (select a.reference,a.branch,a.name/*||'_NOT_OPEN'*/,nvl(a.value,'#') from TMP_TABLES.TMP_GDM_VC a where exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
--            and instr(name,'CARD_ACCOUNT_3')>0 and not exists(select null from account where header='C' and code=a.value))
where (reference,branch,name,'#') in --value) in 
--where (reference,branch,name,value) in 
        (select a.reference,a.branch,a.name/*||'_NOT_OPEN'*/,nvl(a.value,'#') from TMP_TABLES.TMP_GDM_VC a where exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
            and instr(name,'CARD_ACCOUNT_2')>0 and not exists(select null from account where header='C' and code=a.value))
            
            

select rowid,a.* from TMP_TABLES.TMP_GDM_VC a 
where
exists(select null from contracts where reference=a.reference and branch=a.branch and status<>60)
--and length(value)<>20
--and nvl(value,'#')='#'
and substr(value,1,5) not in ('90901','90902')            


--select count(*) --rowid, a.* 
--from tmp_tables.tmp_gdm_vc a 
delete from tmp_tables.tmp_gdm_vc a
where exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)


--select rowid,a.* from tmp_tables.tmp_gdm_vc_2 a 
delete from tmp_tables.tmp_gdm_vc_2 a
where exists(select null from contracts where reference=a.reference and branch=a.branch and status=60)
