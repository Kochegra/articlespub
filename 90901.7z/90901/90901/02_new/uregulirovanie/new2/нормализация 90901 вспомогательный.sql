select 
p_k2.get_Rest_K2_Acc(a.account,sysdate) sum_acc_k2,
UNIVERSE.VARIABLE_CONTRACT(a.branch,a.reference, 'CARD_ACCOUNT_2_840') aaa,
--PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
--(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--rowid,a.* from contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902810912060009024'))
--rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902810912060009024'))
rowid,a.* from contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('40821810505250000119')) --and assist='90902810310248020058'
--rowid,a.* from contracts a where assist='90901810025501500022' 


select 
(select account from contracts where reference=a.reference and branch=a.branch) acc_rko, 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
--rowid,a.* from variable_contracts a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902810620000000016'))
--rowid,a.* from tmp_tables.tmp_gdm_vc_2 a where (reference,branch) in (select contract,branch_contract from TMP_TABLES.TMP_GDM_90902_2 where code in ('90902840600004300016'))
rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('40821810505250000119'))
--rowid,a.* from variable_contracts a where reference=71979 and branch=49000
----18763599 --21375 
and instr(name,'CARD_ACCOUNT_')>0 --and instr(name,'CARD_ACCOUNT_2')=0 

select
(select account from contracts where reference=a.reference and branch=a.branch) acc_rko, 
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.value) and code = a.value and currency = substr(a.value,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.value), a.value, substr(a.value,6,3), sysdate)*pledger.WCOURSE(substr(a.value,6,3), SysDate) sal,
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) acc_909_close,
rowid,a.* from TMP_TABLES.TMP_GDM_VC_2 a 
--where trim(value) in ('90901978101001000082')
where (reference,branch) in (select reference,branch from TMP_TABLES.TMP_GDM_vc_2 where value in ('40821810505250000119'))
--where reference=21375
--and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'CARD_ACCOUNT_2')=0

90901810700021003382	90901392400020003392




select 
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal,
(to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
rowid,a.* from account a where code in ('90901810200321000404') and header in ('C')
--rowid,a.* from TMP_TABLES.TMP_GDM_90901_2 a where code in ('90901810900651000296') and header='C'
--rowid,a.* from account a where contract=19469725 
--and branch_contract=76001--76031


select rowid,a.* from tmp_tables.tmp_gdm_90901_2 a where code in ('90901810001861000435')

select * from contracts 
where reference in (119355) and branch=50 --type_doc in (1620) and status=50

select * from variable_contracts where reference in (31284545) and branch=544



18763599 

select count(*) 
from TMP_TABLES.TMP_GDM_90902_2 
where status=0 

90901810001861000435
90901810100441500502
90901810216031000005
90901810301911500103
90901810900001501662
90901810900651000296





