--��������� �������� 

with vc as (select
                (select close_date from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3)) clos_dt, 
                a.* from TMP_TABLES.TMP_GDM_vc a where instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.value) and code=a.value and currency=substr(a.value,6,3) and close_date is null))
--select * from vc 
select rowid,a.* 
from TMP_TABLES.TMP_GDM_90901 a
--update TMP_TABLES.TMP_GDM_90901 a set log_contract='K1_VC'
where header='C' and exists (select null from vc where trim(value)=a.code)


select a.* 
from TMP_TABLES.TMP_GDM_90901 a
left join TMP_TABLES.TMP_GDM_vc v
on a.code=trim(v.value) 
where a.header='C' --and a.currency=substr()
and instr(v.name,'CARD_ACCOUNT_1')>0 and instr(v.name,'CARD_ACCOUNT_15')=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(v.value) and code=v.value and currency=substr(v.value,6,3) and close_date is null)

update TMP_TABLES.TMP_GDM_90901 set log_contract='K1_VC'
where (header,code,currency,reference,branch) in (
--
select a.header,a.code,a.currency,a.reference,a.branch --a.* 
from TMP_TABLES.TMP_GDM_90901 a
left join TMP_TABLES.TMP_GDM_vc v
on a.code=trim(v.value) 
where a.header='C' --and a.currency=substr()
and instr(v.name,'CARD_ACCOUNT_1')>0 and instr(v.name,'CARD_ACCOUNT_15')=0
and exists(select null from account where header=paccount.HEADER_ACCOUNT(v.value) and code=v.value and currency=substr(v.value,6,3) and close_date is null)
--
)


select a.* 
from TMP_TABLES.TMP_GDM_90901 a
where nvl(log_contract,'#')='K1_VC'