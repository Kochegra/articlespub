create table TMP_TABLES.TMP_GDM_90901 as
    select * from mbank.account a where header='C' and code like '90901%' and close_date is null and nvl(client,0)=0

/    

grant select,insert,update,delete on TMP_GDM_90901 to MBANK
/
  
select rowid,a.* from TMP_TABLES.TMP_GDM_90901 a
/

alter table TMP_GDM_90901
    add (--f_contract        number,
         --f_branch_contract number,
         --log_contract   varchar2(4000 BYTE)
         --var_card_acc_1        VARCHAR2(4000 BYTE),--
         --var_card_acc_15        VARCHAR2(4000 BYTE),
         --var_card_acc_2         VARCHAR2(4000 BYTE),
         --var_card_acc_3         VARCHAR2(4000 BYTE)
         info_1                 VARCHAR2(4000 BYTE)
        )
/        

select * from mbank.account