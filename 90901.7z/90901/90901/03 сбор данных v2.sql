-- 01.
select rowid,a.* from TMP_TABLES.TMP_GDM_90901 a
where 
nvl(contract,0)=0
and substr(code,6,3)<>'810'

update TMP_TABLES.TMP_GDM_90901 set f_contract=null,f_branch_contract=null,log_contract=null
where 
nvl(contract,0)=0
and substr(code,6,3)<>'810'
 

select * from variable_account where (reference,branch) in (select reference,branch from account where code='90901156000561000720')

delete from TMP_TABLES.TMP_GDM_90901

/
-- ������� ��������� ����������� ����������
declare
nGetCont number;
rCont contracts%rowtype;
rAcc account%rowtype;
sAcc varchar2(2000);
nUpd number;
sLog varchar2(4000);
 FUNCTION get_acc_migr (p_acc account.code%type, p_header account.header%type)
    RETURN VARCHAR2
  AS
    ret   account.code%type;
  BEGIN
    select distinct(acc_new) into ret 
    from (
          select acc_mbank acc_new,header,'CFT' abs from acc_migr_cft_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_mbank acc_new,header,'CABS' abs from acc_migr_cabs_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_new acc_new,header,'MBANK' abs from acc_closed_filial 
          where acc_old=p_acc and header=p_header
          );

    RETURN ret;
  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
      RETURN NULL;
    WHEN TOO_MANY_ROWS
    THEN
      RETURN 'TOO_MANY_ROWS';
    WHEN OTHERS
    THEN
      RETURN 'OTHERS';
  END get_acc_migr;
  
  function f_get_cont (p_code account.code%type,p_ref_cli account.client%type,p_br_cli account.branch_client%type,p_name variable_contracts.name%type,p_Cont out contracts%rowtype) return number
  as
   nCnt number;
   --rCont contracts%rowtype;
  begin
    select count(*) into nCnt from contracts cc 
        where refer_client=p_ref_cli and branch_client=p_br_cli
            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                        and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                        and value=p_code);

    if nCnt=1 then
        --Universe.get_contract_rec(rf => v_contract, br => v_branch_contract, stat => null, acc => null, tp => null, rContract)
        select * into p_Cont from contracts cc 
            where refer_client=p_ref_cli and branch_client=p_br_cli
                and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                            and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                            and value=p_code);
    end if;
    
    return nCnt;
  end;
  function f_find_acc(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
    --DBMS_OUTPUT.PUT_LINE('1');
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
       --DBMS_OUTPUT.PUT_LINE('2');
            if rDoc.type_doc<>198 then
            --DBMS_OUTPUT.PUT_LINE('3');
                if rDoc.type_doc=226 and rDoc.payers_account like '474%' then
                    if UNIVERSE.GET_DOCUMENT_REC(rDoc.related, rDoc.branch_related, nArch, 1, rDocRel) then
                        if instr('#'||sRes,rDocRel.payers_account)=0 then
                            nCnt:=nCnt+1;
                            sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                        end if;
                    end if;
                else
                    if instr('#'||sRes,rDoc.payers_account)=0 then
                    --DBMS_OUTPUT.PUT_LINE('4');
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDoc.payers_account||']';
                        --DBMS_OUTPUT.PUT_LINE(sRes);
                    end if;
                end if;
            else -- ����� �������� ��������
                if UNIVERSE.GET_DOCUMENT_REC(rDoc.refer_from, rDoc.branch_from, nArch, 1, rDocRefFrom) then
                    if instr('#'||sRes,rDocRefFrom.payers_account)=0 then
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDocRefFrom.payers_account||']';
                    end if;
                end if;
                if UNIVERSE.GET_DOCUMENT_REC(rDoc.related, rDoc.branch_related, nArch, 1, rDocRel) then
                    if instr('#'||sRes,rDocRel.payers_account)=0 then
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                    end if;
                end if;
            end if;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;
  function f_find_acc2(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    --rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
    sAccMigr account.code%type;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
            for dK2 in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                if UNIVERSE.GET_DOCUMENT_REC(dK2.reference, dK2.branch, nArch, 1, rDocRel) then
                        -- �������� �������������
                        sAccMigr:=get_acc_migr(rDocRel.payers_account,paccount.HEADER_ACCOUNT(rDocRel.payers_account));
                        if sAccMigr is null or sAccMigr in ('TOO_MANY_ROWS','OTHERS') then
                            if instr('#'||sRes,rDocRel.payers_account)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                            end if;
                        else
                            if instr('#'||sRes,sAccMigr)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||sAccMigr||'][MIGR_'||nCnt||'=1]';
                            end if;
                        end if;
                    end if;                
            end loop;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;
begin
    for rec in (
    
        -- ������
--        select 
--        PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
----        (select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
--        a.* 
--        from TMP_TABLES.TMP_GDM_90901 a
--        where 
--            nvl(client,0)<>0
--            and nvl(contract,0)=0
--            and nvl(f_contract,0)=0
--            and substr(code,6,3)<>'810'
--            --and code='90901840615540000002' --

        -- �����
        select 
        PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
--        (select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
        a.* 
        from TMP_TABLES.TMP_GDM_90901 a
        where 
            nvl(client,0)<>0
            and nvl(contract,0)=0
            and nvl(f_contract,0)=0
            and substr(code,6,3)='810'
            --and code='90901810253101004114' --
          

    )loop
        sLog:=null;
        nUpd:=1;
        nGetCont :=f_get_cont(rec.code,rec.client,rec.branch_client,'CARD_ACCOUNT',rCont);
        DBMS_OUTPUT.PUT_LINE(nGetCont||' '||rCont.reference||'/'||rCont.Branch);
        --sAcc := f_find_acc(rec.code);
        sAcc := f_find_acc2(rec.code);
        DBMS_OUTPUT.PUT_LINE(sAcc);
        
        
        if nGetCont=1 then
             if (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and rCont.account=PTOOLS5.READ_PARAM(sAcc,'ACC_1')) or (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=0 and to_number(PTOOLS5.READ_PARAM(sAcc,'JOU'))=0) 
                -- ���� ��� �������, ����� �������� �� ��������� ������, �������� ����, �� ������ ��� ��������, ���� �������� ���. �.�. ���� ���� ������ �� ��������� ���������. ������������ ����� ��������� ���.
                or (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=0) --������������� �� �� ����� ���������
             then 
                DBMS_OUTPUT.PUT_LINE('�������� '||rec.code);
                if 1=nUpd then
                    --update account set contract=rCont.reference, branch_contract=rCont.branch
                    --    where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0;
                    update TMP_TABLES.TMP_GDM_90901 set f_contract=rCont.reference, f_branch_contract=rCont.branch
                        where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0 and nvl(f_contract,0)=0;                        
                    commit; 
                end if;
             else 
                if to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and rCont.account!=PTOOLS5.READ_PARAM(sAcc,'ACC_1') then
                    DBMS_OUTPUT.PUT_LINE('NO_UPD '||rec.code||' ���� ���������� �������� �� ����� ����� �� �������� '||rCont.account||'<> '||PTOOLS5.READ_PARAM(sAcc,'ACC_1'));
                    sLog:=sLog||'���� �������� '||rCont.account||' <> ����� �� ��������'||PTOOLS5.READ_PARAM(sAcc,'ACC_1')||';';
                else
                    DBMS_OUTPUT.PUT_LINE('NO_UPD '||rec.code);
                end if;
             end if;
        else
            DBMS_OUTPUT.PUT_LINE('NO_UPD2 '||rec.code);
        end if; 
        -- ���� ��� ������ ����� ����� �� ��������, �� ������������ ����� ��������� � �������� �� ����� �� �������� �� ���� ������ - ������ ����� ��������� ���������� �� ���������� 90901
        -- + ����� ��������� �������, ����� ����� ����������, ��� ���� �� �������� �� ����������� ������� �� 90901
        if nGetCont=0 then
             if (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and to_number(PTOOLS5.READ_PARAM(sAcc,'JOU'))>0) then 
                if  universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(PTOOLS5.READ_PARAM(sAcc,'ACC_1')), cd => PTOOLS5.READ_PARAM(sAcc,'ACC_1'), cr=>substr(PTOOLS5.READ_PARAM(sAcc,'ACC_1'),6,3),account_rec => rAcc) then
                    if nvl(rAcc.contract,0)>0 and nvl(rAcc.branch_contract,0)>0 
                        -- ������� �������� �������
                        and nvl(rAcc.client,0)=rec.client and nvl(rAcc.branch_client,0)=rec.branch_client
                    then
                        DBMS_OUTPUT.PUT_LINE('�������� �� ��������� '||rec.code||' ������� '||rAcc.contract||'/'||rAcc.branch_contract||' '||rAcc.code);
                        sLog:=sLog||'�������� �� ���������;';
                        if 1=nUpd then
                            --update account set contract=rCont.reference, branch_contract=rCont.branch
                                --    where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0;
                            update TMP_TABLES.TMP_GDM_90901 set f_contract=rAcc.contract, f_branch_contract=rAcc.branch_contract
                            where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0 and nvl(f_contract,0)=0;                        
                            commit; 
                        end if;
                    else
                        DBMS_OUTPUT.PUT_LINE('NO_UPD3 ���� �� �������� �� ��������� � �������� �� ����� 90901 '||rec.code||' ������� '||rAcc.contract||'/'||rAcc.branch_contract||' '||rAcc.code);
                        sLog:=sLog||'�� ��������� ������� �� ����� �� �������� '||rAcc.code||' �� ������ 90901;';
                    end if;
                end if;
             end if;
        else
            DBMS_OUTPUT.PUT_LINE('NO_UPD4 '||rec.code);
        end if; 
        
        DBMS_OUTPUT.PUT_LINE('----');
        if 1=nUpd then
            update TMP_TABLES.TMP_GDM_90901 set log_contract=sLog
               where reference=rec.reference and branch=rec.branch;                        
            commit; 
        end if;

    end loop;

end;
/

-- �� ���
-- ����� ��� �������� 
select 4813 "��� ��������", 4706 "�����������", 107 "�������� �� ������������", 4813-4706 "��������" from dual

select 
--count(*)
--(select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
rowid,a.*
,case 
    when nvl(f_contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=f_contract and branch=f_branch_contract)
    when nvl(contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=contract and branch=branch_contract)
 end rko    
,case 
    when nvl(f_contract,0)<>0 then (select assist from contracts where reference=f_contract and branch=f_branch_contract)
    when nvl(contract,0)<>0 then (select assist from contracts where reference=contract and branch=branch_contract)
 end rko_assist    
from TMP_TABLES.TMP_GDM_90901 a
where 
nvl(contract,0)=0
and nvl(f_contract,0)!=0
and substr(code,6,3)<>'810'
--and code='90901156600071002508'


/
--02. ��������� ������� ���������
declare
sCard1 varchar2(4000);
sCard15 varchar2(4000);
sCard2  varchar2(4000);
sCard3  varchar2(4000);
nUpd number :=1;
sTimeBeg varchar2(50);
sTimeEnd varchar2(50);
begin
    sTimeBeg:=to_char(sysdate,'dd.mm.yyyy  hh24:mi:ss');
    for rec in (
    
--        select 
        select /*+ PARALLEL(4) */ 
            a.*
--            ,case 
--                when nvl(f_contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=f_contract and branch=f_branch_contract)
--                when nvl(contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=contract and branch=branch_contract)
--            end rko    
        from TMP_TABLES.TMP_GDM_90901 a
        where 
            (nvl(contract,0)!=0 or nvl(f_contract,0)!=0)
            --(nvl(contract,0)<>0) -- ����� ���������� ����������� ���������
            --and substr(code,6,3)='810'
            --and code='90901156600071002508'
    
    )loop
        sCard1:=null;
        sCard15:=null;
        sCard2:=null;
        sCard3:=null;
        for varCont in (
            --select * from variable_contracts where reference=rec.contract and branch=rec.branch_contract and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0
            select * from variable_contracts where reference=decode(nvl(rec.contract,0),0,rec.f_contract,rec.contract) and branch=decode(nvl(rec.branch_contract,0),0,rec.f_branch_contract,rec.branch_contract) and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0
        )loop
            if instr(varCont.name,'CARD_ACCOUNT_1')>0 and instr(varCont.name,'CARD_ACCOUNT_15')=0 then
                sCard1:=sCard1||'['||varCont.name||'='||varCont.value||']';                
            end if;
            if instr(varCont.name,'CARD_ACCOUNT_15')>0 then
                sCard15:=sCard15||'['||varCont.name||'='||varCont.value||']';                
            end if;
            if instr(varCont.name,'CARD_ACCOUNT_2')>0 then
                sCard2:=sCard2||'['||varCont.name||'='||varCont.value||']';                
            end if;
            if instr(varCont.name,'CARD_ACCOUNT_3')>0 then
                sCard3:=sCard3||'['||varCont.name||'='||varCont.value||']';                
            end if;
        end loop;
        
--        DBMS_OUTPUT.PUT_LINE(rec.code||' '||sCard1||'-'||sCard15||'-'||sCard2||'-'||sCard3);
        if nUpd=1 then
            update TMP_TABLES.TMP_GDM_90901 set var_card_acc_1=sCard1,var_card_acc_15=sCard15,var_card_acc_2=sCard2,var_card_acc_3=sCard3
                where reference=rec.reference and branch=rec.branch;
            commit;
        end if;
            
    end loop;
    sTimeEnd:=to_char(sysdate,'dd.mm.yyyy  hh24:mi:ss');
    DBMS_OUTPUT.PUT_LINE(sTimeBeg||' - '||sTimeEnd);

end;

/

decode(related,0,refer_from,related)


/
--03. ��������� ������� �������� �� ������� ���������� ������
declare
sInfo varchar2(4000);
nUpd number :=1;
sTimeBeg varchar2(50);
sTimeEnd varchar2(50);
nCnt number;
rAcc account%rowtype;
 function f_get_type_k(p_ref number,p_br number,p_acc account.code%type, p_name variable_contracts.name%type) return number
 as
  nRes number;
 begin
    nRes:=0;
    for i in (select * from variable_contracts where reference=p_ref and branch=p_br and instr(name,p_name)>0 and instr(name,'#')=0 and value=p_acc)
    loop
        nRes:=1;
    end loop;
    return nRes;
 end;
begin
    sTimeBeg:=to_char(sysdate,'dd.mm.yyyy  hh24:mi:ss');
    for rec in (
    
--        select 
        select /*+ PARALLEL(4) */ 
            a.*
--            ,case 
--                when nvl(f_contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=f_contract and branch=f_branch_contract)
--                when nvl(contract,0)<>0 then (select account||';'||type_doc||'_'||sub_type from contracts where reference=contract and branch=branch_contract)
--            end rko    
        from TMP_TABLES.TMP_GDM_90901 a
        where 
            (nvl(contract,0)!=0 or nvl(f_contract,0)!=0)
            --(nvl(contract,0)<>0) -- ����� ���������� ����������� ���������
            --and substr(code,6,3)='810'
            --and code in ('90901810020020000008','90901810020661500653','90901810024451500047')
    
    )loop
        sInfo:=null;
        nCnt:=0;
        if f_get_type_k(nvl(rec.contract,rec.f_contract),nvl(rec.branch_contract,rec.f_branch_contract),rec.code,'CARD_ACCOUNT_15')=1 
        then
            --DBMS_OUTPUT.PUT_LINE('��� 15'||rec.code);
            -- ������� �� ���������
            for varCont in (
                select * from variable_contracts where reference=decode(nvl(rec.contract,0),0,rec.f_contract,rec.contract) and branch=decode(nvl(rec.branch_contract,0),0,rec.f_branch_contract,rec.branch_contract) 
                    and instr(name,'CARD_ACCOUNT15')=0 and instr(name,'CARD_ACCOUNT3')>0 and instr(name,'#')=0 and value<>rec.code and substr(value,1,8)=substr(rec.code,1,8)
            )loop
                --DBMS_OUTPUT.PUT_LINE(varCont.value);
                if  universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(varCont.value), cd => varCont.value, cr=>substr(varCont.value,6,3),account_rec => rAcc) then
                    if rAcc.close_date is null then
                        nCnt:=nCnt+1;
                    end if;
                end if;
            end loop;
            sInfo:=sInfo||'[VC='||nCnt||']';
            
            nCnt:=0;
            -- ������� �� �������� �������
            for tmpT in (select a.* from TMP_TABLES.TMP_GDM_90901 a where (nvl(contract,0)!=0 or nvl(f_contract,0)!=0)
                            and nvl(contract,f_contract)=nvl(rec.contract,rec.f_contract) and nvl(branch_contract,f_branch_contract)=nvl(rec.branch_contract,rec.f_branch_contract)
                            and reference<>rec.reference and branch<>rec.branch
                            and substr(code,6,3)=substr(rec.code,6,3))
            loop
                if  universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(tmpT.code), cd => tmpT.code, cr=>substr(tmpT.code,6,3),account_rec => rAcc) then
                    if rAcc.close_date is null then
                        nCnt:=nCnt+1;
                    end if;
                end if;
            end loop;
            sInfo:=sInfo||'[TMPTAB='||nCnt||']';
            
            --nCnt:=0;
            --������� �� ��������� ����� ���������� - ��� ����� �����
        --else
        --    DBMS_OUTPUT.PUT_LINE('��� �� 15');        
        end if;
        
        if nUpd=1 then
            update TMP_TABLES.TMP_GDM_90901 set info_1=sInfo
                where reference=rec.reference and branch=rec.branch;
            commit;
        end if;
            
    end loop;
    sTimeEnd:=to_char(sysdate,'dd.mm.yyyy  hh24:mi:ss');
    DBMS_OUTPUT.PUT_LINE(sTimeBeg||' - '||sTimeEnd);

end;

/