-- �������� 90901
-- ����
-- �������� �� �������� ����������� �������� ��������� ���������
-- �������� ������� � ��������� ���� ��������
-- ���������
-- ���������� ���������

-- ������� �� ���, ����� �� ���
delete from MBANK.ZYX_EXCEL

select rowid,a.* from MBANK.ZYX_EXCEL@mb2dss a where a='UPD90901' and nvl(c,0)=1


select * from TMP_GDM_90901 

/
-- ��������� ������� � ��������
declare
begin
    for rec in (select rowid,a.* from MBANK.ZYX_EXCEL@ a where a='UPD90901' and nvl(c,0)=1)
    loop
        update TMP_GDM_90901 set info_1='DEL'
        where code=rec.b;
        commit; 
    end loop;
end;
/ 


select * from TMP_GDM_90901 where nvl(info_1,'#')='DEL'
and nvl(contract,0)<>0

/
-- ���������
declare
rAcc account%rowtype;
bExists boolean;
dLastLedger date;
 function f_last_ledger(p_acc account.code%type) return date is 
 begin
    for r in (select COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(p_acc) and code = p_acc and currency = substr(p_acc,6,3) and rest_id = 0 
                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY')) last_ledger  
                     ,a.*
              from account a where header='C' and code = p_acc)    
    loop
        return r.last_ledger;
    end loop;
 end;   
 

begin
    for rec in (
    
                select * from TMP_GDM_90901@mb2dss a where nvl(info_1,'#')='DEL' --and code='90901810192000010041'
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
                --and rownum<=10
    
    )
    loop
        bExists:=TRUE;
        if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.code), cd => rec.code, cr=>substr(rec.code,6,3),account_rec => rAcc) then
            -- �������� ���� ���������� �������
            dLastLedger := f_last_ledger(rAcc.code);
            --DBMS_OUTPUT.PUT_LINE(rAcc.code||' '||to_char(dLastLedger,'dd.mm.yyyy'));
            if dLastLedger>=to_date('01.01.2021','dd.mm.yyyy') then
                bExists:=FALSE;
                DBMS_OUTPUT.PUT_LINE(rAcc.code||' '||to_char(dLastLedger,'dd.mm.yyyy')||' ���� ��������� �������� ������ ��������� ����');
            end if;
            bExists:=TRUE;
            
            -- �������� �������
            if  PLEDGER.SALDO(paccount.HEADER_ACCOUNT(rAcc.code), rAcc.code, substr(rAcc.code,6,3), sysdate)>0 then
                bExists:=FALSE;
                DBMS_OUTPUT.PUT_LINE(rAcc.code||' ���� ������� �� �����. ��������� ������.');
            end if;
            
            if bExists then
                
                update account set close_date=trunc(sysdate)
                    where reference=rAcc.reference and branch=rAcc.branch and code=rAcc.code and close_date is null;
                commit;
                
                if nvl(rAcc.contract,0)<>0 then
                    update variable_contracts set name='#GDM_'||name
                        where reference=rAcc.contract and branch=rAcc.branch_contract
                            and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and value=rAcc.code;
                    commit;
                    
                    -- ������� �������� �� �������
                    update variable_contracts a set name='#GDM_'||name
                    --SELECT rowid,a.* from variable_contracts a
                        where (reference,branch) in (select reference,branch from contracts where refer_client=rAcc.client and branch_client=rAcc.branch_client and status<60
                                and not (reference=rAcc.contract and branch=rAcc.branch_contract)
                                )
                            and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and value=rAcc.code;
                    commit;
                                                
                else
                    update variable_contracts set name='#GDM_'||name
                        where reference=nvl(rec.contract,rec.f_contract) and branch=nvl(rec.branch_contract,rec.f_branch_contract)
                            and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 and value=rAcc.code;
                end if;
                commit;
            end if;
            
        end if;
        

    end loop;
end;
/

select 
(select close_date from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3)) upd_close_date,
a.* from TMP_GDM_90901@mb2dss a 
where nvl(info_1,'#')='DEL' --and code='90901810092000000012'

select * from TMP_GDM_90901@mb2dss a where 
exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)


select * from TMP_GDM_90901@mb2dss a where nvl(info_1,'#')='DEL' --and code='90901810192000010041'
and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)




select * from account where header='C' and code like '90901%' and close_date=trunc(sysdate)


                select * from TMP_GDM_90901@mb2dss a where nvl(info_1,'#')='DEL' --and code='90901810092000000041'
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)


SELECT rowid,a.* from variable_contracts a
                        where (reference,branch) in (select reference,branch from contracts where (refer_client,branch_client) in (select client,branch_client from TMP_GDM_90901@mb2dss where code='90901810192000010041') and status<60
                            --    and not (reference=553941 and branch=208)
                                --and (reference,branch) not in (select contract,branch_contract from TMP_GDM_90901@mb2dss where code='90901810192000010041')
                                )
                            --and (reference,branch) not in (select contract,branch_contract from TMP_GDM_90901@mb2dss where code='90901810192000010041') --reference<>553941 and branch<>208
                            --and instr(name,'CARD_ACCOUNT')>0 --and instr(name,'#')=0 
                            --and value='90901810192000010041'
                            
                            
select * from contracts where (refer_client,branch_client) in (select client,branch_client from TMP_GDM_90901@mb2dss where code='90901810192000010041' and status<60)
