--02. ������� 90901, ������� ��������� � �������� ������/��������� ���
-- �������� ������
select
-- �������
    (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo 
-- ���� ��������� ��������
    (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                    ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
    greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
--rowid,
case 
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K15_' --'� 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K11_;K15_'--'� 1/1; � 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K11_;K15_'--'� 1; � 1/1; � 1/5'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K11_'--'� 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K11_'--'� 1; � 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_'--'� 1'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K15_'--'� 1; � 1/5'
    else '�� ���������'
    --nvl(UNIVERSE.VARIABLE_CONTRACT(BRANCH, REFERENCE, 'CARD_CORP_CONTRACT') then '���, �� ���� ������������'
--    when nvl(contract,0)<>0 then '��'
--    else '���'
 end type_90901, --"���"   
a.*
,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
,c.account,c.status,
(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
from TMP_GDM_90901 a, contracts c
where 
    c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
    -- ������ �������� 90901
    and a.close_date is null
    and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
    and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2


/
-- ��������� ��� 90901 � 0-�� ���������
declare
nSal number;
begin
    for rec in (
    
            select
            -- �������
                (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo 
            -- ���� ��������� ��������
                (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                        and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                            ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
                greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
                a.*
                ,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
                ,c.account,c.status,
                (select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
            from TMP_GDM_90901 a, contracts c
            where 
                c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
                -- ������ �������� 90901
                and a.close_date is null
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
                and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
    
    
    )loop
        nSal:=PLEDGER.SALDO(paccount.HEADER_ACCOUNT(rec.code), rec.code, substr(rec.code,6,3), sysdate)*pledger.WCOURSE(substr(rec.code,6,3), SysDate);
        if nSal=0 then
            if 1=2 then
                update account set close_date=trunc(sysdate)
                    where reference=rec.reference and branch=rec.branch and code=rec.code and close_date is not null;  
                commit;
--                update account@mb2dss set close_date=trunc(sysdate)
--                    where reference=rec.reference and branch=rec.branch and code=rec.code and close_date is not null;
--                commit;  
--                update TMP_GDM_90901 set close_date=trunc(sysdate)    
--                    where reference=rec.reference and branch=rec.branch and code=rec.code and close_date is not null;
--                commit;    
            end if;
        end if;
    end loop;

end;

/

90901810092001000024 0
90901810092001000053 0
90901810092001000105 0
90901810092001000121 0
90901810092001000147 0
90901810092001000286 0
90901810092001000419 0
90901810092001000422 0
90901810092001000587 0
90901810092001000600 0
90901810092001000613 0
90901810092001000846 0
90901810092001000930 0
90901810092001000998 0
90901810092001001146 0
90901810192001000924 0
90901810192001000979 0
90901810192001002184 0
90901810192071000022 0
90901810192071000132 0
90901810292000000061 0
90901810292000010174 0
90901810292001000073 0
90901810292001000196 0
90901810292001000882 0
90901810292001000934 0
90901810292001000950 0
90901810292001001043 0
90901810292001001085 0
90901810292071000032 0
90901810292071000485 0
90901810392000000026 0
90901810392000000233 0
90901810392001000096 0
90901810392001000203 0
90901810392001000261 0
90901810392001000724 0
90901810392001001011 0
90901810392001001370 0
90901810492000001983 0
90901810492001000035 0
90901810492001000213 0
90901810492001000239 0
90901810492001000446 0
90901810492001000695 0
90901810492001000909 0
90901810492001001034 0
90901810492001001212 0
90901810892000001635 0
90901810892001000017 0
90901810892001000143 0
90901810892001000237 0
90901810892001000240 0
90901810892001000305 0
90901810892001000402 0
90901810892001000538 0
90901810892001000965 0
90901810892001000994 0
90901810892001001100 0
90901810892001001922 0
90901810992000000086 0
90901810992000000604 0
90901810992001000014 0
90901810992001000195 0
90901810992001000218 0
90901810992001000386 0
90901810492001001296 0
90901810492001001856 0
90901810492001001940 0
90901810492071000447 0
90901810592000001210 0
90901810592000001786 0
90901810592001000003 0
90901810592001000236 0
90901810592001000265 0
90901810592001000317 0
90901810592001000388 0
90901810592001000401 0
90901810592001000469 0
90901810592001000579 0
90901810592001000870 0
90901810592001001002 0
90901810592001001073 0
90901810592001001170 0
90901810592001001248 0
90901810592071000499 0
90901810692000000506 0
90901810692000001194 0
90901810692000001929 0
90901810692001000686 0
90901810692001000796 0
90901810692001000864 0
90901810692001001342 0
90901810692001001371 0
90901810692001001847 0
90901810692001001928 0
90901810692071000001 0
90901810692071000506 0
90901810792000000011 0
90901810792000000176 0
90901810792001000007 0
90901810792001000201 0
90901810792001000337 0
90901810792001000939 0
90901810792001000968 0
90901810792001001323 0
90901810992001000412 0
90901810992001000425 0
90901810992001000470 0
90901810992001000920 0
90901810992001000959 0
90901810992001000962 0
90901810992001001026 0
90901810992001001848 0
90901810992001002847 0
90901810992070000058 0
90901810992071000510 0
90901978392000000829 0
90901978492001000003 0