-- �������

--02. ������� 90901, ������� ��������� � �������� ������/��������� ���
-- �������� ������
select
-- �������
    (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo 
-- ���� ��������� ��������
    (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                    ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
    (select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2,
-- �������� ref/br ���������
    --decode(nvl(a.contract,0),0,decode(nvl(a.f_contract,0),0,0,a.f_contract),a.contract) decode_conract, 
    --nvl(coalesce(a.f_contract,a.contract),0) coalesce_contract,
    greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
    --nvl2(a.f_contract,a.f_contract,a.contract) nvl2_contract,       
--rowid,
case 
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K15_' --'� 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K11_;K15_'--'� 1/1; � 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K11_;K15_'--'� 1; � 1/1; � 1/5'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K11_'--'� 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K11_'--'� 1; � 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_'--'� 1'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then 'K1_;K15_'--'� 1; � 1/5'
    else '�� ���������'
    --nvl(UNIVERSE.VARIABLE_CONTRACT(BRANCH, REFERENCE, 'CARD_CORP_CONTRACT') then '���, �� ���� ������������'
--    when nvl(contract,0)<>0 then '��'
--    else '���'
 end type_90901, --"���"   
a.*
,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
,c.account,c.status,
(select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
from TMP_GDM_90901 a, contracts c
where 
    c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
    -- ������ �������� 90901
    and a.close_date is null
    and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
    -- 1 �������� �������� ������ ���, �� �� �������� ���������
    --and not exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
    --and c.status<>60
    -- 2 �������� �� �������� ������ ���, �� �������� ���������
    --and exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
    --and c.status=60
    -- 3 �������� �������� ������ ��� � �������� ���������
    --and not exists(select null from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3) and close_date is null)
    --and c.status=60
    --and nvl(contract,0)=0 and nvl(f_contract,0)=0  --�������� �� ���������
    --and (nvl(a.contract,0)!=0 or nvl(a.f_contract,0)!=0) -- �������� ��������� vers1
    and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
    --and 
    and a.code in ('90901810992000000439')-- �������� � �����������
--    and exists(select null from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) 
--                and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
--                and ptools_account2.IsCodeTranzit(account)=1
--    )


/
declare
nIsK1 number;

 function isK1(p_acc account.code%type) return number is
  rAcc account%rowtype;
  bCont boolean;
  rCont contracts%rowtype;
  nResCont number;
  nResContOther number;
  rDoc documents%rowtype;
  nJou number; -- ���-�� ��������
  nJou22 number; -- ���-�� ����� � 22 �������. ���� ����, �� ���������� �2
  nJouNo22 number; -- ���-�� ��������� ����� �� � 22 �������.
  nResJou number;
  nArch   number;
  nRes number;
 begin
    nRes:=0;
    DBMS_OUTPUT.PUT_LINE(p_acc);
    
    -- �� ��������
    nResCont := 0;
    nResContOther := 0;

    if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(p_acc), cd => p_acc, cr=>substr(p_acc,6,3),account_rec => rAcc) then
        bCont:= Universe.get_contract_rec(rf => rAcc.contract, br => rAcc.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rCont);
        if bCont then
            -- K1 �� ��������
            for varCont in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch 
                                    and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=rAcc.code)
            loop
                nResCont:=1;
                exit;    
            end loop;
            
            -- ������ � �� �������� � ����� �� �����
            for varCont in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch 
                                    and (instr(name,'CARD_ACCOUNT_15')>0 or instr(name,'CARD_ACCOUNT_3')>0) and instr(name,'#')=0 and value=rAcc.code)
            loop
                nResContOther:=1;
                exit;    
            end loop;
        end if;
    end if;
    
    DBMS_OUTPUT.PUT_LINE('nResCont = '||nResCont);    
    DBMS_OUTPUT.PUT_LINE('nResContOther = '||nResContOther);    
    
    -- �� ���������
    -- �� ����������� ���������� � 22 �������
    nJou :=0; -- ���-�� ��������
    nJou22 :=0; -- ���-�� ����� � 22 �������. ���� ����, �� ���������� �2
    nJouNo22 :=0;
    for doc in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_acc) and code=p_acc
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(doc.reference, doc.branch, nArch, 1, rDoc) then
            for dK1 in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                        where payers_account is not null and type_doc in (225)
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                nJou:=nJou+1;
                if dK1.status=22 then
                    nJou22:=nJou22+1;
                else
                    if nvl(UNIVERSE.VARIABLE_PART(rDoc.REFERENCE, rDoc.BRANCH, 'CARD_ACCOUNT1'),'')=trim(p_acc) then
                        nJouNo22 := nJouNo22+1;
                    end if;
--                    for vDoc in (select * from v_variable_documents where reference=dK1.reference and branch=dK1.branch 
--                    and name in ('CARD_ACCOUNT1') and value='' 
--                    )
                end if;                
            end loop;
       end if;
    end loop;
   DBMS_OUTPUT.PUT_LINE('nJou = '||nJou);    
   DBMS_OUTPUT.PUT_LINE('nJou22 = '||nJou22);    
   DBMS_OUTPUT.PUT_LINE('nJouNo22 = '||nJouNo22);    
   
    if nJou=0 then
        if nResCont=1 and nResContOther=0 then
            nRes:=1;
        end if;
    end if;
    if nJou>0 then
        if nJou22>0 or nJouNo22>0 then
            nRes:=1;
        end if;
    end if;
    return nRes;
 end isK1;
begin
    for rec in (
    
        select
        -- �������
            (PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate)) sal, -- saldo 
        -- ���� ��������� ��������
            (to_char((COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(a.code) and code = a.code and currency = substr(a.code,6,3) and rest_id = 0 
                    and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate))
                                        ,to_date('01.01.1900','DD.MM.YYYY'))),'dd.mm.yyyy')) last_ledger,
            (select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_ledger2,
        -- �������� ref/br ���������
            greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
            case 
                when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K15_' --'� 1/5'
                when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K11_;K15_'--'� 1/1; � 1/5'
                when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K1_;K11_;K15_'--'� 1; � 1/1; � 1/5'
                when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K11_'--'� 1/1'
                when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K1_;K11_'--'� 1; � 1/1'
                when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K1_'--'� 1'
                when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
                    and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
                    and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
                    and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
                then 'K1_;K15_'--'� 1; � 1/5'
                else '�� ���������'
            end type_90901, --"���"   
            a.info_1,
            a.*
            ,(select account from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))) acc_rko
            ,c.account,c.status,
            (select close_date from account where header=paccount.HEADER_ACCOUNT(c.account) and code=c.account and currency=substr(c.account,6,3)) close_date_acc_rko
        from TMP_GDM_90901 a, contracts c
        where 
            c.reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) and c.branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
            -- ������ �������� 90901
            and a.close_date is null
            --and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
            --and a.code in ('90901810592000000253')-- �������� � �����������
    
    )loop
        nIsK1:=isK1(rec.code);
        if nIsK1=1 and 1=1 then -- ���� �1
            DBMS_OUTPUT.PUT_LINE('��� �1 - ��������');
            update TMP_GDM_90901 set info_1='1'
            where reference=rec.reference and branch=rec.branch and code=rec.code;
            commit;
        end if;
    end loop;

end;

/