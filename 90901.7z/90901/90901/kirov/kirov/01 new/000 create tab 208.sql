create table TMP_GDM_90901 as
    select * from mbank.account a where header='C' and code like '90901%' and close_date is null and nvl(client,0)!=0
        

/    
-- �� ���
delete from TMP_GDM_90901

-- � ����� ����������� �������
insert into TMP_GDM_90901@mb2dss(HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT)
    select HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT from mbank.account a 
        where header='C' and code like '90901%' and close_date is null and nvl(client,0)!=0


--grant select,insert,update,delete on TMP_GDM_90901 to MBANK
/
  
select rowid,a.* from TMP_GDM_90901 a

/

alter table TMP_GDM_90901
    add (f_contract        number,
         f_branch_contract number,
         log_contract   varchar2(4000 BYTE),
         var_card_acc_1        VARCHAR2(4000 BYTE),--
         var_card_acc_15        VARCHAR2(4000 BYTE),
         var_card_acc_2         VARCHAR2(4000 BYTE),
         var_card_acc_3         VARCHAR2(4000 BYTE),
         info_1                 VARCHAR2(4000 BYTE)
        )
/        

select * from mbank.account

--***************************

create table TMP_GDM_90902 as
    select a.* from mbank.account a where header='C' and code like '90902%' and close_date is null and nvl(client,0)!=0
        

/    
-- �� ���
delete from TMP_GDM_90902

-- � ����� ����������� �������
insert into TMP_GDM_90902@mb2dss(HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT)
    select HEADER,BAL,BRANCH,CODE,CURRENCY,OPEN_DATE,CLOSE_DATE,MODIFY_DATE,NAME,BRANCH_CLIENT,CLIENT,BRANCH_CONTRACT,CONTRACT,LSNUM,REFERENCE,OWNER,ASSIST,SUBDEPARTMENT from mbank.account a 
        where header='C' and code like '90902%' and close_date is null and nvl(client,0)!=0


--grant select,insert,update,delete on TMP_GDM_90901 to MBANK
/
  
select rowid,a.* from TMP_GDM_90902 a

/

alter table TMP_GDM_90902
    add (f_contract        number,
         f_branch_contract number,
         log_contract   varchar2(4000 BYTE),
         var_card_acc_1        VARCHAR2(4000 BYTE),--
         var_card_acc_15        VARCHAR2(4000 BYTE),
         var_card_acc_2         VARCHAR2(4000 BYTE),
         var_card_acc_3         VARCHAR2(4000 BYTE),
         info_1                 VARCHAR2(4000 BYTE)
        )
/        

select * from mbank.account