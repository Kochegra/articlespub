        select distinct contract,branch_contract 
        from (
                select a.* from tmp_tables.TMP_GDM_90901 a
                where a.close_date is null and nvl(a.contract,0)!=0 
                and exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
                union all
                select a.* from tmp_tables.TMP_GDM_90902 a
                where a.close_date is null and nvl(a.contract,0)!=0 
                and not exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
              )
        where nvl(info_1,'0')='0'
        --and contract in (553931)
        order by contract


/
declare
bCont boolean;
rCont contracts%rowtype;
sK1 varchar2(2000);
sK2 varchar2(2000);
sK3 varchar2(2000);
sK15 varchar2(2000);
nK1 number;
nK2 number;
nK3 number;
nK15 number;
begin
    for rec in (
    
        select distinct contract,branch_contract 
        from (
                select * from TMP_GDM_90901
                where close_date is null and nvl(contract,0)!=0
                union all
                select * from TMP_GDM_90902
                where close_date is null and nvl(contract,0)!=0
              )
        where nvl(info_1,'0')='0'
        and contract in (553931)
        order by contract
    
    )loop
        -- ������� ���
        bCont:=Universe.get_contract_rec(rf => rec.contract, br => rec.branch_contract, stat => null, acc => null, tp => null, contracts_rec => rCont);
        if bCont then
            DBMS_OUTPUT.PUT_LINE('�/� '||rCont.account);
            DBMS_OUTPUT.PUT_LINE('ASSIST '||rCont.assist);
            nK1:=0; nK2:=0; nK3:=0; nK15:=0;
            for varCont in (select * from variable_contracts where reference=rCont.reference and branch=rCont.branch 
                                and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)
                                and instr(name,'#')=0)
            loop
                if instr(varCont.name,'CARD_ACCOUNT_1')>0 and instr(varCont.name,'CARD_ACCOUNT_15')=0 then
                    nK1:=nK1+1;
                    sK1:=sK1||varCont.name||'='||varCont.value||',';
                end if;
                if instr(varCont.name,'CARD_ACCOUNT_15')>0 then
                    nK15:=nK15+1;
                    sK15:=sK15||varCont.name||'='||varCont.value||',';
                end if;
                if instr(varCont.name,'CARD_ACCOUNT_2')>0 then
                    nK2:=nK2+1;
                    sK2:=sK2||varCont.name||'='||varCont.value||',';
                end if;
                if instr(varCont.name,'CARD_ACCOUNT_3')>0 then
                    nK3:=nK3+1;
                    sK3:=sK3||varCont.name||'='||varCont.value||',';
                end if;
            end loop;
            sK1:='[CNT='||nK1||']#'||substr(sK1,1,length(sK1)-1);
            sK15:='[CNT='||nK15||']#'||substr(sK15,1,length(sK15)-1);
            sK2:='[CNT='||nK2||']#'||substr(sK2,1,length(sK2)-1);
            sK3:='[CNT='||nK3||']#'||substr(sK3,1,length(sK3)-1);
            DBMS_OUTPUT.PUT_LINE('K1 '||sK1);
            DBMS_OUTPUT.PUT_LINE('K2 '||sK2);
            DBMS_OUTPUT.PUT_LINE('K3 '||sK3);
            DBMS_OUTPUT.PUT_LINE('K15 '||sK15);
        end if;
    end loop;
end;
/