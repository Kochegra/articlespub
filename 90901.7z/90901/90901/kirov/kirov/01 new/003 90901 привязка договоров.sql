-- ������� ��������� ����������� ����������
declare
nGetCont number;
rCont contracts%rowtype;
rAcc account%rowtype;
sAcc varchar2(2000);
nUpd number;
sLog varchar2(4000);
 FUNCTION get_acc_migr (p_acc account.code%type, p_header account.header%type)
    RETURN VARCHAR2
  AS
    ret   account.code%type;
  BEGIN
    select distinct(acc_new) into ret 
    from (
          select acc_mbank acc_new,header,'CFT' abs from acc_migr_cft_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_mbank acc_new,header,'CABS' abs from acc_migr_cabs_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_new acc_new,header,'MBANK' abs from acc_closed_filial 
          where acc_old=p_acc and header=p_header
          );

    RETURN ret;
  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
      RETURN NULL;
    WHEN TOO_MANY_ROWS
    THEN
      RETURN 'TOO_MANY_ROWS';
    WHEN OTHERS
    THEN
      RETURN 'OTHERS';
  END get_acc_migr;
  
  function f_get_cont (p_code account.code%type,p_ref_cli account.client%type,p_br_cli account.branch_client%type,p_name variable_contracts.name%type,p_Cont out contracts%rowtype) return number
  as
   nCnt number;
   --rCont contracts%rowtype;
  begin
    select count(*) into nCnt from contracts cc 
        where refer_client=p_ref_cli and branch_client=p_br_cli
            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                        and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                        and value=p_code);

    if nCnt=1 then
        --Universe.get_contract_rec(rf => v_contract, br => v_branch_contract, stat => null, acc => null, tp => null, rContract)
        select * into p_Cont from contracts cc 
            where refer_client=p_ref_cli and branch_client=p_br_cli
                and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                            and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                            and value=p_code);
    end if;
    
    return nCnt;
  end;
  function f_find_acc(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;


    rDoc documents%rowtype;
    rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
    --DBMS_OUTPUT.PUT_LINE('1');
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
       --DBMS_OUTPUT.PUT_LINE('2');
            if rDoc.type_doc<>198 then
            --DBMS_OUTPUT.PUT_LINE('3');
                if rDoc.type_doc=226 and rDoc.payers_account like '474%' then
                    if UNIVERSE.GET_DOCUMENT_REC(rDoc.related, rDoc.branch_related, nArch, 1, rDocRel) then
                        if instr('#'||sRes,rDocRel.payers_account)=0 then
                            nCnt:=nCnt+1;
                            sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                        end if;
                    end if;
                else
                    if instr('#'||sRes,rDoc.payers_account)=0 then
                    --DBMS_OUTPUT.PUT_LINE('4');
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDoc.payers_account||']';
                        --DBMS_OUTPUT.PUT_LINE(sRes);
                    end if;
                end if;
            else -- ����� �������� ��������
                if UNIVERSE.GET_DOCUMENT_REC(rDoc.refer_from, rDoc.branch_from, nArch, 1, rDocRefFrom) then
                    if instr('#'||sRes,rDocRefFrom.payers_account)=0 then
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDocRefFrom.payers_account||']';
                    end if;
                end if;
                if UNIVERSE.GET_DOCUMENT_REC(rDoc.related, rDoc.branch_related, nArch, 1, rDocRel) then
                    if instr('#'||sRes,rDocRel.payers_account)=0 then
                        nCnt:=nCnt+1;
                        sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                    end if;
                end if;
            end if;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;
  function f_find_acc2(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    --rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
    sAccMigr account.code%type;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
            for dK2 in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                if UNIVERSE.GET_DOCUMENT_REC(dK2.reference, dK2.branch, nArch, 1, rDocRel) then
                        -- �������� �������������
                        sAccMigr:=get_acc_migr(rDocRel.payers_account,paccount.HEADER_ACCOUNT(rDocRel.payers_account));
                        if sAccMigr is null or sAccMigr in ('TOO_MANY_ROWS','OTHERS') then
                            if instr('#'||sRes,rDocRel.payers_account)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                            end if;
                        else
                            if instr('#'||sRes,sAccMigr)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||sAccMigr||'][MIGR_'||nCnt||'=1]';
                            end if;
                        end if;
                    end if;                
            end loop;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;
begin
    for rec in (
    
        -- ������
--        select 
--        PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
----        (select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
----        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
----            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
--        a.* 
--        from TMP_GDM_90901 a
--        where 
--            nvl(client,0)<>0
--            and nvl(contract,0)=0
--            and nvl(f_contract,0)=0
--            and substr(code,6,3)<>'810'
--            --and code='90901840615540000002' --

        -- �����
        select 
        PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
--        (select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
        a.* 
        from TMP_GDM_90901 a
        where 
            nvl(client,0)<>0
            and nvl(contract,0)=0
            --and nvl(f_contract,0)=0
            --and substr(code,6,3)='810'
            --and code='90901810253101004114' --
          

    )loop
        sLog:=null;
        nUpd:=1;
        nGetCont :=f_get_cont(rec.code,rec.client,rec.branch_client,'CARD_ACCOUNT',rCont);
        DBMS_OUTPUT.PUT_LINE(nGetCont||' '||rCont.reference||'/'||rCont.Branch);
        --sAcc := f_find_acc(rec.code);
        sAcc := f_find_acc2(rec.code);
        DBMS_OUTPUT.PUT_LINE(sAcc);
        
        
        if nGetCont=1 then
             if (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and rCont.account=PTOOLS5.READ_PARAM(sAcc,'ACC_1')) or (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=0 and to_number(PTOOLS5.READ_PARAM(sAcc,'JOU'))=0) 
                -- ���� ��� �������, ����� �������� �� ��������� ������, �������� ����, �� ������ ��� ��������, ���� �������� ���. �.�. ���� ���� ������ �� ��������� ���������. ������������ ����� ��������� ���.
                or (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=0) --������������� �� �� ����� ���������
             then 
                DBMS_OUTPUT.PUT_LINE('�������� '||rec.code);
                if 1=nUpd then
                    --update account set contract=rCont.reference, branch_contract=rCont.branch
                    --    where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0;
                    update TMP_GDM_90901 set f_contract=rCont.reference, f_branch_contract=rCont.branch
                        where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0 and nvl(f_contract,0)=0;                        
                    commit; 
                end if;
             else 
                if to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and rCont.account!=PTOOLS5.READ_PARAM(sAcc,'ACC_1') then
                    DBMS_OUTPUT.PUT_LINE('NO_UPD '||rec.code||' ���� ���������� �������� �� ����� ����� �� �������� '||rCont.account||'<> '||PTOOLS5.READ_PARAM(sAcc,'ACC_1'));
                    sLog:=sLog||'���� �������� '||rCont.account||' <> ����� �� ��������'||PTOOLS5.READ_PARAM(sAcc,'ACC_1')||';';
                else
                    DBMS_OUTPUT.PUT_LINE('NO_UPD '||rec.code);
                end if;
             end if;
        else
            DBMS_OUTPUT.PUT_LINE('NO_UPD2 '||rec.code);
        end if; 
        -- ���� ��� ������ ����� ����� �� ��������, �� ������������ ����� ��������� � �������� �� ����� �� �������� �� ���� ������ - ������ ����� ��������� ���������� �� ���������� 90901
        -- + ����� ��������� �������, ����� ����� ����������, ��� ���� �� �������� �� ����������� ������� �� 90901
        if nGetCont=0 then
             if (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and to_number(PTOOLS5.READ_PARAM(sAcc,'JOU'))>0) then 
                if  universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(PTOOLS5.READ_PARAM(sAcc,'ACC_1')), cd => PTOOLS5.READ_PARAM(sAcc,'ACC_1'), cr=>substr(PTOOLS5.READ_PARAM(sAcc,'ACC_1'),6,3),account_rec => rAcc) then
                    if nvl(rAcc.contract,0)>0 and nvl(rAcc.branch_contract,0)>0 
                        -- ������� �������� �������
                        and nvl(rAcc.client,0)=rec.client and nvl(rAcc.branch_client,0)=rec.branch_client
                    then
                        DBMS_OUTPUT.PUT_LINE('�������� �� ��������� '||rec.code||' ������� '||rAcc.contract||'/'||rAcc.branch_contract||' '||rAcc.code);
                        sLog:=sLog||'�������� �� ���������;';
                        if 1=nUpd then
                            --update account set contract=rCont.reference, branch_contract=rCont.branch
                                --    where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0;
                            update TMP_GDM_90901 set f_contract=rAcc.contract, f_branch_contract=rAcc.branch_contract
                            where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0 and nvl(f_contract,0)=0;                        
                            commit; 
                        end if;
                    else
                        DBMS_OUTPUT.PUT_LINE('NO_UPD3 ���� �� �������� �� ��������� � �������� �� ����� 90901 '||rec.code||' ������� '||rAcc.contract||'/'||rAcc.branch_contract||' '||rAcc.code);
                        sLog:=sLog||'�� ��������� ������� �� ����� �� �������� '||rAcc.code||' �� ������ 90901;';
                    end if;
                end if;
             end if;
        else
            DBMS_OUTPUT.PUT_LINE('NO_UPD4 '||rec.code);
        end if; 
        
        DBMS_OUTPUT.PUT_LINE('----');
        if 1=nUpd then
            update TMP_GDM_90901 set log_contract=sLog
               where reference=rec.reference and branch=rec.branch;                        
            commit; 
        end if;

    end loop;

end;
/
