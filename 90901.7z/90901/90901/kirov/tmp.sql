select * from contracts cc where 
--reference=16513003
(refer_client,branch_client) in (select client,branch_client from account where code in ('90901392709251000001'))
and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'#')=0 
and value='90901392709251000001')

select rowid, 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.value), a.value,substr(a.value,6,3), sysdate) saldo,
a.* from variable_contracts a where 
(reference,branch) in (select reference,branch from contracts where account='40702392409250000001') 
and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)

and value='90901810500001023171'

40702810200000127530

--select * from variable_contracts where reference=12368260 and branch=3 and instr(name,'CARD_ACCOUNT')>0 and value='90901156600071002508'
--select * from variable_contracts where reference=12368261 and branch=3 and instr(name,'CARD_ACCOUNT')>0 and value='90901156600071002508'

--    select * from contracts cc 
--        where refer_client=114415710 and branch_client=191
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
--                        and instr(name,'CARD_ACCOUNT')>0 and instr(name,'_CARD_ACCOUNT')=0 --and instr(name,'_')=0 
--                        and value='90901156109031000122');

select distinct docnum||',' reference,branch from
    (
    select * from journal j where header=paccount.HEADER_ACCOUNT('90901810500001023171') and code='90901810500001023171' --or assist='90901156109031000122')
        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21,1198))
        --and docnum=6441065990
    order by work_date desc
        )
        
--select rowid,j.*  from journal j where docnum in (5599179191)
--
--SELECT * FROM v_documents d WHERE d.reference = 5599179191 AND d.Branch = 540401
--
--SELECT * FROM v_documents d WHERE d.Related = 5599179191 AND d.Branch_Related = 540401
--            
--SELECT * FROM v_documents d WHERE d.refer_from = 5599179191 AND d.Branch_from = 540401
--
--            AND (d.status >= 30 AND d.status < 1000)        
--            
--            
--select * from account where code in ('40702156300070002508','40702156600071002508')            

select level,
d.* from v_documents d
--where (status in (35,36,38) or (status in (30) and type_doc in (3363)))-- and trim(payers_account)<>''))
where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0')) 
connect by NOCYCLE 
--prior refer_from=reference and prior branch_from=branch --or 
--prior reference=refer_from and prior branch=branch_from --or 
--prior coalesce(related,refer_from)=reference and prior coalesce(branch_related,branch_from)=branch
prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
--prior reference=related and prior branch=branch_related
start with (reference,branch) in (select reference,branch from v_documents where reference in (
6279286964,
6279286965,
6311339180,
6547219223,
6550094261) and branch=191)--
--start with reference=5599179191 and branch=540401
order by level desc

40702810553000017685
40702810850000017685

select * from (
select acc_mbank acc_new,header,'CFT' abs from acc_migr_cft_to_mbank 
where acc_cft='40702810627110000010' --and header=paccount.HEADER_ACCOUNT('40702156300070002508')
union all
select acc_mbank acc_new,header,'CABS' abs from acc_migr_cabs_to_mbank 
where acc_cft='40702810627110000010' --and header= paccount.HEADER_ACCOUNT('40702156300070002508')
union all
select acc_new acc_new,header,'MBANK' abs from acc_closed_filial 
where acc_old='40702810627110000010' --and header= paccount.HEADER_ACCOUNT('40702156300070002508')
)


select * from account where code in (
'90901810100471006568','40702978400470005568'
)
and header in ('A','C')

--
--select * from acc_migr_cft_to_mbank 
--where (acc_mbank in ('40603840300630005646','40603840700630005646') or acc_cft in ('40603840300630005646','40603840700630005646'))
--
--select * from acc_migr_cabs_to_mbank 
--where (acc_mbank in ('40603840300630005646','40603840700630005646') or acc_cft in ('40603840300630005646','40603840700630005646'))
--
--select * from acc_closed_filial 
--where (acc_old in ('40603840700630005646','40603840700630005646') or acc_new in ('40603840700630005646','40603840700630005646'))
--
--
--40603840300630005646    40603840700630005646
--
--
--select * from guides where type_doc=3420


