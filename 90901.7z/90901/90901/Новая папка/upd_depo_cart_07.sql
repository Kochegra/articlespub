declare
  i number;
begin
  for rec in (select (select count(*) from journal j where j.docnum = u1.reference and j.branch = u1.branch) acc_909_journal,
                     (select count(*) from contracts c where c.account = u1.payers_account and date_close is null) count_open_cont,
                     coalesce(universe.VARIABLE_DOC(nBranch => u1.branch, nREFERENCE => u1.reference, cName => 'CARD_ACCOUNT'),(select max((case when payers_account like '99999%' then receivers_account else payers_account end)) from v_documents d where type_doc = 198 and d.related = u1.reference and d.BRANCH_related = u1.branch)) acc_909_child,
                     u1.branch, u1.reference, u1.doc_number, u1.payers_account, u1.receivers_account, u1.summa, u1.memo, u.user_name, u.user_,
                     (select sum(summa) from v_documents vd where ((vd.REFER_FROM = u1.reference and vd.BRANCH_FROM = u1.branch) or (vd.RELATED = u1.reference and vd.BRANCH_related = u1.branch)) and payers_account like '909%') dt_pay,
                     (select sum(summa) from v_documents vd where ((vd.REFER_FROM = u1.reference and vd.BRANCH_FROM = u1.branch) or (vd.RELATED = u1.reference and vd.BRANCH_related = u1.branch)) and receivers_account like '909%') cr_pay
                from documents u1, users u
               where status in (22, 35, 38)
                 and u1.owner = u.user_id
                 and to_number(substr(PAYERS_ACCOUNT, 1, 3)) between 416 and 426
                 and not exists
               (SELECT 1
                        FROM k2_multi z1
                       WHERE z1.reference = u1.reference
                         AND z1.branch = u1.branch
                         AND z1.is_main = 1
                      UNION
                      SELECT 1
                        FROM account            ab1,
                             variable_documents aa1
                       WHERE aa1.reference = u1.reference
                         AND aa1.branch = u1.branch
                         AND aa1.name IN ('CARD_ACCOUNT', 'CARD_ACCOUNT_WAIT')
                         AND aa1.value = ab1.code
                         AND ab1.close_date IS NULL
                         AND ab1.header = 'C'
                         AND ROWNUM < 2)) loop
    if universe.VARIABLE_DOC(nBranch => rec.branch, nREFERENCE => rec.reference, cName => 'CARD_ACCOUNT') is null then
      if rec.acc_909_child is not null then
        universe.INPUT_VAR_DOC(nBranch => rec.branch, nREFERENCE => rec.reference, cName => 'CARD_ACCOUNT', cValue => rec.acc_909_child);
      end if;
    end if;  
  end loop;
  commit;
end; 
/
