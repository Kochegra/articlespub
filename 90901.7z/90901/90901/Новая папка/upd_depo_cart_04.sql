declare 
  i number;
begin
  ptools2.short_init_user(1403);
  for rec in (select 5581776286 reference, 191 branch from dual union all
              select 6171512162 reference, 191 branch from dual union all
              select 6882798987 reference, 191 branch from dual union all
              select 3542258115 reference, 191 branch from dual union all
              select 3542259142 reference, 191 branch from dual union all
              select 5981615450 reference, 191 branch from dual union all
              select 6074817437 reference, 191 branch from dual union all
              select 6071457636 reference, 191 branch from dual union all
              select 6314926528 reference, 191 branch from dual union all
              select 5581760528 reference, 191 branch from dual union all
              select 6171477066 reference, 191 branch from dual union all
              select 5718263069 reference, 191 branch from dual union all
              select 6071430634 reference, 191 branch from dual union all
              select 6333380665 reference, 191 branch from dual union all
              select 5905856279 reference, 191 branch from dual union all
              select 6020455116 reference, 191 branch from dual union all
              select 6432957305 reference, 191 branch from dual union all
              select 6416057053 reference, 191 branch from dual union all
              select 6432982317 reference, 191 branch from dual) loop
    --i := 0;          
    begin
      update documents 
        set status = 36
        where branch = rec.branch
          and reference = rec.reference;
    exception
      when others then 
        null;
    end;    
    commit;  
    --dbms_output.put_line(i);          
  end loop;
end;
/
