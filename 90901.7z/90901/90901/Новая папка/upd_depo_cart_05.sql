declare 
  i number;
begin
  ptools2.short_init_user(1403);
  for rec in (select 6772828812 reference, 191 branch from dual union all
              select 6813628158 reference, 191 branch from dual union all
              select 6732240491 reference, 191 branch from dual union all
              select 101969826 reference, 47 branch from dual union all
              select 6701491149 reference, 191 branch from dual union all
              select 6866068662 reference, 191 branch from dual union all
              select 6259854735 reference, 191 branch from dual union all
              select 6225669373 reference, 191 branch from dual union all
              select 6701475673 reference, 191 branch from dual union all
              select 5785009669 reference, 191 branch from dual union all
              select 6778188362 reference, 191 branch from dual union all
              select 6290880929 reference, 191 branch from dual union all
              select 6701501261 reference, 191 branch from dual union all
              select 5751764218 reference, 191 branch from dual union all
              select 6880622406 reference, 191 branch from dual union all
              select 6334922772 reference, 191 branch from dual union all
              select 6772835211 reference, 191 branch from dual union all
              select 5785082495 reference, 191 branch from dual union all
              select 5784474273 reference, 191 branch from dual union all
              select 6090100970 reference, 191 branch from dual union all
              select 6090104950 reference, 191 branch from dual union all
              select 5785097106 reference, 191 branch from dual union all
              select 6090094849 reference, 191 branch from dual union all
              select 6008017290 reference, 191 branch from dual union all
              select 6008024451 reference, 191 branch from dual union all
              select 6693387380 reference, 191 branch from dual union all
              select 6693376539 reference, 191 branch from dual union all
              select 6225719531 reference, 191 branch from dual union all
              select 6225728661 reference, 191 branch from dual union all
              select 6225706665 reference, 191 branch from dual union all
              select 6346044478 reference, 191 branch from dual union all
              select 6884411171 reference, 191 branch from dual union all
              select 6839848908 reference, 191 branch from dual union all
              select 6731288530 reference, 191 branch from dual union all
              select 6731283925 reference, 191 branch from dual union all
              select 6330918645 reference, 191 branch from dual union all
              select 6839836443 reference, 191 branch from dual union all
              select 6839843609 reference, 191 branch from dual union all
              select 6839819578 reference, 191 branch from dual union all
              select 6866109496 reference, 191 branch from dual union all
              select 6839790288 reference, 191 branch from dual union all
              select 6701481218 reference, 191 branch from dual union all
              select 6773117542 reference, 191 branch from dual union all
              select 6815129069 reference, 191 branch from dual union all
              select 6814892043 reference, 191 branch from dual union all
              select 6508008383 reference, 191 branch from dual union all
              select 6727750516 reference, 191 branch from dual union all
              select 6817369900 reference, 191 branch from dual union all
              select 6743133305 reference, 191 branch from dual union all
              select 6670290653 reference, 191 branch from dual union all
              select 6810403818 reference, 191 branch from dual union all
              select 6881607228 reference, 191 branch from dual union all
              select 6881613207 reference, 191 branch from dual union all
              select 6792111473 reference, 191 branch from dual union all
              select 6828350459 reference, 191 branch from dual union all
              select 6685624187 reference, 191 branch from dual union all
              select 6584500645 reference, 191 branch from dual union all
              select 6881542863 reference, 191 branch from dual union all
              select 6150774959 reference, 191 branch from dual union all
              select 6071288186 reference, 191 branch from dual union all
              select 6892444991 reference, 191 branch from dual union all
              select 6732215739 reference, 191 branch from dual union all
              select 6810225295 reference, 191 branch from dual union all
              select 6782798267 reference, 191 branch from dual union all
              select 6595146596 reference, 191 branch from dual union all
              select 6306107222 reference, 191 branch from dual union all
              select 6724862751 reference, 191 branch from dual union all
              select 6866294378 reference, 191 branch from dual union all
              select 6306109352 reference, 191 branch from dual union all
              select 6306110146 reference, 191 branch from dual union all
              select 6723591025 reference, 191 branch from dual union all
              select 6881571960 reference, 191 branch from dual union all
              select 6881574783 reference, 191 branch from dual union all
              select 6881563524 reference, 191 branch from dual union all
              select 6045377083 reference, 191 branch from dual union all
              select 6305741593 reference, 191 branch from dual union all
              select 6020290006 reference, 191 branch from dual union all
              select 6071654327 reference, 191 branch from dual union all
              select 6817233298 reference, 191 branch from dual union all
              select 6817242501 reference, 191 branch from dual union all
              select 6817237766 reference, 191 branch from dual union all
              select 6881557906 reference, 191 branch from dual union all
              select 6836526790 reference, 191 branch from dual union all
              select 6817227279 reference, 191 branch from dual union all
              select 6683048699 reference, 191 branch from dual union all
              select 6613248375 reference, 191 branch from dual union all
              select 6462484664 reference, 191 branch from dual union all
              select 6187888327 reference, 191 branch from dual union all
              select 6745658313 reference, 191 branch from dual union all
              select 6895027386 reference, 191 branch from dual union all
              select 6745632810 reference, 191 branch from dual union all
              select 6795316241 reference, 191 branch from dual union all
              select 6306116134 reference, 191 branch from dual union all
              select 6306116817 reference, 191 branch from dual union all
              select 6749153182 reference, 191 branch from dual union all
              select 6682981625 reference, 191 branch from dual union all
              select 6048500901 reference, 191 branch from dual union all
              select 6048638503 reference, 191 branch from dual union all
              select 6149164096 reference, 191 branch from dual union all
              select 6048021935 reference, 191 branch from dual union all
              select 6048444221 reference, 191 branch from dual union all
              select 6745599869 reference, 191 branch from dual union all
              select 6305281356 reference, 191 branch from dual union all
              select 6815178935 reference, 191 branch from dual union all
              select 6680539756 reference, 191 branch from dual union all
              select 6865822470 reference, 191 branch from dual union all
              select 6441041821 reference, 191 branch from dual union all
              select 6116944945 reference, 191 branch from dual union all
              select 6390807199 reference, 191 branch from dual union all
              select 6865829197 reference, 191 branch from dual union all
              select 6851011459 reference, 191 branch from dual union all
              select 6612977987 reference, 191 branch from dual union all
              select 6775463715 reference, 191 branch from dual union all
              select 6773810165 reference, 191 branch from dual union all
              select 6836672961 reference, 191 branch from dual union all
              select 6441029501 reference, 191 branch from dual union all
              select 6064100685 reference, 191 branch from dual union all
              select 6728667192 reference, 191 branch from dual union all
              select 6795419738 reference, 191 branch from dual union all
              select 6190668678 reference, 191 branch from dual union all
              select 6742248047 reference, 191 branch from dual union all
              select 6788584084 reference, 191 branch from dual union all
              select 6456080599 reference, 191 branch from dual union all
              select 6592560672 reference, 191 branch from dual union all
              select 6884415641 reference, 191 branch from dual union all
              select 6815221606 reference, 191 branch from dual union all
              select 6306102771 reference, 191 branch from dual union all
              select 6306100562 reference, 191 branch from dual union all
              select 6306101030 reference, 191 branch from dual union all
              select 6306096558 reference, 191 branch from dual union all
              select 6306122462 reference, 191 branch from dual union all
              select 6306129115 reference, 191 branch from dual union all
              select 6306129526 reference, 191 branch from dual union all
              select 6306129934 reference, 191 branch from dual union all
              select 6306130350 reference, 191 branch from dual union all
              select 6306127057 reference, 191 branch from dual union all
              select 6306127644 reference, 191 branch from dual union all
              select 6306128653 reference, 191 branch from dual union all
              select 6865831535 reference, 191 branch from dual union all
              select 6535653830 reference, 191 branch from dual union all
              select 6743087213 reference, 191 branch from dual union all
              select 6459632582 reference, 191 branch from dual union all
              select 6745269671 reference, 191 branch from dual union all
              select 6594953949 reference, 191 branch from dual union all
              select 6865662381 reference, 191 branch from dual union all
              select 6742576100 reference, 191 branch from dual union all
              select 6587990946 reference, 191 branch from dual union all
              select 6865666712 reference, 191 branch from dual union all
              select 6742239868 reference, 191 branch from dual union all
              select 6817387750 reference, 191 branch from dual union all
              select 6854932188 reference, 191 branch from dual union all
              select 6676387134 reference, 191 branch from dual union all
              select 6772313241 reference, 191 branch from dual union all
              select 6728705652 reference, 191 branch from dual union all
              select 6881617362 reference, 191 branch from dual union all
              select 6728704593 reference, 191 branch from dual union all
              select 6676408999 reference, 191 branch from dual union all
              select 6670725321 reference, 191 branch from dual union all
              select 6653689273 reference, 191 branch from dual union all
              select 6881577614 reference, 191 branch from dual union all
              select 6865836167 reference, 191 branch from dual union all
              select 6865842446 reference, 191 branch from dual union all
              select 6724849567 reference, 191 branch from dual union all
              select 6728675405 reference, 191 branch from dual union all
              select 6312007132 reference, 191 branch from dual) loop
    --i := 0;          
    begin
      update documents 
        set status = 36
        where branch = rec.branch
          and reference = rec.reference;
    exception
      when others then 
        null;
    end;   
    commit;   
    --dbms_output.put_line(i);          
  end loop;
end;
/