declare 
  i number;
begin
  ptools2.short_init_user(1403);
  universe.INPUT_VAR_DOC(nBranch => 191, nREFERENCE => 6641911557, cName => 'CARD_ACCOUNT', cValue => '90902810804249782979');
  universe.INPUT_VAR_DOC(nBranch => 191, nREFERENCE => 6477466277, cName => 'CARD_ACCOUNT', cValue => '90902810306560201789');
  universe.INPUT_VAR_DOC(nBranch => 191, nREFERENCE => 5744699733, cName => 'CARD_ACCOUNT', cValue => '90901810027250000703');
  commit;
end;
/