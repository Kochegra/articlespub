declare 
  i number;
begin
  ptools2.short_init_user(1403);
  for rec in (select 5780874034 ip, 6991544536 vn, '90902810016249782181' acc_vn from dual union all
              select 6539494604 ip, 6477478591 vn, '90902810306560201789' acc_vn from dual union all
              select 6878269955 ip, 6878277980 vn, '90902810830240009227' acc_vn from dual union all
              select 6867678875 ip, 6867783359 vn, '90902810500009900169' acc_vn from dual union all
              select 6839782104 ip, 6839787730 vn, '90902810700499781507' acc_vn from dual union all
              select 6839772061 ip, 6839779714 vn, '90902810800258401850' acc_vn from dual union all
              select 6346910084 ip, 6346910348 vn, '90902810120240001401' acc_vn from dual) loop
    i := 0;          
    for rec_d in (select * from v_documents where reference = rec.vn and type_doc = 198) loop
      i := 1;
      for rec_d_i in (select * from v_documents where reference = rec.ip and type_doc = 226) loop
        update archive 
          set refer_from = rec_d_i.reference,
              branch_from = rec_d_i.branch
          where branch = rec_d.branch
            and reference = rec_d.reference;
        universe.INPUT_VAR_DOC(nBranch => rec_d_i.branch, nREFERENCE => rec_d_i.reference, cName => 'CARD_ACCOUNT', cValue => rec.acc_vn);    
        i := 2;
        commit;
      end loop; 
    end loop;
    --dbms_output.put_line(i);          
  end loop;
end;
/           
