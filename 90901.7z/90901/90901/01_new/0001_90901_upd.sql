universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.code), cd => rec.code, cr=>substr(rec.code,6,3),account_rec => rAcc) -- ������ ����
Universe.get_contract_rec(rf => nRefCont, br => nBrCont, stat => null, acc => null, tp => null, contracts_rec => rCont) -- ������ ��������

-- ������ ��������� ����� (��� �������� ������). ������� � STATUS_ACCOUNT
-- 1 - ����������, 0 - �� ����������
-- ptools_account2.IsCodeTranzit(p_Account)
select ptools_account2.IsCodeTranzit('40702156300070002508') a1, ptools_account2.IsCodeTranzit('40702156600071002508') a2 from dual

-- ������� � ������ ����� � ���
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate) sal, -- saldo
PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal, --"�������"
--+ ����������
round(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate)*pledger.WCOURSE(substr(a.code,6,3), SysDate),2) sal, -- saldo
round(PLEDGER.SALDO(paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate),2) sal, --"�������"

-- ���� ��������� ��������
-- vers 1
 function f_last_ledger(p_acc account.code%type) return date is 
 begin
    for r in (select COALESCE((select work_date from ledger l WHERE header = paccount.HEADER_ACCOUNT(p_acc) and code = p_acc and currency = substr(p_acc,6,3) and rest_id = 0 
                                and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),to_date('01.01.1900','DD.MM.YYYY')) last_ledger  
                     ,a.*
              from account a where header='C' and code = p_acc)    
    loop
        return r.last_ledger;
    end loop;
 end;   
--vers 2
,(select nvl(to_char(wd,'dd.mm.yyyy'),'�����������') from (select max(work_date) wd from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code)) last_date --"���� ��������� ��������" 

-- ����� �� ���������
  function f_find_acc2(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    --rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
    sAccMigr account.code%type;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
            for dK2 in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                if UNIVERSE.GET_DOCUMENT_REC(dK2.reference, dK2.branch, nArch, 1, rDocRel) then
                        -- �������� �������������
                        sAccMigr:=get_acc_migr(rDocRel.payers_account,paccount.HEADER_ACCOUNT(rDocRel.payers_account));
                        if sAccMigr is null or sAccMigr in ('TOO_MANY_ROWS','OTHERS') then
                            if instr('#'||sRes,rDocRel.payers_account)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||rDocRel.payers_account||']';
                            end if;
                        else
                            if instr('#'||sRes,sAccMigr)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||'[ACC_'||nCnt||'='||sAccMigr||'][MIGR_'||nCnt||'=1]';
                            end if;
                        end if;
                    end if;                
            end loop;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;





/
declare
rAcc account%rowtype;
nRefCont contracts.reference%type;
nBrCont contracts.branch%type;
bCont boolean;
nCntAcc number;
sAccJour varchar(2000);
rCont contracts%rowtype;
-- �������� ����� �� �������� ��������
 FUNCTION get_acc_migr (p_acc account.code%type, p_header account.header%type)
    RETURN VARCHAR2
  AS
    ret   account.code%type;
  BEGIN
    select distinct(acc_new) into ret 
    from (
          select acc_mbank acc_new,header,'CFT' abs from acc_migr_cft_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_mbank acc_new,header,'CABS' abs from acc_migr_cabs_to_mbank 
          where acc_cft=p_acc and header=p_header
          union all
          select acc_new acc_new,header,'MBANK' abs from acc_closed_filial 
          where acc_old=p_acc and header=p_header
          );
    RETURN ret;
  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
      RETURN NULL;
    WHEN TOO_MANY_ROWS
    THEN
      RETURN 'TOO_MANY_ROWS';
    WHEN OTHERS
    THEN
      RETURN 'OTHERS';
  END get_acc_migr;
-- ����� �� ���������
  function f_find_acc(p_code account.code%type,pCnt out number) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    --rDocRefFrom documents%rowtype;
    rDocRel documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
    sAccMigr account.code%type;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
            for doc in (select level,d.* from v_documents d
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363))) 
                        --where (status in (35,36,38) or (status in (30) and type_doc in (3363) and nvl(trim(payers_account),'0')<>'0'))
                        --where type_doc not in (198)
                        where payers_account is not null and type_doc not in (198) and substr(payers_account,1,5) not in ('47422','47423')
                            connect by NOCYCLE 
                            prior decode(related,0,refer_from,related)=reference and prior decode(branch_related,0,branch_from,branch_related)=branch
                            start with reference=rDoc.reference and branch=rDoc.branch
                        order by level desc
            )loop
                if UNIVERSE.GET_DOCUMENT_REC(doc.reference, doc.branch, nArch, 1, rDocRel) then
                        -- �������� �������������
                        sAccMigr:=get_acc_migr(rDocRel.payers_account,paccount.HEADER_ACCOUNT(rDocRel.payers_account));
                        if sAccMigr is null or sAccMigr in ('TOO_MANY_ROWS','OTHERS') then
                            if instr('#'||sRes,rDocRel.payers_account)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||rDocRel.payers_account||',';
                            end if;
                        else
                            if instr('#'||sRes,sAccMigr)=0 then
                                nCnt:=nCnt+1;
                                sRes:=sRes||sAccMigr||',';
                            end if;
                        end if;
                    end if;                
            end loop;
       end if; 
       nJou:=nJou+1;
    end loop;
    pCnt:=nCnt;                        
    --if nCnt>0 then 
        --sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;

begin
    for rec in (
    
        select 
        --decode(nvl(a.contract,0),0,decode(nvl(a.f_contract,0),0,0,a.f_contract),a.contract) decode_conract, 
        --nvl(coalesce(a.f_contract,a.contract),0) coalesce_contract,
        greatest(nvl(a.contract,0),nvl(a.f_contract,0)) greatest_contract,
        --nvl2(a.f_contract,a.f_contract,a.contract) nvl2_contract,       
        rowid,a.*
        from TMP_TABLES.TMP_GDM_90901 a
        where 
            exists(select null from account where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code and currency=substr(a.code,6,3) and close_date is null)
            --and nvl(contract,0)=0 and nvl(f_contract,0)=0  --�������� �� ���������
            and (nvl(contract,0)!=0 or nvl(f_contract,0)!=0) -- �������� ��������� vers1
            and rownum<100
            --and greatest(nvl(a.contract,0),nvl(a.f_contract,0))!=0 -- �������� ��������� vers2
            --and 
            --and code in ('90901156600071002508','90901810704240005853','90901840100231020084','90901840900111020074','90901978100321500218','90901810809020840243')-- �������� � �����������
            --and exists(select null from contracts where reference=greatest(nvl(a.contract,0),nvl(a.f_contract,0)) 
            --            and branch=greatest(nvl(a.branch_contract,0),nvl(a.f_branch_contract,0))
            --            and ptools_account2.IsCodeTranzit(account)=1)

    
    )loop
        -- ����������?
        -- ����� ��� �� ��������
        -- ����� ��� �� ����������
        if  universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(rec.code), cd => rec.code, cr=>substr(rec.code,6,3),account_rec => rAcc) then
            dbms_output.put_line(rec.code||' '||rAcc.code); -- ���� 90901
            if nvl(rAcc.contract,0)<>0 then
                nRefCont:=rAcc.contract;
                nBrCont:=rAcc.branch_contract;
            else 
                nRefCont:=greatest(nvl(rec.contract,0),nvl(rec.f_contract,0));
                nBrCont:=greatest(nvl(rec.branch_contract,0),nvl(rec.f_branch_contract,0));
            end if;
            if nRefCont>0 then
                --if 
                bCont:=Universe.get_contract_rec(rf => nRefCont, br => nBrCont, stat => null, acc => null, tp => null, contracts_rec => rCont); 
                --then
                --    dbms_output.put_line(rCont.account); -- ���� ��� �� ��������
                --end if;
            else
                exit;
            end if;
            dbms_output.put_line(rCont.account); -- ���� ��� �� ��������
        end if;
        sAccJour := f_find_acc(rec.code,nCntAcc);
        dbms_output.put_line(nCntAcc||' '||sAccJour); -- ���� ��� �� ��������
        dbms_output.put_line('------------------------------');
    end loop;
end;

/ 