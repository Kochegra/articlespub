--��������� ����� ��������� 90901 90902
--����� ����� �� ��������
declare 
  cl_name varchar2(2000);
  vAcc varchar(30);
begin
ptools2.short_init_user(1480729);
    for rec_cont in (select * from contracts where reference = 18680149 and branch = 296)
    loop
        for cl in (select * from clients where reference = rec_cont.refer_client and branch =  rec_cont.branch_client)
        loop
            cl_name := cl.full_name;
        end loop;
        vAcc := ptools_909.add_account(p_Account => rec_cont.account, p_Bal => '90901', p_AccSym => '1' || SUBSTR(rec_cont.account,4, 2)
        , p_Date => TRUNC(sysdate), p_Cur =>'810', p_Owner => rec_cont.owner, p_refer_client => rec_cont.refer_client, p_branch_client => rec_cont.branch_client
        , p_full_name =>  SUBSTR (cl_name, 1, 80)) ;
        DBMS_OUTPUT.PUT_LINE(vAcc);
        if vAcc is not null then
            update account set contract = rec_cont.reference, branch_contract = rec_cont.branch
            --,name = 
            where code = vAcc;
            universe.input_var_contr(rec_cont.branch, rec_cont.reference, 'CARD_ACCOUNT_3_RUR',vAcc); 
            --universe.input_var_contr(rec_cont.branch, rec_cont.reference, 'CARD_ACCOUNT_3',vAcc); 
            --universe.input_var_contr(rec_cont.branch, rec_cont.reference, 'CARD_ACCOUNT_2',vAcc); 
        
        end if;
    end loop;                                                         
end;   
/

select * from clients where reference = 142329 and branch =  354

select rowid,a.* from account a where code in (--'90902810200980002790',
'90901810700171002204')

select * from contracts where reference in (670836,671493) and status=50



select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.xsummacredit, a.owner, a.type_doc, a.doc_number
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
,a.date_document
--distinct a.status,a.payers_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null) card_account,Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD, 
--            Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT
from documents a
  where --(k2.refer_contract,k2.branch_contract) in (select refer_contract,branch_contract from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    payers_account in ('40702810500980091790','40702810200989091790') --(select acc_rko from TMP_TABLES.TMP_GDM_k2 where refer_contract=29379)
    and a.status in (35,38)
--    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT',null),'#')='90901810000601030019'
--    and nvl(Universe.VARIABLE_PART(a.reference,a.branch,'CARD_ACCOUNT_OLD',null),'#')='90902810900600000916'
  
select rowid,a.* from variable_contracts a where (reference,branch,name,value) in (
select reference,branch,name,value from tmp_tables.tmp_gdm_vc where value in ('90901810200981002790')
)  

select rowid,a.* from variable_contracts a where reference=670836 and branch=354



select * from users where subdepartment=296 and user_name like '�����%'