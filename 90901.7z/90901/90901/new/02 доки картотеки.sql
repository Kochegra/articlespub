-- ��������� � �2

-- 1 DOCUMENTS+COLLECTOR_CONTRACTS
select --d.reference||','
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,d.*
,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
--,d_3363.SumRelated(d.reference
--                  ,d.branch) sum_related
--, universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
from   documents           d
       ,collector_contracts c
where  1 = 1
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810900000004791'))
    and (c.reference,c.branch) = (select nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from account a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    and d.branch = c.zbranch_docnum
    and d.reference = c.docnum
    --and c.reference = 17795596 --17741941 --cpRefCont
    --and c.branch = 780 --cpBranchCont
    and c.name = 'CARDLIST_2'
    and c.summa in (0, 1)
    and rownum > 0
    and d.status not in (36)--, 38)
    and d.status >= 30
    and d.status < 1000
    --and d.status <= -30
    --and d.status > -1000
    --and substr(d.payers_account,6,3)<>'810'  

-- 2 DOCUMENTS
select --d.reference||','
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT
,UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD
,d.*
--,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
--,d_3363.SumRelated(d.reference
--                  ,d.branch) sum_related
--, universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
from   documents           d
where  1 = 1
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810900000004791'))
    --and (c.reference,c.branch) = (select nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from account a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    and d.payers_account='40702810900000004791'
    and d.status not in (36)--, 38)
    and d.status >= 30
    and d.status < 1000
    --and substr(d.payers_account,6,3)<>'810'  

-- 3 DOCUMENTS+k2
select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.owner, a.type_doc, a.doc_number,
    (select min(trunc(work_date)) from journal j where j.docnum = a.reference and j.branch = a.branch and j.code like '9090%' and j.assist like '99999%') date_work,
--                              case when a.date_work is null
--                                   then case when a.date_document is null then trunc(a.date_create) else a.date_document end
--                                   else a.date_work end date_work,
Universe.VARIABLE_DOC(a.branch, a.reference, 'COMPDOC_STATUS') COMPDOC_STATUS
,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT') CARD_ACCOUNT
,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT_OLD') CARD_ACCOUNT_OLD
,a.date_document
from documents a, k2
  where a.reference = k2.reference
    and a.branch    = k2.branch
--    and k2.refer_contract     = p_Reference
--    and k2.branch_contract    = p_Branch
    and (k2.refer_contract,k2.branch_contract) in (select nvl(a.contract,a.f_contract),nvl(a.branch_contract,a.f_branch_contract) from TMP_TABLES.TMP_GDM_90901 a where code in ('90901398000001001791'))
    and k2.what_is = 2
    and a.status in (35)
union
select 
a.status,
2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.owner, a.type_doc, a.doc_number,
(select min(trunc(work_date)) from journal j where j.docnum = a.reference and j.branch = a.branch and j.code like '9090%' and j.assist like '99999%') date_work,
Universe.VARIABLE_DOC(a.branch, a.reference, 'COMPDOC_STATUS') COMPDOC_STATUS
,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT') CARD_ACCOUNT
,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT_OLD') CARD_ACCOUNT_OLD
,a.date_document
from documents a, k2_multi k2m
where a.reference = k2m.reference
  and a.branch    = k2m.branch
  --and k2m.refer_contract     = p_Reference
  --and k2m.branch_contract    = p_Branch
  and (k2m.refer_contract,k2m.branch_contract) in (select nvl(a.contract,a.f_contract),nvl(a.branch_contract,a.f_branch_contract) from TMP_TABLES.TMP_GDM_90901 a where code in ('90901398000001001791'))
  and a.status in (35)

/


select * from k2 where account in ('40702810900000004791')

select * from k2_multi k2m where (k2m.refer_contract,k2m.branch_contract) in (select nvl(a.contract,a.f_contract),nvl(a.branch_contract,a.f_branch_contract) from TMP_TABLES.TMP_GDM_90901 a where code in ('90901398000001001791'))



-- ��������� � �1
-- 1 DOCUMENTS
select --d.reference||','
UNIVERSE.VARIABLE_PART(d.reference,d.branch,'CARD_ACCOUNT1',null) CARD_ACCOUNT1
,d.*
--,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
--,d_3363.SumRelated(d.reference
--                  ,d.branch) sum_related
--, universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
from   documents           d
where  1 = 1
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
    --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810900000004791'))
    --and (c.reference,c.branch) = (select nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from TMP_TABLES.TMP_GDM_90901 a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    --and (c.reference,c.branch) in (select a.contract,a.branch_contract from account a where header=paccount.HEADER_ACCOUNT('90901398000001001791') and code in ('90901398000001001791'))
    and d.payers_account='40702810500000050077'
    and d.status = 22
    --and d.status >= 30
    --and d.status < 1000
    --and substr(d.payers_account,6,3)<>'810'  

