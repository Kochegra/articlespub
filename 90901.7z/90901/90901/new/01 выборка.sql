select 
--count(*)
--(select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
--(select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--    and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
--rowid,
a.code 
,PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal
,case 
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1/1; � 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1; � 1/1; � 1/5'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1; � 1/1'
    when not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_1')>0 and instr(name,'CARD_ACCOUNT_15')=0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '� 1; � 1/5'
    else '�� ���������'
 end type   
,case 
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8))
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/5 - ��� ������ ������ � � 1/1'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8))
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/5 - ��� ������ ������ � � 1/1 (�������� ��� �� ���� �� � 1/1)'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8))
            --and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/5 - ���� ������ ����� � � 1/1'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8)) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/1 - ��� ������ ������ � � 1/5'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code) 
            and not exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8)) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/1 - ��� ������ ������ � � 1/5  (�������� ��� �� ���� �� � 1/5)'
    when exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_3')>0 and instr(name,'#')=0 and value=a.code) 
            and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value!=a.code and substr(a.code,1,8)=substr(value,1,8)) 
            --and exists(select null from variable_contracts where reference=nvl(a.contract,a.f_contract) and branch=nvl(a.branch_contract,a.f_branch_contract) and instr(name,'CARD_ACCOUNT_15')>0 and instr(name,'#')=0 and value=a.code)
        and (nvl(a.contract,0)>0 or nvl(a.f_contract,0)>0)
        then '���� � 1/1 - ���� ������ ����� � � 1/5'
    else '�� ������� ����������'
    --nvl(UNIVERSE.VARIABLE_CONTRACT(BRANCH, REFERENCE, 'CARD_CORP_CONTRACT') then '���, �� ���� ������������'
--    when nvl(contract,0)<>0 then '��'
--    else '���'
 end dop_inf   
,case 
    when nvl(f_contract,0)<>0 then (select account from contracts where reference=f_contract and branch=f_branch_contract)
    when nvl(contract,0)<>0 then (select account from contracts where reference=contract and branch=branch_contract)
 end rko    
,case 
    when nvl(f_contract,0)<>0 then (select type_doc||'_'||sub_type from contracts where reference=f_contract and branch=f_branch_contract)
    when nvl(contract,0)<>0 then (select type_doc||'_'||sub_type from contracts where reference=contract and branch=branch_contract)
 end rko    
,case 
    when nvl(f_contract,0)<>0 then (select assist from contracts where reference=f_contract and branch=f_branch_contract)
    when nvl(contract,0)<>0 then (select assist from contracts where reference=contract and branch=branch_contract)
 end rko_assist    
,a.reference,a.branch,a.open_date,a.close_date,a.client,a.branch_client,nvl(a.contract,a.f_contract) contract,nvl(a.branch_contract,a.f_branch_contract) branch_contract
,a.log_contract,a.VAR_CARD_ACC_1,a.VAR_CARD_ACC_15,a.VAR_CARD_ACC_2,a.VAR_CARD_ACC_3
from TMP_TABLES.TMP_GDM_90901 a
where 
--rownum<=1000
--nvl(contract,0)!=0
--and nvl(f_contract,0)=0
--and substr(code,6,3)<>'810'
--and var_card_acc_15 is not null and instr(var_card_acc_15,code)>0 and instr(var_card_acc_3,code)>0 
code in ('90901810000000000077','90901398000001001791')--,'90901810000000000462')

--PTOOLS5.READ_PARAM(sAcc,'ACC_1')