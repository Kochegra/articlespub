40502810001880000001
40502810301880000002

select rowid,a.* from contracts /*as of timestamp (systimestamp - interval '20' minute)*/ a where account in (
'40702810900000004791'
)

select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.value), a.value,substr(a.value,6,3), sysdate) saldo,
rowid,a.* from variable_contracts a where (reference,branch) in (select reference,branch from contracts where account in (
'40702810900000004791'
))
and (instr(name,'CARD_')>0 or instr(name,'ASSIST')>0)


      select d.reference||',',d.*
             ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   documents           d
            ,collector_contracts c
      where  1 = 1
                --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4479898)))--3854900)))--,
                and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702810900000004791'))
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             --and c.reference = 17795596 --17741941 --cpRefCont
             --and c.branch = 780 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36)--, 38)
             and d.status >= 30
             and d.status < 1000
             --and d.status <= -30
             --and d.status > -1000

and substr(d.payers_account,6,3)<>'810'             





select --docnum||',',
rowid,a.* from collector_contracts a where (reference,branch) in (select reference,branch from contracts where account in (
--'40702810627060000160',
'40702810500000050077'
--'40702840500600008088'
))
--and instr(name,'CARDLIST')>0
--and exists (select null from documents where reference=docnum and branch=zbranch_docnum and status<>36)

and docnum in (6818957836)

90902840933060000027

select
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code,substr(a.code,6,3), sysdate) saldo, 
rowid,a.* from account a where (contract,branch_contract) in (select reference,branch from contracts where account in (
--'40702810129260000028'
'90902840129260000372'
--'40702978329260000029'
))


select 
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code,substr(a.code,6,3), sysdate) saldo,
rowid,a.* from account a where code in (--'90902840129260000372',
'90902840129260000372')


      select d.reference||',',d.*
             ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   documents           d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             --and c.reference = 17795596 --17741941 --cpRefCont
             --and c.branch = 780 --cpBranchCont
                and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in (select value from no_files where reference in (4064532)))--3854900)))--,
                --and (c.reference,c.branch) in (select reference,branch from contracts aaa where account in ('40702978801970000112'))
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36, 38)
             and d.status >= 30
             and d.status < 1000
             --and d.status <= -30
             --and d.status > -1000
and substr(d.payers_account,6,3)<>'810'             
-- �������� 17.12.2013 �������� ������� ��������
--             and ((d.payment IS NULL) OR
--                  (d.payment IN (5,6)) OR
--                  ((d.payment IN (3,4)) AND
--                   (universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)))
-- 11.04.2019 �������� ��������� ������ � ����������.
--             AND NVL(d.payment,5) IN (5)
--             AND(universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)
--             and substr(d.receivers_account,1,5) <> '40101'
--<<<<

select rowid,doc.* from documents doc 
--update documents set status=status*(-1)
where  reference in (
6179186610,
6388969708)

      
      union all
      select d.*
            ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.VARIABLE_ARCH(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   archive             d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             and c.reference = 17795596 --17741941 --cpRefCont
             and c.branch = 780 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36, 38)
             and d.status >= 30
             and d.status < 1000;


--======= DOCUMENTS ARCHIVE
select rowid,doc.* from documents doc 
--update documents set status=status*(-1)
where  reference in (4158656062,
4158659135,
4158665639,
4158680134,
4158689343,
4158692076,
5366329115,
5599184230)

--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (1207012554)
or related in (1207012554)

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (5773021814))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch)=

select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (1207012554))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=
