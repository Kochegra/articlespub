--Get_Rest_K2
--Get_Rest_K2_multi
--GetRest4Cursor
--get_Rest_K2_Acc
--ReturnK2Doc
--!!!Get_k2_info

          select 2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.owner, a.type_doc, a.doc_number,
                              (select min(trunc(work_date)) from journal j where j.docnum = a.reference and j.branch = a.branch and j.code like '9090%' and j.assist like '99999%') date_work,
--                              case when a.date_work is null
--                                   then case when a.date_document is null then trunc(a.date_create) else a.date_document end
--                                   else a.date_work end date_work,
                              Universe.VARIABLE_DOC(a.branch, a.reference, 'COMPDOC_STATUS') COMPDOC_STATUS
                              ,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT') CARD_ACCOUNT
                              ,a.date_document
                            from documents a, k2
                              where a.reference = k2.reference
                                and a.branch    = k2.branch
                                and k2.refer_contract     = p_Reference
                                and k2.branch_contract    = p_Branch
                                and k2.what_is = 2
                                and a.status in (35)
          union
          select 2 Card_Type, 0 nType, a.reference, a.branch, a.payment, a.payers_account, a.payers_currency,a.receivers_account, a.receivers_bik, a.summa, a.owner, a.type_doc, a.doc_number,
                              (select min(trunc(work_date)) from journal j where j.docnum = a.reference and j.branch = a.branch and j.code like '9090%' and j.assist like '99999%') date_work,
                              Universe.VARIABLE_DOC(a.branch, a.reference, 'COMPDOC_STATUS') COMPDOC_STATUS
                              ,Universe.VARIABLE_DOC(a.branch, a.reference,  'CARD_ACCOUNT') CARD_ACCOUNT
                              ,a.date_document
                            from documents a, k2_multi k2m
                              where a.reference = k2m.reference
                                and a.branch    = k2m.branch
                                and k2m.refer_contract     = p_Reference
                                and k2m.branch_contract    = p_Branch
                                and a.status in (35)


      select d.*
             ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.variable_doc(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   documents           d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             and c.reference = 22148069 --cpRefCont
             and c.branch = 770 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36, 38)
             and d.status >= 30
             and d.status < 1000
-- �������� 17.12.2013 �������� ������� ��������
--             and ((d.payment IS NULL) OR
--                  (d.payment IN (5,6)) OR
--                  ((d.payment IN (3,4)) AND
--                   (universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)))
-- 11.04.2019 �������� ��������� ������ � ����������.
--             AND NVL(d.payment,5) IN (5)
--             AND(universe.VARIABLE_DOC(d.branch,d.reference,'COMPDOC_STATUS') IS NULL)
--             and substr(d.receivers_account,1,5) <> '40101'
--<<<<
      union all
      select d.*
            ,p_k2.GetRest4Cursor(pBranch_Doc => d.branch, pReference_Doc => d.reference, pBranch_Contract => c.branch, pRefer_Contract => c.reference, pSumma => d.summa, pCard_Type => 2) sum_related
            --,d_3363.SumRelated(d.reference
            --                  ,d.branch) sum_related
-- 11.04.2019 �������� ��������� ������ � ����������.
            , universe.VARIABLE_ARCH(d.branch, d.reference, 'TAX_PAY') tax_memo
      from   archive             d
            ,collector_contracts c
      where  1 = 1
             and d.branch = c.zbranch_docnum
             and d.reference = c.docnum
             and c.reference = 22148069 --cpRefCont
             and c.branch = 770 --cpBranchCont
             and c.name = 'CARDLIST_2'
             and c.summa in (0, 1)
             and rownum > 0
             and d.status not in (36, 38)
             and d.status >= 30
             and d.status < 1000;


                      SELECT universe.variable_doc(c.zbranch_docnum,c.docnum,'CODEMEMONO_NUM') type_no
                      FROM collector_contracts c, documents d
                      WHERE c.reference = 22148069 --pContref 
                      AND c.branch = 770 --pContBranch
                         AND c.name = 'ARREST_ACTION_3363' AND d.status = 30
                         AND d.reference = c.docnum AND d.branch = c.zbranch_docnum AND NVL(d.related,0) = 0 -- �� �����
                         AND nvl(universe.variable_doc(c.zbranch_docnum,c.docnum,'ORGAN'), '0')  = 0
                         AND d_3363.related_doc_count(d.reference,d.branch,30) = 0
                      UNION
                      SELECT universe.VARIABLE_ARCH(c.zbranch_docnum,c.docnum,'CODEMEMONO_NUM') type_no
                      FROM collector_contracts c, archive a
                      WHERE c.reference = 22148069 --pContref 
                      AND c.branch = 770 --pContBranch
                      AND c.name = 'ARREST_ACTION_3363' AND a.status = 30
                      AND a.reference = c.docnum AND a.branch = c.zbranch_docnum AND NVL(a.related,0)= 0
                      AND nvl(universe.VARIABLE_ARCH(c.zbranch_docnum,c.docnum,'ORGAN'), '0')  = 0
                      AND d_3363.related_doc_count(a.reference,a.branch,30) = 0




-- �������� ��������