select 
--reference,doc_number,
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(doc.payers_account), doc.payers_account,substr(doc.payers_account,6,3), sysdate) saldo,
summa,xsummacredit,
p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
--(select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) CARD_ACCOUNT,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT',null) CARD_ACCOUNT,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT_OLD',null) CARD_ACCOUNT_OLD,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'CARD_ACCOUNT_WAIT',null) CARD_ACCOUNT_WAIT,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'TYPE_SROK',null) TYPE_SROK,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'STOP_SROK',null) STOP_SROK,
substr(UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'REASON_38',null),1,10) REASON_38,
(select count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'FSSP_DOC_ID',null) FSSP_DOC_ID,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'INKP_REF',null) INKP_REF,
rowid,doc.* from documents doc
--doc.* from documents doc
--doc.* from archive doc 
--update documents doc set status=1000
--where payers_account='40702810410574209389'
where  (reference in (
338871049   
)
--union all
--select rowid,doc.* from archive doc where (reference in (4180141790)
or (refer_from in (338871049))-- and branch_from=191)
or related in (
338871049
)
)

and status<1000 --=30 and status>15

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (
375251239
))

--and name in ('CARD_ACCOUNT')
and name in ('IP_SKS','WAY4_DOCEXTID','IGNORE_TECH_MSG','CARD_ACCOUNT')

select * from k2 where reference=375251239

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (6040725419))

and name in ('IP_SKS','WAY4_DOCEXTID')

Select d.reference
                from documents d, variable_documents vd
              where d.reference = 264503396
                    and d.branch = 191
                    and vd.reference = d.related
                    and vd.branch = d.branch_related
                    and vd.name = 'IP_SKS'
                    and vd.value = '1'

--======= JOURNAL
select rowid,j.*  from journal j where docnum in (5562001416)

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=4161027991

select rowid,a.* from contracts a 
where reference=1246349 and branch=200151

where account='40702810100004200171' 

select rowid,a.* from variable_contracts a where reference=1246349 and branch=200151 --and docnum=4186462685
                   
select rowid,a.* from collector_contracts a where reference=1246349 and branch=200151 --and docnum=4186462685
order by work_date desc,record_ID desc


select rowid,a.* from account a where code='90901810915811500001'

select rowid,a.* from account_delete a where code='90901810915811500001'