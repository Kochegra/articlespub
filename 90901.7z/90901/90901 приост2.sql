����� ������ ( ���� ����� ��) �������� ����������.
��� ����� ���������� �� ������� �����������  � ����� ������� ������ 90901.
���� �� ����� ������� � ����������, ��� ��������� ������ �� �����  90901 (15 ��������������), �� � ������� ��� ����� 90901 �����.
����� �� �������� ����� ��������?


select * from contracts
where reference=19685920 and branch=770026


select distinct name from variable_contracts
where 
--reference=19685920 and branch=770026
--instr(name,'CARD_ACCOUNT_15')>0
instr(name,'CARD_ACCOUNT_3_')>0

NAME
--##CARD_ACCOUNT_3_RUR
--#CARD_ACCOUNT_3_156
--#CARD_ACCOUNT_3_392
--#CARD_ACCOUNT_3_810
--#CARD_ACCOUNT_3_840
--#CARD_ACCOUNT_3_978
--#CARD_ACCOUNT_3_OLD
--#CARD_ACCOUNT_3_RUR
----CARD_ACCOUNT_3_RUR
CARD_ACCOUNT_3_000
CARD_ACCOUNT_3_156
CARD_ACCOUNT_3_392
CARD_ACCOUNT_3_398
CARD_ACCOUNT_3_410
CARD_ACCOUNT_3_578
CARD_ACCOUNT_3_752
CARD_ACCOUNT_3_756
CARD_ACCOUNT_3_810
CARD_ACCOUNT_3_826
CARD_ACCOUNT_3_840
CARD_ACCOUNT_3_934
CARD_ACCOUNT_3_949
CARD_ACCOUNT_3_978
CARD_ACCOUNT_3_980
CARD_ACCOUNT_3_985
CARD_ACCOUNT_3_OLD
CARD_ACCOUNT_3_RUR
--MIGR_CARD_ACCOUNT_3_RUR
--OLD_CARD_ACCOUNT_3_OLD
--_CARD_ACCOUNT_3_840
--_CARD_ACCOUNT_3_OLD
--_CARD_ACCOUNT_3_RUR


select * from contracts c
where status=50 and date_close is null and type_doc>0
and nvl(type_client,0) not in (5)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15'),'0')<>'0'

and reference=19685920 and branch=770026

/

with tab as 
    (select * from contracts c
        where status=50 and date_close is null and type_doc>0
        and nvl(type_client,0) not in (5)
        and currency='840'
    )
select 
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_840') CARD_ACCOUNT_3_840,
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_978') CARD_ACCOUNT_3_978,
c.* from tab c   
where --nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15_840'),'0')<>'0'
exists(select null from variable_contracts where reference=c.reference and branch=c.branch 
            and instr(name,'CARD_ACCOUNT_15')>0 -- ��������� 15 
            and length(value)=20  -- ����
            and substr(value,1,5)='90901' -- ������ 
            --and substr(value,6,3)<>'810'
            and PLEDGER.SALDO (paccount.HEADER_ACCOUNT(value), value, substr(value,6,3), sysdate)>0 -- ������� ������ 0
        )
        
        
/
-- �� ������ �������� 

with tab as 
    (select * from contracts c
        where status=50 and date_close is null and type_doc>0
        and nvl(type_client,0) not in (5)
        --and currency='810'
        and substr(account,6,3)='810'
    )
select * from (
    select 
        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15'),6,3) CUR_15,
        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3'),6,3) CUR_3,
        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR'),6,3) CUR_3_RUR,
        (select count(*) from variable_contracts where reference=c.reference and branch=c.branch and instr(name,'CARD_ACCOUNT_3_')>0) other_3,
        (select close_date from account where header=paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3')) and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3')) close_acc_3,
        (select close_date from account where header=paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR')) and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR')) close_acc_3_rur,
        c.* 
    from tab c   
    where --nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15_840'),'0')<>'0'
        exists(select null from variable_contracts where reference=c.reference and branch=c.branch 
                and name='CARD_ACCOUNT_15' -- ��������� 15 
                and length(value)=20  -- ����
                and substr(value,1,5)='90901' -- ������ 
                --and substr(value,6,3)<>'810'
                and PLEDGER.SALDO (paccount.HEADER_ACCOUNT(value), value, substr(value,6,3), sysdate)>0 -- ������� ������ 0
               )        
) 
where --other_3>0 
--and 
(card_account_3 is null or  close_acc_3 is not null or card_account_15=card_account_3 or cur_15<>cur_3) 

and card_account_15=card_account_3        


select * from account


select * from contracts c
        where status=50 and date_close is null and type_doc>0
        and nvl(type_client,0) not in (5)
        and currency!='810'
        and substr(account,6,3)='810'
        
        
-- �� ������        
with tab as 
    (select * from contracts c
        where status=50 and date_close is null and type_doc>0
        and nvl(type_client,0) not in (5)
        --and currency='810'
        and substr(account,6,3)!='810'
    )
select * from (
    select 
--        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
--        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15'),6,3) CUR_15,
--        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3') CARD_ACCOUNT_3,
--        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3'),6,3) CUR_3,
--        UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR') CARD_ACCOUNT_3_RUR,
--        substr(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR'),6,3) CUR_3_RUR,
--        (select count(*) from variable_contracts where reference=c.reference and branch=c.branch and instr(name,'CARD_ACCOUNT_3_')>0) other_3,
--        (select close_date from account where header=paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3')) and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3')) close_acc_3,
--        (select close_date from account where header=paccount.HEADER_ACCOUNT(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR')) and code=UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_3_RUR')) close_acc_3_rur,
        c.* 
    from tab c   
    where --nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15_840'),'0')<>'0'
        exists(select null from variable_contracts where reference=c.reference and branch=c.branch 
                and instr(name,'CARD_ACCOUNT_15')>0 -- ��������� 15
                --and name='CARD_ACCOUNT_15' -- ��������� 15 
                and length(value)=20  -- ����
                and substr(value,1,5)='90901' -- ������ 
                --and substr(value,6,3)<>'810'
                --and PLEDGER.SALDO (paccount.HEADER_ACCOUNT(value), value, substr(value,6,3), sysdate)>0 -- ������� ������ 0
               )        
) 

where --other_3>0 
--and 
(card_account_3 is null or  close_acc_3 is not null or card_account_15=card_account_3 or cur_15<>cur_3) 