declare
nGetCont number;
rCont contracts%rowtype;
sAcc varchar2(2000);
  function f_get_cont (p_code account.code%type,p_ref_cli account.client%type,p_br_cli account.branch_client%type,p_name variable_contracts.name%type,p_Cont out contracts%rowtype) return number
  as
   nCnt number;
   --rCont contracts%rowtype;
  begin
    select count(*) into nCnt from contracts cc 
        where refer_client=p_ref_cli and branch_client=p_br_cli
            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                        and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                        and value=p_code);

    if nCnt=1 then
        --Universe.get_contract_rec(rf => v_contract, br => v_branch_contract, stat => null, acc => null, tp => null, rContract)
        select * into p_Cont from contracts cc 
            where refer_client=p_ref_cli and branch_client=p_br_cli
                and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch 
                            and instr(name,p_name)>0 and instr(name,'#')=0 --and instr(name,'_')=0 
                            and value=p_code);
    end if;
    
    return nCnt;
  end;
  function f_find_acc(p_code account.code%type) return varchar2
  as
    lDoc   boolean;
    nArch   number;
    rDoc documents%rowtype;
    sRes varchar(2000);
    nCnt number;
    nJou number :=0;
  begin
    nCnt := 0;
    for rec in (select distinct docnum reference,branch from
                    (select * from journal j where header=paccount.HEADER_ACCOUNT(p_code) and code=p_code
                        and not exists(select null from v_documents where reference=j.docnum and branch=j.branch and type_doc in (21))))
    loop
    --DBMS_OUTPUT.PUT_LINE('1');
       if UNIVERSE.GET_DOCUMENT_REC(rec.reference, rec.branch, nArch, 1, rDoc) then
       --DBMS_OUTPUT.PUT_LINE('2');
            if rDoc.type_doc<>198 then
            --DBMS_OUTPUT.PUT_LINE('3');
                if instr('#'||sRes,rDoc.payers_account)=0 then
                --DBMS_OUTPUT.PUT_LINE('4');
                    nCnt:=nCnt+1;
                    sRes:=sRes||'[ACC_'||nCnt||'='||rDoc.payers_account||']';
                    --DBMS_OUTPUT.PUT_LINE(sRes);
                end if;
            end if;
       end if; 
       nJou:=nJou+1;
    end loop;                        
    --if nCnt>0 then 
        sRes:='[CNT='||nCnt||']'||'[JOU='||nJou||']'||sRes;
    --end if;
    return sRes;
  end;
begin
    for rec in (
    
        select 
        --count(*)
        PLEDGER.SALDO (paccount.HEADER_ACCOUNT(a.code), a.code, substr(a.code,6,3), sysdate) sal,
        (select count(*) from journal where header=paccount.HEADER_ACCOUNT(a.code) and code=a.code) cnt_jrn,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and value=a.code)) cnt_cont_cl,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT')>0 and instr(name,'CARD_ACCOUNT_15')=0 and value=a.code)) cnt_cont_cl_no15,
--        (select count(*) from contracts cc where refer_client=a.client and branch_client=a.branch_client and status=50 and date_close is null 
--            and exists(select null from variable_contracts where reference=cc.reference and branch=cc.branch and instr(name,'CARD_ACCOUNT_15')>0 and value=a.code)) cnt_cont_cl_15,
        a.* 
        from account a
        where header='C' and code like '90901%'
        and close_date is null
        and nvl(client,0)<>0 
        and nvl(contract,0)=0 -- �� ��������� � �������� (��� ��� �� ��������)
        and substr(code,6,3)<>'810' -- �� ��������
        and code='90901392709251000001'    

    )loop
        nGetCont :=f_get_cont(rec.code,rec.client,rec.branch_client,'CARD_ACCOUNT',rCont);
        DBMS_OUTPUT.PUT_LINE(nGetCont||' '||rCont.reference||'/'||rCont.Branch);
        sAcc := f_find_acc(rec.code);
        DBMS_OUTPUT.PUT_LINE(sAcc);
        
        
        if nGetCont=1 then
             if (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=1 and rCont.account=PTOOLS5.READ_PARAM(sAcc,'ACC_1')) or (to_number(PTOOLS5.READ_PARAM(sAcc,'CNT'))=0 and to_number(PTOOLS5.READ_PARAM(sAcc,'JOU'))=0) then 
                DBMS_OUTPUT.PUT_LINE('�������� '||rec.code);
                if 1=2 then
                    update account set contract=rCont.reference, branch_contract=rCont.branch
                        where reference=rec.reference and branch=rec.branch and nvl(contract,0)=0;
                    commit; 
                end if;
             end if;
        end if; 
    end loop;

end;
/