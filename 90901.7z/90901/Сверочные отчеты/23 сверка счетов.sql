/*begin
    dbms_output.put_line('>> ' || to_char(sysdate, 'YYYY.MM.DD HH24:MI:SS'));
    verif_load.init_table(p_table_name => 'VERIF853_05_ACC');
    dbms_output.put_line('<< ' || to_char(sysdate, 'YYYY.MM.DD HH24:MI:SS'));
end;*/

--������ ������
begin
    dbms_output.put_line('>> ' || to_char(sysdate, 'YYYY.MM.DD HH24:MI:SS'));
    verif853_acc.delete_data;
--    verif853_acc.run_jobs(p_thread_count => 12, p_wait => true); 3,5 ����
    verif853_acc.run_jobs(p_work_date => to_date('07.01.2022','dd.mm.yyyy'),p_thread_count => 31, p_wait => true);--1.5 ���� 13:12
--      verif853_acc.run_jobs(p_work_date => to_date('31.12.2021','dd.mm.yyyy'), p_thread_count => 24, p_wait => true); 1 ��� 40 �����
    dbms_output.put_line('<< ' || to_char(sysdate, 'YYYY.MM.DD HH24:MI:SS'));
end;

/*
>> 2022.01.02 13:12:27
<< 2022.01.02 14:57:03


*/
/*
select count(*) from VERIF853_05_ACC*/
