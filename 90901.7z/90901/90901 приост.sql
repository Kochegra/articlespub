select * from contracts
where reference=19685920 and branch=770026


select * from variable_contracts
where 
--reference=19685920 and branch=770026
instr(name,'CARD_ACCOUNT_15')>0

select * from contracts c
where status=50 and date_close is null and type_doc>0
and nvl(type_client,0) not in (5)
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15'),'0')<>'0'

and reference=19685920 and branch=770026

/

with tab as 
    (select * from contracts c
        where status=50 and date_close is null and type_doc>0
        and nvl(type_client,0) not in (5)
        --and currency='840'
    )
select 
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15') CARD_ACCOUNT_15,
c.* from tab c   
where --nvl(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_ACCOUNT_15_840'),'0')<>'0'
exists(select null from variable_contracts where reference=c.reference and branch=c.branch 
            and instr(name,'CARD_ACCOUNT_15')>0 -- ��������� 15 
            and length(value)=20  -- ����
            and substr(value,1,5)='90901' -- ������ 
            --and substr(value,6,3)<>'810'
            and PLEDGER.SALDO (paccount.HEADER_ACCOUNT(value), value, substr(value,6,3), sysdate)>0 -- ������� ������ 0
        )