declare 
 P_STATUS varchar2(2000);
 v_send_status varchar2(2000) := '������';
BEGIN
    for rec in (
    
    select i.* from fssp_doc_corp i
                    where i.created BETWEEN trunc(sysdate)-27
                        AND trunc(sysdate) 
                        --and TO_DATE ('20190326', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
                    --and errormsg like '%�� �������� ��� Card%'
                    and id in (394310)                           
    
    )
    loop
        MBANK.FSSP_ARREST_CORP.SET_FSSP_DOC_ST (
            P_FSSP_DOC_ID   => rec.id, --:P_FSSP_DOC_ID,
            P_DOCSTATUS     => v_send_status,--:P_DOCSTATUS,
            P_ERRORCODE     => null,--:P_ERRORCODE,
            P_ERRORMSG      => null,--:P_ERRORMSG,
            P_STATUS        => P_STATUS);
        commit;
        DBMS_OUTPUT.PUT_LINE(rec.id||' '||v_send_status||' '||P_STATUS);        
    end loop;        
END;
/

select rowid,t.* from FSSP_DOC_corp 
--as of timestamp (systimestamp - interval '40' minute) 
t where trunc(created)>=trunc(sysdate)-5 and pr_account='40802810801230000580'--t.id in (45144656)

select * from fssp_doc_acc where fssp_doc_id in (394310)

select rowid,i.* from fssp_doc_history i where id in (394310) order by changetime desc

select rowid,a.* from contracts a 
--where account='40702810303554208996'
where account in (select acc from fssp_doc_acc where fssp_doc_id in (45144656))

SELECT t.*, t.rowid FROM fssp_doc_corp t WHERE t.related = 393949

select t.*, t.rowid from fssp_doc_change t
where 394262 in (t.related, t.fssp_doc)
