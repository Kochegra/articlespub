select rowid,
--reference,doc_number,
-PLEDGER.SALDO (paccount.HEADER_ACCOUNT(doc.payers_account), doc.payers_account,substr(doc.payers_account,6,3), sysdate) saldo,
summa,xsummacredit,
p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
(select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) waycnt,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'WAY4_DOCEXTID',null) WAY4_DOCEXTID,
(select count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'FSSP_DOC_ID',null) FSSP_DOC_ID,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'INKP_REF',null) INKP_REF,
--doc.* from v_documents doc
doc.* from documents doc
--doc.* from archive doc 
--update documents doc set status=1000
--where payers_account='40702810410574209389'
where  
--(reference in (5993632165)
--union all
--select rowid,doc.* from archive doc where (reference in (4180141790)
--or refer_from in (5581135657)
--or related in (5993632165))
date_work>trunc(sysdate)-10
and status=35
and UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'FSSP_DOC_ID',null) is not null
and exists(select null from v_documents where date_work>=trunc(sysdate)-10 and type_doc=198 and status=30 
                and related=doc.reference and branch_related=doc.branch and summa<doc.summa)
and exists(select null from contracts where account=doc.payers_account and type_doc=590 and sub_type=0 and status in (50,60))

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (265113057))
--and name in ('CARD_ACCOUNT')

and name in ('IP_SKS','WAY4_DOCEXTID','IGNORE_TECH_MSG','CARD_ACCOUNT')



--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (5248659135))

and name in ('IP_SKS','WAY4_DOCEXTID')

Select d.reference
                from documents d, variable_documents vd
              where d.reference = 264503396
                    and d.branch = 191
                    and vd.reference = d.related
                    and vd.branch = d.branch_related
                    and vd.name = 'IP_SKS'
                    and vd.value = '1'

--======= JOURNAL
select rowid,j.*  from journal j where docnum in (5562001416)

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=4161027991

select rowid,a.* from contracts a 
--where reference=16140191 and branch=235
where account='40702810100004200171' 

select rowid,a.* from variable_contracts a where reference=22334222 and branch=770 --and docnum=4186462685
                   
select rowid,a.* from collector_contracts a where reference=22334222 and branch=770 --and docnum=4186462685
order by work_date desc,record_ID desc