8561


select * from fssp_history where obj=152956 order by id desc ; 

select * from fssp_doc_history where id=152956 order by id desc; 

select * from fssp_doc order by id desc; 

select * from fssp_doc_corp where id=392546 order by id desc; 

select * from fssp_jrnl where soapid in (68245256 ) 

select * from fssp_doc_acc 

select * from fssp_guid where guid='08af5e39-26b5-4e24-bd30-1ba6ae30ddcf'

1988-02-05

--update fssp_doc set bmreference = "����� �������� ��������� ���������", bmbranch="����� ����� ��������� ���������"
--where f.id in (74696)

select rowid,f.id,f.related,f.eid,f.docstatus,F.ERRORCODE,F.ERRORMSG,F.CREATED,F.BMREFERENCE,F.BMBRANCH, f.* from fssp_doc f where  
        f.CREATED BETWEEN TO_DATE ('01.01.2018', 'dd.mm.yyyy')
                AND   TO_DATE ('06.03.2018', 'dd.mm.yyyy')
                       + 1
                       - 1 / (1 * 24 * 60 * 60)
--and f.id in (74696 ) 
--and instr(upper(deptsurname),'�������')>0
--and DEPTBIRTHDATE = to_date('02.02.1966','dd.mm.yyyy')
--and (f.id in (147931) or F.RELATED in (147931))
--and f.bmreference in (546198,545265 ) 
--(f.id in (147661) or F.RELATED in (147661)) 
--and docstatus in ('������ ���������') 
--and eid in (9623457)
--and eid in (12911735)
--and docnum in ('486832592/5409[40817810200430294301]')
--and errorcode in ('9005')
--and ipinternalkey=57101639544252
and exists (select * from fssp_doc_acc where fssp_doc_id=f.id and acc in ('5282856901705692'))
order by f.id desc

select * from eid.eid_products where account in (select acc from fssp_doc_acc where fssp_doc_id in (392546))

  select count(*) from eid.eid_products p, eid.eid_products_variable v, fssp_doc_acc fa
  where fa.fssp_doc_id in (152962) and p.account=fa.ACC and p.eid=fa.EID 
        and v.eid=p.eid and v.reference=p.reference and v.branch=p.branch
        and v.type='ARRESTDEBIT' and v.value='1' and v.status=1;

165611    108
288603    108
391012    108
146010    108000
283129    108
251280    108

insert into chg_OBJ@nnovg(ID, TBL, STATUS, REFERENCE, BRANCH, DATE_MODIFY, SUBD_MODIFY, OWNER_MODIFY)
select EID_ADD_LOAD_SEQ.nextval@nnovg,'CONTRACTS',0, reference,branch,sysdate,
subdepartment,
(select user_name from users@nnovg where user_id=owner) from Contracts@nnovg
where reference=387281 and branch=47

insert into chg_OBJ(ID, TBL, STATUS, REFERENCE, BRANCH, DATE_MODIFY, SUBD_MODIFY, OWNER_MODIFY)
select EID_ADD_LOAD_SEQ.nextval,'CONTRACTS',0, reference,branch,sysdate,
subdepartment,
(select user_name from users where user_id=owner) from Contracts
where reference=302180 and branch=54
 
SELECT * FROM CONTRACTS@nnovg WHERE       reference=124306
 
select * from fssp_doc_acc where fssp_doc_id in (392546)
--acc='40817810201970108243'


select analyser.GET_CARD_BAL_ARRKART@proc ('5417157263043477') from dual

----CF_DOCS
select rowid,a.* from EID.EID_CF_DOCS a where reference=139106
--eid in (25606704)

select rowid,a.* from MBANK.CF_DOCS a where reference=139106-- 
--eid=17188629 --reference=22017583


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.CF_CARD_COLLECTOR a where --reference=510065 --
cardnum =  '5298840447569087'
order by work_date,record_id

select rowid,a.* from EID.EID_CF_CARD_COLLECTOR a where --reference=510065 
cardnum =  '5298840447569087'
order by work_date,record_id


select rowid,a.* from eid.eid_card_oper a where --reference='510065' 
card_number in ('5417157263043477') --'5417150857790512') 
order by id --work_date desc

