select * from users where user_id=978489

select * from users where lower(user_name) like '%�����%'

--======= DOCUMENTS ARCHIVE
select rowid,doc.* from documents doc where  reference in (6004846499)


99999810500000000001
90902810900490206975
14162.72



/
declare 
  -- Local variables here
  i integer;
  tmp_v varchar2(300);
  v_RefChar varchar2(300);
  upDel number;
begin
   -- Test statements here                      
   dbms_application_info.set_client_info('MBANK-0Kernel');
   ptools2.short_init_user(21069);--1403);--978489);--1403);

    for rec in (
    
    select rowid,doc.*
                from documents doc 
                where reference in (6004846499)
                --and status=14
    
                )
    loop
          
        tmp_v:= start_process.WORKING(1,11,  rec.branch, rec.reference, null, i);
            -- 11 - ��������, 5 - ��������
        DBMS_OUTPUT.PUT_LINE(rec.reference||' - done'||'  '||tmp_v);  
        commit;
    end loop;
end;
/

