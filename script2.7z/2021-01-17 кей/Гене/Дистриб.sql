--*******
select f.*, rowid from eid.distrib_transactions f       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
--update eid.distrib_transactions set done=1
where --task_kind='IP_LOCK' 
--and 
--tran_id in  (276510485, 276510490, 276634222, 276634240, 276634241, 276634332, 276634334, 276653897, 276653902, 276655038, 276655053, 276655069, 276655097, 276655105, 276675859, 276675871, 276675881, 276675882, 276675884, 276675886, 276676476, 276676491, 276676492, 276676500, 276676506, 276678727, 276678734, 276690216, 276695850, 276695851, 276695852, 276695854, 276695886, 276695888, 276699307, 276699308, 276709327, 276709329, 276709351, 276709353, 276709354, 276723880, 276723881, 276732099, 276732107, 276732108, 276732109, 276732110, 276732113, 276749171)
tran_id in  (select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
                where value in (
'5677896527'
                ))
--and filial in (191,191.3)
order by tran_id,run_order
--and done in (2,0)
--and instr(comments,'�������� tran_id')>0

select rowid,--max(tran_id) 
a.* from eid.distrib_features a 
--where value in ('4132346111')
--and exists (select null from eid.distrib_transactions where tran_id=a.tran_id and sys_date>=sysdate-5/24/60)
where tran_id in (292876583) --=275782942 --  and  task_kind='IP_LOCK' and filial=191.3 and name='SHOW_RESULT_OPER'
and name='FUNCTION'              


select rowid,ec.* from EID.EID_CARD_OPER ec 
where 
reference in ('5677896977')-- and op_status=50
--and card_number='001-C-093090' 
order by id desc