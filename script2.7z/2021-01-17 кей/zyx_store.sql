-- num1
select rowid,a.* from MBANK.ZYX_STORE a where tbl='TEST_BM_WAY'

insert into ZYX_STORE(tbl,num1)
values('TEST_BM_WAY',0)