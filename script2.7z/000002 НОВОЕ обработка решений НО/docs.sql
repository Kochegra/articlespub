select level,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (262813742))--
--262298063))--262295900))
            --reference=262295295 and branch=191
order by level

--======= DOCUMENTS ARCHIVE
select rowid,doc.* from documents doc where  reference in (1207012554)
--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (1207012554)
or related in (1207012554)

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262813742,262813743))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch)=

select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (1207012554))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=
