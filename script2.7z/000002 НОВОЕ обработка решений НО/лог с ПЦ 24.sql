select * from config where name = 'WAY4_ARREST_24_ALGORITHM'

select * from corp_card_x24_web_log --where service in ('ACC_RESTRICT','ACC_TRANSFER','ACC_INFO')
where --gid='11_A094B245C9FA0286E0530AC8C164E31B'
service='ACC_RESTRICT'
order by date_req desc

-- ������ EID_CARD_OPER
select rowid,a.* from CORP_CARD_WAY24_DOC_LOG a 
--where doc_reference=262775632
where trunc(req_date)>=trunc(sysdate)
--and doc_reference=262759474
--and req_out like '%262775656%'
order by req_date desc


select rowid,a.* from mbank.clob_bill_params a where create_date>=sysdate-20 
--and gid in ('16_A0F72BFC8FE5038AE0530AC8C164DAAE')
--and function_name='OUT-MBANKACCOUNTRESTRICTION'
and clob_data like '%262759490%'
order by create_date desc


d_3363
