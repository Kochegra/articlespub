select zs.* from zyx_store zs where oper='MONITOR_MB_WAY24' and trunc(dt_mod) >= trunc(sysdate)

select * from documents where (reference,branch) in (
select zs.num1,zs.num2 from zyx_store zs where oper='MONITOR_MB_WAY24' and trunc(dt_mod) >= trunc(sysdate) and str1='DOCUMENTS'
) 
and type_doc in (226) and status in (30,35)

select 
UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') waycnt,
c.* from contracts c where account in (
'40802810103550000191',
'40802810104550000271',
'40802810305550000054',
'40802810912550000337',
'40802810110550000171',
'40802810915590000475',
'40802810310084200771'
)

select * from variable_contracts where reference=16006486 and branch=235

/
begin 
for rec in (select * FROm v_documents where reference in 
                (1111
    )loop    
        insert into zyx_store (OPER,num1)
            values ('MONITOR_MB_WAY24',rec.reference);
            --values ('MONITOR_MB_WAY24',2662240)
            --values ('MONITOR_MB_WAY24',3838107999)
    end loop;
    commit;
end;

/
--��� �������� ������ �����
select * from documents d where trunc(date_create)>=TO_DATE ('20200401', 'yyyymmdd')
and type_doc in (226,3363,3317)
and exists(select null from account where code=d.PAYERS_ACCOUNT and nvl(contract,0)<>0 and nvl(branch_contract,0)<>0)
and exists(select null from contracts where (reference,branch) in (select contract,branch_contract from account where code=d.PAYERS_ACCOUNT )
                and type_doc = 590 and sub_type in (1) and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
                and account=d.PAYERS_ACCOUNT)
--and exists(select null from account where code=d.RECEIVERS_ACCOUNT and nvl(contract,0)<>0 and nvl(branch_contract,0)<>0)
--and exists(select null from contracts where (reference,branch) in (select contract,branch_contract from account where code=d.RECEIVERS_ACCOUNT )
--                and type_doc = 590 and sub_type in (1) and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
--                and account=d.RECEIVERS_ACCOUNT)
and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=d.reference)  


select * from documents d where trunc(date_create)>=TO_DATE ('20200510', 'yyyymmdd')
                       and type_doc in (226,3317,3363)
                        and (d.PAYERS_ACCOUNT in
                                (select c.account
                                from contracts c
                                where type_doc = 590
                                --and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                                --and status=50
                                and sub_type in (1)
                                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
                            or d.RECEIVERS_ACCOUNT in
                                (select c.account
                                from contracts c
                                where type_doc = 590
                                --and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                                --and status=50
                                and sub_type in (1)
                                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
                            )
                            and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=d.reference)
--and (reference,branch) not in 
--(select reference,branch from documents d where trunc(date_create)>=TO_DATE ('20200401', 'yyyymmdd')
--and type_doc in (226,3363,3317)
--and exists(select null from account where code=d.PAYERS_ACCOUNT and nvl(contract,0)<>0 and nvl(branch_contract,0)<>0)
--and exists(select null from contracts where (reference,branch) in (select contract,branch_contract from account where code=d.PAYERS_ACCOUNT )
--                and type_doc = 590 and sub_type in (1) and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
--                and account=d.PAYERS_ACCOUNT)
--)



/
declare
vMail number := 0;
vPNO_txt varchar2(2000) := null;
vIPNO_txt varchar2(2000) := null;
vDoc_txt varchar2(2000) := null;
vResult_txt varchar2(2000) := null;
begin
    -- ����� ������� � ����������� � WAY24
    for recPNO in (
                    select f.* from no_file f
                        where
                            date_create BETWEEN --trunc(sysdate)-10
                                TO_DATE ('20200501', 'yyyymmdd')
                                AND trunc(sysdate)
                                   + 1
                                   - 1 / (1 * 24 * 60 * 60)
                    and exists (select 1 from contracts a where (a.reference,a.branch) in
                                    (select contract,branch_contract from account where code in
                                        (select value from no_files where reference = f.reference))
                                            and type_doc in (590) and status=50 and sub_type=1
                                            --and d_3363.contract_action_arrest_n (reference, branch)>0
                                )
                    --and reference not in (2657017)
                    and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=f.reference)
    ) loop
        vMail := vMail + 1;
        vPNO_txt := vPNO_txt||recPNO.reference||' '||recPNO.file_name||' '||recPNO.status||chr(9)||chr(13);
        insert into zyx_store (OPER,num1,num2,str1) values ('MONITOR_MB_WAY24',recPNO.reference,recPNO.branch,'NO_FILE');
        commit;
    end loop;

    -- ����� ���������� �����
    for recIPNO in (
        select * from inkp_staging i
            where i.date_load BETWEEN --trunc(sysdate)-10
                                TO_DATE ('20200501', 'yyyymmdd')
                                AND trunc(sysdate)
                                --and TO_DATE ('20190326', 'yyyymmdd')
                                + 1
                                - 1 / (1 * 24 * 60 * 60)
            and exists (select 1 from contracts a where (a.reference,a.branch) in
                           (select contract,branch_contract from account where code = i.ACCOUNT_NO_PAYER)
                                and type_doc in (590) and status=50 and sub_type=1
                            --and d_3363.contract_action_arrest_n (reference, branch)>0
                       )
            and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=i.id)
    )loop
        vMail := vMail + 1;
        vIPNO_txt := vIPNO_txt||recIPNO.id||' '||recIPNO.file_name||' '||recIPNO.status||chr(9)||chr(13);
        insert into zyx_store (OPER,num1,num2,str1) values ('MONITOR_MB_WAY24',recIPNO.id,recIPNO.branch,'INKP_STAGING');
        commit;
    end loop;

    -- ����� ������� �����
    for recDoc in (select * from documents d where trunc(date_create)>=TO_DATE ('20200510', 'yyyymmdd')
                        and type_doc in (226,3317,3363)
                        and (d.PAYERS_ACCOUNT in
                               (select c.account
                                from contracts c
                                where type_doc = 590
                                --and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                                --and status=50
                                and sub_type in (1)
                                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
                            or d.RECEIVERS_ACCOUNT in
                               (select c.account
                                from contracts c
                                where type_doc = 590
                                --and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                                --and status=50
                                and sub_type in (1)
                                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
                            )
                            and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=d.reference and num2=d.branch)
                            --and rownum<5
    )loop
        vMail := vMail + 1;
        vDoc_txt := vDoc_txt||recDoc.reference||'/'||recDoc.branch||' '||recDoc.type_doc||' '||recDoc.status||chr(9)||chr(13);
        insert into zyx_store (OPER,num1,num2,str1) values ('MONITOR_MB_WAY24',recDoc.reference,recDoc.branch,'DOCUMENTS');
        commit;
    end loop;

    vResult_txt:=vResult_txt||'������� �� (�����):'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vPNO_txt||chr(9)||chr(13)||chr(9)||chr(13);
    vResult_txt:=vResult_txt||'���������� �� (�����):'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vIPNO_txt||chr(9)||chr(13)||chr(9)||chr(13);
    vResult_txt:=vResult_txt||'���������:'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vDoc_txt||chr(9)||chr(13)||chr(9)||chr(13);

    if vMail<>0 then
           P_Email.Send_Mail(Reciever => 'SHED_GORODNOV',
                             Subject => '���������� � WAY24',
                             Mail_Text => vResult_txt
                              );
    end if;

end;
/