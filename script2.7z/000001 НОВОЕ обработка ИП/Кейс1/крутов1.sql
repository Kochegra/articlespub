select * from users where user_id in (1004518,978489,1002235,1002288,963502)

declare
t0 number;
t1 varchar2(2000);
t2 varchar2(2000);
begin
  dbms_session.set_nls('nls_language','AMERICAN');
  dbms_session.set_nls('nls_territory','AMERICA');
ptools2.short_init_user(1403);
  dbms_output.put_line( DOCALGO.EXECDOC(191,262079156,'1403',t0,t1,t2) );
end;

select rowid,d.* from documents d where reference=262079156

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262079156))
and name not in ('COMPDOC_STATUS','DATEPLAT','KBK','OKATO','PAYERS_KPP','PAYMENT_ID','RECEIVERS_KPP','ROLLBACKTOEMITENT','TAX_DOCNUMBER','TAX_MEMO','TAX_PERIOD') 



select a.* from account a where header in('A','X') and code like '40702810200009004586%'

select c.* from contracts c where reference=4545965

select c.* from variable_contracts c where reference=4545965 and branch=191



select * from eid.distrib_features
where value='262079156'


select a.* from audit_table a where reference=262079156 and branch=191

select * from folders where folder_id=14

select rowid,q.* from eid.distrib_transactions q
where tran_id in(195047,195048,195049)

194279

194280

pkg_pay_sks.f_transfer_card_ip_way24w


select * from eid.distrib_features
where tran_id=
195048

pkg_pay_sks.f_register_card_ip_way24w

select v.* from variable_documents v where reference=262079156 and branch=191


select d.* from documents d where refer_from=2165137791

select t.* from types t where type_id = 3317

select t.* from types t where lower(name) like '%%'

