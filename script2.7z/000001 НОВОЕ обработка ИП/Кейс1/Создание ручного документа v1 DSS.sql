-- ������� ��������
select * from users where lower(user_name) like '%��������%'


select 
-PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.account), c.account, substr(c.account,6,3),trunc(sysdate)) saldo,
nvl(UNIVERSE.VARIABLE_CONTRACT(c.BRANCH, c.REFERENCE, 'ARREST_ACTION'),0) arr,
c.* 
from contracts c 
where type_doc = 590
and status=50
and date_open>=trunc(sysdate)-300
and -PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.account), c.account, substr(c.account,6,3),trunc(sysdate))>1000
and nvl(UNIVERSE.VARIABLE_CONTRACT(c.BRANCH, c.REFERENCE, 'ARREST_ACTION'),0)=0
and reference in (15795695) and branch=191

select * from variable_contracts where reference in (15795695) and branch=191

select * from clients where reference=114833040 and branch=191

/
declare
   doa__value DOCUMENTS.REFERENCE%type;
   vUSER number := 982038;
   vFOLDER number := 0;  
   vTYPEDOC number := 226;  
   vREFER_FROM number := 0;  
   vBRANCH_FROM number := 0;  
   vN_Group number := 0;
   vRefCont number := 15795695;
   vBrCont number := 191;
   res number;
   vDocBr number;
BEGIN
   ptools2.short_init_user(vUSER);
   doa__value :=
      GLOBAL_FUNCTION.ADD_DOCUMENT (USER          => vUSER,
                                    FOLDER        => vFOLDER,
                                    TYPEDOC       => vTYPEDOC,
                                    REFER_FROM    => vREFER_FROM,
                                    BRANCH_FROM   => vBRANCH_FROM,
                                    N_Group       => vN_Group);
   DBMS_OUTPUT.PUT_LINE(doa__value);

    select branch into vDocBr from documents WHERE REFERENCE = doa__value;

   for rec in (select * from contracts where reference=vRefCont and branch=vBrCont
   )loop
    DBMS_OUTPUT.PUT_LINE(rec.reference);

    UPDATE DOCUMENTS
        SET REFER_FROM = 0,
       BRANCH_FROM = 0,
       RELATED = 0,
       BRANCH_RELATED = 0,
       FOLDER = 0,
       STATUS = 10,
       CHILD = 0,
       owner = vUSER,
       REFER_OFFICE = '',
       Payers = (select full_name from clients where reference=rec.refer_client and branch=rec.branch_client),--'��� "������-�"',
       Payers_inn = (select inn from clients where reference=rec.refer_client and branch=rec.branch_client),--'7723180887',
       Payers_account = rec.account,--'40702810200009004586',
       Summa = 10,
       Memo = '���� ����',
       Payment = '4',
       Doc_Number = '4',
       ShifrOper = '310006',
       Num_Group = 0,
       Receivers_BIK = '040507001',
       Receivers_coracc = '',
       Receivers_bank =
          '��������������� �� ����� ������ �.�����������',
       Receivers_Account = '40101810900000010002',
       Receivers_inn = '2502005990',
       Receivers = '���'
    WHERE REFERENCE = doa__value AND BRANCH = vDocBr;


        for rec_var in (select 'COMPDOC_STATUS' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'04' VALUE, null SUBFIELD from dual
                        union all
                        select 'DATEPLAT' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'20.02.2020' VALUE, null SUBFIELD from dual
                        union all
                        select 'KBK' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'18210301000012100110' VALUE, null SUBFIELD from dual
                        union all
                        select 'OKATO' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'05705000' VALUE, null SUBFIELD from dual
                        union all
                        select 'PAYERS_KPP' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'772301001' VALUE, null SUBFIELD from dual
                        union all
                        select 'PAYMENT_ID' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'RECEIVERS_KPP' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'250201001' VALUE, null SUBFIELD from dual
                        union all
                        select 'ROLLBACKTOEMITENT' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_DOCNUMBER' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'0' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_MEMO' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'��' VALUE, null SUBFIELD from dual
                        union all
                        select 'TAX_PERIOD' name,0 SUBNUMBER,0 ROWNUMBER,0 COLNUMBER,'21.01.2020' VALUE, null SUBFIELD from dual
        )loop 
    
--            res :=
--            variable.updatetable ('VARIABLE_DOCUMENTS',
--                            doa__value,
--                            vDocBr,
--                            :FIELDTYPE,  !!!!!!
--                            rec_var.name,
--                            rec_var.value,
--                            rec_var.subnumber,
--                            rec_var.subfield,
--                            rec_var.rownumber,
--                            rec_var.colnumber);
            UNIVERSE.Input_var_doc(vDocBr, doa__value, rec_var.name, rec_var.value);
        end loop;
    end loop;

commit;
END;
/



