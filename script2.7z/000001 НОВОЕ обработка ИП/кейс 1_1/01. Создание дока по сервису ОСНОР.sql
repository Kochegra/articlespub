declare 
l_rec_no      inkp_staging%rowtype;
SUBTYPE TResult IS varchar2(2000);
l_Result       TResult;
   p_Account      account.code%type;
   v_acct_recipient inkp_staging.account_no_recipient%TYPE;
   l_Refer_doc    documents.reference%type;
   l_Branch_doc   documents.branch%type;
   l_rec_doc      documents%rowtype;

 FUNCTION GET_NO_REC(rf IN NUMBER, br IN NUMBER, no_rec IN OUT NOCOPY inkp_staging%ROWTYPE) RETURN BOOLEAN
 IS
 BEGIN
      SELECT * INTO no_rec FROM inkp_staging WHERE id = rf;-- and branch = br;
  RETURN TRUE;
 EXCEPTION
  WHEN OTHERS THEN no_rec.id := -1; RETURN FALSE;
 END GET_NO_REC;

 FUNCTION f_get_acc_type(ip_account IN account.code%TYPE) RETURN NUMBER
 IS
  v_ret NUMBER;
 BEGIN
  SELECT con.type_doc
  INTO v_ret
  FROM contracts con, account a
  WHERE a.code = ip_account
  AND a.contract = con.reference
  AND a.branch_contract = con.branch
  AND rownum = 1;
  RETURN v_ret;
  EXCEPTION
  WHEN no_data_found THEN
       RETURN -1;
  WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20024,'�� ������� ��������� ��� ����� ��� '||ip_account);
 END f_get_acc_type;


 FUNCTION Create_Doc(ip_inkp_rec    IN inkp_staging%rowtype,
                     ip_purpose     IN VARCHAR2,
                     ip_payer       IN VARCHAR2,
                     ip_payers_account     IN account.code%type,
                     ip_payer_curr  IN currency.currency%TYPE DEFAULT '810',
                     ip_reciver     IN VARCHAR2,
                     ip_recivers_acct IN inkp_staging.account_no_recipient%TYPE,
                     ip_recivers_currency IN currency.currency%TYPE DEFAULT '810',
                     ip_sum           IN inkp_staging.summ%TYPE,
                     ip_parent_ref    IN documents.reference%type DEFAULT NULL,
                     ip_parent_branch IN documents.branch%type DEFAULT NULL,
                     ip_type_doc      IN documents.type_doc%type DEFAULT 226,
                     ip_xsum_cred     IN NUMBER,
                     p_Refer_doc    OUT documents.reference%type,
                     p_Branch_doc   OUT documents.branch%type,
                     op_rec_doc     OUT documents%rowtype
                    )
   RETURN VARCHAR2
 IS
   l_Result       TResult;
   new_doc        documents%rowtype;
   v_num_group    documents.num_group%type;
   SystemDate     Date;
   v_payers_acct_name VARCHAR2(1000);
   v_acc_type NUMBER;
   v_admin_oo NUMBER;
 BEGIN
    --PRINT('Create_doc begin ip_inkp_rec.Branch='||ip_inkp_rec.Branch);
    SystemDate := to_Date(global_parameters.get_param_CFG('SYSTEMDATE'),'dd.mm.yyyy');
    v_payers_acct_name := account_tools.GetAccountName(p_Account => ip_payers_account);
    -------------------------------------------
    -- ���������� �.�. 25.07.2014. ���� �� - ����� 1890, ����� - ��������
    if plink.need_connection(mbGoID) = 0 then
      v_num_group := 1890;
    else
      v_num_group := nvl(global_parameters.get_param('�����_����������'), 0);
    end if;
    --
    new_doc.type_doc            := ip_type_doc;
    new_doc.Status              := 10;
    new_doc.Branch              := ip_inkp_rec.branch;
    new_doc.sub_type            := 30;
    new_doc.summa               := ip_sum;
    new_doc.xsummacredit        := ip_xsum_cred;
    new_doc.folder              := 0;
    new_doc.num_group           := v_num_group;
    new_doc.date_work           := SystemDate;
    new_doc.date_document       := TO_DATE(ip_inkp_rec.poruch_date,'dd.mm.yyyy');
    --new_doc.date_document       := SystemDate;
    --26.03.2014 ������ �������� ��� ����� ��
    v_admin_oo := globals.UserId;
--    --���� ����� �� ��� ���������� �������, �����
--    if nvl(GLOBAL_PARAMETERS.GET_PARAM('365PINKP_ADMIN',mbfilid),0) = 1 then --���� �� �� ����������
--      if v_admin_oo = mbfil_admin then
--        v_admin_oo := NVL(GLOBAL_PARAMETERS.GET_PARAM('���_�����_��', f_get_acc_subdep(ip_payers_account) ), mbfil_admin);
--      end if;
--    end if;

--    print('Create_doc v_admin_oo='||v_admin_oo||' ID='|| ip_inkp_rec.id);
    new_doc.owner               := v_admin_oo;
    new_doc.memo                := ip_purpose;
    new_doc.refer_from          := ip_parent_ref;
    new_doc.branch_from         := ip_parent_branch;
    new_doc.doc_number          := ip_inkp_rec.poruch_num;
    --new_doc.doc_number          := NVL(Doc_num_pak.GET_DOC_NUM_SUBDEP('E_INKP', systemdate),'1050');
    new_doc.payment             := ip_inkp_rec.next_payment;
    -------------------------------------------
    new_doc.payers_account      := ip_payers_account;
    new_doc.payers_currency     := ip_payer_curr;
    new_doc.payers_inn          := ip_inkp_rec.inn_payer;
    new_doc.payers_bik          := ip_inkp_rec.bik_payers_bank;
    new_doc.payers              := NVL(ip_payer, v_payers_acct_name);
    -----------------------------------------------------
    new_doc.receivers           := NVL(ip_reciver, v_payers_acct_name);
    new_doc.Receivers_BIK       := ip_inkp_rec.bik_recipient_bank;
    new_doc.receivers_inn       := ip_inkp_rec.inn_recipient;
    new_doc.Receivers_account   := ip_recivers_acct;
    new_doc.receivers_currency  := ip_recivers_currency;
    new_doc.receivers           := NVL(ip_reciver, v_payers_acct_name);
--    PRINT('Create_doc after filling record. new_doc.doc_number='||new_doc.doc_number||' doc.branch='|| new_doc.Branch);
    l_Result := CALL_PACK.ADD_DOCUMENT(new_doc.owner, new_doc);
--    PRINT('Create_doc after ADD_DOCUMENT. Result='||l_Result);
    IF l_Result is not null THEN
      return l_Result;
    END IF;
--    PRINT('Create_doc before setting out vars');
    p_Refer_doc  := new_doc.reference;
    p_Branch_doc := new_doc.branch;
--    PRINT('Create_doc after setting out vars p_Branch_doc='||p_Branch_doc);
    IF ip_type_doc = 226 THEN
--        PRINT('Create_doc before INPUT_VAR_DOC');
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'INKP_REF', ip_inkp_rec.id);

        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'DOCUM', ip_inkp_rec.id);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'QID',ip_inkp_rec.Branch);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'DATE_PAYERSBANK', TO_CHAR(SystemDate,'DD.MM.YYYY'));
        --����������� � ������� � ����� "�����������"
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TYPEIMPORT', 'E');
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'PAYERS_KPP', CASE WHEN LENGTH(ip_inkp_rec.inn_payer) = 12 AND NVL(ip_inkp_rec.kpp_payer,'0') = '0' THEN '0' ELSE ip_inkp_rec.kpp_payer END);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'RECEIVERS_KPP', ip_inkp_rec.kpp_recipient);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'COMPDOC_STATUS', ip_inkp_rec.status_code);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'KBK',ip_inkp_rec.kbk);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'OKATO',ip_inkp_rec.okato);
        -- ���������� �.�. 06.08.2014 ������ UIN � ��������
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'PAYMENT_ID',ip_inkp_rec.payment_code);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_MEMO',ip_inkp_rec.payment_reason);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_DOCNUMBER', ip_inkp_rec.poruch_num);

        --paa3 ������ �� ����� ���������� �� �����
        /*Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_DATEDOC',ip_inkp_rec.poruch_date);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_TYPEDOC',ip_inkp_rec.payment_type);*/
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_DOCNUMBER', ip_inkp_rec.demand_no);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_DATEDOC',ip_inkp_rec.demand_date);


        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TAX_PERIOD',ip_inkp_rec.pay_till);
        --Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'ALL_EXECUTE','1');
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'TYPE_PLAT', 'EXEC2FREE');
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'CB_ARREST_NO','1');
        v_acc_type := f_get_acc_type(new_doc.payers_account);
        Universe.INPUT_VAR_DOC(p_Branch_doc, p_Refer_doc, 'ACC_TYPE',v_acc_type);
 --       PRINT('Create_doc after INPUT_VAR_DOC');
    END IF;
    op_rec_doc := new_doc;
    return l_Result;
 EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR( -20005, substr(sqlerrm, 1, 2000));
 END Create_Doc;

--********
begin
    mbank.ptools2.short_init_user(1403);--mbfil_admin);

    for rec in (select * from inkp_staging where id=1713
    )loop
        IF GET_NO_REC(rec.id, rec.branch, l_rec_no) THEN
            NULL;
        END IF;

        --DBMS_OUTPUT.PUT_LINE(l_rec_no.id||' '||l_rec_no.account_no_payer);
        p_Account := COALESCE(l_rec_no.account_no_payer,l_rec_no.account_no_payers_bank);
        v_acct_recipient := COALESCE(l_rec_no.account_no_recipient,l_rec_no.account_no_recipient_bank);
        l_Result := Create_Doc(
                 ip_inkp_rec => l_rec_no,
                 ip_purpose => l_rec_no.payment_purpose,
                 ip_payer => l_rec_no.payer,
                 ip_payers_account => p_Account,
                 ip_payer_curr =>'810',
                 ip_reciver => l_rec_no.recipient,
                 ip_recivers_acct => v_acct_recipient,
                 ip_recivers_currency => '810',
                 ip_sum => l_rec_no.summ,
                 ip_type_doc => 226,
                 ip_xsum_cred => NULL,
                 p_Refer_doc =>  l_Refer_doc,
                 p_Branch_doc => l_Branch_doc,
                 op_rec_doc => l_rec_doc);

        DBMS_OUTPUT.PUT_LINE(nvl(l_Result,0)||' '||l_Refer_doc||' '||l_Branch_doc);

        --universe.INPUT_VAR_DOC(nBranch => l_Branch_doc2, nREFERENCE => l_Refer_doc2, cName => 'CB_ARREST_NO', cValue => '1');
        Universe.INPUT_VAR_DOC(l_Branch_doc, l_Refer_doc, 'DIRECTION', 'FORWARD');

    end loop;
commit;
end;
/


-- ������ F5
declare
     doc_ref    number;
     doc_br     number;
     j          NUMBER;
     tmp1       VARCHAR2(2000);
     tmp2       VARCHAR2(2000);
     v_owner    NUMBER;
begin
   doc_ref := 262083390;
   v_owner := 1403;
   doc_br  := 191;
   mbank.ptools2.short_init_user (v_owner);  
   j := NULL; tmp1 := NULL; tmp2 := NULL;
   dbms_output.put_line(DOCALGO.EXECDOC(doc_br, doc_ref, v_owner, j, tmp1, tmp2));
   commit;                 
end;  
/
