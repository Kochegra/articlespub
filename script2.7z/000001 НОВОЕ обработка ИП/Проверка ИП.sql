select level,
(select count(*) from journal where docnum=d.reference) CNT_JOUR,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (262824957))--
--262298063))--262295900))
            --reference=262295295 and branch=191
order by level


select 
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = I.ACCOUNT_NO_PAYER) sal,
rowid, i.id||',',doc_ref||',',--i.*
(nvl2((select distinct docnum from journal where docnum=I.DOC_REF and branch=I.DOC_BRANCH),'YES','NO')) jour,
(select status from documents where reference=I.DOC_REF and branch=I.DOC_BRANCH) doc_stat,
(select status from archive where reference=I.DOC_REF and branch=I.DOC_BRANCH) arh_stat,
i.ID,i.QUEUE_REFER,i.DATE_LOAD,i.CHANGE_DATE,i.STATUS,i.BRANCH,i.IN_FILIAL,i.DOC_REF,i.DOC_BRANCH,i.ERR_CODE,i.ERR_MSG,
i.ACCOUNT_NO_PAYER,i.ACC_TYPE,i.ACCOUNT_NO_RECIPIENT,i.FILE_NAME,i.PORUCH_NUM,i.SUMM,i.REPLIED,i.REPLY_ID,i.CONFIRM_ID,i.KWT_ID,
i.PAYERS_BANK,i.BIK_PAYERS_BANK,i.STATUS_CODE,i.SUBDEPARTMENT,i.LOG_ID,i.INN_PAYER,i.BIK_RECIPIENT_BANK,I.PAYER,I.SEND_GUID
/*i.FILE_ID,*//*i.DOC_ID,*//*i.OKUD,*//*i.PORUCH_DATE,*//*i.KIND_OF_PAYMENT,*//*i.KPP_PAYER,*//*i.PAYER,*/
/*i.ACCOUNT_NO_PAYERS_BANK,*//*i.BRANCH_NO_PAYER,*//*i.RECIPIENT_BANK,*//*i.ACCOUNT_NO_RECIPIENT_BANK,*/
/*i.INN_RECIPIENT,*//*i.KPP_RECIPIENT,*//*i.RECIPIENT,*//*i.ACCOUNT_NO_RECIPIENT,*//*i.OPERATION_TYPE,*//*i.CODE_PAYMENT_PURPOSE,*/
/*i.NEXT_PAYMENT,*//*i.PAYMENT_CODE,*//*i.RES_FIELD,*//*i.PAYMENT_PURPOSE,*//*i.KBK,*//*i.OKATO,*//*i.PAYMENT_REASON,*/
/*i.PAY_TILL,*//*i.DEMAND_NO,*//*i.DEMAND_DATE,*//*i.PAYMENT_TYPE,*//*i.PORUCH_NO_FCURR,*//*i.PORUCH_DATE_FCURR,*//*i.ACCT_NO_FCURR,*/
/*i.DOC_STATUS,*//*i.REF_CLIENT,*//*i.BRANCH_CLIENT,*/
--,(select g.name from guides g where g.type_doc=5386 and g.code not in 'FORM_STORAGE' and num1=1 and g.code=i.ERR_CODE) G5386
,(select bank_fullname from MBANK.BANKS where mfo_depart=i.BIK_PAYERS_BANK) BANK_NAME
from inkp_staging i 
where i.date_load BETWEEN trunc(sysdate)-1
                    --TO_DATE ('20180101', 'yyyymmdd')
                    AND trunc(sysdate) 
                    --and TO_DATE ('20190326', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
and acc_type=590 
and doc_ref is not null
and branch=191                          

-- ���� �� �� ��
select level,
(select count(*) from journal where docnum=d.reference) CNT_JOUR,
d.* from documents d 
where type_doc=226
and exists(select null from contracts where (reference,branch) in (select contract,branch_contract from account where code=d.payers_account
                and header=paccount.HEADER_ACCOUNT(d.payers_account) and currency=substr(d.payers_account,6,3)) and type_doc=590 and sub_type=0)
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (
    select doc_ref
    from inkp_staging i 
    where i.date_load BETWEEN trunc(sysdate)
                    --TO_DATE ('20180101', 'yyyymmdd')
                    AND trunc(sysdate) 
                    --and TO_DATE ('20190326', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
    and acc_type=590 
    and doc_ref is not null
    and branch=191))--
order by level


select 
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'INKP_REF') INKP_REF,
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'FSSP_DOC_ID') FSSP_DOC_ID,
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'INITIALED_EDNO') INITIALED_EDNO,
rowid,ec.*
from EID.EID_CARD_OPER ec 
where 
--reference in ()--,
trunc(work_date)>=trunc(sysdate)
and op_code in ('INKASSO_WRITEOFF','INKASSO_WRITEOFF_REV','INKASSO_ON','INKASSO_OFF')
--and op_status
--and PTOOLS5.READ_PARAM(op_par,'RESPONSE') is not null
order by id desc


--**************************************
-- DISTRIB
--**************************************
--1 eid.distrib_features
select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
--select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and 
--value in ('267514379')--76002801')
and tran_id in (267514379)

--2 eid.distrib_transactions
select 
(select a.value from eid.distrib_features a where task_kind=t.task_kind and tran_id=t.tran_id and filial=t.filial and name='CURREFER') CURREFER,
(select a.value from eid.distrib_features a where task_kind=t.task_kind and tran_id=t.tran_id and filial=t.filial and name='DOC_REF') DOC_REF,
(select a.value from eid.distrib_features a where task_kind=t.task_kind and tran_id=t.tran_id and filial=t.filial and name='FUNCTION') FUNCTION,
(select a.value from eid.distrib_features a where task_kind=t.task_kind and tran_id=t.tran_id and filial=t.filial and name='OPER') OPER,
t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where 
trunc(sys_date)>=trunc(sysdate)
and task_kind  in ('IP_LOCK','E_INKP') 
and done not in (1)
and tran_id not in  (267514379)
order by tran_id,run_order 



select 
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'INKP_REF') INKP_REF,
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'FSSP_DOC_ID') FSSP_DOC_ID,
UNIVERSE.VARIABLE_DOC(BRANCH, REFERENCE, 'INITIALED_EDNO') INITIALED_EDNO,
d.* from documents d where trunc(date_create)>=trunc(sysdate)--TO_DATE ('20200225', 'yyyymmdd')
and type_doc in (226) --not in (1,2,6576,12036,4215,6,5099,270,4434,7440,167,200)
--and status in (14) 
and substr(PAYERS_ACCOUNT,1,5) not in ('30233')
and exists (select null from contracts a where  (a.reference,a.branch) in
                                                        (select contract,branch_contract from account where code = d.PAYERS_ACCOUNT)
                and type_doc in (590) 
                --and status=50 
                and sub_type=0
                --and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
                )
                
select * from documents d where trunc(date_create)>=trunc(sysdate)--TO_DATE ('20200225', 'yyyymmdd')
and type_doc not in (1,2,6576,12036,4215,6,5099,270,4434,7440)
and exists (select null from contracts a where  (a.reference,a.branch) in
                                                        (select contract,branch_contract from account where code = d.RECEIVERS_ACCOUNT)
                and type_doc in (590) 
                --and status=50 
                and sub_type=0
                --and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
                )                