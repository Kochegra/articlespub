/* Formatted on 12/12/2019 10:24:39 (QP5 v5.227.12220.39724) */
DECLARE
   sClobOut   CLOB;
   sClobIn    CLOB;
   --sAmount number := 158000;
   --sDocNum          varchar2(1000) := '123-789-456';
   --����� ���������
   sCardNum      varchar2(100) := '0191-C-234210';
   -----------------
   --��������:
   p_Reference  number := 262742089;
   p_Branch     number := 191;
   p_isBlock    number := 1; --���������� 1/0
   --sMemo varchar2(1000) := '�� ������� � ��������� � 222 �� 31.12.2019 �� ��������� ��.46 �� �� �� 31.07.1998�. � 146-��';
   --sType    varchar2(1000) := '������������';
   p_Currency   varchar2(100);
   p_NODate     varchar2(100);
   p_NONumber   varchar2(100);
         sErr           CLOB;
      sServiceName   VARCHAR2 (1000) := 'ACC_RESTRICT';
      sExtId         VARCHAR2(100) := TO_CHAR(p_Reference)||'_'||TO_CHAR(p_Branch); --TO_CHAR(p_Branch) || TO_CHAR(p_Reference); --�� ����� ����� ������ ����������
      sDocErr        VARCHAR2(2000);
      nFinalSum      NUMBER;
      sBlockType     VARCHAR2(1000);
      sClob          CLOB;
      sXML           xmltype;
      sResponseXML   xmltype ;
      sResult        varchar2(1000);
      sMessageTxt    varchar2(1000);
      TEST_NO_WAY4   NUMBER := 0; 
      sWayLog        varchar2(1000);
      sNODocDate     varchar2(100);
      sOrgan         varchar2(100);
      sInkpRef       varchar2(100);
      nTypeDoc       number;
      sFsspDocId     varchar2(100);
      sBlockOriginator varchar2(100);
      sDocSql        varchar2(4000);   
     
      eeParamsBlock    mbank.sql3web.t_param_list;
      eeResultsBlock   mbank.sql3web.t_param_list;
      g1               VARCHAR2 (50);
      v_ServerName     VARCHAR2 (50);
      v_Port           NUMBER;
      v_Ret            BOOLEAN;
   
--sCardNum varchar2(100) := '40702810312480000000';
 -- ������������ ����� �� ����� ������ � ������ �� �� ����� ��
    function convert_sum_on_cb(p_cur_from varchar2, p_cur_to varchar2, p_summa number, p_dt_course date) return number is
    begin
        return round((p_summa * pledger.wcourse(p_cur_from, p_dt_course)) / pledger.wcourse(p_cur_to, p_dt_course), 2);
    end convert_sum_on_cb;

   FUNCTION send_WAY4 (p_clob CLOB, p_servicename VARCHAR2)
      RETURN CLOB
   AS
      v_service   VARCHAR2 (20);
      v_qname     VARCHAR2 (50);
      p_url       VARCHAR2 (2000);
      s_str       VARCHAR2 (2000);
      clb         CLOB;
      v_qmsgid    NUMBER;
      p_qid       VARCHAR2 (512);
      --
      l_offset    INT := 1;
    
   BEGIN
      CLB :=
         ptools_corp_card_cft_web.get_response (i_service   => p_servicename,
                                                i_data      => p_clob);
      RETURN CLB;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (
            'Error sending to WAY4 :' || p_servicename || '! ' || SQLERRM);
         RETURN NULL;
   END;

BEGIN
    


 
      
      if sNODocDate is null and p_NODate is null then
        sNODocDate := TO_CHAR(NVL(TO_DATE (global_parameters.get_param_CFG ('SYSTEMDATE'),
                  'dd.mm.yyyy'), SYSDATE), 'YYYY-MM-DD');   
      elsif sNODocDate is null and p_NODate is not null then
        sNODocDate := p_NODate;                                 
      end if;
      
      
    
      sDocSql :=
      'select d.type_doc,
      d.summa, 
      d.payers_currency currency,
      d.doc_number,
      vd_organ.value organ,
      vd_inkpref.value inkp_ref,
      vd_fssp.value fssp
      from documents d 
      left join variable_documents vd_organ
      on vd_organ.branch = d.branch 
      and vd_organ.reference = d.reference
      and vd_organ.name = ''ORGAN''
      left join variable_documents vd_inkpref
      on vd_inkpref.branch = d.branch 
      and vd_inkpref.reference = d.reference
      and vd_inkpref.name = ''INKP_REF''
      left join variable_documents vd_fssp
      on vd_fssp.branch = d.branch 
      and vd_fssp.reference = d.reference
      and vd_fssp.name = ''FSSP_DOC_ID''
      where d.branch = :branch 
      and d.reference = :reference';


      if plink.need_connection(p_branch) = 0 then  
        EXECUTE IMMEDIATE sDocSql into nTypeDoc,
        nFinalSum,
        p_Currency,
        p_NONumber,
            sOrgan,
            sInkpRef,
            sFsspDocId
        USING IN p_Branch,
              IN p_Reference;               
      else
        v_Port := mbank.sql3web.http_port;
        v_ServerName := PTOOLS_BY_UTL.GET_WEB_ADR (p_branch); 

        mbank.sql3web.setRemoteInfo (v_ServerName, v_Port);
        mbank.sql3web.setPlSqlBlock(sDocSql,
                                    1);
        eeParamsBlock(1) := mbank.sql3web.bindNum('branch',
                                                  mbank.sql3web.par_in,
                                                  p_Branch);
        eeParamsBlock(2) := mbank.sql3web.bindChar('reference',
                                                   mbank.sql3web.par_in,
                                                   p_Reference);
        g1 := mbank.sql3web.setParams(eeParamsBlock, 1);

        mbank.sql3web.doExec(1);
        mbank.sql3web.startGetResults(g1);

        eeResultsBlock(1) := mbank.sql3web.bindNum('type_doc',
                                                   mbank.sql3web.par_out,
                                                   null);
        eeResultsBlock(2) := mbank.sql3web.bindNum('summa',
                                                   mbank.sql3web.par_out,
                                                   null);     
        eeResultsBlock(3) := mbank.sql3web.bindChar('currency',
                                                   mbank.sql3web.par_out,
                                                   null);   
        eeResultsBlock(4) := mbank.sql3web.bindChar('doc_number',
                                                   mbank.sql3web.par_out,
                                                   null);                                                                                                                                                                                  
        eeResultsBlock(5) := mbank.sql3web.bindChar('organ',
                                                   mbank.sql3web.par_out,
                                                   null);
        eeResultsBlock(6) := mbank.sql3web.bindChar('inkp_ref',
                                                   mbank.sql3web.par_out,
                                                   null);
        eeResultsBlock(7) := mbank.sql3web.bindChar('fssp',
                                                   mbank.sql3web.par_out,
                                                   null);      

        while mbank.sql3web.fetchResult(eeResultsBlock) loop
            nTypeDoc    := eeResultsBlock(1).nvalue;
            nFinalSum   := eeResultsBlock(2).nvalue;
            p_Currency   := eeResultsBlock(3).cvalue;
            p_NONumber   := eeResultsBlock(4).cvalue;
            sOrgan      := eeResultsBlock(5).cvalue;
            sInkpRef    := eeResultsBlock(6).cvalue;
            sFsspDocId  := eeResultsBlock(7).cvalue;
            exit;
        end loop;
      end if;
      
      if nvl(nTypeDoc, 0) = 3363 then
        if sOrgan is not null then
            if sOrgan = '0' then
                sBlockOriginator := '���';
            elsif sOrgan in ('1', '2') then
                sBlockOriginator := '����';
            end if;  
        end if;  
        if sFsspDocId is not null then
            sBlockOriginator := '����';
        end if;          
      elsif nvl(nTypeDoc, 0) = 226 then
         if sInkpRef is not null then 
               sBlockOriginator := '���';  
         elsif sFsspDocId is not null then
            sBlockOriginator := '����';
         end if;   
      else
         sBlockOriginator := '���';             
      end if;
    
      
      --���� �� � ������, ������������ �� �����
      if (p_Currency != '810') then
        nFinalSum := convert_sum_on_cb(p_Currency, '810', nFinalSum, sysdate);
      else
        nFinalSum := nFinalSum;
      end if;
      --form xml
      IF nvl(nTypeDoc, 0) = 3363 THEN
        IF NVL(sOrgan, '0') IN ('0', '1') THEN
            IF NVL (p_isBlock, 0) = 1
                THEN
                sBlockType := '�����';
            ELSE
                sBlockType := '������������';
            END IF;
        ELSIF NVL(sOrgan, '0') IN ('2') THEN
            IF NVL (p_isBlock, 0) = 1
                THEN
                sBlockType := '��������';
            ELSE
                sBlockType := '���������������';
            END IF;
        END IF;
      ELSE  
        IF NVL (p_isBlock, 0) = 1
                THEN
                sBlockType := '�����';
        ELSE
                sBlockType := '������������ ';
        END IF;
      END IF;  

         --���� ����� �� �����, �� AccountRestriction. ���� ���� �������� ���
         sClobOut :=
            '<?xml version="1.0" encoding="UTF-8"?>
            <Request Type="MBankAccountRestriction" ID="%ID%">
            <Card>%CARD%</Card>
            <DocNumber>%DOCNUMBER%</DocNumber>
            <DocDate>%DOCDATE%</DocDate>
            <BlockOriginator>%BLOCKORIGINATOR%</BlockOriginator>
            <BlockType>%BLOCKTYPE%</BlockType>
            <BlockSumm>%BLOCKSUM%</BlockSumm>
            <UserID>000000</UserID>
            <ExtId>%EXTID%</ExtId>
        </Request>';
         sClobOut :=
            REPLACE (sClobOut,
                     '%ID%',
                     TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHH24MISSSSS'));
         sClobOut := REPLACE (sClobOut, '%CARD%', sCardNum);
         sClobOut := REPLACE (sClobOut, '%DOCNUMBER%', p_NONumber);
         sClobOut := REPLACE (sClobOut, '%DOCDATE%', sNODocDate);
         sClobOut := REPLACE (sClobOut, '%EXTID%', sExtId);
         sClobOut := REPLACE (sClobOut, '%BLOCKTYPE%', sBlockType);
         sClobOut := REPLACE (sClobOut, '%BLOCKORIGINATOR%', sBlockOriginator);
         sClobOut :=
            REPLACE (sClobOut,
                     '%BLOCKSUM%',
                     TRIM (TO_CHAR (nFinalSum, '9999999999990.00')));   

   dbms_output.put_line('out = '||substr(sClobOut, 1, 4000));                        
   sClobIn := send_WAY4 (sClobOut, sServiceName);

   DBMS_OUTPUT.put_line ('in = '||SUBSTR (sClobIn, 1, 4000));
END;
/