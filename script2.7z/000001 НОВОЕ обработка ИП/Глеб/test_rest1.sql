/* Formatted on 12/12/2019 10:24:39 (QP5 v5.227.12220.39724) */
DECLARE
   sClobOut   CLOB;
   sClobIn    CLOB;
   sCardNum      varchar2(100) := '1020-C-904410';

   FUNCTION send_WAY4 (p_clob CLOB, p_servicename VARCHAR2)
      RETURN CLOB
   AS
      v_service   VARCHAR2 (20);
      v_qname     VARCHAR2 (50);
      p_url       VARCHAR2 (2000);
      s_str       VARCHAR2 (2000);
      clb         CLOB;
      v_qmsgid    NUMBER;
      p_qid       VARCHAR2 (512);
      --
      l_offset    INT := 1;
    
   BEGIN
      CLB :=
         ptools_corp_card_cft_web.get_response (i_service   => p_servicename,
                                                i_data      => p_clob);
      RETURN CLB;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (
            'Error sending to WAY4 :' || p_servicename || '! ' || SQLERRM);
         RETURN NULL;
   END;

BEGIN
 --���� ����� �� �����, �� AccountRestriction
         sClobOut :=
            '<?xml version="1.0" encoding="utf-8" ?>
<Request Type="MBGetAccountPartyAccount">
    <AccountNumber>%CARD%</AccountNumber>
</Request>';

         sClobOut := REPLACE (sClobOut, '%CARD%', sCardNum);
  

   dbms_output.put_line('out = '||substr(sClobOut, 1, 4000));                        
   sClobIn := send_WAY4 (sClobOut, 'ACC_INFO');

   DBMS_OUTPUT.put_line ('in = '||SUBSTR (sClobIn, 1, 4000));
END;
/