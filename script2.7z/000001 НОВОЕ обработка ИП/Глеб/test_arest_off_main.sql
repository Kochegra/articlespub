DECLARE
nDocReference number := 3866374572;
nDocBranch number := 191;
sAccount varchar2(100) := '40802810919110001038';
l_Result clob;
vContr contracts%rowtype;
lDoc   boolean;
nArch   number;
recDocument documents%rowtype;
vArSum        number := 0;
    vOrgan        VARCHAR2(1);
    vArType       VARCHAR2(1);
    
       -- ������������ ����� �� ����� ������ � ������ �� �� ����� ��
      function convert_sum_on_cb(p_cur_from varchar2, p_cur_to varchar2, p_summa number, p_dt_course date) return number is
        begin
            return round((p_summa * pledger.wcourse(p_cur_from, p_dt_course)) / pledger.wcourse(p_cur_to, p_dt_course), 2);
    end convert_sum_on_cb;   
   FUNCTION loc_getTagFromXml (pi_xml IN XMLTYPE, pi_sTag IN VARCHAR2)
      RETURN VARCHAR2
   IS
      sTmp   VARCHAR2 (254);
   BEGIN
      IF pi_xml.EXISTSNODE (pi_sTag) = 1
      THEN
         sTmp := pi_xml.EXTRACT (pi_sTag || '/text()').getStringVal ();
      END IF;

      RETURN sTmp;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION loc_getAttrFromXml (pi_xml     IN XMLTYPE,
                                pi_sTag    IN VARCHAR2,
                                pi_sAttr   IN VARCHAR2)
      RETURN VARCHAR2
   IS
      sTmp   VARCHAR2 (254);
   BEGIN
      IF pi_xml.EXISTSNODE (pi_sTag) = 1
      THEN
         sTmp := pi_xml.EXTRACT (pi_sTag || '/@' || pi_sAttr).getStringVal ();
      END IF;

      RETURN sTmp;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;   
 --�������� ������� � WAY4 ����� ���-������ � ���������� ������
   FUNCTION send_WAY4 (p_clob CLOB, p_servicename VARCHAR2)
      RETURN CLOB
   AS
      v_service   VARCHAR2 (20);
      v_qname     VARCHAR2 (50);
      p_url       VARCHAR2 (2000);
      s_str       VARCHAR2 (2000);
      clb         CLOB;
      v_qmsgid    NUMBER;
      p_qid       VARCHAR2 (512);
      --
      l_offset    INT := 1;
   BEGIN
       CLB := ptools_corp_card_cft_web.get_response( i_service => p_servicename, i_data => p_clob );
      RETURN CLB;
   EXCEPTION WHEN OTHERS THEN
      RETURN 'Error sending to WAY4 :' || p_servicename || '! '||sqlerrm;
   END;
   
    --���������� ����� way24 / ����������� �� ����� (?)
   FUNCTION LOCK_CARD_WAY24 (p_Reference    documents.reference%TYPE,
                             p_Branch       documents.branch%TYPE,
                             p_Account      account.code%TYPE,
                             p_Currency     currency.currency%TYPE,
                             p_sCard        VARCHAR2,
                             p_Date         DATE,
                             p_Summa        NUMBER,
                             p_NONumber     VARCHAR2,
                             p_NODate       VARCHAR2,
                             p_isBlock      NUMBER)
      RETURN VARCHAR2
   IS
      sErr           CLOB;
      sServiceName   VARCHAR2 (1000) := 'ACC_RESTRICT';
      sClobOut       CLOB;
      sCardNum       VARCHAR2 (50) := p_sCard;
      sExtId         VARCHAR2(100) :=  TO_CHAR(p_Reference)||'_'||TO_CHAR(p_Branch); --�� ����� ����� ������ ����������
      sDocErr        VARCHAR2(2000);
      nFinalSum      NUMBER;
      sBlockType     VARCHAR2(1000);
      sClob          CLOB;
      sXML           xmltype;
      sResponseXML   xmltype ;
      sResult        varchar2(1000);
      sMessageTxt    varchar2(1000);
      sWayLog        varchar2(1000);
      sNODocDate    varchar2(100) := to_char(to_date(p_NODate, 'dd.mm.yyyy'), 'yyyy-mm-dd');
   BEGIN
      --���� �� � ������, ������������ �� �����
      if (p_Currency != '810') then
        nFinalSum := convert_sum_on_cb(p_Currency, '810', p_Summa, sysdate);
      else
        nFinalSum := p_Summa;
      end if;
      --form xml
      IF NVL (p_isBlock, 0) = 1
        THEN
        sBlockType := '�����';
      ELSE
        sBlockType := '������������';
      END IF;
      
         --���� ����� �� �����, �� AccountRestriction
         sClobOut :=
            '<?xml version="1.0" encoding="UTF-8"?>
            <Request Type="MBankAccountRestriction" ID="%ID%">
            <Card>%CARD%</Card>
            <DocNumber>%DOCNUMBER%</DocNumber>
            <DocDate>%DOCDATE%</DocDate>
            <BlockOriginator>����</BlockOriginator>
            <BlockType>%BLOCKTYPE%</BlockType>
            <BlockSumm>%BLOCKSUM%</BlockSumm>
            <UserID>000000</UserID>
            <ExtId>%EXTID%</ExtId>
        </Request>';
         sClobOut :=
            REPLACE (sClobOut,
                     '%ID%',
                     TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHH24MISSSSS'));
         sClobOut := REPLACE (sClobOut, '%CARD%', sCardNum);
         sClobOut := REPLACE (sClobOut, '%DOCNUMBER%', p_NONumber);
         sClobOut := REPLACE (sClobOut, '%DOCDATE%', sNODocDate);
         sClobOut := REPLACE (sClobOut, '%EXTID%', sExtId);
         sClobOut := REPLACE (sClobOut, '%BLOCKTYPE%', sBlockType);
         sClobOut :=
            REPLACE (sClobOut,
                     '%BLOCKSUM%',
                     TRIM (TO_CHAR (nFinalSum, '9999999999990.00')));
     dbms_output.put_line(substr(sClobOut, 1, 4000));
     sClob := send_WAY4 (sClobOut, sServiceName);
     dbms_output.put_line(substr(sClob, 1, 4000));
      if sClob is null then
        return 'empty answer '||substr(sClobOut, 1, 2000);
      end if;
      begin
        sXML := xmltype(sClob);
        sResponseXML := sXML.EXTRACT ('/Response');
        sResult := loc_getTagFromXml(sResponseXML, 'ResultCode');
        sMessageTxt := loc_getTagFromXml(sResponseXML, 'ResultMsg');
      exception when others then
        return 'response error: '||SUBSTR(sClob,1,2000);
      end;

      if sResult = '0' then
        return null;
      else
        return sMessageTxt;
      end if;
      RETURN sErr;
   END;
   
   begin
   lDoc := UNIVERSE.GET_DOCUMENT_REC(nDocReference, nDocBranch, nArch, 0, recDocument);
   
   vArType := nvl(universe.VARIABLE_doc(recDocument.Branch, recDocument.Reference, 'ARTYPE'), '?');
    if vArType = '?'
    then
        raise_application_error(-20000, '�� ����� ��� ������');
    end if;
    
    if vArType = '1'
    then
      vArSum := to_number(nvl(universe.VARIABLE_doc(recDocument.Branch, recDocument.Reference, 'ARSUM'), '0'));
    end if;
   
   SELECT * INTO vContr FROM contracts WHERE ACCOUNT = sAccount and type_doc = 590 and sub_type = 1;
   
        l_Result := LOCK_CARD_WAY24 (recDocument.related, --recDocument.reference,--
                              recDocument.branch_related, --recDocument.branch,--
                              vContr.Account,
                              vContr.Currency,
                              Universe.VARIABLE_CONTRACT(vContr.branch, vContr.reference, 'CARD_CORP_CONTRACT'),
                              recDocument.Date_Document,
                              pno.GET_SUMMA(vArSum, recDocument.Date_Document, vContr.Currency),
                              universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'nalog_doc_number'),
                              universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'nalog_doc_date'),
                              0);  
   
   dbms_output.put_line(l_Result);
   
   end;
/      