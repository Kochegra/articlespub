DECLARE

nDocReference number := 3998157450;
nDocBranch number := 235409;
sAccount varchar2(100) := '40802810310200000946';
sExtID      varchar2(1000) := '';
nIsBlock number := 0; --�����, 0 - ������
l_Result clob;
vContr contracts%rowtype;
lDoc   boolean;
nArch   number;
recDocument documents%rowtype;
vArSum        number := 0;
    vOrgan        VARCHAR2(1);
    vArType       VARCHAR2(1);
    sNoDocNum       varchar2(500);
    sNoDocDate      varchar2(100);
       -- ������������ ����� �� ����� ������ � ������ �� �� ����� ��
      function convert_sum_on_cb(p_cur_from varchar2, p_cur_to varchar2, p_summa number, p_dt_course date) return number is
        begin
            return round((p_summa * pledger.wcourse(p_cur_from, p_dt_course)) / pledger.wcourse(p_cur_to, p_dt_course), 2);
    end convert_sum_on_cb;   
   FUNCTION loc_getTagFromXml (pi_xml IN XMLTYPE, pi_sTag IN VARCHAR2)
      RETURN VARCHAR2
   IS
      sTmp   VARCHAR2 (254);
   BEGIN
      IF pi_xml.EXISTSNODE (pi_sTag) = 1
      THEN
         sTmp := pi_xml.EXTRACT (pi_sTag || '/text()').getStringVal ();
      END IF;

      RETURN sTmp;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION loc_getAttrFromXml (pi_xml     IN XMLTYPE,
                                pi_sTag    IN VARCHAR2,
                                pi_sAttr   IN VARCHAR2)
      RETURN VARCHAR2
   IS
      sTmp   VARCHAR2 (254);
   BEGIN
      IF pi_xml.EXISTSNODE (pi_sTag) = 1
      THEN
         sTmp := pi_xml.EXTRACT (pi_sTag || '/@' || pi_sAttr).getStringVal ();
      END IF;

      RETURN sTmp;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;   
 --�������� ������� � WAY4 ����� ���-������ � ���������� ������
   FUNCTION send_WAY4 (p_clob CLOB, p_servicename VARCHAR2)
      RETURN CLOB
   AS
      v_service   VARCHAR2 (20);
      v_qname     VARCHAR2 (50);
      p_url       VARCHAR2 (2000);
      s_str       VARCHAR2 (2000);
      clb         CLOB;
      v_qmsgid    NUMBER;
      p_qid       VARCHAR2 (512);
      --
      l_offset    INT := 1;
   BEGIN
       CLB := ptools_corp_card_cft_web.get_response( i_service => p_servicename, i_data => p_clob );
      RETURN CLB;
   EXCEPTION WHEN OTHERS THEN
      RETURN 'Error sending to WAY4 :' || p_servicename || '! '||sqlerrm;
   END;
   
      --���������� ����� way24 / ����������� �� �����
   FUNCTION LOCK_CARD_WAY24 (p_Reference    documents.reference%TYPE,
                             p_Branch       documents.branch%TYPE,
                             p_Account      account.code%TYPE,
                             p_Currency     currency.currency%TYPE,
                             p_sCard        VARCHAR2,
                             p_Date         DATE,
                             p_Summa        NUMBER,
                             p_NONumber     VARCHAR2,
                             p_NODate       VARCHAR2,
                             p_isBlock      NUMBER,
                             p_nTypeDoc     NUMBER      DEFAULT NULL,
                             p_sOrgan       VARCHAR2    DEFAULT NULL,
                             p_sInkpRef     VARCHAR2    DEFAULT NULL,
                             p_sFsspDocId   VARCHAR2    DEFAULT NULL,
                             p_sExtId       VARCHAR2    DEFAULT NULL)
      RETURN VARCHAR2
   IS
      sErr           CLOB;
      sServiceName   VARCHAR2 (1000) := 'ACC_RESTRICT';
      sClobOut       CLOB;
      sCardNum       VARCHAR2 (50) := p_sCard;
      sExtId         VARCHAR2(100); --TO_CHAR(p_Branch) || TO_CHAR(p_Reference); --�� ����� ����� ������ ����������
      sDocErr        VARCHAR2(2000);
      nFinalSum      NUMBER;
      sBlockType     VARCHAR2(1000);
      sClob          CLOB;
      sXML           xmltype;
      sResponseXML   xmltype ;
      sResult        varchar2(1000);
      sMessageTxt    varchar2(1000);
      TEST_NO_WAY4   NUMBER := 0;
      sWayLog        varchar2(1000);
      sNODocDate     varchar2(100);
      sOrgan         varchar2(100)  := p_sOrgan;
      sInkpRef       varchar2(100)  := p_sInkpRef;
      nTypeDoc       number         := p_nTypeDoc;
      sFsspDocId     varchar2(100)  := p_sFsspDocId;
      sBlockOriginator varchar2(100);
      sDocSql        varchar2(4000);

      eeParamsBlock    mbank.sql3web.t_param_list;
      eeResultsBlock   mbank.sql3web.t_param_list;
      g1               VARCHAR2 (50);
      v_ServerName     VARCHAR2 (50);
      v_Port           NUMBER;
      v_Ret            BOOLEAN;
   BEGIN
      begin
        sNODocDate := to_char(to_date(p_NODate, 'dd.mm.yyyy'), 'yyyy-mm-dd');
      exception
        when others then null;
      end;
      
      if p_sExtId is not null then
       sExtId := p_sExtId;
      else
       sExtId := TO_CHAR(p_Reference)||'_'||TO_CHAR(p_Branch);
      end if;
      
      if sNODocDate is null and p_NODate is null then
        sNODocDate := TO_CHAR(NVL(TO_DATE (global_parameters.get_param_CFG ('SYSTEMDATE'),
                  'dd.mm.yyyy'), SYSDATE), 'YYYY-MM-DD');
      elsif sNODocDate is null and p_NODate is not null then
        sNODocDate := p_NODate;
      end if;

      if nvl(nTypeDoc, 0) = 3363 then
        if sOrgan is not null then
            if sOrgan = '0' then
                sBlockOriginator := '���';
            elsif sOrgan in ('1', '2') then
                sBlockOriginator := '����';
            end if;
        end if;
        if sFsspDocId is not null then
            sBlockOriginator := '����';
        end if;
      elsif nvl(nTypeDoc, 0) = 226 then
         if sInkpRef is not null then
               sBlockOriginator := '���';
         elsif sFsspDocId is not null then
            sBlockOriginator := '����';
         end if;
      else
         sBlockOriginator := '���';
      end if;


      --���� �� � ������, ������������ �� �����
      if (p_Currency != '810') then
        nFinalSum := convert_sum_on_cb(p_Currency, '810', p_Summa, sysdate);
      else
        nFinalSum := p_Summa;
      end if;
      --form xml
      IF nvl(nTypeDoc, 0) = 3363 THEN
        IF NVL(nFinalSum, 0) = 0 THEN --������ �����
            IF NVL (p_isBlock, 0) = 1
               THEN
                    sBlockType := '��������������';
            ELSE
                    sBlockType := '������������������';
            END IF;
        ELSE
            IF NVL(sOrgan, '0') IN ('0', '1') THEN --�����
                IF NVL (p_isBlock, 0) = 1
                    THEN
                    sBlockType := '�����';
                ELSE
                    sBlockType := '������������';
                END IF;
            ELSIF NVL(sOrgan, '0') IN ('2') THEN --��������
                IF NVL (p_isBlock, 0) = 1
                    THEN
                    sBlockType := '��������';
                ELSE
                    sBlockType := '���������������';
                END IF;
            END IF;
        END IF;

      ELSE
        IF NVL (p_isBlock, 0) = 1
                THEN
                sBlockType := '�����';
        ELSE
                sBlockType := '������������';
        END IF;
      END IF;

      IF NVL(TEST_NO_WAY4, 0) = 1 THEN
        return null;
      END IF;

         --���� ����� �� �����, �� AccountRestriction. ���� ���� �������� ���
         sClobOut :=
            '<?xml version="1.0" encoding="UTF-8"?>
            <Request Type="MBankAccountRestriction" ID="%ID%">
            <Card>%CARD%</Card>
            <DocNumber>%DOCNUMBER%</DocNumber>
            <DocDate>%DOCDATE%</DocDate>
            <BlockOriginator>%BLOCKORIGINATOR%</BlockOriginator>
            <BlockType>%BLOCKTYPE%</BlockType>
            <BlockSumm>%BLOCKSUM%</BlockSumm>
            <UserID>000000</UserID>
            <ExtId>%EXTID%</ExtId>
        </Request>';
         sClobOut :=
            REPLACE (sClobOut,
                     '%ID%',
                     TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHH24MISSSSS'));
         sClobOut := REPLACE (sClobOut, '%CARD%', sCardNum);
         sClobOut := REPLACE (sClobOut, '%DOCNUMBER%', p_NONumber);
         sClobOut := REPLACE (sClobOut, '%DOCDATE%', sNODocDate);
         sClobOut := REPLACE (sClobOut, '%EXTID%', sExtId);
         sClobOut := REPLACE (sClobOut, '%BLOCKTYPE%', sBlockType);
         sClobOut := REPLACE (sClobOut, '%BLOCKORIGINATOR%', sBlockOriginator);
         sClobOut :=
            REPLACE (sClobOut,
                     '%BLOCKSUM%',
                     TRIM (TO_CHAR (nFinalSum, '9999999999990.00')));
        dbms_output.put_line(sClobOut);
      sClob := send_WAY4 (sClobOut, sServiceName);
      dbms_output.put_line(sClob);
      if sClob is null then
        return 'empty answer '||substr(sClobOut, 1, 2000);
      end if;
      begin
        sXML := xmltype(sClob);
        sResponseXML := sXML.EXTRACT ('/Response');
        sResult := loc_getTagFromXml(sResponseXML, '//ResultCode');
        sMessageTxt := loc_getTagFromXml(sResponseXML, '//ResultMsg');
      exception when others then
        return 'response error: '||SUBSTR(sClob,1,2000);
      end;

      if sResult = '0' then
        return null;
      else
        return sMessageTxt;
      end if;
      RETURN sErr;
      exception when others then return sqlerrm||dbms_utility.format_error_backtrace;
   END;
   
   begin
   lDoc := UNIVERSE.GET_DOCUMENT_REC(nDocReference, nDocBranch, nArch, 0, recDocument);
   
   vArType := nvl(universe.VARIABLE_DOC(recDocument.Branch, recDocument.Reference, 'ARTYPE'), '?');
    if vArType = '?' and recDocument.type_doc != 226
    then
        raise_application_error(-20000, '�� ����� ��� ������');
    end if;
    vArSum := recDocument.summa;
    if vArType = '1'
    then
      vArSum := to_number(nvl(universe.VARIABLE_DOC(recDocument.Branch, recDocument.Reference, 'ARSUM'), '0'));
    end if;
   
   SELECT * INTO vContr FROM contracts WHERE ACCOUNT = sAccount and type_doc = 590 and sub_type = 1;
   
   if recDocument.type_doc = 226 then
    sNoDocNum       := recDocument.doc_number;
    sNoDocDate      := TO_CHAR (recDocument.date_document,
                                                  'YYYY-MM-DD');
   else
    sNoDocNum      := universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'nalog_doc_number');
    sNoDocDate     := universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'nalog_doc_date');
   end if;
   
        l_Result := LOCK_CARD_WAY24 (recDocument.reference,
                              recDocument.branch,
                              vContr.Account,
                              vContr.Currency,
                              Universe.VARIABLE_CONTRACT(vContr.branch, vContr.reference, 'CARD_CORP_CONTRACT'),
                              recDocument.Date_Document,
                              pno.GET_SUMMA(vArSum, recDocument.Date_Document, vContr.Currency),
                              sNoDocNum,
                              sNoDocDate,
                              nIsBlock,
                              recDocument.type_doc,
                             universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'ORGAN'),
                             universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'INKP_REF'),
                             universe.variable_doc(recDocument.branch
                                   ,recDocument.reference
                                   ,'FSSP_DOC_ID'),
                              sExtId);  
   
   dbms_output.put_line(l_Result);
   
   end;
/      