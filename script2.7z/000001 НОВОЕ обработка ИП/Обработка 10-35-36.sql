select * from v_documents d
where 
date_work>=trunc(sysdate)-10
and type_doc=226 
and status in (--35,
36)
and date_document>=trunc(sysdate)-10
and exists(select null from contracts where account=d.payers_account and type_doc=590
                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
and nvl(related,0)=0 
and nvl(refer_from,0)=0 
--and UNIVERSE.VARIABLE_DOC(reference,branch,'IP_SKS')=1 -- ��� �����������
and exists(select null from v_variable_documents where reference=d.reference and branch=d.branch and name in ('INKP_REF'))--,
                                                                                                                --'FSSP_DOC_ID'))
--and exists(select null from journal where docnum=d.reference and branch=d.branch)

and exists(select null from v_documents where d.reference in (related,refer_from))





select * from contracts where account in (select payers_account from v_documents where reference=3802683762)

select * from collector_contracts where (reference,branch) in (
    select reference,branch from contracts where account in (select payers_account from v_documents where reference=3802683762)
    )
--and docnum = 3802683762

--======= DOCUMENTS ARCHIVE
select --rowid,
doc.* from v_documents doc where  reference in (3798387278)
--union all
--select rowid,doc.* from archive doc where reference in (3802772054)
or refer_from in (3798387278)
or related in (3798387278)

select doc.* from v_documents doc where  reference in (3802683762,3787886411)
--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (3802683762,3787886411)
or related in (3802683762,3787886411)



--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (3798388126))--,3804715684,3804715227))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch)=

select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (3787886411))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=3802683762


select * from mbank_audit.audit_table where reference=



--DISTR
select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('3787758462','3785744212')--,
order by id desc


--1 eid.distrib_features
--select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
and 
value in ('3798387278'
)--76002801')
--and 
--tran_id in (28061776)

--2 eid.distrib_transactions
select t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where --task_kind='M_FILIAL' and 
tran_id in  (261941241,262294827,262294906,262320952)
order by tran_id,run_order                                                        --� ��������� ������ ������� - ����������� �������� � DONE =1


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
and tran_id in (262188646)


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK')--,'E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
--and tran_id in (262215242)
or
