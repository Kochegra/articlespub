
select level,
(select count(*) from journal where docnum=d.reference) CNT_JOUR,
d.* from documents d 
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (262824957))--
--262298063))--262295900))
            --reference=262295295 and branch=191
order by level

-- ���� �� NO_FILE
select level,
(select count(*) from journal where docnum=d.reference) CNT_JOUR,
''''||d.reference||''',',d.* from documents d 
where type_doc=3363
and exists(select null from contracts where (reference,branch) in (select contract,branch_contract from account where code=d.payers_account
                and header=paccount.HEADER_ACCOUNT(d.payers_account) and currency=substr(d.payers_account,6,3)) and type_doc=590 and sub_type=0)
connect by prior reference in (refer_from,related) and branch in (branch_from,branch_related)
start with (reference,branch) in (select reference,branch from documents where reference in (
    select 
    f.refer_doc
    from no_files f
    where reference in (select reference from no_file where date_create BETWEEN trunc(sysdate) AND trunc(sysdate)+ 1 - 1 / (1 * 24 * 60 * 60)
                        --and instr(file_name,'RPO')>0
                        )
    and nvl((SELECT eid.p_eid_tools2.get_filial_id (subdep => a.subdepartment, ncheckchange => 1)
                        FROM eid.eid_firma_account a
                       WHERE a.code = f.VALUE AND a.header = 'A'),0)=191
    and nvl((select type_doc from contracts where (reference,branch)=(select contract,branch_contract from account where code = f.value)),0)=590 
    and refer_doc is not null
))--
order by level

select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('3901376568',
'3901529790',
'3901376592',
'3901376595',
'3901376598',
'3901376657',
'3901433659',
'3901433795',
'3901433808',
'3901433922',
'3901433929',
'3901434234',
'3901434239',
'3901434296',
'3901434718',
'3901434728',
'3901434793',
'3901434878',
'3901435060',
'3901435086',
'3901435371',
'3901435562',
'3901435609',
'3901436471',
'3901437210',
'3901437305',
'3901437328',
'3901437351',
'3901437399',
'3901437447',
'3901437964',
'3901438007',
'3901438114',
'3901438346',
'3901457169',
'3901483260',
'3901488198',
'3901493936',
'3901495016',
'3901508433',
'3901509768',
'3901510079',
'3901510089',
'3901514623',
'3901516267',
'3901516273',
'3901516369',
'3901518447',
'3901518610',
'3901519154',
'3901520171',
'3901521863',
'3901521983',
'3901522412',
'3901522885',
'3901522936',
'3901522969',
'3901523224',
'3901523520',
'3901525450',
'3901529405',
'3901529720',
'3901376579')--'3792015066')--,
--and op_code in ('INKASSO_WRITEOFF','INKASSO_WRITEOFF_REV')
--and op_par like '%[AMOUNT=220.43]%'
order by id desc