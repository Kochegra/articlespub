select * from zyx_store where oper='MONITOR_MB_WAY24'

insert into zyx_store (OPER,num1)
--values ('MONITOR_MB_WAY24',2657017)
--values ('MONITOR_MB_WAY24',2662240)
--values ('MONITOR_MB_WAY24',3838107999)


-- ����� ���������
select rowid,
-PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.account), c.account, substr(c.account,6,3),trunc(sysdate)) saldo,
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = c.account) sal,
nvl(UNIVERSE.VARIABLE_CONTRACT(c.BRANCH, c.REFERENCE, 'ARREST_ACTION'),0) arr,
d_3363.contract_action_arrest_n (c.reference, c.branch) action_state, 
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = c.assist) sal_ass,
universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') CONTRACT,
c.* 
from contracts c
where type_doc = 590
and date_open>=trunc(sysdate)-100
and status=50
and sub_type in (1)
and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
and account is not null
-- ����
--and reference in (5283491) and branch=191-- 40702810200009004599 <- 30301810800810000001
-- �����
--and reference in (5283481) and branch=191-- 40702810600009004597 <- 30301810800810000001
-- ���
--and reference in (5283486) and branch=191-- 40702810900009004598 <- 30301810800810000001


-- ����� ������� � ����������� � WAY24
select 
--count(*) as cnt
rowid, --f.*
--(select count(*) from no_files where reference=f.reference) cnt_accnts,
--xmltype(value).extract('//*[local-name()=''GUID'']/text()').GETSTRINGVAL() GUID_OSNOR,
--(select count(*) from no_file@khabarovsk where reference=f.reference) cnt_fil,
--(select status from no_file@khabarovsk where reference=f.reference) status_fil,
f.VALUE,
F.COUNTER,
f.REFERENCE||',',f.REFER_TO||',',f.REFERENCE,f.QUEUE_REFER,f.STATUS,f.FILIAL,f.DATE_CREATE,f.REFER_TO,f.BRANCH_TO,f.ANSWERED,f.RESULT_KWT,
f.FILE_NAME,f.TYPE,f.NUMBER_STOP,f.NUMBER_CANCEL,f.SUMMA,
f.ERR_CODE,f.ERR_MESS,/*f.ANSWERED,*/f.REPLY,f.ERR_REPLY,f.REPLY_FILE,/*f.REPLY_OUT,*//*f.RESULT_KWT,*/f.DATE_CREATE_KWT,f.FILE_NAME_KWT,
f.RES_KWT,/*f.VALUE_KWTs,*/f.IN_FILIAL,f.BRANCH,f.SUBDEPARTMENT,f.BIK,f.INN,f.KPP,f.CL_NAME,
/*f.FILE_DIR,*//*f.FILE_EXT,*//*f.ID_FILE,*/f.DATE_STOP,f.DATE_CANCEL/*f.CAUSE,*//*f.NO_NAME,*/,f.DATE_WORK
/*f.LOCALITY,*//*f.ID_NO,*//*f.REFER_CLIENT,*//*f.BRANCH_CLIENT,*//*f.ZAPROS,*//*f.COUNTER,*/
,SEND_GUID,F.CODE_REASON
,(select g.name from guides g where g.type_doc=5386 and g.code not in 'FORM_STORAGE' and num1=1 and g.code=f.ERR_CODE) G5386
from no_file
--as of timestamp (systimestamp - interval '20' minute)
f 
where 
date_create BETWEEN --trunc(sysdate)-10
                    TO_DATE ('20200225', 'yyyymmdd')
                    AND trunc(sysdate)
                    --TO_DATE ('20190401', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
and exists (select 1 from contracts a where (a.reference,a.branch) in 
                    (select contract,branch_contract from account where code in 
                        (select value from no_files where reference = f.reference))
                            and type_doc in (590) and status=50 and sub_type=1
                            --and d_3363.contract_action_arrest_n (reference, branch)>0
                            )
--and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=f.reference)


-- ����� ���������� �����
select --distinct ACCOUNT_NO_RECIPIENT
----count(*) as cnt
--*
--BIK_PAYERS_BANK,BRANCH_NO_PAYER,
--i.ACCOUNT_NO_PAYER,
--paccount.keyaccount(i.ACCOUNT_NO_PAYER,'728') k_728,
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = I.ACCOUNT_NO_PAYER) sal,
rowid, i.id||',',doc_ref||',',--i.*
(nvl2((select distinct docnum from journal@nsibirsk where docnum=I.DOC_REF and branch=I.DOC_BRANCH),'YES','NO')) jour,
(select status from documents@nsibirsk where reference=I.DOC_REF and branch=I.DOC_BRANCH) doc_stat,
(select status from archive@nsibirsk where reference=I.DOC_REF and branch=I.DOC_BRANCH) arh_stat,
i.ID,i.QUEUE_REFER,i.DATE_LOAD,i.CHANGE_DATE,i.STATUS,i.BRANCH,i.IN_FILIAL,i.DOC_REF,i.DOC_BRANCH,i.ERR_CODE,i.ERR_MSG,
i.ACCOUNT_NO_PAYER,i.ACC_TYPE,i.ACCOUNT_NO_RECIPIENT,i.FILE_NAME,i.PORUCH_NUM,i.SUMM,i.REPLIED,i.REPLY_ID,i.CONFIRM_ID,i.KWT_ID,
i.PAYERS_BANK,i.BIK_PAYERS_BANK,i.STATUS_CODE,i.SUBDEPARTMENT,i.LOG_ID,i.INN_PAYER,i.BIK_RECIPIENT_BANK,I.PAYER,I.SEND_GUID
/*i.FILE_ID,*//*i.DOC_ID,*//*i.OKUD,*//*i.PORUCH_DATE,*//*i.KIND_OF_PAYMENT,*//*i.KPP_PAYER,*//*i.PAYER,*/
/*i.ACCOUNT_NO_PAYERS_BANK,*//*i.BRANCH_NO_PAYER,*//*i.RECIPIENT_BANK,*//*i.ACCOUNT_NO_RECIPIENT_BANK,*/
/*i.INN_RECIPIENT,*//*i.KPP_RECIPIENT,*//*i.RECIPIENT,*//*i.ACCOUNT_NO_RECIPIENT,*//*i.OPERATION_TYPE,*//*i.CODE_PAYMENT_PURPOSE,*/
/*i.NEXT_PAYMENT,*//*i.PAYMENT_CODE,*//*i.RES_FIELD,*//*i.PAYMENT_PURPOSE,*//*i.KBK,*//*i.OKATO,*//*i.PAYMENT_REASON,*/
/*i.PAY_TILL,*//*i.DEMAND_NO,*//*i.DEMAND_DATE,*//*i.PAYMENT_TYPE,*//*i.PORUCH_NO_FCURR,*//*i.PORUCH_DATE_FCURR,*//*i.ACCT_NO_FCURR,*/
/*i.DOC_STATUS,*//*i.REF_CLIENT,*//*i.BRANCH_CLIENT,*/
--,(select g.name from guides g where g.type_doc=5386 and g.code not in 'FORM_STORAGE' and num1=1 and g.code=i.ERR_CODE) G5386
,(select bank_fullname from MBANK.BANKS where mfo_depart=i.BIK_PAYERS_BANK) BANK_NAME
-- UPDATE
from inkp_staging i 
where i.date_load BETWEEN --trunc(sysdate)-10
                    TO_DATE ('20200225', 'yyyymmdd')
                    AND trunc(sysdate) 
                    --and TO_DATE ('20190326', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
and exists (select 1 from contracts a where (a.reference,a.branch) in 
                    (select contract,branch_contract from account where code = i.ACCOUNT_NO_PAYER) 
                            and type_doc in (590) and status=50 and sub_type=1
                            --and d_3363.contract_action_arrest_n (reference, branch)>0
                            )
--and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=i.id)                            

-- ����
select * from documents d where trunc(date_create)>=TO_DATE ('20200225', 'yyyymmdd')
--and type_doc in (226)
and type_doc not in (5099)
--and exists (select 1 from contracts a where (a.reference,a.branch) in 
--                    (select contract,branch_contract from account where date_open>=TO_DATE ('20200225', 'yyyymmdd') and 
--                    close_date is null and code = d.PAYERS_ACCOUNT and header = paccount.HEADER_ACCOUNT(d.PAYERS_ACCOUNT)) 
--                            and type_doc in (590) and status=50 and sub_type=1
--                            --and d_3363.contract_action_arrest_n (reference, branch)>0
--                            )
and d.PAYERS_ACCOUNT in (select c.account 
                        from contracts c
                        where type_doc = 590
                        and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                        and status=50
                        and sub_type in (1)
                        and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)
--and not exists(select null from zyx_store where oper='MONITOR_MB_WAY24' and num1=d.reference)                        

union all
select * from archive d where trunc(date_create)>=TO_DATE ('20200225', 'yyyymmdd')
and type_doc in (226)
--and exists (select 1 from contracts a where (a.reference,a.branch) in 
--                    (select contract,branch_contract from account where date_open>=TO_DATE ('20200225', 'yyyymmdd') and 
--                    close_date is null and code = d.PAYERS_ACCOUNT and header = paccount.HEADER_ACCOUNT(d.PAYERS_ACCOUNT)) 
--                            and type_doc in (590) and status=50 and sub_type=1
--                            --and d_3363.contract_action_arrest_n (reference, branch)>0
--                            )
and d.PAYERS_ACCOUNT in (select c.account 
                        from contracts c
                        where type_doc = 590
                        and date_open>=TO_DATE ('20200225', 'yyyymmdd')--trunc(sysdate)-100
                        and status=50
                        and sub_type in (1)
                        and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null)                        
                        