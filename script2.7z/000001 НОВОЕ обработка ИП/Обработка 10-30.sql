select * from documents d
where 
--date_work>=trunc(sysdate)-10
trunc(date_create)>=trunc(sysdate)-10
and 
type_doc=226 
--and status=30
--and exists(select null from contracts where account=d.payers_account and type_doc=590
--                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
--                and sub_type=0
--                )
and nvl(related,0)=0 
and nvl(refer_from,0)=0 
--and UNIVERSE.VARIABLE_DOC(reference,branch,'IP_SKS')=1 -- ��� �����������
and exists(select null from v_variable_documents where reference=d.reference and branch=d.branch and name in ('INKP_REF'))--,'FSSP_DOC_ID'))

and exists(select null from journal where docnum=d.reference and branch=d.branch)
and exists(select null from v_documents where d.reference in (related,refer_from) and type_doc=1)





select * from contracts 
where account in (select payers_account from v_documents where reference=3994800412)
 
select * from variable_contracts where (reference,branch) in (
    select reference,branch from contracts where account in (select payers_account from v_documents where reference=3994801582))


select * from collector_contracts where (reference,branch) in (
    select reference,branch from contracts where account in (select payers_account from v_documents where reference=3994800412)
    )
--and docnum = 3802683762

--======= DOCUMENTS ARCHIVE
select --rowid,
doc.* from v_documents doc where  reference in (3994800572)--3994800412)
--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (3994800572)--3994800412)
or related in (3994800572)--3994800412)

select doc.* from v_documents doc where  reference in (3802683762,3787886411)
--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (3802683762,3787886411)
or related in (3802683762,3787886411)

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (262081605))--,3804715684,3804715227))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in (4128158520)

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=3802683762


select * from mbank_audit.audit_table where reference=


select rowid,d.* from documents d where reference=262079156

select rowid,
doc.summa SumK2,p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
doc.* from documents doc where  reference in (4146510689)--3994800412)
--union all

select rowid,doc.* from archive doc where reference in (4146510689)
or refer_from in (4146510689)--3994800412)
or related in (4146510689)--3994800412)

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (3994504772))
and name not in ('COMPDOC_STATUS','DATEPLAT','KBK','OKATO','PAYERS_KPP','PAYMENT_ID','RECEIVERS_KPP','ROLLBACKTOEMITENT','TAX_DOCNUMBER','TAX_MEMO','TAX_PERIOD') 

select p_k2.Get_Rest_K2(3994801582, 235) from dual


--DISTR
select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('262080195')
order by id desc


--1 eid.distrib_features
--select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
select distinct(tran_id) from eid.distrib_features a                                                         --����� �� reference ���������
where --task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and 
value in (--'3804715641',
--'3804715684',
'87200340','4150472719','4146510689'
--'3804715227'
)--76002801')
--and 
--tran_id in (28061776)

--2 eid.distrib_transactions
select t.*, rowid from eid.distrib_transactions t       --�������������� ������ ������ �� ran_id ��� ����������� ��������  
where --task_kind='M_FILIAL' and 
tran_id in  (270967443,272532175)
order by tran_id,run_order                                                        --� ��������� ������ ������� - ����������� �������� � DONE =1


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where --task_kind in ('IP_LOCK','E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
--and 
tran_id in (272072315)


select rowid,a.* from eid.distrib_features a                                                         --����� �� reference ���������
where task_kind in ('IP_LOCK')--,'E_INKP')
--name = 'REFERENCE' and 
--and value in ('3802683762')--76002801')
--and tran_id in (262215242)
or
