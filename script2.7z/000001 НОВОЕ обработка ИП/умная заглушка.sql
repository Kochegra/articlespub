select rowid,a.* from zyx_store a where oper in ('INTGR_MB_WAY24','#INTGR_MB_WAY24')

insert into zyx_store (OPER,num1,num2)
values ('INTGR_MB_WAY24',100,0)
