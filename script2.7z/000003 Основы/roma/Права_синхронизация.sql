--������������� ����
begin
--������� ������ �����
  for rec in (select * from zyx_excel where a = 'DELETE JOBS_RIGHTS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--��������� ����������� �����
  for rec in (select * from zyx_excel where a = 'INSERT JOBS_RIGHTS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--������� ������ ���������
  for rec in (select * from zyx_excel where a = 'DELETE USER_PARAMETERS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
--��������� ����������� ��������
  for rec in (select * from zyx_excel where a = 'INSERT USER_PARAMETERS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
  --������� ������ ��������� �� ����
  for rec in (select * from zyx_excel where a = 'DELETE JOB_PARAM_VALUES') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
--��������� ����������� �������� �� ����
  for rec in (select * from zyx_excel where a = 'INSERT JOB_PARAM_VALUES') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
  
   dbms_output.put_line('FINISH ');
end;
/
--���������� ����� ����
begin
--����
  for rec in (select * from zyx_excel where a = 'NEW JOBS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--�����
  for rec in (select * from zyx_excel where a = 'NEW JOBS_RIGHTS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--���������
  for rec in (select * from zyx_excel where a = 'NEW USER_PARAMETERS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--�������� ���������� �� ���������
  for rec in (select * from zyx_excel where a = 'NEW JOB_PARAM_VALUES') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;  
  dbms_output.put_line('FINISH ');
end;  

/

select * from zyx_excel where a = 'DELETE JOBS_RIGHTS'

delete zyx_excel

delete jobs_rights where job_id = 35 and object_id = 2205 and code = 5 and operation = 0 and nvl(rights,-1379) = 4294967294

select * from jobs_rights where job_id = 35 and object_id = 2205

select * from Jobs where job_id = 31465


select * from zyx_excel where a = 'INSERT JOBS_RIGHTS' 

insert into jobs_rights(job_id,object_id,code,operation,rights) values(35,2205,5,0,-2)

select * from jobs_rights where job_id = 35 and object_id = 2205 

delete user_parameters where depart_id = 35 and name = 'DIASOFT_HESH'

select * from zyx_excel where a = 'DELETE USER_PARAMETERS' 

select * from users where user_id = 955012986 

select * from 

--����������
select (select count(*) from users@nsibirsk where job = j.job_id) c,j.* from jobs j where job_id in (select distinct b from zyx_jobvtb z where K >= '0' and B > '0')
and exists (select null from jobs@nsibirsk where job_id = j.job_id)

  commit;
  rollback;
  alter session close database link khabarovsk
 /
 
 
select * from job_param_values jpv 
where not exists (select null from job_param_values@khabarovsk where job_id = jpv.job_id and id = jpv.id and value = jpv.value and activated <= jpv.activated)
/ 
 ----------------
 --������ ��� ������������� ���� �� ���� ����
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            and g.num1 = 405
            )
 loop
   jb := '31064'; --������ id ����� �� main 
   n := '';
   begin
  --������ ������ ������ 
   sq := 'delete zyx_excel@'||i.value||' z where substr(z.A,1,6) in (''DELETE'',''INSERT'')'; 
   execute immediate sq;
   commit;
   --��������� ������ �� �������� ������ ���� 
   sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''DELETE JOBS_RIGHTS'',''delete jobs_rights where job_id =''||jr.job_id||'' and object_id = ''||jr.object_id||'' and code = ''||jr.code||'' and operation = ''||jr.operation||'' and nvl(rights,-1379) = ''||nvl(jr.rights,-1379)
 from jobs_rights@'||i.value||' jr where job_id in  ('||jb||') 
and not exists (select null from jobs_rights where job_id = jr.job_id and object_id = jr.object_id and code = jr.code and operation = jr.operation and nvl(rights,-1379) = nvl(jr.rights,-1379))';
   execute immediate sq;
   commit;
   dbms_output.put_line('1 '||sq);
--��������� ������ �� ���������� ���� 
 sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''INSERT JOBS_RIGHTS'',''insert into jobs_rights(job_id,object_id,code,operation,rights) values(''||jr.job_id||'',''||jr.object_id||'',''||jr.code||'',''||jr.operation||'',''||nvl(to_char(jr.rights),''NULL'')||'')''
 from jobs_rights jr where job_id in ('||jb||') 
 and not exists (select null from jobs_rights@'||i.value||' where job_id = jr.job_id and object_id = jr.object_id and code = jr.code and operation = jr.operation and nvl(rights,-1379) = nvl(jr.rights,-1379))';
   execute immediate sq;
   commit;
 dbms_output.put_line('2 '||sq);
sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''DELETE USER_PARAMETERS'',''delete user_parameters where depart_id = ''||up.depart_id||'' and name = ''''''||up.name||''''''''
 from user_parameters@'||i.value||' up where depart_id in ('||jb||')   
and not exists (select null from user_parameters where depart_id = up.depart_id and name = up.name)';
   execute immediate sq;   
   commit;
   dbms_output.put_line('3 '||sq);
sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''INSERT USER_PARAMETERS'',''insert into user_parameters(depart_id,name) values(''||up.depart_id||'',''''''||up.name||'''''')''
 from user_parameters up where depart_id in ('||jb||') and not exists (select null from user_parameters@'||i.value||' where depart_id = up.depart_id and name = up.name)';
  execute immediate sq;
   commit;

   sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''DELETE JOB_PARAM_VALUES'',''delete job_param_values where job_id = ''||jpv.job_id||'' and id = ''||jpv.id||'' and activated = ''||jpv.activated   
                                         from job_param_values@'||i.value||' jpv where job_id in ('||jb||') and not exists (select null from job_param_values where job_id = jpv.job_id and id = jpv.id and activated >= jpv.activated)';
     execute immediate sq;
   commit;
    dbms_output.put_line('5 '||sq);
 
    sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''INSERT JOB_PARAM_VALUES'',''insert into job_param_values(id,job_id,value,activated) values(''||jpv.id||'',''||jpv.job_id||'',''''''||jpv.value||'''''',to_date(''''''||to_char(jpv.activated,''dd.mm.yyyy'')||'''''',''''dd.mm.yyyy''''))'' 
                                       from job_param_values jpv where job_id in ('||jb||') and jpv.activated = (select max(activated) from job_param_values where job_id = jpv.job_id and id = jpv.id)
                                      and not exists (select null from job_param_values@'||i.value||' where job_id = jpv.job_id and id = jpv.id and activated = jpv.activated)' ;
  execute immediate sq;
   commit;
    dbms_output.put_line('6 '||sq);
    
   exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  dbms_output.put_line(i.value||'>> ���-�� >> '||n);
  commit;
  rollback;
  dbms_session.close_database_link(i.value);
  end loop;
end;
/


--������ ��� ���������� ����� ����
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
 j_cnt number; 
begin
  for i in  (--select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all 
            --select server_address value,s.name from subdepartments s where S.ID = 191
            select 'DSS' value,s.name from subdepartments s where S.ID = 191
            --and g.num1 = 47
            )
 loop
   jb := '31465'; --������ id ����� �� main
   j_cnt := 1; --���-�� id ��� ���������� 
   n := '';
   begin
  --������ ������ ������ 
   sq := 'delete zyx_excel@'||i.value||' z where substr(z.A,1,3) in (''NEW'')'; 
   execute immediate sq;
   commit;

   sq := 'select count(*) from jobs where job_id in ('||jb||')';
   execute immediate sq into n;
   commit;

 --/*  
   if n <> to_char(j_cnt) then
     dbms_output.put_line(i.value||'>> �� ������������� ���-�� ����������� �����');
   else
     sq :=  'insert into zyx_excel@'||i.value||'(a,b) select ''NEW JOBS'',''insert into jobs(JOB,JOB_ID,PARENT) values(''''''||j.JOB||'''''',''||j.JOB_ID||'',''||j.PARENT||'')'' 
                 from jobs j where job_id in ('||jb||') and not exists (select null from jobs@'||i.value||' where job_id = j.job_id)';        
     execute immediate sq;
     commit;
     dbms_output.put_line('1 '||sq);
     sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''NEW JOBS_RIGHTS'',''insert into jobs_rights(job_id,object_id,code,operation,rights) values(''||jr.job_id||'',''||jr.object_id||'',''||jr.code||'',''||jr.operation||'',''||nvl(to_char(jr.rights),''NULL'')||'')''
                  from jobs_rights jr where job_id in ('||jb||')';
     execute immediate sq;   
     commit;
     dbms_output.put_line('2 '||sq);
     sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''NEW USER_PARAMETERS'',''insert into user_parameters(depart_id,name) values(''||up.depart_id||'',''''''||up.name||'''''')''
                 from user_parameters up where depart_id in ('||jb||')';
      execute immediate sq;
      commit;     
    dbms_output.put_line('3 '||sq);
     sq := 'insert into zyx_excel@'||i.value||'(a,b)
     
     select ''NEW JOB_PARAM_VALUES'',''insert into job_param_values(id,job_id,value,activated) values(''||jpv.id||'',''||jpv.job_id||'',''''''||jpv.value||'''''',to_date(''''''||to_char(jpv.activated,''dd.mm.yyyy'')||'''''',''''dd.mm.yyyy''''))'' 
                                       from job_param_values jpv where job_id in ('||jb||') and jpv.activated = (select max(activated) from job_param_values where job_id = jpv.job_id and id = jpv.id)';
      execute immediate sq;
      commit;     
    dbms_output.put_line('4 '||sq);                   
   end if;
--*/     
   exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  dbms_output.put_line(i.value||'>> ���-�� >> '||n);
  commit;
  rollback;
  dbms_session.close_database_link(i.value);
  end loop;
end;
/
