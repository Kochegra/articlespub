select
pkg_fil_user.get_copy_userinfo(user_id,subdepartment) userinfo
,PKG_FIL_USER.get_copy_departid(subdepartment) departid
,u.* from users_all u where 
--user_id = 48015620
tab_n = '426353'


select rowid,u.* from users u where user_name like '��������� �.%'
--subdepartment in (191385) 31175

--����� ������������ 
select b.* from boss_emp_all b where 1=1 and d_out > sysdate
--and instr(upper(:str),upper(l_name)) > 0 and instr(upper(:str),upper(f_name)) > 0
--and instr(upper(:str),upper(m_name)) > 0
--and dept_name_4 = '������ ���������� �����������������' 
--and tabn24 = '423834'
and tab_n = '423834'
/

--����� ������������ 
select u.*,b.* from boss_emp_all b, users_all u where d_out > sysdate
and u.tab_n(+) = b.tab_n 
and b.tab_n in ('3530')
/


select rowid,b.* from boss_emp_all b where 1=1  
--and d_upload > sysdate -1
--d_out = '29dec2018'
--and tab_n = '403291'
--tab_n = 329802
and d_modify > sysdate-1
 

--�������� ���� ���������� (�� MAIN) ����� ������� ��� BOSS - UPDATE_BOSS_TO_FILIAL
select * from boss_emp_all b
--update boss_emp_all b set d_out = '29dec2019', d_upload = null 
where d_out = '29dec2018' 
and exists (select null from users_all where tab_n = b.tab_n and job not in (30809))
--and l_name like '��������'

--402070 ��������	��������	����������

select * from boss_emp_all b where d_out = '29dec2018' 
and exists (select null from boss_emp_all where  PASSP_HASH = b.PASSP_HASH and d_out > b.d_out)
/

select * from boss_emp_all b where
d_modify > trunc(sysdate)
and tab_n not in (select tab_n from boss_emp_all@nnovg b where d_modify > trunc(sysdate))

 
PASSP_HASH = '3367190561'

select * from boss_emp_all
--update boss_emp_all set d_upload = null 
where 1=1 
and d_upload > trunc(sysdate) --and d_out < sysdate
--and d_in > sysdate-1000-- and d_in < sysdate-100
and tab_n not in (select tab_n from boss_emp_all@nnovg b where d_modify > trunc(sysdate))
--and PASSP_HASH = '3367190561'
/

select count(distinct 1)
      from boss_emp_all be
     where be.d_upload is null
       and rownum <= 1000;
/
select * from admin_audit where owner in (1006122 )
-- ,977627)
--and tablename = 'USERS'

select * from mbank_audit.admin_audit_archive where owner in (983292)
-- ,977627)
and tablename = 'USERS'
/

select * from jobs where parent = 788
/

--insert into users_rights (user_id,object_id,code,operation,rights)
select u.user_id,ur.object_id,ur.code,ur.operation,ur.rights from users u, users_rights ur where ur.user_id = 2025002092    
--and u.subdepartment = 405008 and u.job = 30880
and not exists (select null from jobs_rights where job_id = u.job and object_id = ur.object_id and code = ur.code)
and not exists (select null from users_rights where user_id = u.user_id and object_id = ur.object_id and code = ur.code)


--��������� ����� � ������ ��������
--insert into users_rights(user_id,object_id,code,operation,rights)
select * from (select distinct uu.user_id,tt.type_id object_id,tt.code,0 operation,(case when code in (4,5,6) then -1 else null end) rights from users uu 
,(select distinct type_id,code from types t start with type_id in (13000) --������ ��������
 connect by to_char(type_id) = prior manual) tt 
 where uu.params in ('0490123','1560032','0490070','1920754','1920978','1920788','1920745','305504',
'1040033','1040351','304921','306690','0710540','0710012','308021','0481019','0480143',
'3540183','3540002','0470076','0470205','0470404','1957','300067','5769','10394','16962','17429') --��������� ������������� 
 and exists (select null from all_users where username = uu.user_)
 ) t where 1=1 
and not exists (select null from users_rights where user_id = t.user_id and object_id = t.object_id and code = t.code)
and not exists (select null from jobs_rights jr, users u where u.user_id = t.user_id and u.job = jr.job_id and code = t.code AND object_id = t.object_id and jr.rights = t.rights)
/

--���������
--insert into user_param_values
select up.id,up.depart_id,u.user_id,'1',trunc(sysdate) from users u,user_parameters up 
where u.job = up.depart_id and u.user_id = 2025002092 
and not exists (select null from user_param_values upv where id = up.id and depart_id = up.depart_id and user_id = u.user_id and activated =
(select max(activated) from user_param_values where id = upv.id and depart_id = upv.depart_id and user_id = upv.user_id))

/

--��������� ���, ��� ���� �� ������������
--insert into user_param_values
select 
(select id from user_parameters where name = up.name and depart_id = u.job) id, 
u.job,u.user_id,upv.value,upv.activated 
,u.*,up.*,upv.*
 from users u, user_parameters up, user_param_values upv
where u.user_id = 1403 
and u.user_id = upv.user_id and upv.depart_id = up.depart_id and upv.id = up.id 
and upv.activated = (select max(activated) from user_param_values v, user_parameters p where p.id = v.id and p.depart_id = v.depart_id 
and v.user_id = upv.user_id and p.name = up.name)  
and not exists (select null from job_param_values v, types t where v.id = t.type_id and t.code = 14 and t.name = up.name and v.job_id = u.job and v.value = upv.value
 and activated = (select max(activated) from job_param_values where id = v.id and job_id = v.job_id))
and not exists (select null from user_param_values v where id = up.id and depart_id = u.job and user_id = u.user_id and activated =
(select max(activated) from user_param_values where id = v.id and depart_id = v.depart_id and user_id = v.user_id))
and up.name not in ('PASSWORD_EXPIRATION','���_���_������','LAST_LOGOUT','���_�_������')
and (select id from user_parameters where name = up.name and depart_id = u.job) is not null
/

--������ ������������� �����, ������� �� ����
--insert into users_rights_sup(user_id,object_id,code,operation,rights,id,branch,dt_act,act) 
select user_id,object_id,code,operation,rights,id,branch,sysdate,'DELETE' from
--delete 
users_rights ur where user_id = 2025002494 
and exists (select * from users u, jobs_rights jr where u.job = jr.job_id and u.user_id = ur.user_id and jr.code = ur.code and jr.object_id = ur.object_id and nvl(jr.rights,-1379) = nvl(ur.rights,-1379))    
/

select * from jobs_rights where job_id = 31175 and object_id = 777 

select * from users_rights where user_id = 2025002092  and object_id = 777 
/


--������������ �����������

--������������ ����������� ��������
select
nvl((select b.tab_n from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash
and bb.tab_n = u.params and bb.d_out < sysdate and b.d_out > sysdate and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate) 
),params) tt,
u.* from users u
--update users u set params = nvl((select b.tab_n from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash and bb.tab_n = u.params and bb.d_out < sysdate and b.d_out > sysdate and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate)),params)
where u.params <> '-9999'
and job not in (1,31445,30809) and subdepartment like mbfilid||'%'
and params in (select tab_n from boss_emp_all where d_out < sysdate)

/

--��� ���� ������������ ��������� �������
begin
  for r in (
  select distinct b.tab_n tab_new,b0.tab_n tab_old, u.user_id from users u, boss_emp_all b, boss_emp_all b0 where substr(b.tab_n,1,1) <> '-' and b.d_out > sysdate and b.d_modify > sysdate-30
             and substr(b0.tab_n,1,1) <> '-' and b0.d_out < sysdate and b0.d_modify > sysdate-30 and b0.passp_hash = b.passp_hash
             and u.params = b0.tab_n 
                )
  loop
    update users set params = r.tab_new where user_id = r.user_id and job in (select job_id from jobs where priority >= 0 and date_start < sysdate and nvl(date_finish,sysdate) > trunc(sysdate)); 
    commit;
  end loop;
end;
/


select * from users where job not in (30809) 
and params in ( 
select b0.tab_n from boss_emp_all b, boss_emp_all b0 where substr(b.tab_n,1,1) <> '-' and b.d_out > sysdate and b.d_modify > sysdate-30
and b0.passp_hash = b.passp_hash and b0.d_out < sysdate and b0.d_modify > sysdate-30 
) 

select job_id from jobs where priority >= 0 and date_start < sysdate and nvl(date_finish,sysdate) > trunc(sysdate)


/

select * from zyx_store where 
--oper='AUDIT_USER' and num1 = mbfilid and str1 = 'INSERT' 
oper='FIL_USERS'
/

--������������ ������ �������� ����������
--select trunc(dt_create,'Q'),sum(case when dt_out > trunc(dt_create,'Q') then 1 else 0 end),count(*) from ( 
select * from (
select nvl((select min(dt1) from zyx_store where oper='AUDIT_USER' and num1 = mbfilid and str1 = 'INSERT' and num2 = u.user_id),to_date('01.01.2010','dd.mm.yyyy')) dt_create
,nvl((select min(d_out) from boss_emp_all where tab_n = u.params),to_date('01.01.2000','dd.mm.yyyy')) dt_out
,u.* from users u where 
 instr(upper(u.user_name),'������') = 0 and u.user_ not in ('MT_MBANK','IT_AUDIT','REP_SRVR','MB','TK','SITE','WEB','RTO','NEW_AUDIT','NEW_ANKETA','TEST_CASSA','SMS','AUDIOTELE') and substr(user_,1,3) <> 'ADM' 
     and upper(substr(user_name,1,5)) <> '�����'  --����������� ������
and nvl(u.params,'-9999') <> '-9999') t
--group by trunc(dt_create,'Q') 
/

insert into zyx_store(OPER,TBL,num1,num2,dt1,str1)
(select 'AUDIT_USER',tablename,mbfilid,owner,time,memo from mbank_audit.admin_audit where tablename = 'USERS' and memo = 'INSERT' and fieldname = 'USER_ID');

--��������, �������� ������ < 5 �����
insert into zyx_store(OPER,TBL,num1,num2,dt1,str1)
(select 'AUDIT_USER',tablename,mbfilid,owner,time,memo from mbank_audit.admin_audit_archive where tablename = 'USERS' and memo = 'INSERT' and fieldname = 'USER_ID');

insert into zyx_store(OPER,TBL,num1,num2,dt1,str1)
with tt1 as (select distinct trunc(add_months('01jul2016',level-1),'Q') dt from dual connect by level < 31),
tt2 as (select nvl((select min(dt1) from zyx_store where oper='AUDIT_USER' and num1 = mbfilid and str1 = 'INSERT' and num2 = u.user_id),to_date('01.01.2010','dd.mm.yyyy')) dt_cr
,nvl((select min(d_out) from boss_emp_all where tab_n = u.params),to_date('01.01.2000','dd.mm.yyyy')) dt_out
,u.* from users u where instr(upper(u.user_name),'������') = 0 and u.user_ not in ('MT_MBANK','IT_AUDIT','REP_SRVR','MB','TK','SITE','WEB','RTO','NEW_AUDIT','NEW_ANKETA','TEST_CASSA','SMS','AUDIOTELE') and substr(user_,1,3) <> 'ADM' 
     and upper(substr(user_name,1,5)) <> '�����'  --����������� ������
and nvl(u.params,'-9999') <> '-9999')
select 'FIL_USERS','USERS',mbfilid,count(*),tt1.dt,'create user statistic' from tt1, tt2
where tt2.dt_cr < tt1.dt and tt2.dt_out >= tt1.dt
group by tt1.dt;
/ 

insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@khabarovsk z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@nsibirsk z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@ekburg z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@nnovg z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@spburg z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@rostov z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@stavropol z where oper = 'FIL_USERS' and tbl = 'USERS';
insert into zyx_store(OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod) select OPER,TBL,NUM1,NUM2,dt1,str1,dt_mod from zyx_store@vtbmain z where oper = 'FIL_USERS' and tbl = 'USERS';
/

select rowid,z.*
--select num1 "������",dt1 "�� ����",num2 "��������"  
from zyx_store z where oper = 'FIL_USERS' and tbl = 'USERS'
and dt_mod = (select max(dt_mod) from zyx_store where oper = z.oper and tbl = z.tbl and num1 = z.num1 and dt1 = z.dt1)   
--and dt1 = '01jan2019'
/

select dt1 "�� ����",sum(num2) "��������"  
from zyx_store z where oper = 'FIL_USERS' and tbl = 'USERS'
and dt_mod = (select max(dt_mod) from zyx_store where oper = z.oper and tbl = z.tbl and num1 = z.num1 and dt1 = z.dt1) 
group by dt1
/

select rowid,z.* from zyx_store z where (num1,dt1,dt_mod)  in 
(select num1,dt1,dt_mod from zyx_store where oper = 'FIL_USERS' and tbl = 'USERS'
and dt_mod = (select max(dt_mod) from zyx_store where oper = z.oper and tbl = z.tbl and num1 = z.num1 and dt1 = z.dt1)   
group by num1,dt1,dt_mod
having count(*) > 1
) and oper = 'FIL_USERS' and tbl = 'USERS'