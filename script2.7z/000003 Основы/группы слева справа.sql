select * from groups where group_id in (75005233,1000248,1000250,1000249) --group_ like '%���_VIP%'

select 
(select user_name from users where user_id=a.user_id) aa,
a.* from GROUP_MEMBERSHIP a where group_id=1000248 --user_id in (61721,61285) --group_id = 32358

select 
(select user_name from users where user_id=a.object_id) aa,
a.* from GROUPs_RIGHTs a where group_id in (75005233,1000248,1000250,1000249) and object_id in (61721,61285)


select * from users where user_name like '%402%'

--��������� ������ ������
--insert into GROUP_MEMBERSHIP(group_id,user_id)
select 1000248,user_id--,user_name
 from users u where user_id=61721 --job = 31195 --and user_id = 4443-- exists (select null from users@nnovg where job = u.job and params = u.params)
 and not exists (select null from GROUP_MEMBERSHIP where user_id = u.user_id and group_id = 32358) 


insert into groups_rights(group_id,object_id,code,rights) 
select 1000248,user_id,-1,0 from users u where --user_id=61285 --job = 31195 
 --and 
 not exists (select null from groups_rights where object_id = u.user_id and group_id = 1000248) 
