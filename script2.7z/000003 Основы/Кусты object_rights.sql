 SELECT src.item_id,
         src.obj_type,
         NVL (src.used, 1) AS used,
         CASE WHEN src.obj_type = -4 THEN g.group_ ELSE s.name END AS name
    FROM object_rights src
         LEFT JOIN groups g ON g.GROUP_ID = src.obj_id AND src.obj_type = -4
         LEFT JOIN subdepartments s ON s.id = src.obj_id AND src.obj_type = -3
   WHERE src.id_type = -1 AND src.id = 1002235 --987761
ORDER BY name

--insert into object_rights(ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS) 
select 987761,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS
FROM object_rights where id in (1003776)--,1002235)

select * FROM object_rights where id in (1003776)--987761)

select * from users where user_name like '��������%'