(select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) waycnt,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'WAY4_DOCEXTID',null) WAY4_DOCEXTID,
UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'INKP_REF',null) INKP_REF,
