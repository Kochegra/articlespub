--PACCOUNT
paccount.keyaccount(g.name,'411')
paccount.HEADER_ACCOUNT
and currency = substr(g.name,6,3)
substr(g_cnt.name,1,8)||'_'||substr(g_cnt.name,10,11)=substr(rec.name,1,8)||'_'||substr(rec.name,10,11) -- ����



--PLEDGER
-- ������ �� �����
l_Saldo := - pledger.SALDO('A', l_contracts(i).Account, l_contracts(i).Currency, SystemDate);

--PKG_INKP
round((- pkg_inkp.Saldo(id, paccount.HEADER_ACCOUNT(account_no_payer), account_no_payer, substr(account_no_payer,6,3), Sysdate))
                    *pledger.WCOURSE(substr(account_no_payer,6,3), SysDate),2) sal,