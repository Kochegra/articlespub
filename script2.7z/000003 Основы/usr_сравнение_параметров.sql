select * from users where --user_name like '��������%'
user_id in (982038,978042)

select * from users where (job,subdepartment) in (select job,subdepartment from users where user_id=982038) and params<>-9999
order by user_name 


-- ���������� ��������� 2-� �������������
with usr1 as (select * from users where user_id in (982038)),
     usr2 as (select * from users where user_id in (978042))
select up.name name,upv.value value,to_char(upv.ACTIVATED,'dd.mm.yyyy') act,
user2.name name2,user2.value value2,
to_char(user2.activated,'dd.mm.yyyy') act2
from user_param_values upv,user_parameters up
inner join (
select up2.name name,upv2.value value,upv2.ACTIVATED activated
from user_param_values upv2,user_parameters up2
where upv2.user_id=(select user_id from usr2) and upv2.depart_id=(select job from usr2) and up2.depart_id=(select job from usr2) and upv2.id=up2.id
and upv2.activated =
(SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr2)
AND ID = upv2.ID AND depart_id = (select job from usr2))) user2
on up.name=user2.name
where upv.user_id=(select user_id from usr1) and upv.depart_id=(select job from usr1) and up.depart_id=(select job from usr1) and upv.id=up.id
 and upv.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr1)
AND ID = upv.ID AND depart_id = (select job from usr1))
union all
select up3.name name,upv3.value value,to_char(upv3.ACTIVATED,'dd.mm.yyyy') act,'' name2,'' value2,'' act2
 from user_param_values upv3,user_parameters up3
 where upv3.user_id=(select user_id from usr1) and upv3.depart_id=(select job from usr1) and up3.depart_id=(select job from usr1) and upv3.id=up3.id
 and upv3.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr1)
 AND ID = upv3.ID AND depart_id = (select job from usr1))
 and up3.name not in (
 select up.name
 from user_param_values upv,user_parameters up
 inner join (
 select up2.name name,upv2.value value,upv2.ACTIVATED activated
 from user_param_values upv2,user_parameters up2
 where upv2.user_id=(select user_id from usr2) and upv2.depart_id=(select job from usr2) and up2.depart_id=(select job from usr2) and upv2.id=up2.id
 and upv2.activated =
(SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr2)
 AND ID = upv2.ID AND depart_id = (select job from usr2))) user2
 on up.name=user2.name
 where upv.user_id=(select user_id from usr1) and upv.depart_id=(select job from usr1) and up.depart_id=(select job from usr1) and upv.id=up.id
 and upv.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr1)
 AND ID = upv.ID AND depart_id = (select job from usr1)))
 union all
 select '' name,'' value,'' act,
 up4.name name2,upv4.value value2,to_char(upv4.ACTIVATED,'dd.mm.yyyy') act2
 from user_param_values upv4,user_parameters up4
 where upv4.user_id=(select user_id from usr2) and upv4.depart_id=(select job from usr2) and up4.depart_id=(select job from usr2) and upv4.id=up4.id
 and upv4.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr2)
 AND ID = upv4.ID AND depart_id = (select job from usr2))
 and up4.name not in (
 select up5.name 
 from user_param_values upv5,user_parameters up5
 inner join (
 select up6.name name,upv6.value value,upv6.ACTIVATED activated
 from user_param_values upv6,user_parameters up6
 where upv6.user_id=(select user_id from usr1) and upv6.depart_id=(select job from usr1) and up6.depart_id=(select job from usr1) and upv6.id=up6.id
 and upv6.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr1)
 AND ID = upv6.ID AND depart_id = (select job from usr1))) user3
 on up5.name=user3.name
 where upv5.user_id=(select user_id from usr2) and upv5.depart_id=(select job from usr2) and up5.depart_id=(select job from usr2) and upv5.id=up5.id
 and upv5.activated =
 (SELECT MAX (activated) FROM user_param_values  WHERE user_id = (select user_id from usr2)
 AND ID = upv5.ID AND depart_id = (select job from usr2)))
 order by 1, 4
 