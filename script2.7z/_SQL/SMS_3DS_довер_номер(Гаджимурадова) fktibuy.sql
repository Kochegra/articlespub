select * from tmp_yag_cardlist 
where (pk,phone) not in 
(
select * from tmp_yag_cardlist t --ptools_string.CLEARPHONE(ec.contact) phone 
where exists (select 1 from eid.eid_products p, eid.eid_contacts ec where ec.EID = p.eid and EC.TYPE_CONTACT = 5 
and ec.status = 1 and p.account = t.pk)
and T.PK not in ('2200650309886667','2200650310200163','2200650322385119')
)
and PK not in ('2200650309886667','2200650310200163','2200650322385119')

--���������� ������ � �������
 select * from tmp_yag_cardlist
-- where phone is null

--��������� ������ �������� �� ���������� �������
--update tmp_yag_cardlist t set phone = 
-- (select ptools_string.CLEARPHONE(ec.contact) phone from eid.eid_products p, eid.eid_contacts ec where ec.EID = p.eid and EC.TYPE_CONTACT = 5 and ec.status = 1 and p.account = t.pk)
-- where phone is null 

--������� ������ ������
--delete tmp_yag_cardlist where phone is null

--���������� ������ ��������� 
--update tmp_yag_cardlist t set phone = ptools_string.CLEARPHONE(phone)

/
--���������� �����
declare 
  -- Local variables here
  i integer;
begin
  -- Test statements here
  for rec_pr in (select l.phone, pr.eid from tmp_yag_cardlist l, eid.eid_products pr where pr.account = l.pk)
  loop
    :st := eid.p_eid_tools.SetTrustMobile(nEID             => rec_pr.eid,
                                   sTrustMobile     => rec_pr.phone,
                                   sCheckTrust      => '[EID=1]',
                                  sChannel         => 7,
                                   dDATE_MODIFY     => sysdate,
                                   sOWNER_MODIFY    => '������������� �������',
                                   nSUBD_MODIFY     => 191,
                                   nCommit          => 1,
                                   nOWNER_MODIFY_ID => 1403,
                                   nWEB             => 1,
                                   nMobileBank      => 1);
   end loop;                                
  end;
/

-- ����������� ���
declare
  v_ss varchar2(2000);
  v_operId varchar2(100);
begin  
  globals_ext.short_init_admin(mbgoid);
  for crd in (
    select c.pk acc, ptools_string.CLEARPHONE(c.phone) phone, p.eid
    from tmp_yag_cardlist c, eid.eid_products p
    where p.account = c.pk  
    and not exists (select null from SMS_LOADED sl where card = c.pk AND FILE_NAME = 'ONLINE_OPEN' 
and reg_date = (select max(reg_date) from SMS_LOADED where card=sl.card and FILE_NAME in ('ONLINE_OPEN','ONLINE_CLOSE'))) 
  ) loop
    v_operId := null;
    v_ss := psms_daily_eid.openonline(trim(crd.acc), crd.phone, null, null, 0, 0, null, null, v_operId);
    if v_ss is not null then
      dbms_output.put_line('v_operId=[' || v_operId || ']; ' || substr('ss >> ' || v_ss, 1, 255));
    end if;
    commit;
  end loop;
end;

/
--����������� 3ds
declare 
  -- Local variables here
  i integer;
begin
  -- Test statements here
  for rec_pr in (select l.phone, pr.eid, pr.account from tmp_yag_cardlist l, eid.eid_products pr where pr.account = l.pk)
  loop
    :st := f_3dsotp_add(rec_pr.account, rec_pr.phone);
    commit;
  end loop;  
  end;
/

-------------------------------------------------------------------------------
--���������� ���
declare
  v_ss varchar2(2000);
  v_operId varchar2(100);
begin  
  globals_ext.short_init_admin(mbgoid);
  for crd in (
     select c.pk acc, ptools_string.CLEARPHONE(ec.contact) phone, p.eid, ec.contact  
        from tmp_yag_cardlist c, eid.eid_products p, eid.eid_contacts ec  
     where p.account = c.pk and ec.EID = p.eid and EC.TYPE_CONTACT = 5 and ec.status = 1  
      and c.pk <> '2200650312623362' 
  ) loop
    v_operId := null;
    v_ss := psms_daily_eid.closeonline(trim(crd.acc), crd.phone, 0, 0, null, crd.eid, v_operId);    
    if v_ss is not null then
      dbms_output.put_line('crd.acc = '||crd.acc||'; v_operId=[' || v_operId || ']; ' || substr('ss >> ' || v_ss, 1, 255));
    end if;
    commit;
  end loop;
end;
/

-- �� �������� �����
declare
  v_ss varchar2(2000);
  v_operId varchar2(100);
begin  
  globals_ext.short_init_admin(mbgoid);
  for crd in (
     select p.account acc, ptools_string.CLEARPHONE(ec.contact) phone, p.eid, ec.contact  
        from eid.eid_products p, eid.eid_contacts ec  
     where ec.EID = p.eid and EC.TYPE_CONTACT = 5 and ec.status = 1
     and p.account in ('2200650312623362') --����� ����
  ) loop
    v_operId := null;
    v_ss := psms_daily_eid.closeonline(trim(crd.acc), crd.phone, 0, 0, null, crd.eid, v_operId);    
    if v_ss is not null then
      dbms_output.put_line('crd.acc = '||crd.acc||'; v_operId=[' || v_operId || ']; ' || substr('ss >> ' || v_ss, 1, 255));
    end if;
    commit;
  end loop;
end;

--���������� 3ds
declare 
  -- Local variables here
  i integer;
begin
  -- Test statements here
  for rec_pr in (select l.phone, pr.eid, pr.account from tmp_yag_cardlist l, eid.eid_products pr where pr.account = l.pk)
  loop
    :st := f_3dsotp_add(rec_pr.account);
    commit;
  end loop;  
  end;
/
--�� ����� �����
begin
 dbms_output.putline(f_3dsotp_add('5577000011112222'));
end 