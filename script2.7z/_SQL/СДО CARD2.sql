select * from zyx_cont_cb

select --distinct status
rowid,a.* 
from eid.eid_card a where 
pk in (select a from zyx_cont_cb)
--exists (select a from zyx_cont_cb)
and status=61

--update eid.eid_card a set status = 202, card_status = 202
select --distinct status
rowid,a.* 
from eid.eid_card a 
where --pk in ()
--and status=61
a.pk in (select aa.pk from eid.eid_card aa where aa.pk in (select a from zyx_cont_cb) and aa.status=61)


select rowid,a.* from eid.eid_card_collector a where --pk in ('2200650354894699')
a.pk in (select aa.pk from eid.eid_card aa where aa.pk in (select a from zyx_cont_cb))-- and aa.status=61)
and a.name in ('CARD_STATUS') and a.value='61'
--and work_date>='01aug2017'
and refer_obj=75564943
order by work_date


select z.a from zyx_cont_cb z where not exists (select 1 from eid.eid_card a where pk in (z.a))




