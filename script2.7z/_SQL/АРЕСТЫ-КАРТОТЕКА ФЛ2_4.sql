select * from operation where code in (730001,730002,730003,730004,730005,730006,730007,730008)

16782641 348578

----CF_DOCS
select rowid,a.* from EID.EID_CF_DOCS a where reference=216338

select rowid,a.* from MBANK.CF_DOCS a where eid=16782641 --eid=22017583 --reference=22017583


select distinct name, cardnum
                     from cf_card_collector
                     where reference = 348578
                       and branch    = 191
                       and name not like 'K+%'

730001    4291580156713829
730001    4291580158160805
730002    4291580156713829
730002    4291580158160805
730004    4291580156713829
730004    4291580158160805
730008    4291580156713829
730008    4291580158160805

--l_CollectorCardEI := 
select pcf.Saldo_Card_CollectorW('730001', 348578, 191, '4291580156713829' , SysDate) from dual 

select pcf.Saldo_Card_CollectorW('730001', 348578, 191, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730002', 348578, 191, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730002', 348578, 191, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 348578, 191, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 348578, 191, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 348578, 191, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 348578, 191, '4291580158160805' , SysDate) from dual

--l_CollectorCard   := 
select pcf.Saldo_Card_Collector ('730001', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730001', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730002', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730002', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730004', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730004', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730008', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730008', 191, 348578, '4291580158160805' , SysDate) from dual





BEGIN
   :FUNCTION_RESULT :=
      "MBANK"."PCF_TOOLS"."IS_CORRECT" (P_REFERENCE   => :P_REFERENCE,
                                        P_BRANCH      => :P_BRANCH);
END;

348578

