select * from  
(select distinct eid, count(eid) as cnt from eid.eid_products a 
where 
date_open >= trunc(sysdate) - 600
and pr_status in (50,60)
and pr_type=3
group by eid)
where cnt>=5
order by cnt