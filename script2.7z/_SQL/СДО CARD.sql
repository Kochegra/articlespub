select rowid,a.* from zyx_cont_cb a

select rowid,aaa.* from eid.eid_card_oper aaa 
where 
trim(aaa.card_number) in (select a from zyx_cont_cb) 
--order by date_modify,id 


select * from eid.eid_card_collector 
where 
pk in (select a from zyx_cont_cb where a='5298840003078259')
order by work_date


SELECT tab1.*, tab2.a   
FROM eid.eid_card_collector tab1  
INNER JOIN zyx_cont_cb tab2 ON tab1.pk = trim(tab2.a)  
WHERE --trim(tab2.h) is not null
    --AND 
    not  EXISTS(SELECT 1 FROM eid.eid_card_collector a
            WHERE tab1.pk = a.pk
                AND tab1.work_date < a.work_date)
order by 1



2554691399


--delete
select * 
from eid.eid_card_collector 
where 
pk in (select trim(a) from zyx_cont_cb)
and refer_obj=2554691399
order by work_date



--update eid.eid_card aaa set status=202,card_status=202,date_destroy=add_months(trunc(date_destroy),3) -- ��������� 3 ������
select rowid,aaa.* from eid.eid_card aaa 
where 
aaa.pk in (select a from zyx_cont_cb) 
--order by date_modify,id 



select add_months(trunc(sysdate),3) from dual






insert into zyx_cont_cb (a) values ('5282850128442742');
insert into zyx_cont_cb (a) values ('5282850198436632');
insert into zyx_cont_cb (a) values ('5282850254851435');
insert into zyx_cont_cb (a) values ('5282850258580691');
insert into zyx_cont_cb (a) values ('5282850382460091');
insert into zyx_cont_cb (a) values ('5282850386189357');
insert into zyx_cont_cb (a) values ('5282850520056561');
insert into zyx_cont_cb (a) values ('5282850734466986');
insert into zyx_cont_cb (a) values ('5282850953806623');
insert into zyx_cont_cb (a) values ('5282850995942857');
insert into zyx_cont_cb (a) values ('5282851069666000');
insert into zyx_cont_cb (a) values ('5282851080215316');
insert into zyx_cont_cb (a) values ('5282851196074706');
insert into zyx_cont_cb (a) values ('5282851340491228');
insert into zyx_cont_cb (a) values ('5282851410485126');
insert into zyx_cont_cb (a) values ('5282851471829147');
insert into zyx_cont_cb (a) values ('5282851675690246');
insert into zyx_cont_cb (a) values ('5282851686239561');
insert into zyx_cont_cb (a) values ('5282851802098941');
insert into zyx_cont_cb (a) values ('5282851946515479');
insert into zyx_cont_cb (a) values ('5282851950244727');
insert into zyx_cont_cb (a) values ('5282852016509368');
insert into zyx_cont_cb (a) values ('5282852077853382');
insert into zyx_cont_cb (a) values ('5282852142918061');
insert into zyx_cont_cb (a) values ('5282852165855109');
insert into zyx_cont_cb (a) values ('5282852200532820');
insert into zyx_cont_cb (a) values ('5282852464537994');
insert into zyx_cont_cb (a) values ('5282852552539712');
insert into zyx_cont_cb (a) values ('5282852622533604');
insert into zyx_cont_cb (a) values ('5282852683877635');
insert into zyx_cont_cb (a) values ('5282852748942309');
insert into zyx_cont_cb (a) values ('5282852771879352');
insert into zyx_cont_cb (a) values ('5282852810286320');
insert into zyx_cont_cb (a) values ('5282852944153537');
insert into zyx_cont_cb (a) values ('5282853014147433');
insert into zyx_cont_cb (a) values ('5282853070562236');
insert into zyx_cont_cb (a) values ('5282853140556135');
insert into zyx_cont_cb (a) values ('5282853162293211');
insert into zyx_cont_cb (a) values ('5282853228557856');
insert into zyx_cont_cb (a) values ('5282853289901878');
insert into zyx_cont_cb (a) values ('5282853328308853');
insert into zyx_cont_cb (a) values ('5282853462176066');
insert into zyx_cont_cb (a) values ('5282853550177786');
insert into zyx_cont_cb (a) values ('5282853676586480');
insert into zyx_cont_cb (a) values ('5282853746580372');
insert into zyx_cont_cb (a) values ('5282853764588208');
insert into zyx_cont_cb (a) values ('5282853895926111');
insert into zyx_cont_cb (a) values ('5282853930603832');
insert into zyx_cont_cb (a) values ('5282854068200300');
insert into zyx_cont_cb (a) values ('5282854156202028');
insert into zyx_cont_cb (a) values ('5282854226195913');
insert into zyx_cont_cb (a) values ('5282854370612440');
insert into zyx_cont_cb (a) values ('5282854412748673');
insert into zyx_cont_cb (a) values ('5282854501950362');
insert into zyx_cont_cb (a) values ('5282854536628082');
insert into zyx_cont_cb (a) values ('5282854547815850');
insert into zyx_cont_cb (a) values ('5282854674224546');
insert into zyx_cont_cb (a) values ('5282854762226270');
insert into zyx_cont_cb (a) values ('5282854888634969');
insert into zyx_cont_cb (a) values ('5282854930771207');
insert into zyx_cont_cb (a) values ('5282855142652325');
insert into zyx_cont_cb (a) values ('5282855150110836');
insert into zyx_cont_cb (a) values ('5282855153840090');
insert into zyx_cont_cb (a) values ('5282855223833984');
insert into zyx_cont_cb (a) values ('5282855280248795');
insert into zyx_cont_cb (a) values ('5282855350242686');
insert into zyx_cont_cb (a) values ('5282855438244407');
insert into zyx_cont_cb (a) values ('5282855456252233');
insert into zyx_cont_cb (a) values ('5282855564653108');
insert into zyx_cont_cb (a) values ('5282855624797168');
insert into zyx_cont_cb (a) values ('5282855625997122');
insert into zyx_cont_cb (a) values ('5282855748676561');
insert into zyx_cont_cb (a) values ('5282855886273031');
insert into zyx_cont_cb (a) values ('5282855956266923');
insert into zyx_cont_cb (a) values ('5282856044268657');
insert into zyx_cont_cb (a) values ('5282856100683450');
insert into zyx_cont_cb (a) values ('5282856104412716');
insert into zyx_cont_cb (a) values ('5282856170677341');
insert into zyx_cont_cb (a) values ('5282856365888588');
insert into zyx_cont_cb (a) values ('5282856435882470');
insert into zyx_cont_cb (a) values ('5282856492297273');
insert into zyx_cont_cb (a) values ('5282856562291172');
insert into zyx_cont_cb (a) values ('5282856650292892');
insert into zyx_cont_cb (a) values ('5282856710436950');
insert into zyx_cont_cb (a) values ('5282856776701594');
insert into zyx_cont_cb (a) values ('5282856838045618');
insert into zyx_cont_cb (a) values ('5282856841774873');
insert into zyx_cont_cb (a) values ('5282856903110289');
insert into zyx_cont_cb (a) values ('5282856926047336');
insert into zyx_cont_cb (a) values ('5282857041906711');
insert into zyx_cont_cb (a) values ('5282857098321525');
insert into zyx_cont_cb (a) values ('5282857168315415');
insert into zyx_cont_cb (a) values ('5282857256317133');
insert into zyx_cont_cb (a) values ('5282857382725837');
insert into zyx_cont_cb (a) values ('5282857444069851');
insert into zyx_cont_cb (a) values ('5282857532071579');
insert into zyx_cont_cb (a) values ('5282857647930966');
insert into zyx_cont_cb (a) values ('5282857704345769');
insert into zyx_cont_cb (a) values ('5282857774339650');
insert into zyx_cont_cb (a) values ('5282857876619959');
insert into zyx_cont_cb (a) values ('5282857988750072');
insert into zyx_cont_cb (a) values ('5282858050094100');
insert into zyx_cont_cb (a) values ('5282858253955206');
insert into zyx_cont_cb (a) values ('5282858310370019');
insert into zyx_cont_cb (a) values ('5282858436778707');
insert into zyx_cont_cb (a) values ('5282858594774324');
insert into zyx_cont_cb (a) values ('5282858652389080');
insert into zyx_cont_cb (a) values ('5282858690796064');
insert into zyx_cont_cb (a) values ('5282858698254579');
insert into zyx_cont_cb (a) values ('5282858701983834');
insert into zyx_cont_cb (a) values ('5282858789985552');
insert into zyx_cont_cb (a) values ('5282858859979444');
insert into zyx_cont_cb (a) values ('5282858916394256');
insert into zyx_cont_cb (a) values ('5282858986388147');
insert into zyx_cont_cb (a) values ('5282859042802956');
insert into zyx_cont_cb (a) values ('5282859174140860');
insert into zyx_cont_cb (a) values ('5282859296820308');
insert into zyx_cont_cb (a) values ('5282859308008074');
insert into zyx_cont_cb (a) values ('5282859610420215');
insert into zyx_cont_cb (a) values ('5282859787623625');
insert into zyx_cont_cb (a) values ('5282859826030592');
insert into zyx_cont_cb (a) values ('5282859914032328');
insert into zyx_cont_cb (a) values ('5282859984026218');
insert into zyx_cont_cb (a) values ('5298841959948206');
insert into zyx_cont_cb (a) values ('5298842565972440');
insert into zyx_cont_cb (a) values ('5298847932188919');
insert into zyx_cont_cb (a) values ('5298848206743397');
insert into zyx_cont_cb (a) values ('5298848411804463');
insert into zyx_cont_cb (a) values ('5298849898407424');
insert into zyx_cont_cb (a) values ('5417150268149902');
insert into zyx_cont_cb (a) values ('5417150423383156');
insert into zyx_cont_cb (a) values ('5417151551159178');
insert into zyx_cont_cb (a) values ('5417151707679491');
insert into zyx_cont_cb (a) values ('5417152115047180');
insert into zyx_cont_cb (a) values ('5417156227078934');
