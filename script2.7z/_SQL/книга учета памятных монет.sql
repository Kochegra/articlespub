  SELECT DISTINCT account,reference,
  name,
                  nominal,
                  year,
                  metal,
                  proba,
                  massa,
                  m_debit,
                  nominal * m_debit summa_debit,
                  m_debit - m_credit m_credit,
                  nominal * (m_debit - m_credit) summa_credit,
                  saldo,
                  nominal * saldo summa_saldo
    FROM (SELECT /*+ INDEX(c CONTRACT_NEXT_NDX) */
                c.account,c.reference,
                b.name name,
                 b.num1 nominal,
                 SUBSTR (
                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'YEAR'),
                    1,
                    5)
                    year,
                 LOWER (SUBSTR (b.str1, 1, 30)) metal,
                 SUBSTR (
                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'D_SPR'),
                    1,
                    15)
                    proba,
                 SUBSTR (
                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'MASSA'),
                    1,
                    15)
                    massa,
                 universe.oborot_collector (
                    c.Branch,
                    c.Reference,
                    'MONEY_' || '' || '191304',
                    '810',
                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
                    1)
                    m_debit,
                 universe.oborot_collector (
                    c.Branch,
                    c.Reference,
                    'MONEY_' || '' || '191304',
                    '810',
                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
                    0)
                    m_credit,
                 UNIVERSE.SALDO_COLLECTOR (
                    c.Branch,
                    c.Reference,
                    'MONEY_' || '' || '191304',
                    '810',
                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1)
                    saldo
            FROM contracts c, guides b
           WHERE     c.type_doc = 2154
                 AND c.status = 50
                 AND b.type_doc = 2914
                 AND b.code = c.doc_number
                 AND b.date_work =
                        (SELECT MAX (date_work)
                           FROM guides
                          WHERE type_doc = 2914 AND code = c.doc_number))
   WHERE m_debit <> 0 OR m_credit <> 0 OR saldo <> 0
ORDER BY metal,
         nominal,
         year,
         name


SELECT * /*+ INDEX(c CONTRACT_NEXT_NDX) */
--                b.name name,
--                 b.num1 nominal,
--                 SUBSTR (
--                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'YEAR'),
--                    1,
--                    5)
--                    year,
--                 LOWER (SUBSTR (b.str1, 1, 30)) metal,
--                 SUBSTR (
--                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'D_SPR'),
--                    1,
--                    15)
--                    proba,
--                 SUBSTR (
--                    universe.VARIABLE_GUIDES (b.branch, b.reference, 'MASSA'),
--                    1,
--                    15)
--                    massa,
--                 universe.oborot_collector (
--                    c.Branch,
--                    c.Reference,
--                    'MONEY_' || '' || '191304',
--                    '810',
--                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
--                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
--                    1)
--                    m_debit,
--                 universe.oborot_collector (
--                    c.Branch,
--                    c.Reference,
--                    'MONEY_' || '' || '191304',
--                    '810',
--                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
--                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1,
--                    0)
--                    m_credit,
--                 UNIVERSE.SALDO_COLLECTOR (
--                    c.Branch,
--                    c.Reference,
--                    'MONEY_' || '' || '191304',
--                    '810',
--                    TO_DATE ('13.04.2016', 'dd.mm.yyyy') - 1)
--                    saldo
            FROM contracts c, guides b
           WHERE     c.type_doc = 2154
                 AND c.status = 50
                 AND b.type_doc = 2914
                 AND b.code = c.doc_number
                 AND b.date_work =
                        (SELECT MAX (date_work)
                           FROM guides
                          WHERE type_doc = 2914 AND code = c.doc_number)
                          and b.name like '����-08%'


select rowid,a.* from contracts a where reference in (5867341,6130295)