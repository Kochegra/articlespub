declare
v_txt varchar2(10000) := null;
v_cnt number;
v_link varchar2(2000);
v_day number := 5; --���-�� ���� �����
v_sinh1 number := 1;      --��������� (1) ������������� 1
v_sinh2 number := 1;      --��������� (1) ������������� 2
v_sinh3 number := 1;      --��������� (1) ������������� 3
begin
--  ������������� 3. �� inkp_staging.
if v_sinh3 = 1 then
v_txt := v_txt||'������������� 3. �� inkp_staging.'||chr(13);
    for c_ip1 in (
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=47
        and not exists (select 1 from inkp_staging@nnovg where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=48
        and not exists (select 1 from inkp_staging@nsibirsk where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=76
        and not exists (select 1 from inkp_staging@khabarovsk where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=104
        and not exists (select 1 from inkp_staging@ekburg where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=49
        and not exists (select 1 from inkp_staging@spburg where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=354
        and not exists (select 1 from inkp_staging@stavropol where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        union all
        select i.* from inkp_staging i where i.date_load between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and i.branch=192
        and not exists (select 1 from inkp_staging@rostov where id=i.id and status=i.status and nvl(doc_ref,0)=nvl(i.doc_ref,0) and nvl(doc_branch,0)=nvl(i.doc_branch,0) and nvl(err_code,0)=nvl(i.err_code,0) and nvl(err_msg,0)=nvl(i.err_msg,0))
        ) loop
            select count(*) into v_cnt from subdepartments s, variable_guides vg, guides g
            where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch
            and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=c_ip1.branch;
            if v_cnt = 1 then
                select vg.value into v_link from subdepartments s, variable_guides vg, guides g
                where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch
                and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=c_ip1.branch;
                    begin
                        execute immediate
                        'declare
                            USID          NUMBER := 1403;
                            USN           VARCHAR2(2000);
                            ExistsChg     number;
                            NEW_ID        number := '||c_ip1.id||';
                            NEW_BRANCH    number := '||c_ip1.BRANCH||';
                        begin
                            SELECT USER_NAME into usn FROM USERS@'||v_link||' WHERE USER_ID=USID;
                            --DBMS_OUTPUT.PUT_LINE(usn);
                            begin
                                ExistsChg := 0;
                                select /*+ index (ch, CHG_OBJ_PK)*/ 1 into ExistsChg from chg_obj@'||v_link||' ch
                                    where reference = NEW_ID and branch = NEW_Branch and tbl = ''INKP_STAGING'' and status in (0, 1);
                                exception
                                    when others then
                                    ExistsChg := 0;
                                end;
                                --DBMS_OUTPUT.PUT_LINE(ExistsChg);
                            IF (ExistsChg = 0) then
                                INSERT INTO CHG_OBJ@'||v_link||'(tbl, REFERENCE, BRANCH, DATE_MODIFY, SUBD_MODIFY, OWNER_MODIFY, STATUS, OWNER_ID_MODIFY)
                                VALUES (''INKP_STAGING'', NEW_ID, NEW_BRANCH, sysdate, NEW_BRANCH, usn, 0, USID);
                                commit;
                            end if;
                        end;';
                    exception when NO_DATA_FOUND then
                        v_txt := v_txt||c_ip1.id||'�� ������ '||chr(13);
                    end;
                    v_txt := v_txt||c_ip1.id||'   '||to_char(c_ip1.date_load,'dd.mm.yyyy hh24:mi:ss')||' - ���������������.'||chr(13);
            else
                v_txt := v_txt||c_ip1.id||' - ����������� �� 1-� ������.'||chr(13);
            end if;
        end loop;
else
    v_txt := v_txt||'������������� 3 - ���������.'||chr(13);
end if;

if v_txt is not null then
    P_Email.Send_Mail(Reciever => 'gorodnov@msk.vtb.ru',
                       Subject => '������������� �������� �� (������ -> ��)',
                       Mail_Text => v_txt);
end if;
end;