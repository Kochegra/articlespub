p_k2.Del_K2

SELECT a.reference||',',A.* FROM DOCUMENTS A
           WHERE (REFERENCE, BRANCH) IN
                    (SELECT /*+ index(COLLECTOR_CONTRACTS COLLECTOR_CONTRACT_PK)*/
                           DOCNUM, ZBRANCH_DOCNUM
                       FROM COLLECTOR_CONTRACTS
                      WHERE     REFERENCE = 42596
                            AND BRANCH = 374000
                            AND NAME = 'CARDLIST_2'
                            AND SUMMA IN (0, 1)) 
                            and status=35
                          --  and exists (select 1 from variable_documents@khabarovsk where reference=a.reference and branch=a.branch and name='TYPE_SROK' and value='0')
                            --and reference=2574627658 




--insert into k2
select d.reference,d.branch,d.PAYERS_CONTRACT refer_conrtact,D.BRANCH_PAYERS branch_contract,
D.PAYERS_ACCOUNT account,D.PAYERS_CURRENCY currency,'D' where_IS,2 what_is
from documents d where d.reference in (37369034,26107786,26134151) --and d.branch=76
and d.status=35
--+ ���������
--STOP_WAIT_IP
--UNSTOP_WAIT_STATUS



select * from k2 
where refer_contract=42596 and branch=374000 
--reference in (37369034)







--======= DOCUMENTS ARCHIVE
select rowid,doc.* from documents doc where  reference in (37369034)
--union all
--select rowid,doc.* from archive doc where reference in (1207012554)
or refer_from in (37369034)
or related in (37369034)

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where reference= and branch=

select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (37369034))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch)=

select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (1207012554))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=
