select * --reference,branch
--             bulk collect
--              into t_reference, t_branch
              from contracts c
             where STATUS in (50,70)
               and TYPE_DOC = 8402
               and DATE_OPEN <= trunc(sysdate)
               and account = '40802810001550000219' --REC_DOC.PAYERS_ACCOUNT
               and SUBDEPARTMENT = 191274 --rec_depart.SUBDEPARTMENT;
               
 select *  --1
                        from mbank.sms_jur_comis s
                       where s.reference = 10227481 --t_reference(1)
                         and s.branch    = 191274 --t_branch(1)
                         and (s.docnum_k2 is not null and s.docnum_k2 != 0)
                         and (s.zbranch_docnum_k2 is not null and s.zbranch_docnum_k2 != 0)
                         
                         
                      