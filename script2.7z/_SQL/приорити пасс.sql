BEGIN
   :doa__value :=
      d_9341.CheckMainCardToExistsCard (pi_CardNumber   => :pi_CardNumber,
                                        pi_PRType       => :pi_PRType,
                                        pi_EID          => :pi_EID);
END;


:DOA__VALUE=['� ������� ��� ���� ����������� ������ �� ������ ����� Priority Pass. ���������� �������� ����� �� �� � ������� ���������� �����']
:PI_CARDNUMBER=['4769890000837341']
:PI_PRTYPE=[0.200000000e+001]
:PI_EID=[0.195001900e+007]


select date_close, card_basic from eid.eid_products p where p.eid = 1950019
                                          and p.pr_type = 9 and p.pr_name = '��������� ����� Priority Pass' and p.pr_status != 60
                                          

SELECT rowid, sdl.*
                                          FROM eid.eid_service_obj_list sdl
--                                         LEFT JOIN eid.open_card o
  --                                          ON o.reference = sdl.reference_obj
    --                                       AND o.branch = sdl.branch_obj
      --                                   LEFT JOIN eid.eid_products p
        --                                    ON o.card = p.account
                                         WHERE --operation = :v6
                                           --AND 
                                           sdl.eid = 1950019
                                           --AND sdl.status_obj > :v7
                                           --AND p.account IS NULL
                                           --and sdl.reference_obj=1615347036
                                           --and sdl.status<=20
                                           
                                           1607728211
                                           
SELECT rowid, sdl.*
                                          FROM eid.eid_service_obj_list sdl
--                                         LEFT JOIN eid.open_card o
  --                                          ON o.reference = sdl.reference_obj
    --                                       AND o.branch = sdl.branch_obj
      --                                   LEFT JOIN eid.eid_products p
        --                                    ON o.card = p.account
                                         WHERE --operation = :v6
                                           --AND 
                                          -- sdl.eid = 1950019
                                           --AND sdl.status_obj > :v7
                                           --AND p.account IS NULL
                                           --and
                                            sdl.reference_obj in (1567378413,1601670172)



select rowid,doc.* from documents doc where  reference in (1207012554)
--union all


SELECT rowid, sdl.* FROM eid.eid_service_obj_list sdl where reference_obj in (
select doc.reference from archive doc where --reference in (1609814773)
--or related in (-)  -- ������ � �������
--and 
type_doc in (9341) and status in (30)
and refer_office='EID_CARDCLOSE_REQUEST_PP'
--and num_group=180
--and branch=191404 
--and doc_number>980875000 
--and 
--owner in (429913)
--and refer_office like '%19631393%'
and date_work>=trunc(sysdate)-20 --to_date('17.03.2014','dd.mm.yyyy') 
)
                                           