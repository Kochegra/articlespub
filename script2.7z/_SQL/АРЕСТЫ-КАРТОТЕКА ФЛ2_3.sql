select distinct name, cardnum
                     from cf_collector
                     where reference = 242431 --400558
                       and branch    = 191
                       and name not like 'K+%'

730001    4291580156713829
730001    4291580158160805
730002    4291580156713829
730002    4291580158160805
730004    4291580156713829
730004    4291580158160805
730008    4291580156713829
730008    4291580158160805

--l_CollectorCardEI := 
select pcf.Saldo_Card_CollectorW('730001', 429923, 191, '5417154755954717' , SysDate) from dual 

select pcf.Saldo_Card_CollectorW('730001', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730002', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730002', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730004', 429923, 191, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_CollectorW('730008', 429923, 191, '5417154755954717' , SysDate) from dual

--l_CollectorCard   := 
select pcf.Saldo_Card_Collector ('730001', 191, 429923, '5417154755954717' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730001', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730002', 191, 400558, '4652065098284256' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730002', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730004', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730004', 191, 348578, '4291580158160805' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730008', 191, 348578, '4291580156713829' , SysDate) from dual

select pcf.Saldo_Card_Collector ('730008', 191, 348578, '4291580158160805' , SysDate) from dual

