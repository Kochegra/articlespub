   
   begin preport_storno.rep_3528 (
   
   
   
   
select rowid,doc.* from documents@stavropol doc where  reference in (34349448,34256401 )

--union all

�����. ����� ��������. �� 34349779 � �����. ���.  �� 34256399

�����. �����. ������. �� 34349805 � ���. ���. �� 34256400


select rowid,doc.* from variable_archive@stavropol doc where 
--reference in (34349448,34256401  ) 
reference in (34349779,34256399)
--reference in (34349805,34256400)
and branch=354

                 select /*+ index(d archive_date_work_index) */
                        * --DATE_WORK, REFERENCE, BRANCH, STATUS, RELATED, branch_related, refer_from, branch_from
                 from ARCHIVE@stavropol d
                 where DATE_WORK = '29aug2017' --r_date_day
                   --and NUM_GROUP = p_storno
                   and (   (PAYERS_ACCOUNT not like '2%' and RECEIVERS_ACCOUNT not like '2%')
                        or (PAYERS_ACCOUNT like '20208%' and RECEIVERS_ACCOUNT like '20208%')
                        or (PAYERS_ACCOUNT like '20309%' and RECEIVERS_ACCOUNT like '61213%')
                        or (RECEIVERS_ACCOUNT like '20309%' and PAYERS_ACCOUNT like '61213%')
                       )
                       and reference in (34349448)


select WORK_DATE, HEADER, CODE, ASSIST, YSUBDEPARTMENT from JOURNAL@stavropol
                       where DOCNUM =  34349448 and BRANCH = 354--r1.BRANCH
                         and FLAG_DEBIT = '+'
                         and (   (0 = 0 and HEADER in ('A'))
                              or (1 = 1 and HEADER in ('B','C','D','E'))
                             )
--                         and cSearch_depart_exclude NOT LIKE '%,'||to_char(YSUBDEPARTMENT)||',%'
                       order by WORK_DATE desc


SELECT to_number(universe.variable_part(34349448, 354, 'STORNO_REFERENCE')) from dual


or refer_from in (1207012554)
--or related in (-)  -- ������ � �������
--and type_doc in (203) and status in (30)
--and num_group=180
--and branch=191404 
--and doc_number>980875000 
--and 
--owner in (429913)
--and refer_office like '%19631393%'
--and date_work>=to_date('17.03.2014','dd.mm.yyyy') 
--and summa=3 
--**
--and payers_account like '%42301978001920100083%'  
--or receivers_account like '%4652064565336129%'
--**
--����������� ����������� �������� REFER_FROM=-1
--order by doc_number
   

STORNO_BRANCH
STORNO_REFERENCE
STORNO_WORK_DATE