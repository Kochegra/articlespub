18363650

select distinct name, refer_contract, branch_contract, acc_category category, filial
                     from cf_collector
                     where reference = 242431
                       and branch    = 191
                       and name not like 'K+%'

--l_CollectorEI := 
select 'eid',pcf.Saldo_CollectorW('730004',402334,191,754202,48071, SysDate,3) from dual
union all
--l_Collector   := 
select 'main',pcf.Saldo_Collector('730004',191,402334,754202,48071, SysDate,3) from dual
union all
select 'fil',pcf.Saldo_Collector@nsibirsk('730004',191,402334,754202,48071, SysDate,3) from dual


----CF_DOCS
select rowid,a.* from EID.EID_CF_DOCS a where --eid=18363650 --
reference=242431

--insert into MBANK.CF_DOCS@nsibirsk
select rowid,
a.* from MBANK.CF_DOCS a where reference=242431-- eid=22017583 --reference=22017583
------------------------------------------------------------------

select rowid,a.* from MBANK.CF_ACC a where reference=242431


---- REST_CF_DOCS
select rowid,a.* from MBANK.REST_CF_DOCS a where reference=402334

select rowid,a.* from EID.EID_REST_CF_DOCS a where reference=242431
-------------------------------------------------------------------------


-----CF_COLLECTOR
select * from 
(select 'MAIN'as qqq,a.* from MBANK.CF_COLLECTOR a where --account='5417150857790512' --
reference=402334
and name not like 'K+%'
--order by work_date,record_id
union all
select 'FIL' as qqq,a.* from MBANK.CF_COLLECTOR@nsibirsk a where --account='5417150857790512' --
reference=402334
and name not like 'K+%')
order by work_date,name,qqq,record_id

--delete
insert into MBANK.CF_COLLECTOR@nsibirsk(NAME, REFER_CONTRACT, BRANCH_CONTRACT, ACCOUNT, CURRENCY, 
    REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, 
    SUMMA_CF, RECORD_ID, USERS, ACC_CATEGORY, FILIAL)
select NAME, REFER_CONTRACT, BRANCH_CONTRACT, ACCOUNT, CURRENCY, 
    REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, 
    SUMMA_CF, cf_collector_id.NEXTVAL@nsibirsk as record_id, USERS, ACC_CATEGORY, FILIAL 
from MBANK.CF_COLLECTOR a where --account='5417150857790512' --
reference=402334
and name not like 'K+%'
--order by work_date,record_id


select rowid,a.* from mbank.CF_COLLECTOR a where --account='5417150857790512' --
reference=402334
and name not like 'K+%'
order by work_date,record_id


select rowid,a.* from EID.EID_CF_COLLECTOR a where --account='5417150857790512' --
reference=402334
and name not like 'K+%'
order by work_date,record_id
-----------------------------------------------------------------------------------------------------

insert into EID.EID_CF_CARD_COLLECTOR (NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY)
select 
NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY
from MBANK.CF_CARD_COLLECTOR a where reference=400558


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.CF_CARD_COLLECTOR a where reference=400558 --cardnum like  '4652080601578276%'

select rowid,a.* from EID.EID_CF_CARD_COLLECTOR a where reference=400558 --cardnum like  '4652080601578276%'
---------------------------------------------------------------------------------------------------------------


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.REST_CF_CARDS a where reference=216338 --cardnum like  '4652080601578276%'

select rowid,a.* from EID.EID_REST_CF_CARDS a where reference=216338 --cardnum like  '4652080601578276%'
---------------------------------------------------------------------------------------------------------------

select rowid,a.* from eid.eid_card_oper a where reference='400558' 
--card_number in ('4652065098284256') --'5417150857790512') 
order by id --work_date desc

declare 
    xret varchar(2);
begin
  ptools2.short_init_user(1403);
  xRET := pcf.mass_deb(22017582,22017584, true, false, false);
  DBMS_OUTPUT.PUT_LINE('1'||xret);
end;


declare
 l_tab ANALYSER.arrest.ARRESTS_TO_OFF_LIST@proc;
begin
  ANALYSER.arrest.EID_OPER_ARREST@proc(35520365, case when l_tab.Count > 0 then l_tab else null end);
end;



select * from MBANK.CF_ERROR_EXECUTE where reference=216338


select pcf_check.saldo_collector(730001,216338,191,sysdate) from dual

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 200, sysdate, 13677 ,191) from dual 

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 41027, sysdate, 1208141832  ,191349) from dual 
