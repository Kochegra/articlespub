������� ��������� �� ������� � �����

select * from (
select rownum rn,b.* from (
select distinct a.work_date, A.NAME from MBANK.CF_COLLECTOR a where reference=240798
and name not like 'K+%'
order by work_date --,docnum
) b
)
where rn between 30 and 50 

-----CF_COLLECTOR
select * from 
(select 'MAIN'as shm,a.* from MBANK.CF_COLLECTOR a where reference=240798 and name not like 'K+%'
union all
select 'FIL' as shm,a.* from MBANK.CF_COLLECTOR@spburg a where reference=240798 and name not like 'K+%')
where work_date=to_date('18/04/2016','dd/mm/yyyy') and name in ('730001')
--and 
--shm='FIL'
order by work_date,name,shm,docnum,record_id


--������
select NAME, REFER_CONTRACT, BRANCH_CONTRACT, ACCOUNT, CURRENCY, REFERENCE, BRANCH, WORK_DATE, 
    REST, SUMMA, SUMMA_CF, RECORD_ID, docnum, zbranch_docnum, 
    USERS,  ACC_CATEGORY, FILIAL, S_CF_COLLECTOR, S_CF_BACK, S_BACK
from MBANK.CF_COLLECTOR 
where reference=240798 
and work_date=to_date('09/12/2015','dd/mm/yyyy')
and record_id=30806243 -- ������ 20812
                      
-- ������





-- ���� ������ ���� ���������,�� ����� ��� ���� ���������� �� ������

��  1864795042
��� 1864795043 

select reference,branch from archive@spburg where refer_from in (select refer_from from archive where reference=1857939922)
union all
select reference,branch from documents@spburg where refer_from in (select refer_from from documents where reference=1857939922)

--������ �� �������
-----CF_COLLECTOR
--delete 
select rowid,a.* 
from MBANK.CF_COLLECTOR@spburg a 
where reference=240798 and name not like 'K+%'

---- REST_CF_DOCS
--delete
select rowid,a.* 
from MBANK.REST_CF_DOCS@spburg a 
where reference=240798 and name not like 'K+%'


-- �������� ��������� � ����� �� ������

--insert into MBANK.CF_COLLECTOR@spburg(NAME, REFER_CONTRACT, BRANCH_CONTRACT, ACCOUNT, CURRENCY, REFERENCE, BRANCH, WORK_DATE, 
--    REST, SUMMA, SUMMA_CF,
--    record_id, 
--    docnum,
--    zbranch_docnum,
--    USERS,  ACC_CATEGORY, FILIAL, S_CF_COLLECTOR, S_CF_BACK, S_BACK)
select NAME, REFER_CONTRACT, BRANCH_CONTRACT, ACCOUNT, CURRENCY, REFERENCE, BRANCH, WORK_DATE, 
    REST, SUMMA, SUMMA_CF, 
    cf_collector_id.NEXTVAL@spburg as record_id,--RECORD_ID, 
    case (
            select (select count(*) as cnt from archive where reference=docnum and branch=zbranch_docnum)+
                    (select count(*) as cnt from documents where reference=docnum and branch=zbranch_docnum) as cnt_all from dual
          ) 
        when 0 then docnum
    else 
        case (
                select refer_from from archive where reference=docnum and branch=zbranch_docnum
                union all 
                select refer_from from documents where reference=docnum and branch=zbranch_docnum
             ) 
            when 0 then docnum
        else
            (
                select reference from archive@spburg where (refer_from,branch_from) in (select refer_from,branch_from from archive where reference=docnum and branch=zbranch_docnum)
                union all 
                select reference from documents@spburg where (refer_from,branch_from) in (select refer_from,branch_from from documents where reference=docnum and branch=zbranch_docnum)
            )    
        end --as docnum,  --docnum,        
    end as docnum, 
--
    case (
            select (select count(*) as cnt from archive where reference=docnum and branch=zbranch_docnum)+
                    (select count(*) as cnt from documents where reference=docnum and branch=zbranch_docnum) as cnt_all from dual
          ) 
        when 0 then zbranch_docnum
    else 
        case (
                select refer_from from archive where reference=docnum and branch=zbranch_docnum
                union all 
                select refer_from from documents where reference=docnum and branch=zbranch_docnum
             ) 
            when 0 then zbranch_docnum
        else
            (
                select branch from archive@spburg where (refer_from,branch_from) in (select refer_from,branch_from from archive where reference=docnum and branch=zbranch_docnum)
                union all 
                select branch from documents@spburg where (refer_from,branch_from) in (select refer_from,branch_from from documents where reference=docnum and branch=zbranch_docnum)
            )    
        end --as docnum,  --docnum,        
    end as zbranch_docnum, 
--
    USERS,  ACC_CATEGORY, FILIAL, S_CF_COLLECTOR, S_CF_BACK, S_BACK
from MBANK.CF_COLLECTOR cf_c 
where reference=240798 
and name not like 'K+%'
--order by work_date,docnum




                        
            