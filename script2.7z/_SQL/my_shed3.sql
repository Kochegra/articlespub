-- ��������� ������������� �� � �� � ��������
declare
    v_txt       varchar2(4000) := null;
    v_txt2      varchar2(4000) := null;
    v_txt_toad  varchar2(4000) := null;
    v_tmp_cnt   number;
    v_time_h    number := 1;  -- ����
    v_time_m    number := 0;  -- ������
    v_cnt_fil   number;
    v_stat_fil  varchar2(2000);
begin
    v_tmp_cnt := 0;
    for c_ip_sinh in (
        select i.ID,i.QUEUE_REFER,i.DATE_LOAD,i.CHANGE_DATE,i.STATUS,i.BRANCH,i.IN_FILIAL,i.DOC_REF,i.DOC_BRANCH,i.ERR_CODE,i.ERR_MSG,
        i.ACCOUNT_NO_PAYER,i.ACC_TYPE,i.FILE_NAME,i.PORUCH_NUM,i.SUMM,i.REPLIED,i.REPLY_ID,i.CONFIRM_ID,i.KWT_ID,
        i.PAYERS_BANK,i.BIK_PAYERS_BANK,i.STATUS_CODE,i.SUBDEPARTMENT,i.LOG_ID
        from inkp_staging i 
        where i.date_load BETWEEN trunc(sysdate)  AND trunc(sysdate) 
                           + 1 - 1 / (1 * 24 * 60 * 60)
        and i.branch!=191
        --and i.id in (346332,346352,346358)
        and not exists (select 1 from inkp_staging@nnovg where id=i.id and status=i.status
        union all
        select 1 from inkp_staging@nsibirsk where id=i.id and status=i.status
        union all
        select 1 from inkp_staging@khabarovsk where id=i.id and status=i.status
        union all 
        select 1 from inkp_staging@ekburg where id=i.id and status=i.status
        union all
        select 1 from inkp_staging@spburg where id=i.id and status=i.status
        union all
        select 1 from inkp_staging@stavropol where id=i.id and status=i.status
        union all 
        select 1 from inkp_staging@rostov where id=i.id and status=i.status)
        ) loop
            if (c_ip_sinh.date_load + v_time_h/24 + v_time_m/60/24) < sysdate then             
                v_tmp_cnt := v_tmp_cnt + 1;
                
                select count(*) into v_cnt_fil from 
                (select status from inkp_staging@nnovg where id=c_ip_sinh.id
                union all
                select status from inkp_staging@nsibirsk where id=c_ip_sinh.id
                union all
                select status from inkp_staging@khabarovsk where id=c_ip_sinh.id
                union all 
                select status from inkp_staging@ekburg where id=c_ip_sinh.id
                union all
                select status from inkp_staging@spburg where id=c_ip_sinh.id
                union all
                select status from inkp_staging@stavropol where id=c_ip_sinh.id
                union all 
                select status from inkp_staging@rostov where id=c_ip_sinh.id);
                
                v_stat_fil := null;
                
                if v_cnt_fil = 1 then
                    select * into v_stat_fil from 
                    (select status from inkp_staging@nnovg where id=c_ip_sinh.id
                    union all
                    select status from inkp_staging@nsibirsk where id=c_ip_sinh.id
                    union all
                    select status from inkp_staging@khabarovsk where id=c_ip_sinh.id
                    union all 
                    select status from inkp_staging@ekburg where id=c_ip_sinh.id
                    union all
                    select status from inkp_staging@spburg where id=c_ip_sinh.id
                    union all
                    select status from inkp_staging@stavropol where id=c_ip_sinh.id
                    union all 
                    select status from inkp_staging@rostov where id=c_ip_sinh.id);
                end if;
                
                
                v_txt := v_txt||v_tmp_cnt||') '||c_ip_sinh.file_name||' (ID = '||c_ip_sinh.id||', Fil = '||c_ip_sinh.branch||')'||chr(13);
                v_txt_toad := v_txt_toad||c_ip_sinh.id||','; 
                if v_cnt_fil = 0 then
                    v_txt := v_txt||'     - �� ������� � ������� ����������� ������ ��';
                end if;

                if v_cnt_fil = 1 then
                    v_txt := v_txt||'     - ������ �� '||c_ip_sinh.status||' ���������� �� ������� ������� '||v_stat_fil||chr(13);
                end if;
                                    
                if v_cnt_fil > 1 then
                    v_txt := v_txt||'     - �����-�� ��� ���� ����!!!'||chr(13);
                end if;
        
            end if;
        end loop;


      if v_txt is not null then
            v_txt := '===== ���������� �� (������ 7028) - �������� ������������� �������� �� � ��������'||chr(13)||chr(13)||v_txt;
            v_txt := v_txt||chr(13)||'��� TOAD: '||v_txt_toad||chr(13)||chr(13);
      end if;


    v_tmp_cnt := 0;
    v_txt_toad := null;

    
    for c_rpo_sinh in (
        select f.REFERENCE,f.QUEUE_REFER,f.STATUS,f.FILIAL,f.DATE_CREATE,f.REFER_TO,f.BRANCH_TO,f.ANSWERED,f.RESULT_KWT,
        f.FILE_NAME,/*f.VALUE,*/f.TYPE,f.NUMBER_STOP,f.NUMBER_CANCEL,f.SUMMA,
        f.ERR_CODE,f.ERR_MESS,/*f.ANSWERED,*/f.REPLY,f.ERR_REPLY,f.REPLY_FILE,/*f.REPLY_OUT,*//*f.RESULT_KWT,*/f.DATE_CREATE_KWT,f.FILE_NAME_KWT,
        f.RES_KWT,/*f.VALUE_KWT,*/f.IN_FILIAL,f.BRANCH,f.SUBDEPARTMENT,f.BIK,f.INN,f.KPP,f.CL_NAME
        from no_file f where f.date_create BETWEEN trunc(sysdate)  AND trunc(sysdate) 
                           + 1 - 1 / (1 * 24 * 60 * 60)
        and f.filial is not null
        and f.STATUS not in ('ANSWER')
        --and i.reference in (346332,346352,346358)
        and not exists (select 1 from no_file@nnovg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@nsibirsk where reference=f.reference and status=f.status
        union all
        select 1 from no_file@khabarovsk where reference=f.reference and status=f.status
        union all 
        select 1 from no_file@ekburg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@spburg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@stavropol where reference=f.reference and status=f.status
        union all 
        select 1 from no_file@rostov where reference=f.reference and status=f.status)
        ) loop
            if (c_rpo_sinh.date_create + v_time_h/24 + v_time_m/60/24) < sysdate then             
                v_tmp_cnt := v_tmp_cnt + 1;
                
                select count(*) into v_cnt_fil from 
                (select status from no_file@nnovg where reference=c_rpo_sinh.reference
                union all
                select status from no_file@nsibirsk where reference=c_rpo_sinh.reference
                union all
                select status from no_file@khabarovsk where reference=c_rpo_sinh.reference
                union all 
                select status from no_file@ekburg where reference=c_rpo_sinh.reference
                union all
                select status from no_file@spburg where reference=c_rpo_sinh.reference
                union all
                select status from no_file@stavropol where reference=c_rpo_sinh.reference
                union all 
                select status from no_file@rostov where reference=c_rpo_sinh.reference);
                
                v_stat_fil := null;
                
                if v_cnt_fil = 1 then
                    select * into v_stat_fil from 
                    (select status from no_file@nnovg where reference=c_rpo_sinh.reference
                    union all
                    select status from no_file@nsibirsk where reference=c_rpo_sinh.reference
                    union all
                    select status from no_file@khabarovsk where reference=c_rpo_sinh.reference
                    union all 
                    select status from no_file@ekburg where reference=c_rpo_sinh.reference
                    union all
                    select status from no_file@spburg where reference=c_rpo_sinh.reference
                    union all
                    select status from no_file@stavropol where reference=c_rpo_sinh.reference
                    union all 
                    select status from no_file@rostov where reference=c_rpo_sinh.reference);
                end if;
                
                
                v_txt2 := v_txt2||v_tmp_cnt||') '||c_rpo_sinh.file_name||' (REF = '||c_rpo_sinh.reference||', Fil = '||c_rpo_sinh.filial||')'||chr(13);
                v_txt_toad := v_txt_toad||c_rpo_sinh.reference||','; 
                if v_cnt_fil = 0 then
                    v_txt2 := v_txt2||'     - �� ������� � ������� ����������� ������ ������� ��';
                end if;

                if v_cnt_fil = 1 then
                    v_txt2 := v_txt2||'     - ������ �� '||c_rpo_sinh.status||' ���������� �� ������� ������� '||v_stat_fil||chr(13);
                end if;
                                    
                if v_cnt_fil > 1 then
                    v_txt2 := v_txt2||'     - �����-�� ��� ���� ����!!!'||chr(13);
                end if;
        
            end if;
        end loop;


      if v_txt2 is not null then
            v_txt2 := '===== ������� �� (������ 5407) - �������� ������������� �������� �� � ��������'||chr(13)||chr(13)||v_txt2;
            v_txt2 := v_txt2||chr(13)||'��� TOAD: '||v_txt_toad||chr(13)||chr(13);
      end if;

      v_txt := v_txt||v_txt2;

      if v_txt is not null then
--         DBMS_OUTPUT.PUT_LINE(cloud);
         P_Email.Send_Mail(Reciever => 'gorodnov@msk.vtb.ru,aalekseev@msk.vtb.ru',
                          Subject => '������ - �������� ������������� �������� �� (������ -� ��)',
                          Mail_Text => v_txt);
      end if;

end;