select rowid,a.* from MBANK.SECURITIES a where doc_number in-- ('698588728') --
('5755894','5755897')
--nominal in (698588728,1095623973)

select rowid,a.* from MBANK.status_SECURITIES a where --docnum in (698588728,1095623973)--
doc_number='5755897' 