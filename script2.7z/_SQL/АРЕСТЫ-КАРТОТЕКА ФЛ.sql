


select rowid,a.* from eid.eid_card_oper a where card_number like  '5417159784385932%' order by id --work_date desc

select a.* from eid.eid_card_oper a where card_number like  '4652080601578276%' --order by id --work_date desc
union all
select a.* from eid.eid_card_oper a where card_number like  '4652080601578276%' --order by id --work_date desc
order by 12


select rowid,a.* from eid.eid_card_oper a where card_number like  '4652080890741486%' order by id --work_date desc

select rowid,a.* from EID.EID_CF_CARD_COLLECTOR a where reference=77428 --cardnum like  '4652080601578276%'

select rowid,a.* from MBANK.CF_CARD_COLLECTOR a where reference = 13677--44953

select rowid,a.* from MBANK.CF_ACC a where account like '%40817810700330100007%' --reference = 77428--44953

select rowid,a.* from MBANK.CF_docs a where doc_number like '%10006/12/24/77%' --reference in (13677) --44953

select pcf_check.saldo_collector(730001,4221063,15,sysdate) from dual

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 200, sysdate, 13677 ,191) from dual 

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 41027, sysdate, 1208141832  ,191349) from dual 

select rowid,doc.* 
from documents doc
--from archive doc
--from documents_delete doc 
where reference in (1174071189,1174078142)--973214743,787369958)
or refer_from in (1174071189,1174078142)

select rowid,doc.* 
from variable_documents doc 
--from variable_archive doc
where reference in (1174071189,1174078142)--973214743,787369958)



select * from PRC_LOADER.CLOSEPK_ACCEPT where card='4652081188532074' --'4652080855231986' 
order by id


���� ������ ��������� � ���������� ������, �� ��� ���� ��������� ������ ������ � ������, �� ��������� �������� ���������.

select * from variable_documents where reference=1072191404 --or refer_from=1066159195

select * from cf_docs where reference=77428

select rowid,a.* from cf_collector a where reference=77428 order by work_date

select rowid,a.* from archive a where reference=1066158137

--select * from MBANK.CF_ERROR_EXECUTE where reference=77428

select * from MBANK.CF_INS --where reference=77428