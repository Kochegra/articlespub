-- ���� ������
select * from users where 
upper(user_name) like upper('%��������%')

-- ������ F5
declare
     doc_ref    number;
     doc_br     number;
     j          NUMBER;
     tmp1       VARCHAR2(2000);
     tmp2       VARCHAR2(2000);
     v_owner    NUMBER;
begin
   doc_ref := 3088652033;
   doc_br  := 191;
   v_owner := 982038;
   mbank.ptools2.short_init_user (v_owner);  
   j := NULL; tmp1 := NULL; tmp2 := NULL;
   dbms_output.put_line(DOCALGO.EXECDOC(doc_br, doc_ref, v_owner, j, tmp1, tmp2));
   commit;                 
end;  
/
