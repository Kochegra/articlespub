BEGIN
   :doa__value :=
      eid.p_eid_firma_modify.get_list_fill (nEID            => :nEID,
                                            nID_Hist        => :nID_Hist,
                                            nID_Collision   => :nID_Collision,
                                            nUserId         => :nUserId,
                                            sOwner_modify   => :sOwner_modify,
                                            nSubd_modify    => :nSubd_modify,
                                            nCommit         => :nCommit);
END;


select h.* from EID.EID_BLACK_HUMAN H where (refer_firma,branch_firma) in --1455580 --search_doc like '%5052009892%'
(SELECT fir1.reference, fir1.branch
                         FROM eid.eid_black_firma fir1
                        WHERE fir1.inn = '5052009892')

SELECT rowid,fir1.* --fir1.reference, fir1.branch
                         FROM eid.eid_black_firma fir1
                        WHERE fir1.inn = '5052009892'
                        
                        EID.EID_TOOLS_CHEC


p_eid_firma_modify
complince
eid_tools_check

select fdif.id_record, fdif.norder, fdif.table_name table_name_r, 
decode(status, 1, 0, 2, 1) Ignore, fdif.basic,
(select gd.name from mbank.guides gd where gd.type_doc = 6462 and gd.code = fdif.type_modify
                    and fdif.table_name = gd.code1 and gd.str1 is null and rownum < 2) table_name,
                   case when fdif.table_name = 'EID.EID_FIRMA_VARIABLE' then mbank.eid_gate.nameguide(6048, fdif.element_name)
                   else (select acom.comments from all_col_comments acom where acom.owner = 'EID'
                         and acom.table_name = substr(fdif.table_name, instr(fdif.table_name, '.') + 1, length(fdif.table_name))
                         and acom.column_name = fdif.element_name) end column_name,
                   mbank.eid_gate.NameGuide(6464, fdif.error_code) ErrorCodeName,
                   fdif.error_text, fdif.owner_modify, fdif.subd_modify,
                   (select sub.name from eid.eid_subdepartments sub where sub.id = fdif.subd_modify) sub_name
                   from eid.eid_firma_difference fdif where eid = 1455580 and id_hist = 133967
                   and id_collision = 0 and type_modify = 'FILL_DATA'
                   
                   
select * from eid.eid_firma_difference  where eid = 1455580


    SELECT * FROM eid.eid_black_firma
      WHERE (source = '������ ����')  AND
        inn = '5052009892'
--        OR UPPER(Name_firma) like '%'||UPPER(pName)||'%'
--        OR UPPER(Name_firma) like '%'||UPPER(pFull)||'%'
--        OR UPPER(Name_firma) like '%'||UPPER(pLat)||'%'
--        OR UPPER(pName) like '%'||UPPER(Name_firma)||'%'
--        OR UPPER(pFull) like '%'||UPPER(Name_firma)||'%'
--        OR UPPER(pLat) like '%'||UPPER(Name_firma)||'%'
        

select EID.EID_TOOLS_CHECK.CHECK_FIRMA('5052009892','','','') from dual