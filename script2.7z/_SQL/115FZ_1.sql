--// ������� ����� 115�� � ������ �������������
--update eid.eid_anketa_115fz ss set ss.anketa_branch = &&dst_SUB 
--where ss.anketa_branch = &&src_SUB;
--COMMIT;
-- Created on 24.08.2013 by KONDRASHOV_AV 

begin
  -- Test statements here
  for x in (select * from eid.eid_anketa_115fz where anketa_branch=191411 and ANKETA_EID in (
select distinct related from
( 
  SELECT ROW_NUMBER () OVER (ORDER BY b.name, full_name) RNUM,
         '#RM_' || branch || '_' || eid AS RecordMarker,
         branch depart_id,
         b.name depart,
         ANKETA_REFERENCE,
         eid related,
         full_name
    FROM eid.eid_115fz_internal j
         JOIN (SELECT id, name
                 FROM eid.eid_subdepartments c
                WHERE c.id IN (    SELECT DISTINCT id
                                     FROM eid.eid_subdepartments s
                               START WITH id IN (191411)
                               CONNECT BY parent = PRIOR id)) b
            ON j.branch = b.id
   WHERE eid > 0 AND rep_id = 1641
ORDER BY b.name, full_name
)
--where full_name like '�%'
--ORDER BY full_name
)
 and anketa_subd_modify=191200)
    loop                                           
      eid.eid_115fz_tools.Modify_115FZ_Data(x.anketa_eid);
    end loop;
    commit;
end;



--select * from eid.eid_anketa_115fz where anketa_branch=&&dst_SUB