----CF_DOCS
select rowid,a.* from EID.EID_CF_DOCS a where --reference=510065--400558
eid in (21817377)

select rowid,a.* from MBANK.CF_DOCS a where reference=510065-- 
--eid=17188629 --reference=22017583
------------------------------------------------------------------

select rowid,a.* from MBANK.CF_ACC a where --filial not in (999,191) 
reference in (510057,510065,510066) --=510065
order by 1 desc 

select analyser.GET_CARD_BAL_ARRKART@proc ('5417159516788288') from dual

select analyser.GET_CARD_BAL_ARRKART@proc ('5417153127238403') from dual

---- REST_CF_DOCS
select rowid,a.* from MBANK.REST_CF_DOCS@nsibirsk a where reference=510065

select rowid,a.* from EID.EID_REST_CF_DOCS a where reference=510065
-------------------------------------------------------------------------


-----CF_COLLECTOR
select rowid,a.* from MBANK.CF_COLLECTOR a where --account='5417150857790512' --
reference=510065 and name not like 'K+%' and account = '5417159516788288'
order by work_date,record_id

INSERT INTO cf_collector(
name, 
branch,
reference, 
refer_contract, 
branch_contract,
work_date,
rest,
summa,
summa_cf,
record_id, 
docnum, 
users, 
zBranch_Docnum, 
Acc_Category, 
account, 
currency, 
s_cf_collector, 
s_back, 
s_cf_back, 
filial)
VALUES('730001', 
191, 
269876, 
327877, 
76031, 
trunc(sysdate), 
500,--case when nName = '730009' then Greatest(0, nRest + nSumma) else nRest + nSumma end,
500, --case when nName = '730009' and (nRest + nSumma) < 0 then nRest else nSumma end, 
500, --l_SummaCF,
cf_collector_id.NEXTVAL, --   workId, 
'', --cDocNum, 
1403, --cUser, 
191, --nBranch_Docnum, 
1.2, ---nAcc_Category, 
'42305810300650018256', --nAccount, 
'810', --nCurrency, 
'', --nSummaCF_Collector, 
'', --nSumma_Back, 
'', --nSumma_Back_CF, 
76) --nFilial);



select rowid,a.* from EID.EID_CF_COLLECTOR a where --account='5417150857790512' --
reference=510065


INSERT INTO eid.eid_cf_collector(
name, 
branch,
reference, 
refer_contract, 
branch_contract,
work_date,
rest,
summa ,
summa_cf,
record_id, 
docnum, 
users, 
zBranch_Docnum, 
Acc_Category, 
account, 
currency)
VALUES( 
'730001', --nName, 
191, 
269876, 
327877, 
76031,  
trunc(sysdate), 
500, --nRest + nSumma, 
500, --nSumma, 
500, --l_SummaCF,
eid.eid_cf_collector_id.NEXTVAL, --workId, 
'', --cDocNum, 
1403, --cUser, 
191, --nBranch_Docnum, 
1.2, --nvl(nAcc_Category, 0), 
'42305810300650018256', --nAccount, 
'810') --nCurrency, 



-----------------------------------------------------------------------------------------------------

insert into EID.EID_CF_CARD_COLLECTOR (NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, 
RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY)

select 
NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY
from MBANK.CF_CARD_COLLECTOR a where reference=510065


select cf_card_collector_id.NEXTVAL from dual

SELECT eid.eid_cf_collector_id.NEXTVAL from dual

INSERT INTO cf_card_collector(name, branch, reference, cardnum, currency, work_date, rest, summa, summa_cf,
                          record_id,docnum,users,zBranch_Docnum, Acc_Category--, s_cf_collector, s_back, s_cf_back
                          )
                  VALUES( '730008', 191, 429923, '5417154755954717', '810', trunc(sysdate), 0 --nRest + nSumma,
                  ,-12.05 --nSumma
                  ,-12.05 -- l_SummaCF,
                  ,cf_collector_id.NEXTVAL   --     workId, 
                  ,2001924531,1403, 191, 1.1--nvl(nAcc_Category, 0),
                   --nSummaCF_Collector, nSumma_Back, nSumma_Back_CF
                   );

INSERT INTO EID.EID_CF_CARD_COLLECTOR(name, branch, reference, cardnum, currency, work_date, rest, summa, summa_cf,
                          record_id,docnum,users,zBranch_Docnum, Acc_Category--, s_cf_collector, s_back, s_cf_back
                          )
                  VALUES( '730008', 191, 429923, '5417154755954717', '810', trunc(sysdate), 0 --nRest + nSumma,
                  ,-12.05 --nSumma
                  ,-12.05 -- l_SummaCF,
                  ,eid.eid_cf_collector_id.NEXTVAL   --     workId, 
                  ,2001924531,1403, 191, 1.1--nvl(nAcc_Category, 0),
                   --nSummaCF_Collector, nSumma_Back, nSumma_Back_CF
                   );

INSERT INTO EID.EID_CF_CARD_COLLECTOR(name, branch, reference, cardnum, currency, work_date, rest, summa, summa_cf,
                          record_id,docnum,users,zBranch_Docnum, Acc_Category--, s_cf_collector, s_back, s_cf_back
                          )
                  VALUES( '730001', 191, 429923, '5417154755954717', '810', trunc(sysdate), 0 --nRest + nSumma,
                  ,-42.76 --nSumma
                  ,-42.76 -- l_SummaCF,
                  ,eid.eid_cf_collector_id.NEXTVAL   --     workId, 
                  ,2001924531,1403, 191, 1.1--nvl(nAcc_Category, 0),
                   --nSummaCF_Collector, nSumma_Back, nSumma_Back_CF
                   );
                   
INSERT INTO CF_CARD_COLLECTOR(name, branch, reference, cardnum, currency, work_date, rest, summa, summa_cf,
                          record_id,docnum,users,zBranch_Docnum, Acc_Category--, s_cf_collector, s_back, s_cf_back
                          )
                  VALUES( '730001', 191, 429923, '5417154755954717', '810', trunc(sysdate), 0 --nRest + nSumma,
                  ,-42.76 --nSumma
                  ,-42.76 -- l_SummaCF,
                  ,cf_collector_id.NEXTVAL   --     workId, 
                  ,2001924531,1403, 191, 1.1--nvl(nAcc_Category, 0),
                   --nSummaCF_Collector, nSumma_Back, nSumma_Back_CF
                   );                   

-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.CF_CARD_COLLECTOR a where reference=510065 --cardnum like  '4652080601578276%'
order by work_date,record_id

select rowid,a.* from EID.EID_CF_CARD_COLLECTOR a where reference=510065 --cardnum like  '4652080601578276%'
order by work_date,record_id

---------------------------------------------------------------------------------------------------------------


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.REST_CF_CARDS a where reference=510065 --cardnum like  '4652080601578276%'

select rowid,a.* from EID.EID_REST_CF_CARDS a where reference=510065 --cardnum like  '4652080601578276%'
---------------------------------------------------------------------------------------------------------------

select rowid,a.* from eid.eid_card_oper a where reference='510065' 
--card_number in ('4652065098284256') --'5417150857790512') 
order by id --work_date desc

declare 
    xret varchar(2);
begin
  ptools2.short_init_user(1403);
  xRET := pcf.mass_deb(22017582,22017584, true, false, false);
  DBMS_OUTPUT.PUT_LINE('1'||xret);
end;


declare
 l_tab ANALYSER.arrest.ARRESTS_TO_OFF_LIST@proc;
begin
  ANALYSER.arrest.EID_OPER_ARREST@proc(35520365, case when l_tab.Count > 0 then l_tab else null end);
end;



select * from MBANK.CF_ERROR_EXECUTE where reference=216338


select pcf_check.saldo_collector(730001,216338,191,sysdate) from dual

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 200, sysdate, 13677 ,191) from dual 

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 41027, sysdate, 1208141832  ,191349) from dual 
