������ �������
����� �������� 20 ������
�������� sub_type=0
������� ��������.


select rowid,doc.* from documents doc where  reference in (2580007650,2580008828,2580008829)
--union all
--select rowid,doc.* from archive doc where reference in (1136182734,1136194848 )
or refer_from in (2580007650,2580008828,2580008829)
or related in (2580007650,2580008828,2580008829)

select rowid,doc.* from variable_documents doc where  reference in (2579884802) and branch=191413 and name='SEND_SMS'

select * from eid.Eid_Public_jurist ud  WHERE --eid=12752371 
ud.doc_Ref = 2579884802 --And ud.doc_Br = 3

select rowid,a.* from eid.eid_objects a where eid = (select VALUE from variable_documents where reference = 2579884802 and NAME = 'EID' 
and TYPE = 'PERSONAL_LAWYER') 

----------------
���������

select rowid,doc.* from documents doc where  reference in (2579885530,2579893623,2579893624)
or refer_from in (2579885530,2579893623,2579893624)
or related in (2579885530,2579893623,2579893624)

select rowid,doc.* from variable_documents doc where  reference in (2579885530) and branch=191413 --and name='SEND_SMS'

select  rowid,a.* from eid.eid_objects a where eid = (select VALUE from variable_documents where 
reference = 2579885530 and NAME = 'EID' and TYPE = 'VTB_STRAH')


---------------
2579884993

select rowid,doc.* from documents doc where  reference in (2579884993,2579893632,2579893634)
or refer_from in (2579884993,2579893632,2579893634)
or related in (2579884993,2579893632,2579893634)

select  rowid,a.* from eid.eid_objects a where eid = 8936709 

 (select VALUE from variable_documents where 
reference = 2579884993 and NAME = 'EID' and TYPE = 'VTB_STRAH')


