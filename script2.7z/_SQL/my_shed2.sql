DECLARE
   cloud        VARCHAR2 (10000) := NULL;
   v_txt1       VARCHAR2 (2000) := NULL;
   v_txt2       VARCHAR2 (2000) := NULL;
   v_txt3       VARCHAR2 (2000) := NULL;
   flag         NUMBER := 0;
   v_tmp_cnt    NUMBER;
   v_file_name  VARCHAR2 (2000) := NULL;
   v_file_cnt   NUMBER := 0;
   TYPE t_double IS TABLE OF no_file.date_create%TYPE;
   v_time t_double;
   v_par_day    NUMBER := 0;  -- ���
   v_par_time   NUMBER := 1;  -- ����
   v_shed1      NUMBER := 1;
BEGIN
    IF v_shed1 = 1 then
        -- ���� �� ������� � ����� ���������� �������
        SELECT max(max_date) max_dt
        BULK COLLECT into v_time
        FROM (
            SELECT max(date_create) max_date
            from no_file where date_create >= to_date('01.05.2016','dd.mm.yyyy')
            and file_name in (select file_name from
            (select distinct FILE_NAME, count(FILE_NAME) cnt from no_file
                   where date_create BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                             + 1
                                             - 1 / (1 * 24 * 60 * 60)
            group by FILE_NAME) tbl
            where tbl.cnt>1)
        union all
            SELECT max(date_load) max_date
            from zno where date_load >= to_date('01.05.2016','dd.mm.yyyy')
            and file_name in (select file_name from
            (select distinct FILE_NAME, count(FILE_NAME) cnt from zno
                   where date_load BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                             + 1
                                             - 1 / (1 * 24 * 60 * 60)
            group by FILE_NAME) tbl
            where tbl.cnt>1)
        union all
            SELECT max(date_load) max_date
            from inkp_staging where date_load >= to_date('01.05.2016','dd.mm.yyyy')
            and file_name in (select file_name from
            (select distinct FILE_NAME, count(FILE_NAME) cnt from inkp_staging
                   where date_load BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                             + 1
                                             - 1 / (1 * 24 * 60 * 60)
            group by FILE_NAME) tbl
            where tbl.cnt>1)
        );
    -- ���� ���� ������, ��
    --DBMS_OUTPUT.PUT_LINE('1 - '||v_time.count||' - '||to_char(v_time(1),'dd.mm.yyyy hh24:mi:ss')||'  ������� - '||to_char(sysdate-10/24,'dd.mm.yyyy hh24:mi:ss'));
        if v_time.count=1 then
--            if v_time(1) is null then DBMS_OUTPUT.PUT_LINE('���� ����� ����'||to_char(v_time(1),'dd.mm.yyyy hh24:mi:ss')||CHR (13)); end if;
--            if trim(to_char(v_time(1),'dd.mm.yyyy hh24:mi:ss'))=''  then DBMS_OUTPUT.PUT_LINE('���� ����� �����'||CHR (13)); end if;
--            if trim(v_time(1))=''  then DBMS_OUTPUT.PUT_LINE('���� ����� �����'||CHR (13)); end if;
          if v_time(1) is not null then
            if (sysdate-v_par_day-v_par_time/24) < v_time(1) then
--            DBMS_OUTPUT.PUT_LINE('1 - '||v_time.count||' - '||to_char(v_time(1),'dd.mm.yyyy hh24:mi:ss')||'  ������� - '||to_char(sysdate-8-10/24,'dd.mm.yyyy hh24:mi:ss'));
                cloud := cloud||'===== ������� �� (������ 5407) - ����� ====='||CHR (13)||CHR (13);
                v_tmp_cnt := 0;
                FOR cur
                    IN (
                        select * from
                            (select distinct FILE_NAME, count(FILE_NAME) cnt from no_file
                                where date_create BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                              + 1
                                              - 1 / (1 * 24 * 60 * 60)
                                group by FILE_NAME) tbl
                                where tbl.cnt>1
                        )
                LOOP
                    v_tmp_cnt := v_tmp_cnt + 1;
                    v_file_name := cur.file_name;
                    v_file_cnt := cur.cnt;
                    if v_tmp_cnt = 1 then
                        v_txt2 := v_txt2||''''||v_file_name||'''';
                    else
                        v_txt2 := v_txt2||','''||v_file_name||'''';
                    end if;
                    cloud := cloud||v_tmp_cnt||') '||v_file_name||CHR (13);
                    FOR cur2 in (select * from no_file where file_name = v_file_name order by date_create)
                    loop
                        cloud := cloud||'     - '||to_char(cur2.date_create,'dd.mm.yyyy hh24:mi:ss')||'   REF = '||cur2.reference||CHR (13);
                    end loop;
                end loop;
                IF v_txt2 is not NULL then
                    cloud := cloud||CHR (13)||'��� TOAD:'||CHR (13)||v_txt2||CHR (13)||CHR (13)||CHR (13);
                end if;
            --DBMS_OUTPUT.PUT_LINE(cloud);
            --DBMS_OUTPUT.PUT_LINE('��� TOAD:'||CHR (13)||v_txt2||CHR (13)||CHR (13)||CHR (13));
--
--
--
--
                v_tmp_cnt := 0;
                v_txt2 := NULL;
                cloud := cloud||'===== ������� �� (������ 7667) - ����� ====='||CHR (13)||CHR (13);
                FOR cur
                    IN (
                        select * from
                            (select distinct FILE_NAME, count(FILE_NAME) cnt from zno
                                where date_load BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                              + 1
                                              - 1 / (1 * 24 * 60 * 60)
                                group by FILE_NAME) tbl
                                where tbl.cnt>1
                        )
                LOOP
                    v_tmp_cnt := v_tmp_cnt + 1;
                    v_file_name := cur.file_name;
                    v_file_cnt := cur.cnt;
                    if v_tmp_cnt = 1 then
                        v_txt2 := v_txt2||''''||v_file_name||'''';
                    else
                        v_txt2 := v_txt2||','''||v_file_name||'''';
                    end if;
                    cloud := cloud||v_tmp_cnt||') '||v_file_name||CHR (13);
                    FOR cur2 in (select * from zno where file_name = v_file_name order by date_load)
                    loop
                        cloud := cloud||'     - '||to_char(cur2.date_load,'dd.mm.yyyy hh24:mi:ss')||'   REF = '||cur2.id||CHR (13);
                    end loop;
                end loop;
                IF v_txt2 is not NULL then
                    cloud := cloud||CHR (13)||'��� TOAD:'||CHR (13)||v_txt2||CHR (13)||CHR (13)||CHR (13);
                end if;
--            DBMS_OUTPUT.PUT_LINE(cloud);
--            DBMS_OUTPUT.PUT_LINE('��� TOAD:'||CHR (13)||v_txt2);
                v_tmp_cnt := 0;
                v_txt2 := NULL;
                cloud := cloud||'===== ���������� �� (������ 7028) - ����� ====='||CHR (13)||CHR (13);
                FOR cur
                    IN (
                        select * from
                            (select distinct FILE_NAME, count(FILE_NAME) cnt from inkp_staging
                                where date_load BETWEEN trunc(sysdate)-v_par_day AND trunc(sysdate)-v_par_day
                                              + 1
                                              - 1 / (1 * 24 * 60 * 60)
                                group by FILE_NAME) tbl
                                where tbl.cnt>1
                        )
                LOOP
                    v_tmp_cnt := v_tmp_cnt + 1;
                    v_file_name := cur.file_name;
                    v_file_cnt := cur.cnt;
                    if v_tmp_cnt = 1 then
                        v_txt2 := v_txt2||''''||v_file_name||'''';
                    else
                        v_txt2 := v_txt2||','''||v_file_name||'''';
                    end if;
                    cloud := cloud||v_tmp_cnt||') '||v_file_name||CHR (13);
                    FOR cur2 in (select * from inkp_staging where file_name = v_file_name order by date_load)
                    loop
                        cloud := cloud||'     - '||to_char(cur2.date_load,'dd.mm.yyyy hh24:mi:ss')||'   REF = '||cur2.id||CHR (13);
                    end loop;
                end loop;
                IF v_txt2 is not NULL then
                    cloud := cloud||CHR (13)||'��� TOAD:'||CHR (13)||v_txt2||CHR (13)||CHR (13)||CHR (13);
                end if;
---************************************************
--                DBMS_OUTPUT.PUT_LINE(cloud);
---************************************************
--            DBMS_OUTPUT.PUT_LINE('��� TOAD:'||CHR (13)||v_txt2);
            end if;
          end if;
        end if;
--
--
--
        if v_time.count>1 then
        --DBMS_OUTPUT.PUT_LINE('>1 - '||v_time.count||' - ���� �����-��!!!');
            cloud := CHR(13)||cloud||'>1 - '||v_time.count||' - ���� �����-��!!!';
        end if;
--
        if v_time.count=0 then
--            DBMS_OUTPUT.PUT_LINE('0 - '||v_time.count);
            cloud := CHR(13)||cloud||'0 - '||v_time.count||' - ���� �����-��!!!';
        end if;
--
      if cloud is not null then
--         DBMS_OUTPUT.PUT_LINE(cloud);
         P_Email.Send_Mail(Reciever => 'gorodnov@msk.vtb.ru',
                          Subject => '������ - ��������� NEW (RPO,ZNO,PNO)',
                          Mail_Text => cloud);
      end if;
--
    end if;
--
END;