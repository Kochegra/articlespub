2448694111 2444987358 

            2448989792

select rowid,doc.* from documents doc where  reference in (2448989792)
--union all

select rowid,doc.* from archive doc where reference in (2448989792)
or refer_from in (2448989792)
--or related in (-)  -- ������ � �������
--and type_doc in (203) and status in (30)
--and num_group=180
--and branch=191404 
--and doc_number>980875000 
--and 
--owner in (429913)
--and refer_office like '%19631393%'
--and date_work>=to_date('17.03.2014','dd.mm.yyyy') 
--and summa=3 
--**
--and payers_account like '%42301978001920100083%'  
--or receivers_account like '%4652064565336129%'
--**
--����������� ����������� �������� REFER_FROM=-1
--order by doc_number



p_form_docs_9334.exec_form_docs_9334;

select global_parameters.isworkday(-1, sysdate) from dual

SELECT trunc(sysdate)-4,a.* --HOLYDAY_DATE INTO D 
FROM BANK_DATE a WHERE HOLYDAY_DATE=trunc(sysdate)-4

1 - �� ��������
0 - ��������

--SELECT HOLYDAY_DATE INTO D FROM CALENDAR WHERE HOLYDAY_DATE=D AND

v_work_day := global_parameters.isworkday(-1, systemdate + 1);

select global_parameters.isworkday(-1, sysdate + 1) from dual


select distinct branch_payers--universe.variable_doc(d.branch,d.reference,'DATE_DT') date_dt,  d.*
from documents d where type_doc = 9333
and status = 21
and to_date(universe.variable_doc(d.branch,d.reference,'DATE_DT'),'dd.mm.yyyy')  between  p_dt_from and p_dt_to
  


-- ID ��������� SUBDEPARTMENTS
select * from eid.eid_subdepartments where id in (191275)--9 --001 -- or parent=51 
--upper(name) like upper('%����%')  --191389

select * from subdepartments where --id=2 -- or parent=51 
upper(name) like upper('%��� ���%')  --191389
