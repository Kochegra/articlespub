declare
v_txt varchar2(10000) := null;
v_cnt number;
v_link varchar2(2000);
v_day number := 5; --���-�� ���� �����
v_sinh1 number := 1;      --��������� (1) ������������� 1
v_sinh2 number := 1;      --��������� (1) ������������� 2
v_sinh3 number := 1;      --��������� (1) ������������� 3
begin
--  ������������� 1. ����� NO_FILES.
if v_sinh1 = 1 then
v_txt := v_txt||'������������� 1. ����� NO_FILES.'||chr(13);
    for c_rpo1 in (
        select distinct reference from (
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=49)
        and not exists (select 1 from no_files@spburg where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=48)
        and not exists (select 1 from no_files@nsibirsk where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=47)
        and not exists (select 1 from no_files@nnovg where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=76)
        and not exists (select 1 from no_files@khabarovsk where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=104)
        and not exists (select 1 from no_files@ekburg where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=192)
        and not exists (select 1 from no_files@rostov where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
        union all
        select ff.* from no_files ff where ff.reference in (select f.REFERENCE from no_file f where --f.date_create BETWEEN trunc(sysdate) AND trunc(sysdate) + 1 - 1 / (1 * 24 * 60 * 60)
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial=354)
        and not exists (select 1 from no_files@stavropol where reference=ff.reference and value=ff.value and err_code=ff.err_code and nvl(err_mess,0)=nvl(ff.err_mess,0) and push=ff.push and nvl(status_doc,0)=nvl(ff.status_doc,0))
       )) loop
            dbms_output.put_line(c_rpo1.reference);
       end loop;
else
    v_txt := v_txt||'������������� 1 - ���������.'||chr(13);
end if;
v_txt := v_txt||chr(13);
--  ������������� 2. ����� NO_FILE.
if v_sinh2 = 1 then
v_txt := v_txt||'������������� 2. ������� � NO_FILE.'||chr(13);
    for c_rpo2 in (
        select f.REFERENCE,f.QUEUE_REFER,f.STATUS,f.FILIAL,f.DATE_CREATE,f.REFER_TO,f.BRANCH_TO,f.ANSWERED,f.RESULT_KWT,
        f.FILE_NAME,f.TYPE,f.NUMBER_STOP,f.NUMBER_CANCEL,f.SUMMA,
        f.ERR_CODE,f.ERR_MESS,f.REPLY,f.ERR_REPLY,f.REPLY_FILE,f.DATE_CREATE_KWT,f.FILE_NAME_KWT,
        f.IN_FILIAL,f.BRANCH,f.SUBDEPARTMENT,f.BIK,f.INN,f.KPP,f.CL_NAME
        from no_file f where
        F.DATE_CREATE between to_date(to_char(trunc(sysdate)-v_day,'dd.mm.yyyy')||' 00:00:01','dd.mm.yyyy hh24:mi:ss') and sysdate - 2/24
        and f.filial is not null
        and f.STATUS not in ('ANSWER')
        and not exists (select 1 from no_file@nnovg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@nsibirsk where reference=f.reference and status=f.status
        union all
        select 1 from no_file@khabarovsk where reference=f.reference and status=f.status
        union all
        select 1 from no_file@ekburg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@spburg where reference=f.reference and status=f.status
        union all
        select 1 from no_file@stavropol where reference=f.reference and status=f.status
        union all
        select 1 from no_file@rostov where reference=f.reference and status=f.status)
        ) loop
            select count(*) into v_cnt from subdepartments s, variable_guides vg, guides g
            where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch
            and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=c_rpo2.filial;
            if v_cnt =1 then
                select vg.value into v_link from subdepartments s, variable_guides vg, guides g
                where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch
                and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=c_rpo2.filial;
                    begin
                        execute immediate
                        'declare
                            Ref_no number := '||c_rpo2.reference||';
                            Br_no  number := 191;
                            l_Result VARCHAR2(2000);
                         begin
                            l_Result := p_export_tables.execoper@'||v_link||'(table_name => ''mbank.no_file'',
                                      table_columns => ''"REFERENCE","BRANCH","DATE_WORK","REFER_TO","BRANCH_TO","REFER_CLIENT","BRANCH_CLIENT","STATUS","ERR_MESS","ERR_CODE"'',
                                      table_conditions => ''reference = ''||Ref_no||'' and branch = ''||Br_no,
                                      table_operation => ''update'',
                                      table_columns_pk => ''reference, branch'',
                                      filials => to_char(mbgoid),
                                      filial_conditions => '''',
                                      exec_every_row    => '''');
                                      DBMS_OUTPUT.PUT_LINE(l_Result);
                         end;';
                    exception when NO_DATA_FOUND then
                        v_txt := v_txt||c_rpo2.reference||'�� ������ '||chr(13);
                    end;
                    v_txt := v_txt||c_rpo2.reference||'   '||to_char(c_rpo2.date_create,'dd.mm.yyyy hh24:mi:ss')||' - ���������������.'||chr(13);
            else
                dbms_output.put_line(c_rpo2.reference||' - ����������� �� 1-� ������.');
                v_txt := v_txt||c_rpo2.reference||' - ����������� �� 1-� ������.'||chr(13);
            end if;
        end loop;
else
    v_txt := v_txt||'������������� 2 - ���������.'||chr(13);
end if;
v_txt := v_txt||chr(13);
if v_txt is not null then
    P_Email.Send_Mail(Reciever => 'gorodnov@msk.vtb.ru',
                       Subject => '������������� �������� �� (������ -> ��)',
                       Mail_Text => v_txt);
end if;
end;