select * from all_tables where upper(table_name) like '%ACCES%' and owner in ('MBANK','EID') order by owner


21069657
21300735

select rowid,a.* from MBANK.SMS_LOADED a where card in ('4652069813464524') 
--select distinct A.PHONE from MBANK.SMS_LOADED a where --card in ('4652061489471057') 
--eid in ('9163206') 
order by record_id

45507810701950001337        79661921481
45507810301950001410        79661921481
4652065500419680

PHONE
79161258406
79661921481
9161258406

--*******   ��   ***********
--====================================================================
-- �� ���-�������
--====================================================================
-- ����� MBANK
--update sms_note set eid=18043457
select * from SMS_NOTE where sms_id='4652069813464524' --or 
--eid in ('10645071','3526388')

--update sms_variable set eid=18043457
select * from SMS_VARIABLE where sms_id='4652069813464524' --or 
--eid in ('10645071','3526388')

-- ����� EID
select rowid,a.* from EID.SMS_NOTE a where sms_id='4652069813464524' --or 
--eid in ('4652069813464524')

select rowid,a.* from EID.SMS_NOTE_phone a where sms_id='4652069813464524'
--phone in ('79160724851','79153043612')

select rowid,a.* from EID.SMS_VARIABLE a where sms_id='4652069813464524' --or 
--eid in ('9163206')
order by valid_from

select rowid,a.* from EID.SMS_OPERATION a where sms_id='4652069813464524' --or 
--eid in ('9163206')
order by date_work

--�������� ������ �� �������� �� ����� � eid �� ������� �������
/* ��� �������� - ��������� �� �3 ��� ��������� (�������� ���� �����) ��� ��������� - ������������ ����� ���������*/
begin
  psms_daily_eid.prepareaction(pacard => '4652060827025724', paeid => 1343833, pastatus => 1001);
  commit;
end;



begin
  insert into sms_link2another(card, new_sms_eid, old_sms_eid) values('4652069813464524','23494976','26805482');
  commit;                                                                                          
end;
/

--=====================================================
-- ��. ��� �������� �� ����� �����.
--=====================================================
������ ���������, ������������ � ��������:

select sv.*
  from eid.sms_variable sv
where system.smsidx.open_phone(sv.name, sv.subfield, sv.value) = substr(psms_tools.getDigit('79055797147'), -11)

���������� �������� ��������:

declare
  v_ss varchar2(2000);
  v_acc varchar2(200) := '5417151497827425'; --  5584470914139231 9173991687
  v_close_phone varchar2(200) := substr('79266620354', -10);
  v_operId varchar2(100);
begin  
  begin
    insert into sms_dontsend(bal, currency) values(v_acc, 'ALL');
    null;
  exception
    when DUP_VAL_ON_INDEX then
      null;
  end;  
  v_operId := null;
  dbms_output.put_line(substr(psms_daily_eid.closeOnline(v_acc, v_close_phone, 0, 0, null, null, v_operId), 1, 250));
  commit;
end;
/







--**************************************************************************************************
--�����
select 'select * from '||owner||'.'||table_name 
from all_tables where upper(table_name) like '%SMS%' and owner in ('MBANK','EID') order by owner  


select * from EID.SMS_NOTE 
where eid = '16762050' --status = 50 
order by date_open desc

select * from EID.SMS_NOTE_DELETE where eid = '16762050' order by date_open desc

select * from eid.eid_products where reference = 6044941 and eid=16762050

select * from EID.SMS_OPERATION 
where eid = '16762050'
order by date_work desc

select * from EID.SMS_OPERATION_DELETE 
where eid = '16762050'
order by date_work desc

select * from archive where reference = 1007177588 and branch = 191389

select * from archive@krasnodar where reference = 27352854     and branch = 50000

select * from EID.EID_HUMAN_SMS 
--where eid = 16762050 
where phone='9055176699'
order by date_create desc

select * from EID.EID_HUMAN_PACKAGES_SMS --where value = '4652062876035927' 
order by date_variable desc

select * from EID.SMS_VARIABLE 
where eid = '16762050'
order by valid_from desc

select * from EID.SMS_VARIABLE_DELETE 
where eid = '16762050'
order by valid_from desc

select * from EID.SMS_AUDIT 
where oper_id='BNKF22FA782547A06B6E0430A3A448006B6' --'BNKF22FA782547A06B6E0430A3A448006B6'
--where sms_id='4652062876035927'
order by date_work desc


----select * from EID.SMS_SIGN 
----where eid = 16762050
----order by date_open desc

--******************************************************
--select * from EID.SMS_PROXY_LINK

        select * from EID.SMS_OPERATION_DELETE order by date_work desc

select * from EID.SMS_SHEDULER where filial=191

        select * from EID.SMS_SIGN order by date_open desc

        select * from EID.SMS_VARIABLE order by valid_from desc

        select * from EID.SMS_VARIABLE_DELETE order by valid_from desc

select * from EID.TEMP_SMS_PHONE

        select * from EID.SMS_AUDIT order by date_work desc

       !!!select * from EID.EID_HUMAN_PACKAGES_SMS order by date_variable desc

        select * from EID.EID_HUMAN_SMS order by date_create desc

select * from EID.SMS_FREE order by date_create desc

        select * from EID.SMS_NOTE --where eid = '3787842' 
        order by date_open desc

        select * from EID.SMS_NOTE_DELETE order by date_open desc

        select * from EID.SMS_OPERATION order by date_work desc

select * from EID.SMS_PROXY_LOG

-----------------------------------------------------------------
select * from MBANK.SMS_CLIENTS order by date_work desc

select * from MBANK.SCORING_FORMS_SMS_RESULT

select * from MBANK.SMS_STATES order by date_work desc

select * from MBANK.SMS_SENDINFO order by date_create desc

select * from MBANK.SMS_QUEUE

select * from MBANK.SMS_LOADED order by load_date desc

select * from MBANK.SMS_ACTIV

select * from MBANK.SMS_LINK2ANOTHER order by reg_date desc

select * from MBANK.SMS_OPERATION order by date_work desc

select * from MBANK.SMS_RESPONSE









