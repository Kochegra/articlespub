select *
from cbs_errors
where msg_date > sysdate - 0.1 and message like '%UPLOAD_RS%'
order by  msg_date desc


select * from (
select d.*,rownum from documents d where type_doc=203
and date_work=trunc(sysdate)
)
where --nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'IS_ID_CARD'),'z')='1'
--and 
UNIVERSE.VARIABLE_DOC(branch,reference,'PC_APPL_FILENAME') is null
--and UNIVERSE.VARIABLE_DOC(branch,reference,'VIP') = '1'
order by date_create


select rowid,a.* from documents a where reference in (
1144639736,
1145556303
)