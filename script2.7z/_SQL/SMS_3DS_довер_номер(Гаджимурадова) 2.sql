select count(*) from MBANK.ZYX_CONT_CB 

insert into TMP_YAG_CARDLIST (pk,phone)
select c,e from ZYX_CONT_CB

select rowid,a.* from MBANK.TMP_YAG_CARDLIST a --where phone='0'
--where length(trim(phone))!=11
where phone not in (
'79165108036',
'79162634243',
'79999818248')
order by pk

select count(*)-3 from MBANK.TMP_YAG_CARDLIST a --where length(trim(phone))!=11

select count(*) from
(select distinct pk from MBANK.TMP_YAG_CARDLIST a) --where length(trim(phone))!=11


select * from
(select pk,count(pk) as cnt from MBANK.TMP_YAG_CARDLIST group by pk)
where cnt>1


update tmp_yag_cardlist t set phone = ptools_string.CLEARPHONE(phone)