select bm.*, CASE WHEN NVL (ref_doc, 0) > 0 THEN 'True' ELSE 'False' END docs,
         CASE WHEN NVL (ref_cont, 0) > 0 THEN 'True' ELSE 'False' END cons,
         CASE WHEN NVL (ref_miss, 0) > 0 THEN 'True' ELSE 'False' END misses
FROM bots_monitor bm
WHERE date_create BETWEEN trunc(sysdate) AND TRUNC(SYSDATE)+1-1/24/60/60
and name = 'AUTO_MISSIONS'
ORDER BY date_create DESC

--����������

SELECT c.*,
         DECODE (SIGNATURE, 1, 1, 2) SIGN,
         DECODE (STATUS,  0, '',  1, 'X',  '?') cStatus,
         DECODE (NO_SROK,
                 1, '���������.',
                 '�� ' || TO_CHAR (SROK, 'dd.mm.yyyy'))
            cSROK
    FROM CARD_ACCOUNT C
   WHERE --REFERENCE = 23425446 AND BRANCH = 331
            (reference,branch) = (select reference,branch from account where code = '40702810900880009372')
ORDER BY WORK_DATE DESC, SIGNATURE

select * from account where code in ('40702810900880009372')

select us1.* from users us1 where us1.subdepartment in (select subdepartment from account where code in ('40702810900880009372'))
and us1.job in (select job_id from jobs where upper(job) in ('��������� �/�','��������� �-�/�','���������'))
and exists(
SELECT 1
  FROM v$session vs,
       v$process vp,
       users us,
       jobs s,
       subdepartments t
 WHERE     vs.TYPE != 'BACKGROUND'
       AND vs.status != 'KILLED'
       AND vp.addr = vs.paddr
       AND NOT vs.username IN ('SCANNER', 'MBANK')
       /*and client_info like '%RETAIL%'*/
       AND us.user_ = vs.username
       AND s.job_id = us.job
       AND us.subdepartment = t.id
       AND us.USER_ID = us1.user_id--1666416
) 


select * 



macAudit




declare
v_acc           varchar2(2000) := '40702810000340001370';  -- ������� ����
v_acc_close     number := 0; -- 0 - ���� ������, 1 - ���� ������  
v_cli           number := 0;
v_branch_cli    number := 0; 
begin
    --���� �������
    select acc.CLIENT,acc.BRANCH_CLIENT into v_cli,v_branch_cli from account acc where acc.code in (v_acc);
    DBMS_OUTPUT.PUT_LINE('CLIENT = '||v_cli||'     '||'BRANCH_CLI = '||v_branch_cli);
end;
