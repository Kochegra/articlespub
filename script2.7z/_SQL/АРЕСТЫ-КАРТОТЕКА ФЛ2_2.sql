----CF_DOCS
select rowid,a.* from EID.EID_CF_DOCS a where reference=400558--400558

select rowid,a.* from MBANK.CF_DOCS a where reference=400558-- eid=22017583 --reference=22017583
------------------------------------------------------------------

select rowid,a.* from MBANK.CF_ACC a where reference=400558


---- REST_CF_DOCS
select rowid,a.* from MBANK.REST_CF_DOCS a where reference=216338

select rowid,a.* from EID.EID_REST_CF_DOCS a where reference=216338
-------------------------------------------------------------------------


-----CF_COLLECTOR
select rowid,a.* from MBANK.CF_COLLECTOR a where --account='5417150857790512' --
reference=400558

select rowid,a.* from EID.EID_CF_COLLECTOR a where --account='5417150857790512' --
reference=400558
-----------------------------------------------------------------------------------------------------

insert into EID.EID_CF_CARD_COLLECTOR (NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY)
select 
NAME, CARDNUM, REFERENCE, BRANCH, WORK_DATE, REST, SUMMA, SUMMA_CF, RECORD_ID, DOCNUM, USERS, ZBRANCH_DOCNUM, CURRENCY, ACC_CATEGORY
from MBANK.CF_CARD_COLLECTOR a where reference=400558


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.CF_CARD_COLLECTOR a where reference=400558 --cardnum like  '4652080601578276%'

select rowid,a.* from EID.EID_CF_CARD_COLLECTOR a where reference=400558 --cardnum like  '4652080601578276%'
---------------------------------------------------------------------------------------------------------------


-------------CF_CARD_COLLECTOR
select rowid,a.* from MBANK.REST_CF_CARDS a where reference=216338 --cardnum like  '4652080601578276%'

select rowid,a.* from EID.EID_REST_CF_CARDS a where reference=216338 --cardnum like  '4652080601578276%'
---------------------------------------------------------------------------------------------------------------

select rowid,a.* from eid.eid_card_oper a where reference='400558' 
--card_number in ('4652065098284256') --'5417150857790512') 
order by id --work_date desc

declare 
    xret varchar(2);
begin
  ptools2.short_init_user(1403);
  xRET := pcf.mass_deb(22017582,22017584, true, false, false);
  DBMS_OUTPUT.PUT_LINE('1'||xret);
end;


declare
 l_tab ANALYSER.arrest.ARRESTS_TO_OFF_LIST@proc;
begin
  ANALYSER.arrest.EID_OPER_ARREST@proc(35520365, case when l_tab.Count > 0 then l_tab else null end);
end;



select * from MBANK.CF_ERROR_EXECUTE where reference=216338


select pcf_check.saldo_collector(730001,216338,191,sysdate) from dual

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 200, sysdate, 13677 ,191) from dual 

select pcf_check.check_cf(4221063, 15, '40817810700330100007', 41027, sysdate, 1208141832  ,191349) from dual 
