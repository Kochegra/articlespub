        select *
        from eid.eid_card_oper
        where work_date=trunc(sysdate) --and op_status=50
        and op_code in ('INKASSO_OFF') --,'INKASSO_ON','INKASSO_WRITEOFF','INKASSO_WRITEOFF_REV')
        and upper(op_par) like upper('%��������%')
        and branch=191
        

select rowid,doc.* from variable_documents doc where  (reference,branch) in
(select reference,branch from documents where  reference in (1659821375))


select rowid,doc.* from documents doc where  reference in (1659821375)
--union all
--select rowid,doc.* from archive doc where reference in (1136182734,1136194848 )
--or refer_from in (1659821375)
--or related in (1659821375)

select rowid,doc.* from documents doc where  
date_work>=to_date('30.03.2017','dd.mm.yyyy')
and type_doc in (226) and status in (36)
and exists (select type_doc from contracts a where (reference,branch) in 
               (select contract,branch_contract from account where code=doc.payers_account) and type_doc=590)
and not exists (select * from variable_contracts a where (reference,branch) in 
               (select contract,branch_contract from account where code=doc.payers_account)
               and name='CARD_CORP_CONTRACT'
               and value is not null)
--and num_group=180
--and branch=191404 
--and doc_number>980875000 
--and 
--owner in (429913)
--and refer_office like '%19631393%'
--and date_work>=to_date('17.03.2014','dd.mm.yyyy') 
--and summa=3 
--**
--and payers_account like '%42301978001920100083%'  
--or receivers_account like '%4652064565336129%'
--**
--����������� ����������� �������� REFER_FROM=-1
--order by doc_number


select rowid,ec.* from EID.EID_CARD_OPER ec where reference in ('1659821375') 
order by id desc



select * from contracts a where (reference,branch) in (select contract,branch_contract from account where code='40702810701092000481')
and type_doc=590


select * from variable_contracts a where (reference,branch) in (select contract,branch_contract from account where code='40702810701092000481')
and name='CARD_CORP_CONTRACT'
and value is not null
--and not trim(value) = ''

Select * from documents d
where type_doc = 226
and branch = 104
and date_work > trunc(sysdate) - 5
and status in (30, 900)
and exists (Select * from contracts where reference = d.payers_contract and branch = d.branch_payers and type_doc = 590)
and exists (Select * from variable_documents where reference = d.reference and branch = d.branch and name = 'INKP_REF')
and not exists (Select * from variable_documents where reference = d.reference and branch = d.branch and name in ('IP_SKS', 'IN WAY4'))


Select * from archive d
where type_doc = 226
and branch = 104
and date_work > trunc(sysdate) - 5
and status = 30
and exists (Select * from contracts where reference = d.payers_contract and branch = d.branch_payers and type_doc = 590)
and exists (Select * from variable_archive where reference = d.reference and branch = d.branch and name = 'INKP_REF')
and not exists (Select * from variable_archive where reference = d.reference and branch = d.branch and name in ('IP_SKS', 'IN WAY4'))

