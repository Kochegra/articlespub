declare
doa__value varchar2(2000) := null;
nEID number;
sOwner_modify varchar2(2000) := '������������� �������';
nOwner_modify_id number :=1403;
nSubd_modify number :=191;
nOkved varchar2(2000) := null;
v_cnt number :=0;
begin
--    nEID := 91251;
--    nOkved := '46.90'; 
   dbms_output.put_line('���������� �����');
    for rec in (select a,b from ZYX_CONT_CB where a not in (91251)) loop
        nEID := rec.a;
        nOkved := trim(rec.b);
        v_cnt:=v_cnt+1; 
        insert into eid.eid_firma_variable(EID,DATE_MODIFY,STATUS,OWNER_MODIFY,SUBD_MODIFY,PRIORITY,TYPE,VALUE
            ,OWNER_DELETE,SUBD_DELETE,DATE_DELETE
            ,DATE_EXEC
            ,REFERENCE_OBJ,BRANCH_OBJ)
        values (nEID,sysdate,1,'������������� �������',191,1,'OKVED',nOkved
            ,null,null,null
            ,trunc(sysdate)
            ,null,null);
        dbms_output.put_line(v_cnt||'     '||rec.a);
    end loop;
    commit;
--    
   dbms_output.put_line('');
   dbms_output.put_line('������������� � ��� ����������.');
   v_cnt:=0;
    for rec in (select a,b from ZYX_CONT_CB where a not in (91251)) loop
        nEID := rec.a;
        nOkved := trim(rec.b);
        v_cnt:=v_cnt+1; 
        doa__value :=
          eid.p_eid_firma_modify.SynchroClientToFilial (
             nEID               => nEID,
             sOwner_modify      => sOwner_modify,
             nOwner_modify_id   => nOwner_modify_id,
             nSubd_modify       => nSubd_modify);
        dbms_output.put_line(v_cnt||'     '||rec.a);
    end loop;
end;





select a,b from ZYX_CONT_CB

select a,b from ZYX_CONT_CB where a not in (91251)




select rowid,a.* from eid.eid_firma a where eid=91251

select rowid,a.* from eid.eid_firma_variable a where eid=91251 and type='OKVED'


insert into eid.eid_firma_variable(EID,DATE_MODIFY,STATUS,OWNER_MODIFY,SUBD_MODIFY,PRIORITY,TYPE,VALUE
        ,OWNER_DELETE,SUBD_DELETE,DATE_DELETE,
        ,DATE_EXEC
        ,REFERENCE_OBJ,BRANCH_OBJ) --,TABN_MODIFY,TABN_DELETE,ID
--        )
values (91251,sysdate,1,'������������� �������',191,1,'OKVED','46.90'
        ,null,null,null
        ,trunc(sysdate)
        ,null,null) --,null,null   ,        )



insert into eid.eid_firma_variable(EID,DATE_MODIFY,STATUS,OWNER_MODIFY,SUBD_MODIFY,PRIORITY,TYPE,VALUE
        ,OWNER_DELETE,SUBD_DELETE,DATE_DELETE,
        ,DATE_EXEC
        ,REFERENCE_OBJ,BRANCH_OBJ)
values (91251,sysdate,1,'������������� �������',191,1,'OKVED','46.90'
        ,null,null,null
        ,trunc(sysdate)
        ,null,null)



    insert into eid.eid_firma_variable(EID, DATE_MODIFY, STATUS, OWNER_MODIFY, SUBD_MODIFY, PRIORITY, TYPE, VALUE, OWNER_DELETE, SUBD_DELETE,
                                              DATE_DELETE, DATE_EXEC, REFERENCE_OBJ, BRANCH_OBJ)
    select EID, DATE_MODIFY, STATUS, OWNER_MODIFY, SUBD_MODIFY, PRIORITY, TYPE, VALUE, OWNER_DELETE, SUBD_DELETE,
                                              DATE_DELETE, DATE_EXEC, REFERENCE_OBJ, BRANCH_OBJ



insert into eid.eid_firma_variable (EID,DATE_MODIFY,STATUS,OWNER_MODIFY,SUBD_MODIFY,PRIORITY,TYPE,VALUE,OWNER_DELETE,SUBD_DELETE,DATE_DELETE,DATE_EXEC,REFERENCE_OBJ,BRANCH_OBJ,TABN_MODIFY,TABN_DELETE,ID)
values ()


select * from users where user_id=1403


:DOA__VALUE=[NULL]
:NEID=[91251]
:SOWNER_MODIFY=['�������� �.�.']
:NOWNER_MODIFY_ID=[0.982038000e+006]
:NSUBD_MODIFY=[0.191000000e+003]

