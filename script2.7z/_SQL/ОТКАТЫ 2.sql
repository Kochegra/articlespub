--select * from documents where reference=1024342662 and branch=191389

START_PROCESS.WORKING

--** START_PROCESS.WORKING
-- ������� �������� � ��� ����������� ���������
declare
str1 VARCHAR2(2000) := '';
    PROCEDURE myRETURN_INTO_DOCUMENTS(nBRANCH IN NUMBER, nREFERENCE IN NUMBER)
    IS
    BEGIN
           str1 := str1||to_char(nREFERENCE)||',';

           FOR rec IN (SELECT REFERENCE,BRANCH FROM DOCUMENTS
                       where refer_from = nREFERENCE and Branch_from = nBRANCH)
           LOOP
                myRETURN_INTO_DOCUMENTS(rec.BRANCH, rec.REFERENCE);
               --if rec.count = 0 then
               -- str1 := str1||'qqqq';
               --end if; 
           END LOOP;

           FOR rec IN (SELECT REFERENCE,BRANCH FROM ARCHIVE
                       where refer_from = nREFERENCE and Branch_from = nBRANCH)
           LOOP
                myRETURN_INTO_DOCUMENTS(rec.BRANCH, rec.REFERENCE);
           END LOOP;
    END;
begin
    myRETURN_INTO_DOCUMENTS(191389,1024342662);
    str1 := str1;
    --select * from documents where reference in ( 
    DBMS_OUTPUT.PUT_LINE('select rowid, ''DOCUMENTS'' as Tab, d.* from documents d where reference in ('||str1||')'||chr(10)||
                             'union all'||chr(10)||
                             'select rowid, ''ARCHIVE'' as Tab, a.* from archive a where reference in ('||str1||')'   );
end;