select rowid,doc.* from documents doc where  reference in (2458658505,2459574231,2459574232,2459584710)
--union all
--select rowid,doc.* from archive doc where reference in (1136182734,1136194848 )
or refer_from in (2458658505,2459574231,2459574232)
or related in (2458658505,2459574231,2459574232)
--and type_doc in (203) and status in (30)
--and num_group=180
--and branch=191404 
--and doc_number>980875000 
--and 
--owner in (429913)
--and refer_office like '%19631393%'
--and date_work>=to_date('17.03.2014','dd.mm.yyyy') 
--and summa=3 
--**
--and payers_account like '%42301978001920100083%'  
--or receivers_account like '%4652064565336129%'
--**
--����������� ����������� �������� REFER_FROM=-1
--order by doc_number


select * from journal where docnum in (2459574231,2459574232)