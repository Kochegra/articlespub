SELECT col.table_name,
  col.column_name,
  col.data_type,
  col.data_length,
  col.data_precision,
  col.data_scale,
  col.nullable,
  com.comments
FROM ALL_TAB_COLUMNS col
LEFT JOIN user_col_comments com
ON (col.table_name  = com.table_name
AND col.column_name = com.column_name)
WHERE col.TABLE_NAME = 'SMS_NOTE'
ORDER BY table_name,
  column_name;
  
  
SELECT b.*,a.* --object_name 
FROM all_objects a 
LEFT JOIN user_col_comments b
ON (a.object_name  = b.table_name)
--AND col.column_name = com.column_name)
WHERE a.owner = 'EID' AND 
a.object_type = 'TABLE'
--and a.object_name like 'SMS_NOTE'
and a.object_name in ('SMS_NOTE','SMS_OPERATION')
