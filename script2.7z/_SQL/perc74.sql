8185817
17

select rowid,a.*  from COLLECTOR_CONTRACTS a
where reference=8185817  order by work_date

INSERT INTO COLLECTOR_CONTRACTS 
select :name,reference,currency,:dt0,universe.SALDO_COLLECTOR(cc.branch,cc.reference,:name,cc.currency,:dt0)+:ssum
,:ssum,collector_contracts_id.NEXTVAL,-1379,users,branch,to_char(sysdate,'yyyymmdd') from collector_contracts cc where reference = :c_ref and branch = :c_br and rownum < 2
