select *
        from zyx_store where oper like '%INTGR_MB_WAY24%'
        
/        
declare 
   sClobIn    CLOB;
   sCardNum   varchar2(100);
begin    
   sCardNum := '2008-C-872280';       
   sClobIn := PKG_PAY_SKS_GO.SEND_CHECK_FSSPBALANCE_WAY24(p_ContractNo => sCardNum);
   DBMS_OUTPUT.put_line (sCardNum||' in = '||SUBSTR (sClobIn, 1, 4000));
end;
/        

declare 
   sFSSPBalance    varchar2(2000);
   sBalance    varchar2(2000);
   sCardNum   varchar2(100);
begin    
   sCardNum := '2008-C-872280';       
   sBalance := PKG_PAY_SKS_GO.PARSE_BALANCE_WAY24(p_ContractNo => sCardNum);
   sFSSPBalance := PKG_PAY_SKS_GO.PARSE_FSSPBALANCE_WAY24(p_ContractNo => sCardNum);
   DBMS_OUTPUT.put_line (sCardNum||' Balance = '||sBalance);
   DBMS_OUTPUT.put_line (sCardNum||' FSSPBalance = '||sFSSPBalance);
end;

/
declare 
   sBalance    varchar2(2000);
   sCardNum   varchar2(100);
begin    
   sCardNum := '2008-C-872280';       
   
   
end;
/

