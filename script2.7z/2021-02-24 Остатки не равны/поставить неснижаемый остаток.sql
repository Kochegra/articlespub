declare
rContr contracts%rowtype;
addColl varchar2(2000);
nSumNSO number := 18500;
begin
    for rec in (
    
        select --rowid,
        --reference,doc_number,
        -PLEDGER.SALDO (paccount.HEADER_ACCOUNT(doc.payers_account), doc.payers_account,substr(doc.payers_account,6,3), sysdate) saldo,
        --summa,xsummacredit,
        p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,
        doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
        (select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) waycnt,
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'WAY4_DOCEXTID',null) WAY4_DOCEXTID,
        (select count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
        UNIVERSE.VARIABLE_PART(doc.reference,doc.branch,'FSSP_DOC_ID',null) FSSP_DOC_ID,
        --doc.* from v_documents doc
        doc.* from v_documents doc
        --doc.* from archive doc 
        --update documents doc set status=1000
        --where payers_account='40702810410574209389'
            where  (reference in (
            264510313 
            )
            --or refer_from in (5581135657)
            --or related in (
            --264510313 
            --)
            )
    
    
    )loop
        SELECT * INTO rContr FROM contracts WHERE ACCOUNT = rec.payers_account and type_doc=590 and sub_type=1;    
        --if nUpd=1 then
            addColl := UNIVERSE.ADD_COLLECTOR(rContr.BRANCH, 
                                              rContr.REFERENCE, 
                                              'CHANGE_MINREST_3317',
                                              rContr.CURRENCY,   
                                              trunc(sysdate),
                                              nSumNSO,--recDocument.summa,
                                              rec.reference*(-1),   
                                              1403, 
                                              rec.branch);
            commit;
            DBMS_OUTPUT.PUT_LINE('1 CHANGE_MINREST_3317 '||rContr.reference||'/'||rContr.branch);
        --else
        --    DBMS_OUTPUT.PUT_LINE('0 CHANGE_MINREST_3317 '||rContr.reference||'/'||rContr.branch);
        --end if;
                
        update contracts set summa=summa+nSumNSO where reference=rContr.REFERENCE and branch=rContr.branch;-- and nUpd=1;                                                  
        commit;
    
    end loop;
end;
/    

select rowid,a.* from collector_contracts a where (reference, branch) in (select reference,branch from contracts where account='40702810900009004585' and type_doc=590)
order by work_date desc, record_id desc

select rowid,a.* from contracts a where (reference, branch) in (select reference,branch from contracts where account='40702810900009004585' and type_doc=590)
