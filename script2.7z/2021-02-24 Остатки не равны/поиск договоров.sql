-- ����� ���������
select rowid,
-PLEDGER.SALDO(paccount.HEADER_ACCOUNT(c.account), c.account, substr(c.account,6,3),trunc(sysdate)) saldo,
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = c.account) sal,
nvl(UNIVERSE.VARIABLE_CONTRACT(c.BRANCH, c.REFERENCE, 'ARREST_ACTION'),0) arr,
d_3363.contract_action_arrest_n (c.reference, c.branch) action_state, 
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = c.assist) sal_ass,
universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') CONTRACT,
c.* 
from contracts c
where type_doc in (590,94)
--and date_open>=trunc(sysdate)-100
and status=50
and sub_type in (1,0)
--and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
-- ����
--and reference in (5283491) and branch=191-- 40702810200009004599 <- 30301810800810000001
-- �����
and reference in (1611866,5283481,5003577) and branch=191-- 40702810600009004597 <- 30301810800810000001
-- ���
--and reference in (5283486) and branch=191-- 40702810900009004598 <- 30301810800810000001
--and account='40702810300009004596'

select rowid,c.* from variable_contracts c where reference=5283491 and branch=191

select rowid,c.* from collector_contracts c where reference=5283491 and branch=191

select rowid,c.* from rest_contracts c where reference=5283491 and branch=191

select * from variable_clients where (reference,branch) in (select refer_client,branch_client 
                                                        from contracts c where reference=5283486 and branch=191)

-- ������� � �������� ���������
select rowid,ecc.* 
                       from eid.closing_card ecc 
                      where ecc.payers_coracc = '40702810100009004589'
                        and rownum < 2 


--����� �����
select * from documents d
where 
--date_work>=trunc(sysdate)-10
trunc(date_create)>=trunc(sysdate)-10
and 
type_doc=226 
and payers_account='40702810900009004585'

--and status=30
--and exists(select null from contracts where account=d.payers_account and type_doc=590
--                and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
--                and sub_type=0
--                )
and nvl(related,0)=0 
and nvl(refer_from,0)=0 
--and UNIVERSE.VARIABLE_DOC(reference,branch,'IP_SKS')=1 -- ��� �����������
and exists(select null from v_variable_documents where reference=d.reference and branch=d.branch and name in ('INKP_REF'))--,'FSSP_DOC_ID'))
and exists(select null from journal where docnum=d.reference and branch=d.branch)
and exists(select null from v_documents where d.reference in (related,refer_from) and type_doc=1)


-- ������ �����
select --distinct ACCOUNT_NO_RECIPIENT
----count(*) as cnt
--*
--BIK_PAYERS_BANK,BRANCH_NO_PAYER,
--i.ACCOUNT_NO_PAYER,
--paccount.keyaccount(i.ACCOUNT_NO_PAYER,'728') k_728,
(select -pkg_inkp.saldo(0,header,code,currency,trunc(sysdate)) from account where code = I.ACCOUNT_NO_PAYER) sal,
rowid, i.id||',',doc_ref||',',--i.*
(nvl2((select distinct docnum from journal where docnum=I.DOC_REF and branch=I.DOC_BRANCH),'YES','NO')) jour,
(select status from documents where reference=I.DOC_REF and branch=I.DOC_BRANCH) doc_stat,
(select status from archive where reference=I.DOC_REF and branch=I.DOC_BRANCH) arh_stat,
i.ID,i.QUEUE_REFER,i.DATE_LOAD,i.CHANGE_DATE,i.STATUS,i.BRANCH,i.IN_FILIAL,i.DOC_REF,i.DOC_BRANCH,i.ERR_CODE,i.ERR_MSG,
i.ACCOUNT_NO_PAYER,i.ACC_TYPE,i.ACCOUNT_NO_RECIPIENT,i.FILE_NAME,i.PORUCH_NUM,i.SUMM,i.REPLIED,i.REPLY_ID,i.CONFIRM_ID,i.KWT_ID,
i.PAYERS_BANK,i.BIK_PAYERS_BANK,i.STATUS_CODE,i.SUBDEPARTMENT,i.LOG_ID,i.INN_PAYER,i.BIK_RECIPIENT_BANK,I.PAYER,I.SEND_GUID
/*i.FILE_ID,*//*i.DOC_ID,*//*i.OKUD,*//*i.PORUCH_DATE,*//*i.KIND_OF_PAYMENT,*//*i.KPP_PAYER,*//*i.PAYER,*/
/*i.ACCOUNT_NO_PAYERS_BANK,*//*i.BRANCH_NO_PAYER,*//*i.RECIPIENT_BANK,*//*i.ACCOUNT_NO_RECIPIENT_BANK,*/
/*i.INN_RECIPIENT,*//*i.KPP_RECIPIENT,*//*i.RECIPIENT,*//*i.ACCOUNT_NO_RECIPIENT,*//*i.OPERATION_TYPE,*//*i.CODE_PAYMENT_PURPOSE,*/
/*i.NEXT_PAYMENT,*//*i.PAYMENT_CODE,*//*i.RES_FIELD,*//*i.PAYMENT_PURPOSE,*//*i.KBK,*//*i.OKATO,*//*i.PAYMENT_REASON,*/
/*i.PAY_TILL,*//*i.DEMAND_NO,*//*i.DEMAND_DATE,*//*i.PAYMENT_TYPE,*//*i.PORUCH_NO_FCURR,*//*i.PORUCH_DATE_FCURR,*//*i.ACCT_NO_FCURR,*/
/*i.DOC_STATUS,*//*i.REF_CLIENT,*//*i.BRANCH_CLIENT,*/
--,(select g.name from guides g where g.type_doc=5386 and g.code not in 'FORM_STORAGE' and num1=1 and g.code=i.ERR_CODE) G5386
,(select bank_fullname from MBANK.BANKS where mfo_depart=i.BIK_PAYERS_BANK) BANK_NAME
-- UPDATE
from inkp_staging i 
--update inkp_staging i set i.ACCOUNT_NO_PAYER=paccount.keyaccount(i.ACCOUNT_NO_PAYER,'728')
--update inkp_staging i set replied=null,send_guid=null
where i.date_load BETWEEN trunc(sysdate)-50
                    --TO_DATE ('20180101', 'yyyymmdd')
                    AND trunc(sysdate) 
                    --and TO_DATE ('20190326', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
--and acc_type=590
--and branch=191
--and I.STATUS in ('SET TO CATALOGUE2')
--and I.STATUS in ('COMPLETED')
--and i.ACCOUNT_NO_PAYER<>paccount.keyaccount(i.ACCOUNT_NO_PAYER,'728')
--and I.BRANCH in (191)
--and I.ACC_TYPE=590
--and I.DOC_BRANCH in (191)
and exists(select null from contracts where account=I.ACCOUNT_NO_PAYER and type_doc=590 and sub_type in (0,1))

