update inkp_staging i 
set status='PARSED', --'COMPLETED',
branch=null,
in_filial=null,
doc_ref=null,
doc_branch=null,
err_code=null,
err_msg=null,
replied='N'
where i.date_load BETWEEN --trunc(sysdate) 
                    TO_DATE ('20170908', 'yyyymmdd')
                    AND trunc(sysdate) 
                    --TO_DATE ('20180806', 'yyyymmdd') 
                           + 1
                           - 1 / (1 * 24 * 60 * 60)
and I.ID in (1839172)


/

declare
l_Result varchar2(2000);
begin
    mbank.ptools2.short_init_user(1403);--mbfil_admin);
    for rec in (select * from inkp_staging where id in (1717)     )--and status = 'PARSED' /*and queue_refer is not null*/)
      loop
      l_Result := MBANK.PKG_INKP.EXECUTE_INKP(rec.id, 0);
      DBMS_OUTPUT.PUT_LINE(l_Result);
      commit;
    end loop;
end;    
/