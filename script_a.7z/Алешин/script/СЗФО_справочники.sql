select rowid,g.* from guides g where type_doc = 10224 --������ ���� 
select rowid,s.* from guides s where type_doc = 1198 --�������
select rowid,g.* from guides g where type_doc = 4616 --��������� ��� ������ 4686 ����������� (�������)
select rowid,g.* from guides g where type_doc = 589 order by code--��������� ��� �������� 589 �������  (�������)
select rowid,g.* from guides g where type_doc = 9936 --� 9936 ������ ������ ����� c ������ ��������� (�������)
select rowid,g.* from guides g where type_doc = 553 --������� ���������� (�������)
select rowid,g.* from guides g where type_doc = 851 --������� ���������� (�������)
select rowid,g.* from guides g where type_doc = 6626 --��������� ������� ���� ���� ��� � � ������
select rowid,g.* from guides g where type_doc = 11012 --���� ��� ����� ���������� (�������)
select rowid,g.* from guides g where type_doc = 11263 and code = '7724261610' and num1 = 100000 --�������, num1 ��������� � 100000 �� 500000 
select rowid,g.* from guides g where type_doc = 12021 --��������� ��� ���������� �� MAIN (����������������)
select rowid,g.* from guides g where type_doc = 10233  --����������� 10233 (�������� �����)
select rowid,g.* from guides g where type_doc = 12552  --�����������  (�������� �����) ������� ����� ����� ��� ������  
select rowid,g.* from guides g where type_doc = 10036  --�����������  (�������� �����)
select rowid,g.* from guides g where type_doc = 5963 and code like mbfilid||'%'  --��������� ��� ������ ����� �������� + (���-�� ����������������)
select rowid,g.* from guides g where type_doc = 5960 --��������� ���������� ������������� ����� ������ �� MAIN 4087 (�� �������� ���� �� ������)
select rowid,g.* from guides g where type_doc = 7025 --��� ������ 7016
select rowid,g.* from guides g where type_doc = 10751  --����� 30305/30306

 /
--�������
select rowid,g.* from guides g where type_doc = 540
select rowid,g.* from guides g where type_doc = 581 
select rowid,g.* from guides g where type_doc = 820
select rowid,g.* from guides g where type_doc = 851
select rowid,g.* from guides g where type_doc = 1224
select rowid,g.* from guides g where type_doc = 1836
select rowid,g.* from guides g where type_doc = 1958
select rowid,g.* from guides g where type_doc = 2144
select rowid,g.* from guides g where type_doc = 2816
select rowid,g.* from guides g where type_doc = 3467
select rowid,g.* from guides g where type_doc = 4141
select rowid,g.* from guides g where type_doc = 4221
select rowid,g.* from guides g where type_doc = 11263
 /

--�������� ���� ����
select rowid, g.* from guides g where type_doc = 2761 --��������� PSPOS
/

select * from course where work_date > sysdate-1 --����� ����� �������
select * from bank_date where holyday_date > sysdate-1 --��������� ���
/

--������������� ����������� ����� zyx_guides
select * from variable_guides where name not in ('TAGS','FORM','UPD_9999','GRID','ORDERING','GRID2','ORDERING2')

create table zyx_guides as select mbfilid fil_id, u.*  from guides u where rownum < 100

create table zyx_variable_guides as select mbfilid fil_id, u.*  from variable_guides u where rownum < 100

truncate table zyx_guides 

truncate table zyx_variable_guides 

 select * from all_constraints where table_name = 'ZYX_VARIABLE_GUIDES'
  
  alter table ZYX_VARIABLE_GUIDES drop constraint SYS_C00285667

select universe.nametype(type_doc), type_doc,count(*) from guides
 group by type_doc
order by count(*) desc

select universe.nametype(type_doc), type_doc,count(*) from guides g where 
not exists (select null from hash_config where name = 'GUIDE' and instr(text,''''||g.type_doc||'''') > 0)
and type_doc not in (1365,1364,2372,7396,587,586,9936,3772,10036,5183,11295,1363,2097,588,1495,2772,1970,365)
and nvl(owner,0) not in (0,1403)  
group by type_doc
order by count(*) desc
/

/
select * from guides g
/

--������ ��� ������������� ������������ � ��������
declare 
 n varchar2(4000);
 sq varchar2(4000); 
 err varchar2(4000);
 g_list varchar2(4000);
begin
  --g_list := '2135,2761,521,10729,8947,985,5450,1873,1035,4744,4745,12523,12882,8154,1978' ;
  g_list := '553'; 
  for i in  (select vg.value,s.name,s.id from subdepartments s, zyx_variable_guides vg, zyx_guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            and code1 = '200' and g.num1 <> 208 
            )
 loop
   begin 
     sq := 'insert into zyx_variable_guides select * from (select '||i.id||' fil_id, u.* from variable_guides@'||i.value||' u
              where (reference,branch) in (select reference,branch from guides@'||i.value||' where code <> ''FORM_STORAGE'' and type_doc in ('||g_list||')  )) t
            where not exists (select null from zyx_variable_guides where fil_id = t.fil_id and reference = t.reference and branch = t.branch)';
     execute immediate sq;

     sq := 'insert into zyx_guides select * from (select '||i.id||' fil_id, u.* from guides@'||i.value||' u
              where code <> ''FORM_STORAGE'' and type_doc in ('||g_list||') ) t
            where not exists (select null from zyx_guides where fil_id = t.fil_id and reference = t.reference and branch = t.branch)';
     execute immediate sq;
         
   commit;  

        --dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
       rollback;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;      
 end loop;
end;
/

--insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1)
select mbfilid,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1 from zyx_guides@mbdev01 g where 
type_doc = 10224
and not exists (select null from guides where type_doc = g.type_doc and date_work = g.date_work and code = g.code and code1 = g.code1)
/

select * from guides g
--update guides g set str5 = (select str5 from zyx_guides@mbdev01 where type_doc = g.type_doc and date_work = g.date_work and code = g.code and code1 = g.code1 and nvl(substr(str5,-7,7),'-1379') <> nvl(substr(g.str5,-7,7),'-1379') )
--update guides g set str4 = (select str4 from zyx_guides@mbdev01 where type_doc = g.type_doc and date_work = g.date_work and code = g.code and code1 = g.code1 and nvl(substr(str4,-7,7),'-1379') <> nvl(substr(g.str4,-7,7),'-1379') )
where  
 exists (select null from zyx_guides@mbdev01 where type_doc = g.type_doc and date_work = g.date_work and code = g.code and code1 = g.code1 
--and nvl(substr(str5,-7,7),'-1379') <> nvl(substr(g.str5,-7,7),'-1379')
and nvl(substr(str4,-7,7),'-1379') <> nvl(substr(g.str4,-7,7),'-1379')
 )
/

--������ 10224
select rowid,g.* from guides g where type_doc = 10224
--and code = '2520047'
and not exists (select null from account where code = g.str5)  
/

select * from account where
code in (select str5 from guides where type_doc = 10224)
/

select rowid,length(str1),d.* from guides d where type_doc = 11295 and code = '1511206'
/

declare
 aaa varchar2(30);  
 function open_acc(a varchar2) return varchar2 is
  acode varchar2(30);
  aname varchar2(256);
  acfu varchar2(20);
  adep number := mbfilid;
  aown number; 
 begin 
  if length(nvl(a,'')) = 20 then   
   acfu := lpad(global_parameters.get_param('���',adep),4,0);
   aown := global_parameters.get_param('���_�����_��',adep);
   acode := paccount.keyaccount(substr(a,1,9)||acfu||substr(a,14,7),substr(global_parameters.get_param('���_�������',mbfilid),-3,3));
   aname := '����';
   for g in (select d.* from guides d where type_doc = 11295 and code = substr(a,-7,7))
   loop
     aname := substr(g.str1,1,256); 
   end loop;   
   if aname = '����' and substr(a,1,5) = '70606' then
     aname := '������� �� ������������ (������������) �������� �� ��������� ������';
   end if;
   if aname = '����' and substr(a,1,5) = '70601' then
     aname := '������ �� �������������� (����������) �������� �� ��������� ������';
   end if;   
   for aa in (select count(*) cnt from account where code = acode) loop
     if aa.cnt = 0 then
       --dbms_output.put_line('a = '||a||' code = '||acode);
       INSERT INTO account(header,code,currency,open_date, modify_date,lsnum,bal, owner,client,branch_client,name, branch,subdepartment,reference)
       values('A',acode,substr(acode,6,3),trunc(sysdate),sysdate,substr(acode,13,7),substr(acode,1,5),aown,0,0,aname,adep,adep,account_id.nextval);                
     end if;
   end loop;     
   for aa in (select code from account where code = acode) loop
     return aa.code;
   end loop;     
  end if; 
  return null;
 exception when OTHERS then
   dbms_output.put_line('a = '||a||' code = '||acode||' ERR ='||substr(SQLERRM,1,256));
   return null;       
 end; 
begin
  for gd in (select rowid,g.* from guides g where type_doc = 10224 and code <> 'FORM_STORAGE') 
  loop
    for a in (select count(*) cnt from account where code = gd.str4) loop
      if a.cnt = 0 then
        aaa := nvl(open_acc(gd.str4),'ZYX');
        if aaa <> 'ZYX' then
          update guides set str4 = aaa where rowid = gd.rowid; 
        end if;
      end if;
    end loop;  
    for a in (select count(*) cnt from account where code = gd.str5) loop
      if a.cnt = 0 then
        aaa := nvl(open_acc(gd.str5),'ZYX');
        if aaa <> 'ZYX' then
          update guides set str5 = aaa where rowid = gd.rowid; 
        end if;
      end if;        
    end loop;
    --commit;
  end loop;  
end;
/
---------------------------------------

--1198 ������� �� Main ������ code1=200 , ���� �� etalon, ���� �� �������, ������� ������ ��� Branch �������������� = 200
     --insert into guides(branch,FOLDER,TYPE_DOC,OWNER,CHILD,DATE_WORK,CODE,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)
          select mbfilid,FOLDER,TYPE_DOC,OWNER,CHILD,DATE_WORK,CODE,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 from guides@etalon g where type_doc = 1198 
          and not exists (select null from guides where type_doc = g.type_doc and nvl(code,'z') = nvl(g.code,'z')
           and nvl(code1,'z') = nvl(g.code1,'z') and date_work = g.date_work);
           --�������� �          
        --insert into variable_guides(name,reference,branch,value)              
        --  select name,gd_ref,branch,value from variable_guides where (reference,branch) in (select reference,branch  from guides g where type_doc = 5947 and code = to_char(rec.dept_id));
/

 
----------------------------
--��������� ������� ����� ���� ��� � � ������ 
select rowid,g.* from guides g where type_doc = 6626 

 select * from guides g, users u where type_doc = 6626 and g.code = to_char(user_id) 

select * from 
--delete 
zyx_guides@mbdev01 where type_doc = 6626

--�������� ���������� �� ��������� �������
--insert into zyx_guides@mbdev01(folder,type_doc,date_work,code,num1,code1)  
select folder,type_doc,date_work,params,num1,code1 from guides g, users u where type_doc = 6626 and to_char(user_id) = g.code  

--�������� �� ��������
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,num1,code1)  
select guides_reference.nextval,mbfilid branch,folder,type_doc,owner,date_work,code,num1,code1 from 
(select FOLDER,TYPE_DOC,1403 owner,DATE_WORK,to_char(u.user_id) code,NUM1,to_char(sysdate,'J')+to_char(sysdate,'SSSSS') code1 
from zyx_guides@mbdev01 g,users u where type_doc = 6626 and u.params = g.code) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code)
/
----------------------------------
  --��������� ��� ���������� (����������������)
select rowid,g.* from guides g where type_doc = 12021

--insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1)
select BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,'204',NAME,'0063','041117708','������ ����� ��� (��������� ����������� ��������) � �. ������������',STR4,'7702070139',NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1 from guides where 
type_doc = 12021 and code = '201'
/


select * from archive where reference = 4037600
 
select * from audit_table where reference = 9118473

select * from guides where type_doc = 985
/


select * from zyx_variable_guides where (reference,branch,fil_id) in (select reference,branch,fil_id from zyx_guides where type_doc = 553)

select * from zyx_guides where type_doc = 985   
--and branch not like '405%' 

select * from
--delete 
guides where code <> 'FORM_STORAGE' and type_doc = 11012   
--and code not in (select code from guides@lnk_209 where type_doc = 8947)
and code like '9812'
--and branch <> 200

select * from guides@lnk_207 where type_doc = 1978 

select * from zyx_users where new_id = 1037189

select * from users where user_id = 1037189

select * from zyx_guides g, zyx_users u where g.type_doc = 2135 and u.fil_id = g.fil_id
and g.code = to_char(u.user_id) and nvl(u.new_id,0) > 0
/
select * from zyx_guides where code = '985'

/  
--�������� ����������
select date_work,code,nvl(code1,'#'),count(*) from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 985) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
group by date_work,code,nvl(code1,'#')
order by count(*) desc

/
2135
2761
521
10729
8947
985
5450
1873
1035
4744
4745
12523
12882
1978
/
--2135
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,to_char(u.new_id) code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g, zyx_users u where g.type_doc = 2135 and u.fil_id = g.fil_id
and g.code = to_char(u.user_id) and nvl(u.new_id,0) > 0) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#')) 
/

--2761
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,200090,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where branch not like '405%' and type_doc = 2761) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
/

--521
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,to_char(u.new_id) code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g, zyx_users u where g.type_doc = 521 and u.fil_id = g.fil_id
and g.code = to_char(u.user_id) and nvl(u.new_id,0) > 0) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#')) 
/

--10729
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 10729) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
/

--8947
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 8947) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(CODE,'704'), g.* from guides g
--update guides g set code = PACCOUNT.KEYACCOUNT(CODE,'704')  
where type_doc = 8947 and length(code) = 20 and PACCOUNT.KEYACCOUNT(CODE,'704') <> code
/

--985
declare
  ref number;
  t number;
begin
  for rec in (                                                 
            select g.* from zyx_guides g where type_doc = 985
            )
loop
    ref := guides_reference.nextval;
insert into guides (reference,branch,folder,type_doc,status,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select ref, 
t.* from 
(select branch,folder,type_doc,status,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = rec.type_doc and fil_id = rec.fil_id and reference = rec.reference and branch = rec.branch) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'));

insert into variable_guides(name,reference,branch,subnumber,rownumber,colnumber,value,subfield)
select name,ref,branch,subnumber,rownumber,colnumber,value,subfield from zyx_variable_guides vg 
where reference = rec.reference and branch = rec.branch and fil_id = rec.fil_id
and not exists (select null from variable_guides where reference = ref and branch = vg.branch and name = vg.name and nvl(subfield,'#') = nvl(vg.subfield,'#'));  
commit;
end loop; 
end;
/
/*
select PACCOUNT.KEYACCOUNT(value,'704'), g.* from variable_guides g 
--update variable_guides g set str1 = PACCOUNT.KEYACCOUNT(str1,'704')
where (reference,branch) in (select reference,branch from guides where type_doc = 985)    
and length(value) = 20 and PACCOUNT.KEYACCOUNT(value,'704') <> value
--and exists (select null from account where code = PACCOUNT.KEYACCOUNT(value,'704'))
--*/
/

--5450
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 5450) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(str1,'704'), g.* from guides g
--update guides g set str1 = PACCOUNT.KEYACCOUNT(str1,'704')  
where type_doc = 5450 and length(str1) = 20 and PACCOUNT.KEYACCOUNT(str1,'704') <> str1

--update guides g set str2 = PACCOUNT.KEYACCOUNT(str2,'704')  
where type_doc = 5450 and length(str2) = 20 and PACCOUNT.KEYACCOUNT(str2,'704') <> str2
/

--1873
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 1873 and branch <> 203) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
/

--1035
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,fil_id code1 
from zyx_guides g where  type_doc = 1035) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(str2,'704'), g.* from guides g
--update guides g set str2 = PACCOUNT.KEYACCOUNT(str2,'704')  
where type_doc = 1035 and length(str2) = 20 and PACCOUNT.KEYACCOUNT(str2,'704') <> str2
and exists (select null from account where code = PACCOUNT.KEYACCOUNT(str2,'704'))
/

--4744
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where  type_doc = 4744) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
/

--4745
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where type_doc = 4745) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
/

--12523
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,'044030704' str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where type_doc = 12523) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(code,'704'), g.* from guides g
--update guides g set code = PACCOUNT.KEYACCOUNT(code,'704')  
where type_doc = 12523 and length(code) = 20 and PACCOUNT.KEYACCOUNT(code,'704') <> code
and exists (select null from account where code = PACCOUNT.KEYACCOUNT(code,'704'))
/

--12882
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where type_doc = 12882) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(code,'704'), g.* from guides g
--update guides g set code = PACCOUNT.KEYACCOUNT(code,'704')  
where type_doc = 12882 and length(code) = 20 and PACCOUNT.KEYACCOUNT(code,'704') <> code
and exists (select null from account where code = PACCOUNT.KEYACCOUNT(code,'704'))
/

--1978
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where type_doc = 1978) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))

select PACCOUNT.KEYACCOUNT(str1,'704'), g.* from guides g
--update guides g set str1 = PACCOUNT.KEYACCOUNT(str1,'704')  
where type_doc = 1978 and length(str1) = 20 and PACCOUNT.KEYACCOUNT(str1,'704') <> str1
and exists (select null from account where code = PACCOUNT.KEYACCOUNT(str1,'704'))
/

--553
--insert into guides (reference,branch,folder,type_doc,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)  
select guides_reference.nextval,
t.* from 
(select branch,folder,type_doc,nvl((select new_id from zyx_users where fil_id = g.fil_id and user_id = g.owner and nvl(new_id,0) > 0),g.owner) owner 
,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 
from zyx_guides g where type_doc = 1978) t 
where not exists (select null from guides where type_doc = t.type_doc and date_work = t.date_work and code = t.code and nvl(code1,'#') = nvl(t.code1,'#'))
