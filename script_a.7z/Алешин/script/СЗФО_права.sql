select * from global_name

--������ ������ ���������
select * from
--delete 
missions where subdepartment in 200101
(select id from subdepartments s where type in (301,300) and parent <> 0 and (parent < 200 or parent > 209))

select * from 
--delete
PARAMGROUPMEMBERSHIP where depart_id in 200101
(select id from subdepartments s where type in (301,300) and parent <> 0 and (parent < 200 or parent > 209))

/
--�������
select rowid,s.* from
--delete
subdepartments s
--update subdepartments set parent = substr(id,1,3)   
--update subdepartments set name = '�� '||name
where 1=1
--and type in (301,300) and parent <> 0 and (parent < 200 or parent > 209) or type not in (400,301) --��� ����� ������
--and type = 301 and parent = 0 --��� update
--and type = 301 and substr(name,1,3) <> '�� ' --��� update
and parent = mbfilid
order by id
/

----------------
--������ server_address �� ������
select * from subdepartments
--update subdepartments set server_address = (select global_name from global_name),parent_address = (select global_name from global_name) 
where --substr(server_address,3,6) = 'PRE'||mbfilid
server_address <> (select global_name from global_name)

/
--����� ���������
--insert into subdepartments(id,name,parent,server_address,type,parent_address)
select 200005,'������ ����� ���������',mbfilid,server_address,301,parent_address from subdepartments
where id = 200
/

--��������� ����
select * from config
--update config set value = to_char(sysdate,'dd.mm.yyyy')
where name = 'SYSTEMDATE'
/

select * from variable_subdepartments 
--update variable_subdepartments vs set value = (select VALUE from config where name = vs.name)
where depart_id like mbfilid||'%' and name = 'SYSTEMDATE'
/
--------------
--���� ��� ������� ������
select * from
--delete 
jobs j where name is null and not exists (select null from users where job = j.job_id)

select rowid,g.* from groups g
order by group_
--update groups set group_ = 'ADMIN' where group_id = 75005233

--insert into groups(group_id,group_) 
select mbfilid*5000+group_id.nextval,column_value from table(cast(mbank.CONVERT_TOOLS.str2varchar2tbl('ALL,ALL ��������,ALL ���������') as mbank.Varchar2Table)) t
where not exists (select null from groups where Group_ = t.column_value)

--insert into groups(group_id,group_) 
select mbfilid*5000+group_id.nextval,'D'||to_char(id)||' '||trim(substr(name,1,20)) from subdepartments s where parent = mbfilid 
and not exists (select null from groups where instr(group_,s.id) > 0)

--insert into groups(group_id,group_) 
select mbfilid*5000+group_id.nextval,t.* from (select 'J613 ��� '||trim(substr(name,1,20)) group_ from subdepartments s where id = 200000) t
where not exists (select null from groups where group_ = t.group_)

insert into groups_rights(group_id,object_id,code,rights)
--select * from (select group_id,0 object_id,4 code,7 rights from groups where group_ like 'D%' or group_ like 'J613%' or group_ in ('ALL','ALL ���������')) g
--select * from (select group_id,0 object_id,5 code,7 rights from groups where group_ like 'D%' or group_ like 'J613%' or group_ = 'ALL') g
select * from (select group_id,0 object_id,6 code,7 rights from groups where group_ like 'D%' or group_ like 'J613%' or group_ = 'ALL') g
where not exists (select null from groups_rights where group_id = g.group_id and object_id = g.object_id and code = g.code)     

select * from groups_rights where group_id = 1030250 
/

select * from group_membership where group_id = 1040254
/

--������� �����_oo (����� �����)
select rowid,u.* from users u where -- user_ like 'ADM%' 
job = 31445 
--update users set job = 31445 where user_id = 1403 and job <> 31445 
/
--������������� �� ��
select rowid,u.* from users u
--update users u set subdepartment = mbfilid||'000'
where subdepartment = mbfilid 
and job in (175,31378,55)


begin
globals.INIT_USER_EXT('GRUZ');
end;

--��������� ������ 1403
--insert into groups_rights(group_id,object_id,code)
(select g.group_id,user_id,-1
from users u, groups g where user_id = 14231
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
)

--��������� ������ ��� OO
--insert into groups_rights(group_id,object_id,code) (select g.group_id,user_id,-1
--(select u.*, g.* 
from users u, groups g where subdepartment <> mbfilid and job not in(1)
and instr(g.group_,'D'||u.subdepartment||' ') > 0
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
)

--��������� ����� ��� �� 
--insert into group_membership(group_id,user_id) (select g.group_id,u.user_id
--(select u.*, g.* 
from users u, groups g where subdepartment <> mbfilid and job not in(1)
and instr(g.group_,'D'||u.subdepartment||' ') > 0
and not exists (select null from group_membership where user_id = u.user_id and group_id = g.group_id)  
)
/

--�������� �� ����
--insert into groups_rights(group_id,object_id,code) (select g.group_id,user_id,-1
--(select u.*, g.* 
from users u, groups g where subdepartment like mbfilid||'%' and job not in(1,31410)
and instr(g.group_,'ALL') > 0
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
)
/
--�������� � �������
--insert into groups_rights(group_id,object_id,code) (select g.group_id,user_id,-1
--(select u.*, g.* 
from users u, groups g where subdepartment like mbfilid||'%' and instr(g.group_,'ADMIN') > 0 
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
)

--��������� ������������� ��������� �� ���� ����� ���������
select * from users u, groups g where subdepartment like mbfilid||'00%' and job not in(1) and instr(g.group_,u.subdepartment) = 0
/

select * from 
--delete 
group_membership where (group_id,user_id) in (select g.group_id,u.user_id from users u, groups g where subdepartment like mbfilid||'00%' and job not in(1) and instr(g.group_,u.subdepartment) = 0)
/

select rowid,g.* from groups g order by group_
/
--insert into group_membership(group_id,user_id) (select g.group_id,u.user_id
--(select u.*, g.* 
from users u, groups g where subdepartment like '20007%' and
 job in (175) and params <> '-9999'
and exists (select null from boss_emp_all where tab_n = u.params and d_out > sysdate)
and instr(g.group_,'J613 ��� �� � �. ������� (���') > 0
and not exists (select null from group_membership where user_id = u.user_id and group_id = g.group_id)  
)   
/


--insert into groups_rights(group_id,object_id,code) (select g.group_id,user_id,-1
--(select u.*, g.* 
from users u, groups g where instr(g.group_,'J613 �� ������ �����') > 0
and u.job in (613) 
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
)
/

select * from 
--delete 
groups_rights where --group_id in (1000301) and code = -1
--and not exists (select null from users where user_id = object_id and job in (613,31445,175,761,9) and subdepartment  like '20007%')
object_id = 1403 and group_id in (select group_id from groups where substr(group_,1,3) not in ('ADM','ALL')) 
/

select * from 
--delete 
group_membership g where group_id in (1000306,1000299) 
and not exists (select null from users where user_id = g.user_id and job in (336)) 
/
--�������� ���� 336 � ������ ALL ���������

--insert into group_membership(group_id,user_id) (select g.group_id,u.user_id
--(select u.*, g.* 
from users u, groups g where --subdepartment = mbfilid and
 job in(336,217,31160) and params <> '-9999'
and exists (select null from boss_emp_all where tab_n = u.params and d_out > sysdate)
and instr(g.group_,'ALL ���������') > 0
and not exists (select null from group_membership where user_id = u.user_id and group_id = g.group_id)  
) 

/
--������������
select * from users u, boss_emp_all b
                 where subdepartment like mbfilid||'%'
                 and b.tab_n = u.params and u.params <> '-9999' and b.d_out > sysdate and not exists (select null from all_users where username = u.user_)
                 and nvl(global_parameters.get_param(u.user_id,'������',trunc(sysdate)),'0') = '0'
                 and job not in (30809)
                 and length(set_mb_user.decryptpassn_login(u.user_,'PASSWORD')) < 16 and length(set_mb_user.decryptpassn_login(u.user_,'RIGHTS')) < 32

/

--������� ���� �������������
begin
for rec in (select u.user_,set_mb_user.decryptpassn_login(u.user_,'RIGHTS') ora_pswd from users u, boss_emp_all b
                 where subdepartment like '2000%'
                 and b.tab_n = u.params and u.params <> '-9999' and b.d_out > sysdate and not exists (select null from all_users where username = u.user_)
                 and nvl(global_parameters.get_param(u.user_id,'������',trunc(sysdate)),'0') = '0'
                 and job not in (30809)
                 and length(set_mb_user.decryptpassn_login(u.user_,'PASSWORD')) < 16 and length(set_mb_user.decryptpassn_login(u.user_,'RIGHTS')) < 32
                )
loop
  personal.makeOracleUser(rec.user_,rec.ora_pswd,mbfilid);
end loop;                   
end;
/


select * from users u
                 where subdepartment like mbfilid||'%'
                 and u.params = '-9999'
                 and nvl(global_parameters.get_param(u.user_id,'������',trunc(sysdate)),'0') = '0'
                 and job not in (30809,31445)
                 
/

--�������� �������������
--delete zyx_users@mbdev01

--delete zyx_user_param_values@mbdev01

--delete zy�_user_parameters@mbdev01

--delete zyx_users_rights@mbdev01

--insert into zyx_users@mbdev01
 select user_,user_name,user_id, set_mb_user.decryptpassn_login(user_,'PASSWORD') password
   ,job,params,set_mb_user.decryptpassn_login(user_,'RIGHTS') rights, subdepartment from users u


--insert into zyx_users@mbdev01 select * from zyx_user

 insert into zyx_users@mbdev01  
   select   
   user_, user_name,    user_id,    nvl(password,'111'),    job,    params,    nvl(rights,'222'),    subdepartment
 from zyx_users
 
 
select * from zyx_users

create table zyx_users1 as select mbfilid fil_id, u.*, user_id new_id from users u

create table zyx_users_rights as select mbfilid fil_id, u.* from users_rights u

create table zyx_user_parameters as select mbfilid fil_id, u.*  from user_parameters u

create table zyx_user_param_values as select mbfilid fil_id, u.*  from user_param_values u

create table zyx_groups as select mbfilid fil_id, u.*  from groups u

create table zyx_groups_rights as select mbfilid fil_id, u.*  from groups_rights u

create table zyx_group_membership as select mbfilid fil_id, u.*  from group_membership u
  
-- drop table zyx_users
 truncate table zyx_users1

 truncate table zyx_user_param_values

 truncate table zyx_user_parameters
 
 truncate table zyx_users_rights
  
 truncate table zyx_groups
 
 truncate table zyx_groups_rights
 
 truncate table zyx_group_membership
  
 select * from all_constraints where table_name = 'ZYX_USERS1'
  
  alter table ZYX_USERS1 drop constraint SYS_C00285373

/

select * from zyx_group_membership

select * from zyx_users_rights
/
select *  from  zyx_users zu where user_name like '�������%' 
subdepartment like mbfilid||'%' and job <> 31445
                and exists (select null from boss_emp_all where tab_n = zu.params)  
--and user_name like '�������%'

/

select rowid,zu.* 
               from  zyx_users zu where job not in (30809) and new_id is null --and user_id = 1022384
                and exists (select null from boss_emp_all where tab_n = zu.params and d_out > sysdate)
/
select * from users where 
--job = 336  --user_name like '�������%'
user_id = 1032274
/
select * from user_parameters where depart_id = 336 and id = 944
/
select * from user_param_values where user_id = 1022195
/
select * from users_rights where user_id = 1022195
/
select * from group_membership 
/
select user_id,object_id,code,operation,rights from zyx_users_rights@mbdev01 
   where user_id = 1047336
   and not exists (select null from users_rights where user_id = usr_id and object_id = ur.object_id and code = ur.code);
/

 
select * from (select nvl((select id from user_parameters where depart_id = up.depart_id and name = up.name),0) id 
  ,pv.depart_id,1002180 user_id,value,activated from zyx_user_param_values@mbdev01 pv, zy�_user_parameters@mbdev01 up  where activated =
  (select max(activated) from zyx_user_param_values@mbdev01 where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id)
   and up.id = pv.id and up.depart_id = pv.depart_id and pv.user_id = 1047343) tbl
   where id > 0 and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id);

/

--�������� �������������
declare
  usr_id number;
  usr_job number;
begin 
  for usr in (select rowid,zu.* 
               from  zyx_users zu where job not in (30809) and new_id is null --and user_id = 1022384
                and exists (select null from boss_emp_all where tab_n = zu.params and d_out > sysdate)  
                --and user_id = 1047343              
               ) 
  loop
    usr_id := null;
    usr_job := usr.job;
    for u in (select * from users where user_ = usr.user_ or (nvl(params,'0') = nvl(usr.params,'0') and params <> '-9999'))                            
    loop
      usr_job := u.job;            
      usr_id := u.user_id;      
      dbms_output.put_line('����������. u.user_id = '||u.user_id||' u.user_ = '||u.user_||' usr.user_id = '||usr.user_id||' usr.user_ = '||usr.user_);
      update zyx_users set new_id = -usr_id where rowid = usr.rowid;  
    end loop;     
    --��� ������ ����� �� �� ����� �� �� ���������� = ��������� � users
    if usr_id is null then
      dbms_output.put_line('��������� usr.user_id = '||usr.user_id||' usr.job = '||usr.job);
      usr_job := usr.job;
      usr_id := usr.user_id;
      --�� ���������� user_id
      for u in (select * from users where user_id = usr.user_id)                            
      loop          
        usr_id := null;      
      end loop;
      begin     
        insert into users(user_,user_name,user_id,job,params,subdepartment,password,rights)
        values (usr.user_,usr.user_name,usr_id,usr.job,usr.params,usr.subdepartment
        --,'111','111'
         ,nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.password)),'111')
         ,nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.rights)),'111')
        );                       
        commit;
      exception when others then
        rollback;
        usr_job := -1;
        dbms_output.put_line('���������� �������� usr_id = '||usr_id||' usr.job = '||usr.job||' usr.user_name = '||usr.user_name);   
      end;   
      for u in (select * from users where user_ = usr.user_) --�������� ����� user_id                            
      loop          
        usr_id := u.user_id;      
      end loop;
     -- update users set password = nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.password)),'111')
      --                ,rights = nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.rights)),'111') where user_id = usr_id;
         
    end if;
    --���������� �������������� ����� � ��������� ������ ��� ���������� ����
    if usr_job = usr.job then
      usr_id := nvl(usr_id,usr.user_id);
      dbms_output.put_line('���������� ����� usr_id = '||usr_id||' usr.user_id = '||usr.user_id);
      insert into users_rights(user_id,object_id,code,operation,rights)
      select usr_id,object_id,code,operation,rights from zyx_users_rights ur 
      where user_id = usr.user_id and fil_id = usr.fil_id 
        and not exists (select null from users_rights where user_id = usr_id and object_id = ur.object_id and code = ur.code);
      commit; 
      insert into user_param_values 
       select * from (select nvl((select id from user_parameters where depart_id = up.depart_id and name = up.name),0) id 
                      ,pv.depart_id,usr_id user_id,value,activated from zyx_user_param_values pv, zyx_user_parameters up  where activated =
        (select max(activated) from zyx_user_param_values where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id and fil_id = pv.fil_id )
          and up.id = pv.id and up.depart_id = pv.depart_id and up.fil_id = pv.fil_id and pv.user_id = usr.user_id and pv.fil_id = usr.fil_id ) tbl
       where id > 0 and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id);
      commit;  
    end if;
    update zyx_users set new_id = usr_id where rowid = usr.rowid and new_id is null;
    commit; 
  end loop;  
end;
/

select --200000+decode(length(subdepartment),3,(subdepartment-200)*10,(trunc(subdepartment/1000) - 200)*10 + mod(subdepartment,10)) ss
rowid 
,substr(user_,1,6)||subdepartment, substr(user_name,1,7)||subdepartment||')'
,u.* from users u
--update users set subdepartment = subdepartment||'000'  
--update users set subdepartment = 200000+decode(length(subdepartment),3,(subdepartment-200)*10,(trunc(subdepartment/1000) - 200)*10 + mod(subdepartment,10))
--update users set user_ = substr(user_,1,6)||subdepartment, user_name = substr(user_name,1,7)||subdepartment||')'
--where length(subdepartment) = 3 and subdepartment <> mbfilid
where subdepartment not like mbfilid||'%'
--where user_ like 'ADMIN_20%' and instr(user_name,subdepartment) = 0  
/

declare
 pswd varchar2(256);
 rght varchar2(256);
begin
  for usr in (select * from zyx_users zu where nvl(new_id,0) > 0 and not exists (select null from all_users where username = zu.user_) )
  loop
    begin
      pswd := nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.password)),'111');
      rght := nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.rights)),'111');
      update users set password = pswd, rights = rght where user_id = usr.new_id;
      commit;
    exception when OTHERS then   
      rollback;
      dbms_output.put_line('usr.user_id = '||usr.user_id||' usr.password = '||usr.password);
    end;  
  end loop;  
end;
/


select u.*, u1.job job_new from zyx_users1 u1, zyx_users u where u.fil_id = u1.fil_id and u.user_id = u1.user_id 
and u.job <> u1.job and nvl(u.new_id,0) > 0
/
--�������� ���� �������������
declare
  usr_id number;
  usr_job number;
begin 
  for usr in (select u.*, u1.job job_new from zyx_users1 u1, zyx_users u where u.fil_id = u1.fil_id and u.user_id = u1.user_id 
               and u.job <> u1.job and nvl(u.new_id,0) > 0         
               ) 
  loop
     update users set job = usr.job_new where user_id = usr.new_id;
     usr_id := usr.user_id;      
      insert into users_rights(user_id,object_id,code,operation,rights)
      select usr_id,object_id,code,operation,rights from zyx_users_rights ur 
      where user_id = usr.user_id and fil_id = usr.fil_id 
        and not exists (select null from users_rights where user_id = usr_id and object_id = ur.object_id and code = ur.code);
      commit; 
      insert into user_param_values 
       select * from (select nvl((select id from user_parameters where depart_id = up.depart_id and name = up.name),0) id 
                      ,pv.depart_id,usr_id user_id,value,activated from zyx_user_param_values pv, zyx_user_parameters up  where activated =
        (select max(activated) from zyx_user_param_values where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id and fil_id = pv.fil_id )
          and up.id = pv.id and up.depart_id = pv.depart_id and up.fil_id = pv.fil_id and pv.user_id = usr.user_id and pv.fil_id = usr.fil_id ) tbl
       where id > 0 and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id);
      commit;  
  end loop;  
end;
/

update users u set (password,rights) = (select nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.password)),'111') pssw
       ,nvl(utl_raw.cast_to_raw(set_mb_user.enCryptPassN_login(usr.user_,usr.rights)),'111') rght from zyx_users usr where new_id = u.user_id)  
where u.job not in (30809) and password = '0111'

/

--���������� �������������� ����
select * from users where user_id = 1000502398
/

--��������� ����� � ������ ��������
--insert into users_rights (user_id,object_id,code,operation,rights)
select distinct u.user_id,type_id object_id,code,0 operation,(case when code in (4,5,6) then -1 else null end) rights from users u
,(select distinct type_id,code from types start with type_id in (591,592,593,455,232,339,682,428,3543,10425
,593,455,780,7530,417,12001,10596,8087,11149,11742,12655,7433,2313,
4179,2730,2722,2723,1213,12369,12377,5274,10757,10756,5349,5351,998,12417,638,
6590,11810,12082,6077,11803,1586,10717,7301,1680,8575, 
12856,8634,4920,10718,664,5846,5845,3037,6184,6560,1292,515,5858
,8216,7156,4241,4235,3974,4563
,564,8737,7156,614,9273,1153,8361,397,598,420,2330,8947,8575,8963
) --������ ��������
connect by to_char(type_id) = prior manual)  t 
where u.user_id in (1022199) --������ �����
and not exists (select null from jobs_rights where job_id = u.job and CODE = t.code AND object_id = t.type_id)
and not exists (select null from users_rights where user_id = u.user_id and CODE = t.code AND object_id = t.type_id)  
/

--insert into users_rights (user_id,object_id,code,operation,rights)
select distinct u.user_id,type_id object_id,13,0 operation,(case when code in (4,5,6) then -1 else null end) rights from users u
,(select distinct type_id,code from types start with type_id in (8947
) --������ ��������
connect by to_char(type_id) = prior manual)  t 
where code = 11 and u.user_id in (1022199) --������ �����
and not exists (select null from jobs_rights where job_id = u.job and CODE = 13 AND object_id = t.type_id)
and not exists (select null from users_rights where user_id = u.user_id and CODE = 13 AND object_id = t.type_id)  
/
select rowid,u.* from users u where user_name like '��������� �%'
/

 --insert into user_param_values
 select up.id,up.depart_id,u.user_id,'1',trunc(sysdate) from users u, user_parameters up where user_id in (1022199)  
 and up.depart_id = u.job 
 and not exists (select null from user_param_values upv where user_id = u.user_id and depart_id = up.depart_id and id = UP.ID 
                        and activated = (select max(activated) from user_param_values where depart_id = upv.depart_id and id = upv.id and user_id = upv.user_id))
 and up.name in ('������_������_��','������_��������_������','������_��������_����','������_8575','������_8575_�����') 

/
 

593,455,780,7530,417,12001,10596,8087,11149,11742,12655,7433,2313,
4179,2730,2722,2723,1213,12369,12377,5274,10757,10756,5349,5351,998,12417,638,
6590,11810,12082,6077,11803,1586,10717,7301,1680,8575, 
12856,8634,4920,10718,664,5846,5845,3037,6184,6560,1292,515,5858
/

8216,7156,4241,4235,3974,4563
/


1000502423,1000502406,1000752512,1001952570,1001952585,1003402700,1003402690,1001852222,1001852224,1001852223
1003402678,1001852256
1000502398
1000502422,1003396,1002962,1000752484,1000752492,1003226,1002987,1000752562,1003373,1003225,1002980,1002982,1004003471,1004002880
,1003372,1004002901,1004002929,1002977,1003398,1004002879,1004002906,1001952624,1001952569,1001952610,1001952576,1001952615,1001952626
,1001952643,1001952641,1001952598,1003003,1001952625,1001952616,1001952600,1002963,1001952620,1003386,1003402669,1003402665,1003402668
,1003402667,1003402717,1003402725,1003402666,1003402702,1002970,1003402709,1001852325,1001852369,1000502413,1001852317,1001852264
,1001852261,1001852296,1001852316,1001852236,1001852229,1001852315,1001852230
1000752498,1003402727

/

select distinct u.user_id,type_id,code,0, (case when code in (4,5,6) then -1 else null end) rights 
from users u, (select distinct type_id,code from types start with type_id in (593,592)
connect by to_char(type_id) = prior manual) t
where u.user_id in (1000502422)



select distinct u.user_id,type_id object_id,code,0 operation,(case when code in (4,5,6) then -1 else null end) rights,manual,job from types t, users u
where u.user_id in (1000502422)
start with type_id in (593,592)
connect by to_char(type_id) = prior manual


select * from types t
--where u.user_id in (1000502422)
start with type_id in (593,592)
connect by to_char(type_id) = prior manual
/

select * from boss_emp_all where tab_n = 234064
/
--���������
select rowid,u.* from users u where params = '-9999'
and job not in (1,31445) and subdepartment like mbfilid||'%'
/

--������������ �����������
select
nvl((select b.tab_n from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash
and bb.tab_n = u.params and bb.d_out < sysdate and b.d_out > sysdate and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate) 
),params) tt,
u.* from users u
--update users u set params = nvl((select b.tab_n from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash and bb.tab_n = u.params and bb.d_out < sysdate and b.d_out > sysdate and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate)),params)
where u.params <> '-9999'
and job not in (1,31445) and subdepartment like mbfilid||'%'
--and user_id = 1001852361
and params in (select tab_n from boss_emp_all where d_out < sysdate)
and nvl((select b.tab_n from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash
         and bb.tab_n = u.params and bb.d_out < sysdate and b.d_out > sysdate 
         and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate)), '0') <> '0'  
  
/


select * from boss_emp_all b, boss_emp_all bb  where b.passp_hash = bb.passp_hash
and bb.tab_n = 310622 and bb.d_out < sysdate and b.d_out > sysdate-- and b.d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate) 
/

select
(select tab_n from boss_emp_all b  where passp_hash = (select passp_hash from boss_emp_all where tab_n = u.params) 
and d_modify = (select max(d_modify) from boss_emp_all where passp_hash = b.passp_hash and d_out > sysdate) 
) tt,
u.* from users u where u.params <> '-9999'
and user_id = 1001852361 
/

select * from boss_emp_all where passp_hash in 
(select passp_hash from boss_emp_all b where b.tab_n <> '-9999' and b.tab_n = 400880)
/
--����� ���������
--insert into user_param_values 
select * from 
(select up.id,up.depart_id,u.user_id
,(select appoint_name from boss_emp_all b where d_out > sysdate and tab_n = u.params) value
,trunc(sysdate)-1 activated from users u, user_parameters up where up.name = '���������' and up.depart_id = u.job) tbl 
 where id > 0 and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id)
 and value is not null
/

--����������� ����
declare
  usr_id number;
  
begin 
  for usr in (select zu.* from zyx_users zu, users u where nvl(zu.new_id,0) = u.user_id and u.job = zu.job       
               ) 
  loop
    usr_id := usr.new_id;
    --���������� �������������� ����� � ��������� ������ ��� ���������� ����
    dbms_output.put_line('���������� ����� usr_id = '||usr_id||' usr.user_id = '||usr.user_id);
    insert into users_rights(user_id,object_id,code,operation,rights)
      select usr_id,object_id,code,operation,rights from zyx_users_rights ur 
      where user_id = usr.user_id and fil_id = usr.fil_id 
        and not exists (select null from users_rights where user_id = usr_id and object_id = ur.object_id and code = ur.code);
      commit; 
      insert into user_param_values 
       select * from (select nvl((select id from user_parameters where depart_id = up.depart_id and name = up.name),0) id 
                      ,pv.depart_id,usr_id user_id,value,activated from zyx_user_param_values pv, zyx_user_parameters up  where activated =
        (select max(activated) from zyx_user_param_values where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id and fil_id = pv.fil_id )
          and up.id = pv.id and up.depart_id = pv.depart_id and up.fil_id = pv.fil_id and pv.user_id = usr.user_id and pv.fil_id = usr.fil_id ) tbl
       where id > 0 and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id);
      commit;  
  end loop;  
end;
/

--insert into groups(group_id,group_) 
select mbfilid*5000+group_id.nextval,'D'||to_char(id)||' '||trim(substr(name,1,20)) from subdepartments s where id like '2000%' 
and not exists (select null from groups where instr(group_,s.id) > 0)
/

select User_ "�����",User_NAME "���",(select name from jobs where job_id = u.JOB) "����"
    ,UNIVeRSE.namedepart(subdepartment) "�������" from users u 
    where
    subdepartment = 200 
    --subdepartment like '200%' and (substr(subdepartment,4,1) <> '0' or subdepartment in (200000,200))   
    and job not in (1,31445,31410,30809,30955,30845,491)
order by subdepartment,job 
/

select * from subdepartments where id like '200%' and (substr(id,4,1) <> '0' or id in (200000,200)) 
/

--������������ ������������� c 200 �� ��

select rowid,u.* from users u where
params = '234061' 
--user_id in (1047388 )
--and subdepartment <> 200151

select * from group_membership where user_id = 1001852295
/

select * from 
--delete 
 group_membership where (group_id,user_id) in 
(select g.group_id,u.user_id from users u, groups g, subdepartments s where user_id = 1001852295 and s.id in 
(select depart_id from variable_subdepartments where name like 'HEAD_DEPART' and value = u.subdepartment union select u.subdepartment from dual)
and job not in(1) and instr(g.group_,s.id) = 0)
/

select * from users u, groups g, subdepartments s where user_id = 1000752488 and s.id in 
(select depart_id from variable_subdepartments where name like 'HEAD_DEPART' and value = u.subdepartment union select u.subdepartment from dual)
and length(s.id) > 3
and job not in(1) and instr(g.group_,s.id) > 0
/
select * from groups where group_id in (1000254,1000263,1000265)
/
select * from variable_subdepartments where name like 'HEAD_DEPART' and value = '200370'
/

select * from groups_rights where object_id = 1000752488 and group_id in (select group_id from groups where group_ like 'D%') 
  and group_id not in
    (select g.group_id from users u, groups g, subdepartments s where user_id = 1000752488 and s.id in 
     (select depart_id from variable_subdepartments where name like 'HEAD_DEPART' and value = u.subdepartment union select u.subdepartment from dual)
     and length(s.id) > 3 and job not in(1) and instr(g.group_,s.id) > 0); 

/
declare
  dep number := 200680; 
begin
  for usr in (select rowid,u.* from users u where user_id in 
(1003402681,1003402671,1003402661,1003402685,3371,1003402660,1003402683,1003402692)
and subdepartment <> dep)
loop
  update users set subdepartment = dep where rowid = usr.rowid;
  delete group_membership where user_id = usr.user_id and group_id not in
    (select g.group_id from users u, groups g, subdepartments s where user_id = usr.user_id and s.id in 
     (select depart_id from variable_subdepartments where name like 'HEAD_DEPART' and value = to_char(dep) union select dep from dual)
     and length(s.id) > 3 and job not in(1) and instr(g.group_,s.id) > 0);
  delete groups_rights where object_id = usr.user_id and group_id in (select group_id from groups where group_ like 'D%') 
  and group_id not in
    (select g.group_id from users u, groups g, subdepartments s where user_id = usr.user_id and s.id in 
     (select depart_id from variable_subdepartments where name like 'HEAD_DEPART' and value = dep union select dep from dual)
     and length(s.id) > 3 and job not in(1) and instr(g.group_,s.id) > 0); 
 --��������� ����� ��� �� 
  insert into group_membership(group_id,user_id) (select g.group_id,u.user_id from users u, groups g where user_id = usr.user_id
  and length(dep) > 3  and job not in(1) and instr(g.group_,dep) > 0
  and not exists (select null from group_membership where user_id = u.user_id and group_id = g.group_id) );

  insert into group_membership(group_id,user_id) (select g.group_id,u.user_id from users u, groups g where user_id = usr.user_id
  and length(dep) > 3  and job not in(1) and instr(g.group_,dep) > 0
  and not exists (select null from group_membership where user_id = u.user_id and group_id = g.group_id) );
  
  insert into groups_rights(group_id,object_id,code) (select g.group_id,user_id,-1
from users u, groups g where length(dep) > 3 and job not in(1) and instr(g.group_,dep) > 0 and user_id = usr.user_id
and not exists (select null from groups_rights where object_id = u.user_id and group_id = g.group_id)  
);
         
end loop;
end;
/

200370
1001852295,1001852231,1001852315,1001852236,1001852318,1001852230,1001852266,1001852296,1001852316,1001852220,1001852336,1001852345,1001852235,1001852309,1001852341,1001852234,1001852233,1001852229

200390
1001952599,1001952602,1001952572,1001952615,1001952566,1001952643,1001952623,1038218,1001952626,1001952592,1001952567,1038183,1038165,1038206,1001952629

200100
1038204,1038180,1047296,1000502412

200150
1000752537,1000752546,1000752516,1000752558

200151
1000752488

200680
1003402681,1003402671,1003402661,1003402685,3371,1003402660,1003402683,1003402692
/

--������������ �����
select substr(group_,1,8)||(select substr(name,1,21) from subdepartments where id = substr(g.group_,2,6))  
 ,g.* from groups g
--update groups g set group_ = substr(group_,1,8)||(select substr(name,1,21) from subdepartments where id = substr(g.group_,2,6))  
where group_ like 'D%' and substr(group_,2,6) > '200099'
/

--���������
select rowid,u.* from users u where params in 
(select params from users where params <> '-9999' group by params having  count(*) > 1)
order by params


select * from audit_table where user_id = 1022252

select * from boss_emp_all where tab_n = 235359

select * from boss_emp_all where l_name = '��������' and F_name = '�������'
and d_out > sysdate

/

