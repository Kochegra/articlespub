--���������
select * from subdepartments where id like '20%'
/
--insert into subdepartments
select * from subdepartments@lnk_209 s where id like '209%'
and id not in (select id from subdepartments)
/
--��� ���� ��������
select * from variable_subdepartments where depart_id like '20%'
/
--insert into variable_subdepartments
select * from variable_subdepartments@lnk_209 s where depart_id like '209%'
and (name,depart_id,rownumber) not in (select name,depart_id,rownumber from variable_subdepartments)
/
--���������� HEAD_DEPART = ���
select rowid, v.* from variable_subdepartments v where name = 'HEAD_DEPART' and depart_id like '200%'
/
--������ ���������� ���������
select * from paramgroupmembership where depart_id like '20%'
/

--insert into paramgroupmembership
select * from paramgroupmembership@lnk_209 s where depart_id like '209%'
and (group_id,depart_id) not in (select group_id,depart_id from paramgroupmembership)
/

--�������� ����������
select * from paramvalues
/
--insert into paramvalues
select pp.id,pv.paramgroupid,pv.departid,pv.value,pv.activated from parameters@lnk_209 p, paramvalues@lnk_209 pv, parameters pp 
where p.id = pv.paramid and p.group_id = pv.paramgroupid and (paramid,paramgroupid,departid,activated) in
(select paramid,paramgroupid,departid,max(activated) from paramvalues@lnk_209 where departid like '209%'
group by paramid,paramgroupid,departid)
and p.name = pp.name and (pp.id,pv.departid) not in (select paramid,departid from paramvalues) 
 /
--------------
--����� ������� ������ �������
declare 
-- n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
 err varchar2(4000);
begin
  for fl in  (
            select g.num1 id,vg.value lnk,s.name from subdepartments s, zyx_variable_guides vg, zyx_guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            and code1 = '200' and g.num1 = 202
            )
 loop
   begin
     sq := 'insert into subdepartments
            select * from subdepartments@'||fl.lnk||' where id like '''||fl.id||'%'' and id not in (select id from subdepartments)';
--dbms_output.put_line('1 '||sq);
 execute immediate sq;
     sq := 'insert into variable_subdepartments
            select * from variable_subdepartments@'||fl.lnk||' where depart_id like '''||fl.id||'%''
              and (name,depart_id,rownumber) not in (select name,depart_id,rownumber from variable_subdepartments)';
--dbms_output.put_line('2 '||sq);
 execute immediate sq;
     sq := 'insert into paramgroupmembership
            select * from paramgroupmembership@'||fl.lnk||' where depart_id like '''||fl.id||'%''
              and (group_id,depart_id) not in (select group_id,depart_id from paramgroupmembership)';
--dbms_output.put_line('3 '||sq);
 execute immediate sq;
     sq := 'insert into paramvalues
            select pp.id,pv.paramgroupid,pv.departid,pv.value,pv.activated from parameters@'||fl.lnk||' p, paramvalues@'||fl.lnk||' pv, parameters pp 
            where p.id = pv.paramid and p.group_id = pv.paramgroupid and (paramid,paramgroupid,departid,activated) in
              (select paramid,paramgroupid,departid,max(activated) from paramvalues@'||fl.lnk||' where departid like '''||fl.id||'%''
                 group by paramid,paramgroupid,departid)
              and p.name = pp.name and (pp.id,pv.departid) not in (select paramid,departid from paramvalues)';     
     execute immediate sq;
commit;
     --dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := fl.lnk||' �� ������';
      -- n := null;
      rollback;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     commit; rollback;
     begin
       dbms_session.close_database_link(fl.lnk);
     exception when OTHERS then
       dbms_output.put_line(fl.lnk||'��� �����');
     end;    
   end if;      
 end loop;
end;
/

--� ������ ����� id
select * from paramgroupmembership
-- update paramgroupmembership set depart_id = 200000+decode(length(depart_id),3,(depart_id-200)*10,(trunc(depart_id/1000) - 200)*10 + mod(depart_id,10))
where depart_id not like '200%' and length(depart_id) = 6 

select * from paramvalues 
-- update paramvalues set departid = 200000+decode(length(departid),3,(departid-200)*10,(trunc(departid/1000) - 200)*10 + mod(departid,10))     
where departid not like '200%' and length(departid) = 6  
/

select * from variable_subdepartments vd
-- update variable_subdepartments set depart_id = 200000+decode(length(depart_id),3,(depart_id-200)*10,(trunc(depart_id/1000) - 200)*10 + mod(depart_id,10))
where depart_id not like '200%' and length(depart_id) = 6 
and not exists (select null from variable_subdepartments where depart_id = 200000+decode(length(vd.depart_id),3,(vd.depart_id-200)*10,(trunc(vd.depart_id/1000) - 200)*10 + mod(vd.depart_id,10))
and name = vd.name )
/ 


select 200000+decode(length(id),3,(id-200)*10,(trunc(id/1000) - 200)*10 + mod(id,10)) newid,s.* from subdepartments s  
where id not like '200%' and length(id) = 6  


select p.* from paramvalues as of timestamp (sysdate-3/24) p
--update guides g set code = PACCOUNT.KEYACCOUNT(code,'704') 
where departid = 200020 
--and nvl(length(regexp_replace(value,'[^[[:digit:]]]*')),0) = 20 and PACCOUNT.KEYACCOUNT(value,'704') <> value
--and exists (select null from account where code = PACCOUNT.KEYACCOUNT(value,'704'))

select * from admin_audit where tablename like 'PARAMVALUES' and time > trunc(sysdate) 
and oldvalue = '200020'
