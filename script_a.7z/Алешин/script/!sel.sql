--������� ������� ��������� ADMIN 
declare
  usr_job number := 31445;
  usr_tabn varchar2(250) := '-9999'; 
  cnt number;
  new_id number;  
  cur_id number;
  cursor crs_id is select user_id from users where user_id = new_id;
begin
 for rec in (SELECT 'FTS_EXCHANGE_SIGNER' usr_,'��������� JaCartaApp.exe ('||s.id||')' usr_name, s.* 
                    FROM subdepartments s where id = mbfilid 
                    )       
 loop
   cnt := 0; 
   select count(*) into cnt from users where user_ = upper(rec.usr_);
   if cnt = 0 then
     -- ��������� id ������������
      loop
        cur_id := 0;
        new_id := mbfilid*1000000+user_id.nextval;      
        open crs_id;
        fetch crs_id into cur_id;
        close crs_id;
        exit when new_id <> cur_id;  
      end loop;
     insert into users(user_id,user_,user_name,password,job,params,rights,subdepartment) values(new_id,rec.usr_,rec.usr_name
     ,'A230AFFEF92BDC60A8456829D677DF1A',usr_job,usr_tabn,'78AECA443A21A8AD6476BAB88EDA3042',rec.id);
   end if;
   --commit;  
 end loop;                   
end;
/
commit;
exit;
/
