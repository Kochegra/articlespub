select * from users where user_id = 1007202
/
select * from types where type_id = 4315
/


select rowid,a.* from account a
--update account set subdepartment=200000
--update account set owner=1403
--update account a set owner = (select user_id from users where subdepartment = a.subdepartment and user_ = 'ADMIN_'||a.subdepartment)
where 1=1 
--and nvl(subdepartment,mbfilid)=mbfilid and substr(code,1,3) not in ('301','303','444','555','706','777','999')
--and nvl(owner,0) = 0
--and owner not in (select user_id from users)
and owner = 1403 and length(subdepartment) > 3   
/

--��������� �������� � ����������, � �� ������� (�������� ����� � ��������� �������)
select 
(select count(*) from account where client = a.reference and branch_client = a.branch and subdepartment <> a.subdepartment)  val
,a.* from clients a
--update clients a set owner = (select user_id from users where subdepartment = a.subdepartment and user_ = 'ADMIN_'||a.subdepartment)
--update clients a set subdepartment = (select subdepartment from users where user_id = a.owner)
where 1=1
--and nvl(subdepartment,0) = 0
--and nvl(owner,0) = 0 
--and subdepartment = mbfilid and status = 310 and exists (select null from users where user_id = a.owner and subdepartment <> subdepartment)
--and owner not in (select user_id from users)
--and owner = 1403 and exists (select null from account where client = a.reference and branch_client = a.branch and subdepartment <> a.subdepartment)
and owner = 1403 and length(subdepartment) > 3 and status > 10 and status < 100  
/

select * from contracts
--update contracts set subdepartment = mbfilid
--update contracts set  owner=global_parameters.get_param('���_�����_��',subdepartment)
 where 1=1 
 --and nvl(subdepartment,0) = 0
 --and   nvl(owner,0) = 0 
--and  owner not in (select user_id from users)
and owner = 1403 and length(subdepartment) > 3 and status > 10 and status < 100     
/

select * from contracts a
--update contracts a set subdepartment=(select subdepartment from account where code = a.account and subdepartment <> a.subdepartment)
--update contracts a set subdepartment=(select subdepartment from clients where reference=a.REFER_CLIENT and branch=a.BRANCH_CLIENT and subdepartment <> a.subdepartment)
--update contracts a set owner=(select owner from account where code = a.account and owner <> a.owner)
where 1=1 and status in (50,70,60) and type_doc not in (715)
and nvl(subdepartment,mbfilid)=mbfilid and exists (select null from clients where reference=a.REFER_CLIENT and branch=a.BRANCH_CLIENT and type_doc=4 and folder=2)
--and exists (select null from account where code = a.account and subdepartment <> a.subdepartment)
--and exists (select null from clients where reference=a.REFER_CLIENT and branch=a.BRANCH_CLIENT and subdepartment <> a.subdepartment)
and nvl(owner,1403) = 1403 and exists (select null from account where code = a.account and owner <> a.owner)
/


--�� ��������� refer_from = null ������ �� 0
select * from contracts
--update contracts set refer_from = 0, branch_from = 0  
where 
--refer_from is null 
--related is null
--refer_client is null
owner is null

/

--����� ��� ������������ 
select (select nvl(UNIVERSE.VARIABLE_CLIENT(branch,reference,'CORPORATION_FULL_NAME'),Full_name) from clients where reference = a.client and branch = a.branch_client) nm 
,a.* from account a --AS OF TIMESTAMP (TO_TIMESTAMP ('17.09.2018 19:00:40', 'dd.mm.yyyy hh24:mi:ss.ff')) a 
--update account a set name = (select nvl(UNIVERSE.VARIABLE_CLIENT(branch,reference,'CORPORATION_FULL_NAME'),Full_name) from clients where reference = a.client and branch = a.branch_client) 
where name is null and nvl(client,0) <> 0  
/

--����������� ����� 90902 � ���������  ��������
select (select count(*) from account where contract = c.reference and branch_contract = c.branch and code like '90902%' and close_date is null and currency = c.currency) cnt, c.* from contracts c
--update contracts c set assist = (select code from account where contract = c.reference and branch_contract = c.branch and code like '90902%' and close_date is null and currency = c.currency) 
where assist is null and type_doc = 94 and status = 50
and exists (select null from account where contract = c.reference and branch_contract = c.branch and code like '90902%' and close_date is null and currency = c.currency)          
/
select * from account where contract = 557015 and branch_contract = 207 and code like '90902%' and close_date is null
/
select * from 
--delete 
variable_contracts 
where name = 'CARD_ACCOUNT_2' and (value,reference,branch) in (select code,contract,branch_contract from account where code like '90902%' and close_date is null)    
/
--�� ��������
select *
--insert into variable_contracts(name,reference,branch,value) select 'CARD_ACCOUNT_2',a.contract,a.branch_contract,a.code   
from account a 
where code like '90902810%' and close_date is null and contract <> 0
and not exists (select null from variable_contracts where reference = a.contract and branch = a.branch_contract and name like 'CARD_ACCOUNT_2%') 
and exists (select null from contracts where reference = a.contract and branch = a.branch_contract and currency <> '810')
/


--��� ������ ����� � ���������
 select
  --(select count(*) from contracts where account = a.code and status in (50,60) and status = 50 and summa > 0 ) val
  (select count(distinct c.reference) from variable_contracts vc, contracts c where type_doc not in (715) and value = a.code and c.reference = vc.reference and c.branch = vc.branch and c.status in (50,60) and name not like '%CORACC%') val 
 ,a.* from account a
 --update account a set (contract,branch_contract) = (select reference,branch from contracts where account = a.code and status in (50,60) and status = 50 and summa > 0 ) 
 --update account a set (contract,branch_contract) = (select distinct c.reference,c.branch from variable_contracts vc, contracts c where type_doc not in (715) and  value = a.code and c.reference = vc.reference and c.branch = vc.branch and c.status in (50,60) and name not like '%CORACC%')
 where nvl(contract,0) = 0 and close_date is null and client > 0
 --and (select count(*) from contracts where account = a.code and status in (50,60) and status = 50 and summa > 0) >= 1 
  --and (select count(*) from contracts where account = a.code and status in (50,60) ) > 1
 --and client = 180748
 --and exists (select null from variable_contracts vc, contracts c where type_doc not in (715) and value = a.code and c.reference = vc.reference and c.branch = vc.branch and c.status in (50,60) and name not like '%CORACC%')
 --and code like '91414%892'
/

--��� ������ ����� � ��������
 select
  (select count(*) from contracts c, clients cl where c.reference = a.contract and c.branch = a.branch_contract and cl.reference = c.refer_client and cl.branch = c.branch_client ) val
 ,a.* from account a
 --update account a set (client,branch_client) = (select refer_client,branch_client from contracts c, clients cl where c.reference = a.contract and c.branch = a.branch_contract and cl.reference = c.refer_client and cl.branch = c.branch_client)  
 where contract > 0 and close_date is null and nvl(client,0) = 0


/
select * from contracts where
account = '47423810884000003645' 
(reference,branch) in
(select reference,branch from variable_contracts where value = '45818810086000000940')
/

select * from variable_contracts where value = '40902840192000000009'

/
select rowid,a.* from account a where code in 
'40702978384000000436'
/

--� ��������� ����� ��� ������ ��������� ������ ��� ���������
select * from documents 
--update documents set RECEIVERS_CURRENCY = substr(receivers_account,6,3)
where status = 35 and nvl(RECEIVERS_CURRENCY,'z') = 'z'

--��� RECEIVERS_CORACC �� ���������� ���������� 
select * from documents d 
--update documents d set RECEIVERS_CORACC = (select corr_acc from banks_all b where mfo_depart = '044525716' and rowid = (select max(rowid) from banks_all where mfo_depart = b.mfo_depart))
where status = 35 and type_doc = 226 and nvl(RECEIVERS_CORACC,'z') = 'z' and substr(RECEIVERS_ACCOUNT,1,5) not in ('40101','40302') 

select * from banks_all b where mfo_depart = '044030809'
and rowid = (select max(rowid) from banks_all where mfo_depart = b.mfo_depart)
/

select * from users where user_id in (1037204)
select * from zyx_users where user_id = 1037204

select * from account where code like '40702810484%2443'   
/
--���������� ��������� owner ����� �������� �������������
select (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) own,
 a.* from account a
--update account a set owner = (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) )
where subdepartment like '2000%' and subdepartment not like '____0_'
and nvl(owner,0) in (select user_id from zyx_users where nvl(new_id,0) > 0 and user_id <> new_id 
and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) 
--and code like '40702810484%2443'    
/

select (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) own,
 a.* from contracts a
--update contracts a set owner = (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) )
where subdepartment like '2000%' and subdepartment not like '____0_'
and nvl(owner,0) in (select user_id from zyx_users where nvl(new_id,0) > 0 and user_id <> new_id 
and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) 
--and reference = 621868   
/

select (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) own,
 a.* from clients a
--update clients a set owner = (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) )
where subdepartment like '2000%' and subdepartment not like '____0_'
and nvl(owner,0) in (select user_id from zyx_users where nvl(new_id,0) > 0 and user_id <> new_id 
and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) ) 
/

select (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.xsubdepartment) ) own,
 owner,a.* from documents a
--update clients a set owner = (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) )
where status > 0 and status < 1000 and xsubdepartment like '2000%' and xsubdepartment not like '____0_'
and nvl(owner,0) in (select user_id from zyx_users where nvl(new_id,0) > 0 and user_id <> new_id 
and xsubdepartment in (select old_id from szrc_mirg where new_id = a.xsubdepartment) ) 
/

select (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.xsubdepartment) ) own,
 owner,a.* from archive a
--update clients a set owner = (select new_id from zyx_users where nvl(new_id,0) > 0 and user_id = a.owner and subdepartment in (select old_id from szrc_mirg where new_id = a.subdepartment) )
where status > 0 and status < 1000 and xsubdepartment like '2000%' and xsubdepartment not like '____0_'
and nvl(owner,0) in (select user_id from zyx_users where nvl(new_id,0) > 0 and user_id <> new_id 
and xsubdepartment in (select old_id from szrc_mirg where new_id = a.xsubdepartment) ) 
and rownum < 1000
/