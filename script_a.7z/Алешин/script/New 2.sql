select rowid,a.* from account a where 
code = '40502810480000000102'
--code like '6030981031%15'
--contract = 779941

select rowid,c.* from contracts c where 
--refer_client = 302266 and type_doc = 94  
--account like '40702810337002014036'
reference = 1208001

select rowid,c.* from variable_contracts c where 
--account like '40702810337002014036'
reference = 993647

select rowid,c.* from collector_contracts c where 
--account like '40702810337002014036'
reference = 993647

select * from parameters where name in ('����_���_��������_�����������')

select * from parameters where name like '��_����������_%'

select rowid,g.* from guides g where type_doc = 11012

select rowid,d.* from documents d where --RECEIVERS_INN ='7710353606' 
--type_doc = 12916 and status = 30
reference in (101334168) --666100910091
--refer_from = 101087805


select rowid,d.* from archive d where --RECEIVERS_INN ='7710353606' 
--type_doc = 12916 and status = 30
reference in (101076055)
 
select * from documents where type_doc = 226 and status = 30 --reference = 101077391

select rowid,d.* from variable_documents d where reference in (101073877)

select * from u_reports where modify_date > sysdate-1 rep_id = 8040   

select * from users where
--user_name like '��������� %'
subdepartment = 200800

select rowid,t.* from tax_contracts t where reference in (807547,817252,817334,817335,810567) and operation = '800371'

select rowid,t.* from taxs_contracts t where reference = 817386

SELECT rowid,p.* FROM PERCENT_CONTRACTS p WHERE REFERENCE = 993647 AND BRANCH = 200 AND OPERATION = '204110' ORDER BY WORK_DATE DESC 

select rowid,j.* from jobs_rights j where job_id = 31445 and object_id = 12877

select rowid,j.* from users_rights j where object_id = 12877

select * from chg_obj where status = 0

select * from audit_table where reference = 100062422


create table zyx_doc_20181117 as
select * from documents where type_doc = 2 and date_work = '17nov2018' and num_group = '8889'

select * from journal where work_date = '17nov2018'

--insert into journal_zp
select * from journal
--delete journal
--where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978))
where (docnum,branch) in (select reference,branch from zyx_doc_20181117)
/

--insert into journal
select j.* from journal_zp j
where (docnum,branch) in (select reference,branch from zyx_doc_20181117)
--and users = 1403
/ 

--update journal_zp 
set work_date = '19nov2018', value_date = '19nov2018'
--set rsum = 8200, vsum = 8200
where (docnum,branch) in (select reference,branch from zyx_doc_20181117)
/

select * from documents
--update documents set date_work = '19nov2018', date_value = '19nov2018'
where (reference,branch) in (select reference,branch from zyx_doc_20181117)
/

select * from plan_account where bal = '40101'

--select * from users

select * from variable_documents  
where name = 'DATE_PAYERSBANK' and value is not null
and (reference,branch) in (select reference,branch from documents where type_doc in (226,2,225) and status = 35) 
/

alter table zyx_variable_documents alter column subnumber default 0

select * from account 

select * from journal_delete where docnum = 100914612 

select * from journal where docnum = 101076053 

select rowid,a.* from mbank_audit.audit_table a where reference = 100914612 

d_cash

D_1161

/

