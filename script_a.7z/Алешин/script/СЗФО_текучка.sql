select * from smtp_messages where upper(reciever) = upper('fanera@jakor.ru')
/

select * from documents where reference = 9231732

select * from collector_contracts where reference = 558233

select rowid,c.* from contracts c where reference = 558233 --type_doc = 12575
and exists (select null from collector_contracts where reference = c.reference and branch = c.branch and name = 'CARDLIST_2')

/
--���������� ������ � ��������� 
--INSERT INTO COLLECTOR_CONTRACTS 
select NAME,REFERENCE,CURRENCY,WORK_DATE,REST,SUMMA,collector_contracts_id.NEXTVAL,DOCNUM,USERS,BRANCH,ZBRANCH_DOCNUM from 
(select 'CARDLIST_2' name,payers_contract reference,payers_currency currency,date_work work_date
,0 rest, 0 summa,reference docnum,owner users,branch_payers branch,branch zbranch_docnum from documents 
where status = 35 and reference in (9231732,9237115)) t
where not exists (select null from collector_contracts where reference = t.reference and branch = t.branch and name = t.name
and docnum = t.docnum and zbranch_docnum = t.zbranch_docnum) 
/



--insert into journal_zp
select * from journal
--delete journal
--where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978))
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in ( 100967734,100980381))
/

--update journal_zp 
set work_date = '19-jul-2018', value_date = '19-jul-2018'
--set rsum = 8200, vsum = 8200
 where  (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (100967734,100980381))
/

--insert into journal
select * from journal_zp
--select * from journal_delete
--select rowid,j.* from journal_zp j
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (100967734,100980381))
/
30305810891000101001


exptools_routing.getAccMF4HEAD_Cl