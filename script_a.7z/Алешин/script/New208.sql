select * from v$session where 1=1
--program = 'retail.exe' 
--and username like 'NWR35290'
and osuser = 'NWR35290'


select * from documents where 
date_create > sysdate-6 and date_work >= to_date('03.11.2021','dd.mm.yyyy') and type_doc not in (8225)
--date_create > sysdate-1 and status > 0 and status < 1000 and status not in (22,30,35,36,45) and type_doc not in (8225)
order by date_create desc


select to_date('01.01.2000','dd.mm.yyyy')+related, j.* from journal j where
-- work_date >= trunc(sysdate)-1
 work_date >= trunc(sysdate)
--and operation = '519002'
order by related desc 

select * from journal 
--delete journal
where docnum = 15506923 and journal_id=14249694

select * from clients where date_modify > trunc(sysdate)

select * from contracts where date_modify > to_date('04.11.2021','dd.mm.yyyy')
order by date_modify desc

select * from account where modify_date > to_date('04.11.2021','dd.mm.yyyy')
order by modify_date desc

select trunc(sysdate)-1,c.* from config c where name like '%CLOSE%'

select rowid,c.* from config c where name like '%CLOSE%'

select * from cbs_errors where msg_date > sysdate -3
and message not like '"CM"."TRF_BOT" FIN_ERROR:%'
order by msg_date desc

select * from audit_table where time > sysdate-1
and upper(action) like '%�����%'
order by time desc

select * from ERROR_EXECUTE where time > sysdate -1
order by time desc

select * from mb_od_log where start_time > trunc(sysdate)-1
order by start_time

select s.* from shed_jobs s where 
--task_name in ('SUBO1','SZRC_TELEBANK')
--task_name like '%TELE%'
text like '%198;%'

select rowid,s.* from shed_jobs s where 
--task_name in ('SUBO1','SZRC_TELEBANK')
job_name in ('OD_194_CHECK_NSO_PREV_DAY','OD_192_CMO_CLOSE','OD_198_CLOSE_NEW_NSO')

select * from shed_hist where started >trunc(sysdate)-1 
order by started desc
/

select * from shed_tasks where active is null



select * from shed_tasks where task_name not in ('ADMINISTRATIVE','BOSS','SUBO1','CHG_OBJ','OUR_TASKS','SUPPORT','EMAIL','SKHOD_UNLOAD','RATES')
and active = 1 
order by task_name

SCD,MQ,IMPEX,JBPR,��������������� ���������
/

select * from tbl_queue_KFT_MB_MQ where mod_dt > sysdate-1/24

select * from tbl_queue_KFT_MQ_MB where create_dt > sysdate-1/12

select * from tbl_queue_SWA_MQ_MB where create_dt > sysdate-1/12

select * from tbl_queue_SWA_MB_MQ where create_dt > sysdate-1/12

select * from tbl_queue


select * from MBANK_AUDIT.mb_audit WHERE DT > TRUNC(SYSDATE)
ORDER BY DT desc

/

    begin
      p_operday.movedocuments(to_date('01.01.2021','dd.mm.yyyy'),to_date('04.11.2021','dd.mm.yyyy'));
    end;
    /

--��������� �����  
    begin
mbank.verif_load.init_all('208');
end;
/

select global_parameters.get_param('FILIAL_CODE',208)
,global_parameters.get_param('���',208)
 from dual


 select global_parameters.get_param('���_�������',208)
,global_parameters.get_param('���',208)
 from dual
 
 
 select * from journal_delay
 
