select rowid,c.* from config c where name = 'SYSTEMDATE'

select * from variable_subdepartments
--update variable_subdepartments set value =(select value from config c where name = 'SYSTEMDATE')   
where name = 'SYSTEMDATE' 
and value <> (select value from config c where name = 'SYSTEMDATE')
/

113896440

1002183 1002201
/
select * from users where user_id in (1002183, 1002201)
/

select rowid,d.* from documents d where reference in (113934349,113934687) --(113896440,113902582)

select rowid,d.* from audit_table d where reference in (113902582)
/

--������� ���������
declare
     doc_owner number;
      j                NUMBER;
   tmp1             VARCHAR2(2000);
   tmp2             VARCHAR2(2000);
   status19 boolean;
   resDoc varchar2(4000);
  begin
  for doc in (select rowid,d.* from documents d where reference in (113934349))
  loop 
    doc_owner := 1002183;
    mbank.ptools2.short_init_user(doc_owner); 
    j := null; tmp1 := NULL; tmp2 := NULL;
    dbms_output.put_line('resDoc = '||resDoc||' start - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
    resDoc := DOCALGO.EXECDOC(doc.branch, doc.reference, doc_owner, j, tmp1, tmp2);
    --resDoc := start_process.WORKING(2, 5, doc.branch, doc.reference, null, j);
    dbms_output.put_line('resDoc = '||resDoc||' finish - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
    commit;                   
  end loop; 
end; 
/


select
MAX((select count(*) from collector_contracts where docnum = D.REFERENCE)) CNT, 
min(time),max(time) from audit_table d where reference in (113934349)
and time > (select max(time) from audit_table where reference = d.reference and branch = d.branch and action = '��������')
and time < nvl((select max(time) from audit_table where reference = d.reference and branch = d.branch and action = '���������'),time+1)

select count(*) from collector_contracts where docnum = 113896440

select count(*),min(date_create),max(date_create) from documents where refer_from = 113896440 

/

declare
  xMemo varchar2(4000);
  xRET VARCHAR2(2000);
xSTAGE NUMBER := 175;
xOD_ID NUMBER;
xDate DATE := to_date('30.04.2019','dd.mm.yyyy');
xBranch NUMBER;
begin  
    ptools2.short_init_user(1403);
  xMemo := '���������� ��������� � ����� ������ (6776)';
  dbms_output.put_line('6776 ����� = '||xRET||' start - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  xRET := MBANK.p_6776.count_all_contracts(xDate);
  dbms_output.put_line('6776 ����� = '||xRET||' finish - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  COMMIT;
end; 
/

declare
  xMemo varchar2(4000);
  xRET VARCHAR2(2000);
xSTAGE NUMBER := 175;
xOD_ID NUMBER;
xDate DATE := to_date('01.06.2019','dd.mm.yyyy');
xBranch NUMBER;
begin  
    ptools2.short_init_user(1403);
  xMemo := '�������� ��������� �������� � ������������� ������� (���������� �������)';
  dbms_output.put_line('6776 = '||xRET||' start - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  xRET := MBANK.p_6776.close_all_contracts(xDate);
  --xRET := p_7500.close_all_contracts(xDate);
  dbms_output.put_line('6776 = '||xRET||' finish - '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  COMMIT;
end; 
/

select type_doc,count(*) from contracts where type_doc in(3709,3710,6774,6776,4184) and status=50 and date_work = to_date('01.06.2019','dd.mm.yyyy')
group by type_doc
/
select count(*) from documents where type_doc = 3247 and date_create > sysdate-1/2 and doc_number = '�������'

select * from documents where type_doc = 3247 and date_create > sysdate-1 and payers_operation = '201100'

select (select count(*) from collector_contracts where docnum = d.reference) cnt, 
date_create,
(select max(date_create) from documents where refer_from = d.reference and branch_from = d.branch) dt_finish
 from documents d where reference = 113992818
 
 select * from audit_table where time > sysdate-1/48