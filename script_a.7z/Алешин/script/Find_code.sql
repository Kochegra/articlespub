select replace(text,' ',''),a.* from all_source a 
where --type like '%TRIGGER%'
instr(replace(upper(text),' ',''),replace(upper(:str),' ','')) > 0 --and name like '%REP%'
--and  instr(upper(text),upper('�� �������')) > 0 
--and owner = 'MBANK'
/

select * from TBL_ENTITY_SQL w
where instr(upper(W.SQL_TXT),upper(:str)) > 0
/

/
select * from all_objects where object_name in ('TBL_DEILT_MESSAGE_BI','DOC_ROUTING',upper('impex_1tools'))
(select distinct name from all_source where instr(upper(text),upper(:str)) > 0)
--select * from all_views where  instr(upper(text),upper(:str)) > 0
/
DEILT_EXCHANGE
eid.P_EID_TOOLS5

PTOOLS_PK_LOCAL

PCOMMUNAL

D_1683

select * from sforms where instr(upper(text),upper(:str))>0
--and instr(upper(text),upper('VIP'))>0
/

select * from types where type_id in (10269,11512,11511) 
/
select * from all_objects where object_name like '%TMP_JOURNAL_INFO%' owner = 'MBANK' and 
/

select universe.nametype(type_doc),type_doc,count(*) 
from guides where (
+ instr(nvl(replace(upper(name),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str1),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str2),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str3),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str4),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str5),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code1),' ',''),'z'),replace(upper(:str),' ',''))
) > 0
--and type_doc not in (9999,1312,1364,1365,3454,453,2372,969,1363,1978,985,4512,4853,1970,5096,4895,4336,5761
--,6701,2761,3384,6433,4765,3752,7168,1979,5027,5079,2867,5215,2895,4978)
--and type_doc in 9922
--985 8846   8350 
group by type_doc order by count(*) desc
/

select rowid,d.* from guides d where type_doc = 985  and 
(
+ instr(nvl(replace(upper(name),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str1),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str2),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str3),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str4),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str5),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code1),' ',''),'z'),replace(upper(:str),' ',''))
) > 0
/

select rowid,d.* from VARIABLE_GUIDES d where reference = 44595690

select * from variable_guides where instr(upper(value),:str) > 0

Select * from types where type_id = 124

select * from guides where type_doc = 3451

select * from all_tables where table_name like '%LOAN%' and owner in ('MBANK','EID') 3312594 

select * from shed_jobs where  instr(upper(text),upper(:str)) > 0 

select * from dba_jobs  where instr(upper(what),upper(:str)) > 0

select * from SMTP_MESSAGES where instr(upper(reciever),upper(:str)) > 0  

select * from all_tables where table_name like '%SMTP%'

select * from text_files where 


PDEMAND_LOG.canStartMassPerc


ptools_course_join.Send_New_By_Group;
/

select * from course where currency =  '975' and course <> 0

select * from SHED_HIST where job_name = 'info_kiosk'

select * from shed_jobs where job_name in ('info_kiosk','web_anketa')

/

select * from audit_table where reference = 587891
/

select * from account where header = 'A' and code like '303__840%01001'