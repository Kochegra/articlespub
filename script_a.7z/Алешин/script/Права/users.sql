select * from users_all where 
user_name like '�������� �%'
--user_id = 520002024
tab_n = 1040377

select * from users where user_id = 1577572  = 'MAKAROVA_NV2'

select 1603214 user_id,* from users_rights where user_id = 992183 

select 1603210 user_id,object_id,code,operation,rights from users_rights  where user_id = 1577572 and object_id <> '0'


select rowid, d.* from documents d where reference = 2595116470 


--insert into users_rights
select * from (select u.user_id,ur.object_id,ur.code,ur.operation,ur.rights from users_rights ur, users u where ur.code = 13 and ur.user_id = 1571773 
--and not exists (select null from users_rights ur where user_id = u.user_id and object_id = object_id and code = ur.code and operation = ur.operation)
and u.user_id in (1574066,1570200,1603210,1603212,1603213,1603214,1603215,1603217,1603252,1603253,1603255)) users_rights

1574066
1570200


select * from users where user_id in (1574066,1570200,1603210,1603212,1603213,1603214,1603215,1603217,1603252,1603253,1603255)


�������������_�������    
�������_�������                


select * from account where code like '30102810%'   

select * from users where user_ = 'SHARLAY_VV'


select set_mb_user.decryptpassn_login(Upper(u.user_), 'PASSWORD'),u.* from users u where subdepartment = 405003


select * from jobs_rights where depart_id 


select * from users_all where user_id in (983203,520241358)


select * from users where subdepartment = 312 and user_name like '���%'

select * from users_rights

--insert into users_rights(user_id,object_id,code,operation,rights)
select u.user_id,ur.object_id,ur.code,ur.operation,ur.rights from users_rights ur, users u where ur.user_id = 1603210 
and not exists (select null from users_rights  where user_id = u.user_id and object_id = ur.object_id and code = ur.code and operation = ur.operation)
and u.subdepartment =  and u.user_id <> ur.user_id 


select rowid,vs.* from variable_subdepartments vs where depart_id = 312  


select rowid,vs.* from config vs where depart_id = 312  

select user_id from users u where user_ in (select  replace(user_,substr(user_,-3),'') from users u where user_id = ur.user_id)

--����������� ����

begin
globals.INIT_USER_EXT('GRUZ');
insert into users (USER_,USER_NAME,user_id,PASSWORD,JOB,PARAMS,RIGHTS,SUBDEPARTMENT)
select replace(user_,substr(user_,-3),''),user_name||'(3)',user_id.nextval,PASSWORD,JOB,PARAMS,RIGHTS,405003 
 from users u where user_id in (2025002092,2025002093,2025002090,2025002125,1636237,1636238);
end;     


insert into users_rights(user_id,object_id,code,operation,rights)
select (select user_id from users u where user_ in (select  replace(user_,substr(user_,-3),'') from users u where user_id = ur.user_id)),ur.object_id,ur.code,ur.operation,ur.rights from users_rights ur, users u where ur.user_id in (2025002092,2025002093,2025002090,2025002125,1636237,1636238)
and not exists (select null from users_rights  where user_id = (select user_id from users u where user_ in (select  replace(user_,substr(user_,-3),'') from users u where user_id = ur.user_id)) 
and object_id = ur.object_id and code = ur.code and operation = ur.operation)
and u.subdepartment = 405000 and u.user_id = ur.user_id 
/

--insert into user_param_values
select upv.id,upv.depart_id,(select user_id from users u where user_ in (select  replace(user_,substr(user_,-3),'') from users u where user_id = upv.user_id)),value,trunc(sysdate)-1
 from user_param_values upv, users u where upv.user_id in (2025002092,2025002093,2025002090,2025002125,1636237,1636238) and u.user_id = upv.user_id and u.job = upv.depart_id
and activated = (select max(activated) from user_param_values where id = upv.id and depart_id = upv.depart_id and user_id = upv.user_id and activated <= trunc(sysdate)) 
and u.subdepartment = 405000  
--and not exists (select null from user_param_values where user_id = (select user_id from users u where user_ in (select  replace(user_,substr(user_,-3),'') from users u where user_id = ur.user_id))
--and depart_id = upv.depart_id and value code = ur.code )
/

select * from groups_rights where group_id in (select group_id from groups where substr(group_,1,3) in ('ADM','ALL'))
and object_id in (select user_id from users where subdepartment in (405011,405007,405000,405003))