users -- ID ��������� �� ��   
  --������
    if :new.user_ID is null then
      <<again>>
      select user_id.nextval into ttt from dual;
      if (nvl(mbone(0), 0) <> 1) then
        ttt := ttt + :new.Subdepartment * 5000;
      end if;
      open aaa;
      fetch aaa
        into bbb;
      IF aaa%FOUND THEN
        close aaa;
        goto again;
      end if;
      close aaa;
      :new.user_ID := ttt;
      :new.user_   := Upper(:new.user_);
    end if;
--������
 if :new.user_ID is null then
      a := 0;
      <<again>>
      ttt := user_id.nextval;
      if (nvl(mbone(0), 0) <> 1) and mbfilid <> mbgoid then        
            ttt := mbfilid*1000000+ttt;
      end if;
      open aaa;
      fetch aaa
        into bbb;
      IF aaa%FOUND and a < 1000000 THEN
        a := a + 1;     
        close aaa;
        goto again;
      end if;
      close aaa;
      :new.user_ID := ttt;
      :new.user_   := Upper(:new.user_);
    end if;
---------------------------------
users_rights -- update-��� id �� ������������� sequence
  --������
       if :new.id is null then
          select id into bbb from subdepartments where server_address=
                 ( select global_name from global_name) and rownum < 2;
<<again>>
          select user_rights_id.nextval into ttt from dual;
          ttt := bbb*5000+ttt;
          begin
               select id into bbb from users_rights where id = ttt;
               goto again;
          exception
                   when others then NULL;
          end;
          :new.ID := ttt;
       end if;
 --������
        if :new.id is null then
         :new.ID := user_rights_id.nextval;
       end if;         
---------------------------------
user_parameters --�������������� ������ sequence �� ������������� ID
  --������
---       
         if :new.ID is null then
        select id into bbb from subdepartments where server_address=
               ( select global_name from global_name) and id <> 0 and rownum < 2;
<<again>>
         select user_parameters_ID.nextval into ttt from dual;
--  begin
       ttt := bbb * 5000 + ttt;
--   select id into b from user_parameters where id=ttt;
--   goto again;
--  exception when no_data_found then
--    :new.ID := ttt;
--  end;
        :new.ID := ttt;
      end if;
---
--������
    if :new.ID is null then
        :new.ID := user_parameters_ID.nextval;
      end if;
          
--------------------------------------
jobs -- ��� �������� ������ �������� +1000000 �� branch
  --������
       if :new.job_id is null then
          select id into bbb from subdepartments where server_address=
                 ( select global_name from global_name) and rownum < 2;
<<again>>
          select job_id.nextval into ttt from dual;
          ttt := bbb*5000+ttt;
          begin
               select job_id into bbb from jobs where job_id = ttt;
               goto again;
          exception
                   when others then NULL;
          end;
          :new.job_ID := ttt;
       end if;
 --������
       if :new.job_id is null then
<<again>>
          select job_id.nextval into ttt from dual;
          if mbfilid <> mbgoid then
            ttt := mbfilid*1000000+ttt;
          end if;  
          begin
               select job_id into bbb from jobs where job_id = ttt;
               goto again;
          exception
                   when others then NULL;
          end;
          :new.job_ID := ttt;
       end if;
---------------------------------       
 jobs_rights --update-��� id �� ������������� sequence
    --������
           if :new.id is null then
          select id into bbb from subdepartments where server_address=
                 ( select global_name from global_name) and rownum < 2;
<<again>>
          select job_rights_id.nextval into ttt from dual;
          ttt := bbb*5000+ttt;
          begin
               select id into bbb from jobs_rights where id = ttt;
               goto again;
          exception
                   when others then NULL;
          end;
          :new.ID := ttt;
       end if;
  --������
         if :new.id is null then
          :new.ID := job_rights_id.nextval;
       end if;
       
-----------------------------------
groups -- ID ��������� �� �� 
--������
    if inserting then
<<again>>
	if :new.group_ID is null then
	  	select id into bbb from subdepartments where server_address=
	 		( select global_name from global_name) and rownum < 2;
		select group_id.nextval into ttt from dual;
		ttt := bbb*5000+ttt;
		open aaa;
		fetch aaa into bbb;
		IF aaa%FOUND THEN
			close aaa;
			goto again;
		end if;
		close aaa;
		:new.group_ID := ttt;
	end if;
  --������
    if inserting then
<<again>>
	if :new.group_ID is null then
		ttt := group_id.nextval;
		if mbfilid <> mbgoid then
            ttt := mbfilid*1000000+ttt;
        end if;  
		open aaa;
		fetch aaa into bbb;
		IF aaa%FOUND THEN
			close aaa;
			goto again;
		end if;
		close aaa;
		:new.group_ID := ttt;
	end if;
-----------------------------
groups_rights --update-��� id �� ������������� sequence
--������
   if :new.id is null then
    select id into bbb from subdepartments where server_address=globals.globalname
     and rownum < 2;
<<again>>
        select group_rights_id.nextval into ttt from dual;
  ttt := bbb*5000+ttt;
  begin
   select id into bbb from groups_rights where id = ttt;
   goto again;
  exception
   when others then NULL;
  end;
       :new.ID := ttt;
  end if;
--������
   if :new.id is null then      
     :new.ID := group_rights_id.nextval;
   end if;