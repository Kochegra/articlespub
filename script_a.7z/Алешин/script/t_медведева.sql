select * from documents where reference in (101127923)

select * from archive where reference in (101127923)

select * from variable_documents where reference = 101127304

select * from variable_archive where reference = 101128613

select * from documents where type_doc = 3823 and receivers_inn = '5047085094'

select * from guides where type_doc = 4330 and  str5 = '5047085094'

Universe.

select * from variable_guides where reference = 1390228372

select SUMMA
,(select universe.VARIABLE_GUIDES(BRANCH,REFERENCE,'BAGSIMBOL') from guides where type_doc = 4330 
 and to_char(num3) = UNIVERSE.VARIABLE_PART(refer_from,branch_from,'POINTID')) ksm_Sym
,(select universe.VARIABLE_GUIDES(BRANCH,REFERENCE,'POINTALIAS') from guides where type_doc = 4330 
  and to_char(num3) = UNIVERSE.VARIABLE_PART(refer_from,branch_from,'POINTID')) ALIAS
,universe.VARIABLE_PART(reference,branch,'NUMBAG') BAG
,(select to_char(date_document,'dd.mm.yyyy') from (select * from documents union select * from archive)
where reference = a.refer_from and branch = a.branch_from) FDATE  
--,memo 
--replace(memo,'{SUMMA}',summa,'BAG',universe.variable_arch(reference,branch,'NUMBAG')),
 ,a.* from archive a where 
type_doc = 3823 and date_work = '21nov2018' and receivers_inn = '5047085094'
/



select SUMMA
,(select universe.VARIABLE_GUIDES(BRANCH,REFERENCE,'BAGSIMBOL') from guides where type_doc = 4330 
 and to_char(num3) = UNIVERSE.VARIABLE_PART(refer_from,branch_from,'POINTID')) ksm_Sym
,(select universe.VARIABLE_GUIDES(BRANCH,REFERENCE,'POINTALIAS') from guides where type_doc = 4330 
  and to_char(num3) = UNIVERSE.VARIABLE_PART(refer_from,branch_from,'POINTID')) ALIAS
,universe.VARIABLE_PART(reference,branch,'NUMBAG') BAG
,(select to_char(date_document,'dd.mm.yyyy') from (select * from documents union select * from archive)
where reference = a.refer_from and branch = a.branch_from) FDATE  
--,memo 
--replace(memo,'{SUMMA}',summa,'BAG',universe.variable_arch(reference,branch,'NUMBAG')),
 ,a.* from documents a where 
type_doc = 3823 and receivers_inn = '5047085094'

/
select --replace(memo,'{SUMMA}',summa,'BAG',universe.variable_arch(reference,branch,'NUMBAG')),
 a.* from archive a where 
type_doc = 3823 and date_work = '20nov2018' and receivers_inn = '5047085094'


select summa,universe.variable_arch(branch,reference,'NUMBAG') bag
,memo 
--replace(memo,'{SUMMA}',summa,'BAG',universe.variable_arch(reference,branch,'NUMBAG')),
 ,a.* from documents a where 
type_doc = 3823 and date_work = '22nov2018' and receivers_inn = '5047085094'


/

insert into journal
select * from journal_delete where 
--code = '40702810380000006501' and work_date = '21nov2018'
docnum in (101147863,101144599) 

40702810680000006502

101144599

select rowid,d.* from documents d where reference in (101147863,101144599)

d_12883

bag_svod

--        c03 Ved_Date,
--        c04 Client,
--        n11 Summa_Obyavl,
--        n12 Summa_Peresch,

  select * from bag_svod_event

        select * from bag_svod
            where id in (
                select bag_svod from bag_svod_event
                    where team=pTeam
                    and date_team=pDate
                group by bag_svod))
    loop
        mr:=mr_new;
        mr.rep_id:='SubJournal';
        mn:=mn+1;
        mr.n01:=mn;
        mr.n20:=j_r.id;
        mr.c02:=j_r.nomer;   
        mr.c03:=to_char(j_r.work_date,'dd.mm.yyyy');
        

        select * from bag_detail
            where bag_svod=j_r.id
            and in_out=0
            and status=0
            and date_storn is null;
        mr.n11:=sum1;
        
                select sum(nominal*count) into sum1 from bag_detail
            where bag_svod=j_r.id
            and in_out=1
            and status=0
            and date_storn is null;
        mr.n12:=sum1;
        
        
                    select * from bag_dep_variable
                where src_object='BAG_SVOD.ID'
                and dst_object='RECOUNT.REFERENCE'
                and src_id=j_r.id)
        loop
            for docs in
                (select * from documents where refer_from=refs.r and branch_from=j_r.subdepartment
                union all