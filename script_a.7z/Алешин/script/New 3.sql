--select replace(payers_bank,chr(10)), d.* from documents d 
update documents set payers_bank=replace(payers_bank,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and payers_bank like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update documents set payers=replace(payers,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and payers like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update documents set receivers=replace(receivers,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and receivers like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update documents set receivers_bank=replace(receivers_bank,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and receivers_bank like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update archive set payers_bank=replace(payers_bank,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and payers_bank like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update archive set payers=replace(payers,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and payers like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update archive set receivers=replace(receivers,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and receivers like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update archive set receivers_bank=replace(receivers_bank,chr(10))
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and receivers_bank like '%'||chr(10)||'%'
    and real_payers like '3030_810%'
/

update documents set memo=replace(memo,chr(10)) 
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and memo like ('%'||chr(10)||'%')
    and real_payers like '3030_810%'
/

update archive set memo=replace(memo,chr(10)) 
  where date_work >= to_date('15.11.2018','DD.MM.YYYY')
    and type_doc=6
    and memo like ('%'||chr(10)||'%')
    and real_payers like '3030_810%'
/

mbank.pjournal.CORR_ACCOUNT_SUMMARY
/


select to_date('01.01.2000','dd.mm.yyyy')+related,j.* from journal j where header = 'a'
order by to_date('01.01.2000','dd.mm.yyyy')+related

select * from account where code = '301028106910000000008084'

select rowid,j.* from journal j where docnum = 101325894

select rowid,j.* from journal_delete j where docnum = 101325894
/

impex_rurswift.process_sw_messages_shed

IMPEX_RURSWIFT.ProcExpDocRUSW_MQ