select * from audit_table

select * from paramvalues
/

select * from dba_tables where table_name like '%LOG%'
and owner like 'SYS%'


select * from dba_objects where object_name like '%AUD'
and object_type = 'TRIGGER'
and owner like 'SYS%'
/

select * from V$reserved_words where keyword like 'AUD%'


select * from sys.AUDIT_ACTIONS
/

select * from variable_guides

select * from dba_tab_columns

select * from dba_tab_comments where owner = 'MBANK'

select * from dba_col_comments where owner = 'MBANK_AUDIT'
/

CREATE SEQUENCE mbank.mb_audit_ref
  START WITH 1
  MAXVALUE 1000000000000000000000000000
  MINVALUE 1
  CYCLE
  CACHE 100
  ORDER;
  
 grant select on mbank.MB_AUDIT_ref to mbank_audit
 /
 
 select * from object_rights 
 
/
  --�������� �� ���������
create or replace trigger MBANK.OBJECT_RIGHTS_AUD
  before insert or update or delete on mbank.object_rights
  for each row
-- %Author  : ALESHIN_RL
-- %Created : 14.03.2020
-- %usage ����� �������, � ��������� ��������� �� �����
-- �������� �� ������ select * from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
declare
  aud  mbank_audit.mb_audit%rowtype;  
  procedure aud_val(fld varchar2, v_o varchar2, v_n varchar2)
  is
  begin
    insert into mbank_audit.mb_audit_values(ref,br,field,val_old,val_new) values(aud.ref,aud.br,fld,v_o,v_n); 
  end;  
begin
  aud.own := 'MBANK';
  aud.tbl := 'OBJECT_RIGHTS';
  aud.ref := mbank.mb_audit_ref.nextval;
  aud.br  := mbfilid;
  if inserting then
    aud.oper := 'INSERT';
  end if;   
  if deleting then
    aud.oper := 'DELETE';
  end if;   
  if updating then
    aud.oper := 'UPDATE';
  end if;   
  aud.obj_id := nvl(:new.obj_id,:old.obj_id);
  aud.obj_type := nvl(:new.obj_type,:old.obj_type);  
  aud.ref_id := nvl(:new.id,:old.id);
  aud.ref_type := nvl(:new.id_type,:old.id_type);
  --aud.obj_name := nvl(:new.name,:old.name);
  --aud.obj_dt := nvl(:new.work_date,:old.work_date);
  insert into mbank_audit.mb_audit values aud;
--��������� ������� �� ������ ��������
--select '  IF UPDATING('''||column_name||''') THEN AUD_VAL('''||column_name||''',:OLD.'||column_name||',:NEW.'||column_name||'); END IF;' from all_tab_columns where table_name = 'OBJECT_RIGHTS'
  if updating('ID') then aud_val('ID',:old.id,:new.id); end if;
  if updating('ID_TYPE') then aud_val('ID_TYPE',:old.id_type,:new.id_type); end if;
  if updating('OBJ_ID') then aud_val('OBJ_ID',:old.obj_id,:new.obj_id); end if;
  if updating('OBJ_TYPE') then aud_val('OBJ_TYPE',:old.obj_type,:new.obj_type); end if;
  if updating('RIGHTS') then aud_val('RIGHTS',:old.rights,:new.rights); end if;      
end object_rights_aud;
/

select * from mbank_audit.mb_audit

select * from mbank_audit.mb_audit_values

select * from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
/

SELECT owner, table_name, sum(bytes) B
FROM
(SELECT segment_name table_name, owner, bytes  FROM dba_segments  WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
 UNION ALL
 SELECT i.table_name, i.owner, s.bytes  FROM dba_indexes i, dba_segments s  WHERE s.segment_name = i.index_name
 AND s.owner = i.owner AND s.segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes FROM dba_lobs l, dba_segments s WHERE s.segment_name = l.segment_name
 AND s.owner = l.owner AND s.segment_type IN ('LOBSEGMENT', 'LOB PARTITION', 'LOB SUBPARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes FROM dba_lobs l, dba_segments s WHERE s.segment_name = l.index_name
 AND s.owner = l.owner AND s.segment_type = 'LOBINDEX')
WHERE 1=1
and table_name in ('MB_AUDIT','MB_AUDIT_VALUES')
GROUP BY table_name, owner
ORDER BY SUM(bytes) desc

2013331456
1006698496
/

select * from mb_users