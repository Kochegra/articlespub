select '44FZTEST' type_obj, 1 value,s.id from eid.eid_subdepartments s
where 1=1 and type = 301
--and nvl(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'DEPART_OUT'),0) = 2 
and nvl(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'SERVICE_FIRMA'),0) = 1
and nvl(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'44FZTEST'),0) <> 1
and nvl(deleted,0) <> 1
--and s.id
and boss_subdep_id in (select id from boss_subdepartments start with id in (146018,173088,145908) connect by prior id = dept_id)  
--and s.id in (select distinct num4 from zyx_store z where OPER = 'FIL_MIGR' and num1 = 76)
--and id like '192%' and length(id) > 3
--and exists (select null from users_all where subdepartment = s.id and job in (175,31452) and P_USER_PARAMETERS.GET_PARAM(user_id,subdepartment,'ORA_LOCK_DATE') is null)
/


select * from u_reports@pro8 where rep_id = 12795 

/

select inn,count(*) from eid.eid_firma

select CLIENT_NAME,INN,CODE,(select name from eid.v_subdep_all where id = a.subdepartment) depart
,(select fil from eid.v_subdep_all where id = a.subdepartment) "������"
 from eid.eid_firma f, eid.eid_firma_account a
 where inn in (
select trim(chr(10) from column_value) val from table(cast(mbank.CONVERT_TOOLS.str2varchar2tbl(
'1101300281
,1101028269
,1101034833
,1101061308
,1101111125
,1101015654
,110701355787
,110901128044
,110211928870
,110802560422
,110208200706
,1101005744
,110402085405
,110210536750
,1121009024
,110201728247
,1101144219
,110211311798
,110550258130
,1118001709
,110114297202
,110312812159
,1101095106
,1101205849
,1110003574
,1106007505
,1101141183
,1101148661
,1106027903'
) as mbank.Varchar2Table))
) 
and a.EID = f.eid and (a.code like '40_0%' or a.code like '45_0%') 
  and close_date is null
and a.subdepartment not in (405007)
order by client_name
-- group by inn