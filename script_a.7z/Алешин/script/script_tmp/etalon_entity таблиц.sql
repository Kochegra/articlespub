         ������� �����������    
      
          1. TBL_SCHEDULE_EVENT
          2. TBL_PLAN_EVENT
          3. TBL_REG_ENTITY_OBJ
          4. TBL_REG_TRANSACTION
          5. COLLECTOR_CONTRACTS
          6. TBL_SCHEDULE_EVENT_PARAM
          7. TBL_SCHED_EV_PARAM_CDPROD
          8. TBL_LINK_PLAN_EVENT_TO_RASPR
          

--============================================================================================================
--================================================================== 1. TBL_SCHEDULE_EVENT ===================
--============================================================================================================
        
--==============================================================
--=== 1.1. ���������� TBL_SCHEDULE_EVENT =======================
--==============================================================
/
insert into tbl_schedule_event
select TSE.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
/
 
--==============================================================
--=== 1.2. �������� � �������� TBL_SCHEDULE_EVENT ==============
--==============================================================
/
-- �������� ������� �� MAIN
select TSE.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event TSE
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
order by TSE.INS_DATE
/

/
-- �������� c MAIN
delete from tbl_schedule_event
where (reference,branch) in 
(select TSE.REFERENCE,TSE.BRANCH 
  from 
        contracts@nnovg C
        ,tbl_schedule_event TSE
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID)
/


--============================================================================================================
--================================================================== 2. TBL_PLAN_EVENT =======================
--============================================================================================================

--==============================================================
--=== 2.1 ���������� TBL_PLAN_EVENT ============================
--==============================================================
/
insert into tbl_plan_event
select TPE.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
/

 
--==============================================================
--=== 2.2. �������� � �������� TBL_PLAN_EVENT ==================
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'MAIN' SERVER                                                           
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event TPE
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
union
select count(1) COUNT, 'NNOVG'                                                         
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
/

/
-- �������� ������� �� MAIN
select TPE.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event TPE
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
order by TPE.REFER_SCHED,TPE.DATE_WORK        
/

/
-- ��������
delete from tbl_plan_event
where (reference,branch) in 
(select TPE.REFERENCE,TPE.BRANCH  
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event TPE
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH)
/


--============================================================================================================
--================================================================== 3. TBL_REG_ENTITY_OBJ ===================
--============================================================================================================

--==============================================================
--=== 3.1. ���������� TBL_REG_ENTITY_OBJ =======================
--==============================================================
/
insert into tbl_reg_entity_obj
select TREO.* 
  from tbl_reg_entity_obj@nnovg TREO
        ,tbl_entity_object@nnovg TEO
        ,contracts@nnovg C
 where TREO.eobj_id = TEO.eobj_id 
   and TEO.reference = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT' 
/

--==============================================================
--=== 3.2. �������� � �������� TBL_REG_ENTITY_OBJ ==============
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'MAIN' SERVER                                                           
  from tbl_reg_entity_obj TREO
        ,tbl_entity_object@nnovg TEO
        ,contracts@nnovg C
 where TREO.eobj_id = TEO.eobj_id 
   and TEO.reference = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'
union
select count(1) COUNT, 'NNOVG'                                                         
  from tbl_reg_entity_obj@nnovg TREO
        ,tbl_entity_object@nnovg TEO
        ,contracts@nnovg C
 where TREO.eobj_id = TEO.eobj_id 
   and TEO.reference = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'  
/

/
-- �������� ������� �� MAIN
select TREO.* 
  from tbl_reg_entity_obj TREO
        ,tbl_entity_object@nnovg TEO
        ,contracts@nnovg C
 where TREO.eobj_id = TEO.eobj_id 
   and TEO.reference = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'
order by TREO.eobj_id,TREO.date_work desc 
/

/
-- ��������
delete from tbl_reg_entity_obj
where eobj_id in 
(select TREO.EOBJ_ID  
  from tbl_reg_entity_obj TREO
        ,tbl_entity_object@nnovg TEO
        ,contracts@nnovg C
 where TREO.eobj_id = TEO.eobj_id 
   and TEO.reference = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT')
/


--============================================================================================================
--================================================================== 4. TBL_REG_TRANSACTION ==================
--============================================================================================================

--==============================================================
--=== 4.1. ���������� TBL_REG_TRANSACTION ======================
--==============================================================
/
insert into tbl_reg_transaction
select TRT.*                                                           
  from tbl_reg_transaction@nnovg TRT 
       ,tbl_entity_object@nnovg TEO
       ,contracts@nnovg C
 where TRT.eobj_id = TEO.eobj_id 
   and TEO.REFERENCE = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'
/



--==============================================================
--=== 4.3. �������� � �������� TBL_REG_TRANSACTION =============
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'MAIN' SERVER                                                           
  from tbl_reg_transaction TRT 
       ,tbl_entity_object@nnovg TEO
       ,contracts@nnovg C
 where TRT.eobj_id = TEO.eobj_id 
   and TEO.REFERENCE = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'
union
select count(1) COUNT, 'NNOVG'                                                         
  from tbl_reg_transaction@nnovg TRT 
       ,tbl_entity_object@nnovg TEO
       ,contracts@nnovg C
 where TRT.eobj_id = TEO.eobj_id 
   and TEO.REFERENCE = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'   
/

/
-- �������� ������� �� MAIN
select TRT.*                                                           
  from tbl_reg_transaction TRT 
       ,tbl_entity_object@nnovg TEO
       ,contracts@nnovg C
 where TRT.eobj_id = TEO.eobj_id 
   and TEO.REFERENCE = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT'
order by TRT.eobj_id,TRT.date_work desc
/   
   
/
-- ��������
delete from tbl_reg_transaction
 where eobj_id in 
(select TRT.EOBJ_ID                                                           
  from tbl_reg_transaction TRT 
       ,tbl_entity_object@nnovg TEO
       ,contracts@nnovg C
 where TRT.eobj_id = TEO.eobj_id 
   and TEO.REFERENCE = C.reference
   and TEO.BRANCH = C.branch
   and C.type_doc in (30171,30172,30173,7731,7632)
   and 1324959   in (C.reference,c.refer_from)                                      
   and 47        in (C.branch,C.branch_from)
   and TEO.ARCHETYPE_KEY='CONTRACT')
/


--============================================================================================================
--================================================================== 5. COLLECTOR_CONTRACTS ==================
--============================================================================================================

--==============================================================
--=== 5.1. ���������� COLLECTOR_CONTRACTS ======================
--==============================================================
/
insert into collector_contracts_tmp@nnovg
select CC.*                                                          
  from 
        collector_contracts@nnovg CC
        ,contracts@nnovg C
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and CC.REFERENCE = C.REFERENCE
        and CC.BRANCH = C.BRANCH 
/

--==============================================================
--=== 5.2. �������� � �������� COLLECTOR_CONTRACTS =============
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'TMP' SERVER                                                           
  from 
        collector_contracts_tmp@nnovg CC
        ,contracts@nnovg C
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and CC.REFERENCE = C.REFERENCE
        and CC.BRANCH = C.BRANCH 
union
select count(1) COUNT, 'NNOVG'                                                         
  from 
        collector_contracts@nnovg CC
        ,contracts@nnovg C
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and CC.REFERENCE = C.REFERENCE
        and CC.BRANCH = C.BRANCH 
/

/
-- �������� ������� � TMP �������
select CC.*                                                          
  from 
        collector_contracts_tmp@nnovg CC
        ,contracts@nnovg C
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and CC.REFERENCE = C.REFERENCE
        and CC.BRANCH = C.BRANCH 
order by CC.WORK_DATE        
/

/
-- ��������
delete from collector_contracts_tmp@nnovg
where (reference,branch) in 
(select CC.REFERENCE,CC.BRANCH                                                          
  from 
        collector_contracts_tmp@nnovg CC
        ,contracts@nnovg C
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and CC.REFERENCE = C.REFERENCE
        and CC.BRANCH = C.BRANCH )
/


--============================================================================================================
--================================================================== 6. TBL_SCHEDULE_EVENT_PARAM =============
--============================================================================================================

--==============================================================
--=== 6.1. ���������� TBL_SCHEDULE_EVENT_PARAM =================
--==============================================================
/
insert into tbl_schedule_event_param
select TSEP.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param@nnovg TSEP
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        --and TSE.STATUS = 'ACTIVE'
/
 

--==============================================================
--=== 6.2. �������� � �������� TBL_SCHEDULE_EVENT_PARAM ========
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'MAIN' SERVER                                                           
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
union
select count(1) COUNT, 'NNOVG'                                                         
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param@nnovg TSEP
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
/

/
-- �������� ������� �� MAIN
select TSEP.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
order by TSEP.REFERENCE        
/

/
-- ��������
delete from tbl_schedule_event_param
where (reference,branch) in 
(select TSEP.REFERENCE,TSEP.BRANCH  
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH)
/


--============================================================================================================
--================================================================== 7. TBL_SCHED_EV_PARAM_CDPROD ============
--============================================================================================================

--==============================================================
--=== 7.1. ���������� TBL_SCHED_EV_PARAM_CDPROD ================
--==============================================================
/
insert into tbl_sched_ev_param_cdprod
select 
        TSEP_M.ID NEW_ID
        ,TSEPCD.PAY_DAY
        ,TSEPCD.START_MONTH
        ,TSEPCD.TYPE_DATE
        ,TSEPCD.IS_CALENDAR
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param@nnovg TSEP
        ,tbl_sched_ev_param_cdprod@nnovg TSEPCD
        ,tbl_entity_object@nnovg TEO
        ,tbl_schedule_event_param TSEP_M 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        and TSEP_M.REFERENCE = TSE.REFERENCE
        and TSEP_M.BRANCH = TSE.BRANCH
        and TSEP_M.EVENT_KEY =  TSEP.EVENT_KEY
        and TSEPCD.ID = TSEP.ID
/
 

--==============================================================
--=== 7.2. �������� � �������� TBL_SCHED_EV_PARAM_CDPROD =======
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'MAIN' SERVER                                                           
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_sched_ev_param_cdprod TSEPCD
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        and TSEPCD.ID = TSEP.ID   
union
select count(1) COUNT, 'NNOVG'                                                         
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param@nnovg TSEP
        ,tbl_sched_ev_param_cdprod@nnovg TSEPCD
        ,tbl_entity_object@nnovg TEO  
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        and TSEPCD.ID = TSEP.ID
/

/
-- �������� ������� �� MAIN
select TSEPCD.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_sched_ev_param_cdprod TSEPCD
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        and TSEPCD.ID = TSEP.ID   
order by TSEP.REFERENCE        
/

/
-- ��������
delete from tbl_sched_ev_param_cdprod
where ID in 
(select TSEPCD.ID  
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_schedule_event_param TSEP
        ,tbl_sched_ev_param_cdprod TSEPCD
        ,tbl_entity_object@nnovg TEO 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TSEP.REFERENCE = TSE.REFERENCE
        and TSEP.BRANCH = TSE.BRANCH
        and TSEPCD.ID = TSEP.ID )
/


--============================================================================================================
--================================================================== 8. TBL_LINK_PLAN_EVENT_TO_RASPR =========
--============================================================================================================

--==============================================================
--=== 8.1. ���������� TBL_LINK_PLAN_EVENT_TO_RASPR =============
--==============================================================

--������������ � ������� � ������� ��������� �������
create table tbl_link_plan_ev_to_raspr_tmp
as
select TLPETR.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
        ,tbl_link_plan_event_to_raspr@nnovg TLPETR
where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
        and TLPETR.REFERENCE = TPE.REFERENCE
        and TLPETR.BRANCH = TPE.BRANCH

--==============================================================
--=== 8.2. �������� � �������� TBL_LINK_PLAN_EVENT_TO_RASPR ====
--==============================================================
/
-- �������� ����������
select count(1) COUNT, 'TMP' SERVER                                                           
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
        ,tbl_link_plan_ev_to_raspr_tmp@nnovg TLPETR 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
        and TLPETR.REFERENCE = TPE.REFERENCE
        and TLPETR.BRANCH = TPE.BRANCH
union
select count(1) COUNT, 'NNOVG'                                                         
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
        ,tbl_link_plan_event_to_raspr@nnovg TLPETR
where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
        and TLPETR.REFERENCE = TPE.REFERENCE
        and TLPETR.BRANCH = TPE.BRANCH
/

/
-- �������� ������� � TMP �������
select TLPETR.* 
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
        ,tbl_link_plan_ev_to_raspr_tmp@nnovg TLPETR 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
        and TLPETR.REFERENCE = TPE.REFERENCE
        and TLPETR.BRANCH = TPE.BRANCH
order by TPE.DATE_WORK        
/

/
-- ��������
delete from tbl_link_plan_ev_to_raspr_tmp@nnovg
where (reference,branch) in 
(select TLPETR.REFERENCE,TLPETR.BRANCH  
  from 
        contracts@nnovg C
        ,tbl_schedule_event@nnovg TSE
        ,tbl_entity_object@nnovg TEO 
        ,tbl_plan_event@nnovg TPE
        ,tbl_link_plan_ev_to_raspr_tmp@nnovg TLPETR 
 where  
        1=1
        and C.type_doc in (30171,30172,30173,7731,7632)
        and 1324959   in (C.reference,C.refer_from)                                      
        and 47      in (C.BRANCH,C.branch_from)
        and C.status in (50,60)
        and TEO.REFERENCE = C.REFERENCE
        and TEO.BRANCH = C.BRANCH 
        and TSE.EOBJ_ID = TEO.EOBJ_ID
        and TPE.REFER_SCHED = TSE.REFERENCE 
        and TPE.BRANCH_SCHED = TSE.BRANCH
        and TLPETR.REFERENCE = TPE.REFERENCE
        and TLPETR.BRANCH = TPE.BRANCH)
/

/
-- �������� ������� tbl_link_plan_ev_to_raspr_tmp@nnovg
-- ��������� �� ������� NNOVG
drop table tbl_link_plan_ev_to_raspr_tmp
/

