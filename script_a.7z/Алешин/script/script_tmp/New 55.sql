

select u.user_name, u.user_id, u.params,
b.tab_n, b.tabn24,b.tabn_easup,b.eid,b.l_name,b.f_name,b.m_name
from mbank.users u
left join mbank.boss_emp_all b on u.params=b.tab_n --and b.d_out>=sysdate
where user_id in (
select f.owner
  from mbank.TBL_FIRM_WIZARD f, mbank.users u
where f.entity_key in ('FIRM_WIZARD_IP', 'FIRM_WIZARD_RKO', 'FIRM_WIZARD_NEXT', 
                       'FIRM_WIZARD_SPECACC')
   and f.date_create>=trunc(sysdate)-90
   and f.status = 1000
   and mbank.pkg_fw_tools.get_wizard_attr(f.reference,f.branch, 'SPECIAL_ACCOUNT_TYPE') in ('7298','7302','5788','5787','12579','12580','12582','12575','12583','13913','13952','13953','12457')
   and f.owner = u.user_id   
   and f.owner_subdep = u.subdepartment
)
/


 SELECT max(DATE_CREATE)
    FROM PRC_LOADER.TBL_METRO_SALES_ROSTER_FILE T
    
    PKG_METRO_SALES.SEND_PAMENT_ERROR;

select * from shed_jobs where task_name = 'RUNNERS' 
--and (text like '%999%' or text1 like '%999%')

select * from mb_od_log where start_time > trunc(sysdate)
order by start_time


eid.stockholders



select max(u.TUNED_UNDORETENTION) TUNED_UNDORETENTION,
       MAXQUERYSQLID SQL_ID,
   (select to_char(substr(SQL_TEXT,1,4000)) from  dba_hist_sqltext s where   u.MAXQUERYSQLID = s.SQL_ID ) as   SQL_TEXT,
   max(u.MAXQUERYLEN) MAXQUERYLEN
   ,count(*)
  from DBA_HIST_UNDOSTAT u where begin_time < to_date('09.12.2021','dd.mm.yyyy') 
 group by MAXQUERYSQLID 
 having max(u.MAXQUERYLEN) > 40000
 order by count(*)
 /
 
 select * from fssp_doc_corp where SOAPID_DOC = -1
/


select min(begin_time) from DBA_HIST_UNDOSTAT u

select  u.* from DBA_HIST_UNDOSTAT u where MAXQUERYSQLID = 'c98hbbzkbx37s'
order by BEGIN_TIME desc

select audsid,count(*) from v$session
group by audsid 

select * from v$session where audsid = 1484613099