 SELECT
 owner, 
 table_name, 
 TRUNC(sum(bytes)/1024/1024/1024) GB,
 sum(bytes) B,
 ROUND( ratio_to_report( sum(bytes) ) over () * 100) Percent
FROM
(SELECT segment_name table_name, owner, bytes
 FROM dba_segments
 WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
 UNION ALL
 SELECT i.table_name, i.owner, s.bytes
 FROM dba_indexes i, dba_segments s
 WHERE s.segment_name = i.index_name
 AND s.owner = i.owner
 AND s.segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.segment_name
 AND s.owner = l.owner
 AND s.segment_type IN ('LOBSEGMENT', 'LOB PARTITION', 'LOB SUBPARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.index_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBINDEX')
WHERE 1=1 --owner in ('MBANK','EID') and table_name in 
and table_name like 'ACCOUNT'
--(select table_name from dba_tables where owner = 'MBANK' and (table_name like 'TBL%MQ_MB' or table_name like 'TBL%MB_MQ'))
GROUP BY table_name, owner
--HAVING SUM(bytes)/1024/1024/1024 > 1 /* Ignore really small tables */
ORDER BY SUM(bytes) desc
/

declare
  Ls globals.useridlist;

begin
  ar13.user_init(978042);
  dbms_output.put_line('GetRight_Subdep = '||ar13.getright_subdep(55081,544300));
  dbms_output.put_line('ChkParam = '||ar13.chkparam(55081,'���_���_������','10045,0579'));
  dbms_output.put_line('GetRight_Object = '||ar13.getright_object(55081,-1,544,-3));
 -- ls := ar13.GetObjects_List(978042,-1,-1);
 -- dbms_output.put_line('GetObjects_List >> '||ls.count||' '||ls.first||' = '||ls(ls.first));
 -- dbms_output.put_line('GetObjects_List >> '||ls.next(ls.first)||' = '||ls(ls.next(ls.first)));
  --ls := GetUsers_List(978042);
  --dbms_output.put_line('GetUsers_List >> '||ls.count||' '||ls.first||' = '||ls(ls.first));  
  -- ls := GetSubdepartments_List(978042);
  --dbms_output.put_line('GetSubdepartments_List >> '||ls.count||' '||ls.first||' = '||ls(ls.first));  
end;
/

select * from users where GLOBALS.check_subuser(user_id) =1
/


select * from subdepartments where GLOBALS.check_subdepartments(id) = 1
/
select * from paramvalues where paramid in 
    (SELECT id from parameters where name = '������������������')
    /
    
    select * from config where name = 'MIRROR'
/

begin
dbms_output.put_line(dbms_db_version.version);
end;
/
  UserList UserIdList;
  SubDepartmentsList UserIdList;
  UserId NUMBER;
  UserJob NUMBER;
  BranchId NUMBER;  
  OsUser VARCHAR2(128);
  Term VARCHAR2(128);
  Program VARCHAR2(512);
  SystemDate DATE;
  LocalCurrency VARCHAR2(30);
    BlockSumma NUMBER;
  BlockOperation NUMBER;
    BlockAccount VARCHAR2(25);
  OracleVersion NUMBER;
  BranchFilial NUMBER;    
  BranchGO number;
  ServerNameGo varchar2(2000);
  New_Reference NUMBER;
    SCHEMA VARCHAR2(30);
  GlobalName VARCHAR2(128);
    IsMaster BOOLEAN;
      cMasterServer VARCHAR2(30);  
      
      
  CorrAccount_Filial VARCHAR2(25);
  Code_Depart VARCHAR2(5);

       -- from subdepartments where parent=-1;
  IsMirror BOOLEAN;




/

select ar13.GetRight_Subdep(978042 ,id) r
,s.* from subdepartments s where 1=1
-- and type = 301
 and ar13.GetRight_Subdep(978042 ,id) < 0


/

select * from object_rights 

                 where nvl(rights,0) > -16 
                  -- and decode(obj_id,0,fobj,obj_id) = fobj
                  -- and decode(obj_type,0,fobj_type,obj_type) = fobj_type
                 start with id = 4719 
                 connect by nocycle prior decode(obj_id,0,id,obj_id) = id 
                                and prior decode(obj_type,0,id_type,obj_type) = id_type
                                and prior nvl(rights,0) > -16
                                /
     drop index SUBDEPARTMENTS_tree  
                              
CREATE INDEX MBANK.SUBDEPARTMENTS_tree ON MBANK.SUBDEPARTMENTS
(ID,PARENT)
LOGGING
TABLESPACE IDX_SMALL
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        17
            FREELIST GROUPS  1
            BUFFER_POOL      KEEP
           )
           /
           
           globals
           /
           
 SELECT n.name, ROUND(m.value/1024) kbytes
  FROM V$STATNAME n, V$MYSTAT m
 WHERE n.statistic# = m.statistic#
   AND n.name LIKE 'session%memory%'
   
  select name, sum(ROUND(s.value/1024))  
  from v$sesstat s , v$statname n where s.statistic# = n.statistic# and n.name like 'session%memory%' 
  group by name; 
  /
  
  select * from v$sesstat st , v$statname sn, v$session ss 
  where st.statistic# = sn.statistic# 
    --and sn.name like 'session%memory'
    and ss.sid = st.sid and value > 0 
    and ss.sid = 389
  
  select ss.sid,ss.osuser,sn.name,sum(st.value) from v$sesstat st , v$statname sn, v$session ss 
  where st.statistic# = sn.statistic# 
    and sn.name like 'session%memory'
    and ss.sid = st.sid 
    and ss.osuser = 'aleshin_rl'
  group by ss.sid,ss.osuser,sn.name;
  