--select * from mb_od_log where start_time >= '14mar2019'
select round(vsum*pledger.WCOURSE(currency,work_date),2) V, j.* from journal j where docnum in 3299229973--(41401487,41401862,3299229973) --41401862
order by journal_id
/

select round(vsum*pledger.WCOURSE(currency,work_date),2) V, j.* from journal j where docnum in (41401862)


select round(vsum*pledger.WCOURSE(currency,work_date),2) V,j.* from journal j where currency <> '810' and substr(assist,1,5) = '55555' and work_date = '13mar2019'
            and round(vsum*pledger.WCOURSE(currency,work_date),2) <> rsum and substr(code,1,5) in  ('47427','47411','30301')
          
/

select distinct docnum,branch,work_date,currency,vsum from journal j where currency <> '810'-- and substr(assist,1,5) = '55555' 
        and work_date = '13mar2019' and currency = assist_currency and vsum <> 0
            and round(vsum*pledger.WCOURSE(currency,work_date),2) <> rsum --and substr(code,1,5) in  ('47427','47411','30301')
            and not exists (select null from journal where docnum = j.docnum and branch = j.branch and currency <> j.currency)
/

  select rowid,d.* from
   config d where name = 'ARCHIVE_CLOSE_DATE' and to_date(value,'dd.mm.yyyy')+1 = (select to_date(value,'dd.mm.yyyy') from config where name = 'SYSTEMDATE') 

/

declare
  val varchar2(50);
begin
  select value into val from config where name = 'ARCHIVE_CLOSE_DATE'; 
  update config set value = to_char(to_date(value,'dd.mm.yyyy')-1,'dd.mm.yyyy') 
  where name = 'ARCHIVE_CLOSE_DATE' and to_date(value,'dd.mm.yyyy')+1 = (select to_date(value,'dd.mm.yyyy') from config where name = 'SYSTEMDATE'); 
  for jj in (select round(vsum*pledger.WCOURSE(currency,work_date),2) RNEW,j.* from journal j where currency <> '810' and substr(assist,1,5) = '55555' and work_date = '13mar2019'
            and round(vsum*pledger.WCOURSE(currency,work_date),2) <> rsum and substr(code,1,5) in  ('47427','47411','30301'))
  loop
    insert into journal_zp select * from journal where docnum = jj.docnum and branch = jj.branch;
    delete journal where docnum = jj.docnum and branch = jj.branch;
    update journal_zp set rsum = jj.rnew where docnum = jj.docnum and branch = jj.branch and rsum <> jj.rnew;
    update journal_zp set vsum = jj.rnew where docnum = jj.docnum and branch = jj.branch and vsum <> jj.rnew and substr(code,1,5) = '70601'; 
    insert into journal select * from journal_zp where docnum = jj.docnum and branch = jj.branch;
    commit;   
  end loop;
  update config set value = val where name = 'ARCHIVE_CLOSE_DATE' and value <> val; 
end; 
/

declare
  val varchar2(50);
  rnew number;
begin
  select value into val from config where name = 'ARCHIVE_CLOSE_DATE'; 
  update config set value = to_char(to_date(value,'dd.mm.yyyy')-1,'dd.mm.yyyy') 
  where name = 'ARCHIVE_CLOSE_DATE' and to_date(value,'dd.mm.yyyy')+1 = (select to_date(value,'dd.mm.yyyy') from config where name = 'SYSTEMDATE'); 
  for jj in (select distinct docnum,branch,work_date,currency,vsum from journal j where currency <> '810' 
        and work_date = '13mar2019' and currency = assist_currency and vsum <> 0
            and round(vsum*pledger.WCOURSE(currency,work_date),2) <> rsum 
            and not exists (select null from journal where docnum = j.docnum and branch = j.branch and currency <> j.currency))            
  loop
    rnew := round(jj.vsum*pledger.WCOURSE(jj.currency,jj.work_date),2);
    insert into journal_zp select * from journal where docnum = jj.docnum and branch = jj.branch;
    delete journal where docnum = jj.docnum and branch = jj.branch;
    update journal_zp set rsum = rnew where docnum = jj.docnum and branch = jj.branch and rsum <> rnew;
  --  update journal_zp set vsum = rnew where docnum = jj.docnum and branch = jj.branch and vsum <> rnew and substr(code,1,5) = '70601'; 
    insert into journal select * from journal_zp where docnum = jj.docnum and branch = jj.branch;
    commit;   
  end loop;
  update config set value = val where name = 'ARCHIVE_CLOSE_DATE' and value <> val;
  commit; 
end; 
/


select round(vsum*pledger.WCOURSE(currency,work_date),2),j.* from journal j where 
code = '42301840700652000111' and work_date = '13mar2019'
--docnum = 3299268185

select round(wrest*pledger.WCOURSE(currency,work_date),2),l.* from ledger l where code = '30306840300650300000' and work_date = '13mar2019'

select * from journal_delete where 
code = '42301840700652000111' and work_date = '13mar2019'
--docnum = 188751441
/

select /*+index(j JOURNAL_DATE_IDX)*/
* from 
  journal j where header||'' = 'A' and substr(code,1,5) in ('47411')
and work_date = '13mar2019'  and nvl(operation,0) in ('519002')
--and journal_id = 194761263 
/

select JOURNAL_ID, count(*)
 from journal j where header||'' = 'A' and substr(code,1,4) not in ('7060')--,'47411','30301')
and work_date >= '13mar2019'  and nvl(operation,0) in ('519002')
group by JOURNAL_ID having count(*) > 1
/


--���������� ������
declare
    val varchar2(50);
begin
  select value into val from config where name = 'ARCHIVE_CLOSE_DATE'; 
  update config set value = to_char(to_date(value,'dd.mm.yyyy')-1,'dd.mm.yyyy') 
  where name = 'ARCHIVE_CLOSE_DATE' and to_date(value,'dd.mm.yyyy')+1 = (select to_date(value,'dd.mm.yyyy') from config where name = 'SYSTEMDATE'); 

  for jj in (
  select --/*+index(j JOURNAL_DATE_IDX)*/
              * from journal j where 1=1 
              --docnum in (3745957954,3746979225,3748117449) and journal_id in (1674919346,1674954489,1675069208)              
                --header||'' = 'C' and substr(code,1,5) in ('90901')                 
                 and nvl(operation,0) in ('519002')
                and code like '42301978700002000001'
              and work_date = '25feb2020'
                )
  loop

    delete journal where journal_id = jj.journal_id and work_date = jj.work_date;
    --commit;
  end loop;
       update config set value = val where name = 'ARCHIVE_CLOSE_DATE' and value <> val; 

commit;  
end;
/

--���������� ������ ��� 
declare
    val varchar2(50);
begin
    select value into val from config where name = 'ARCHIVE_CLOSE_DATE'; 
  update config set value = to_char(to_date(value,'dd.mm.yyyy')-1,'dd.mm.yyyy') 
  where name = 'ARCHIVE_CLOSE_DATE' and to_date(value,'dd.mm.yyyy')+1 = (select to_date(value,'dd.mm.yyyy') from config where name = 'SYSTEMDATE'); 

  for jj in (select /*+index(j JOURNAL_DATE_IDX)*/
              * from journal j where header||'' = 'A' and substr(code,1,4) not in ('7060')
                and work_date = '13mar2019'  and nvl(operation,0) in ('519002'))
  loop

    delete journal where journal_id = jj.journal_id and work_date = jj.work_date;
    commit;
  end loop;
       update config set value = val where name = 'ARCHIVE_CLOSE_DATE' and value <> val; 

commit;  
end;
/
   update config set value = val where name = 'ARCHIVE_CLOSE_DATE' and value <> val; 

select * from audit_table where table_name = 'DOCUMENTS' and time > sysdate-1/96 and action like '���� ��� ����������%'
--p_operday.evaluate_main_operdate
/

--********************************************************************
declare
  eoUser   config.value%TYPE;
  eoBranch documents.branch%TYPE;
  eoRefer  documents.reference%TYPE;
  eoResult VARCHAR2(2000);
  eoSystemDate      DATE;
  eoTmp_Num       NUMBER;
  eoNum_Group Number;

procedure GENERATEERRORMESSAGE( cSubject in VARCHAR2, cMessage in VARCHAR2 )
is
geList Varchar2( 2000 );
geIdx NUMBER;
geAddress Varchar2( 2000 );
geTmp_Num NUMBER;
begin
  geList := replace(global_parameters.get_param( 'ERROR_ADMIN' ), ' ');
  While length( geList ) > 0 loop
     geIdx := instr( geList,',' );
     geAddress := substr( geList,1, geIdx-1 );
     geList := substr( geList,geIdx + 1, 1000 );
     begin
--                 geTmp_Num := message.send( to_number( geAddress ),'���� ��� ����� ����',
--                   '���� ��� ����� ���� �� ������� ' || globals.globalname );
       geTmp_Num := message.send( to_number( geAddress ),cSubject, cMessage );
     exception when others then NULL;
     end;
     if geIdx < 1 then
       exit;
     end if;
  end loop;
end;
  
BEGIN
  dbms_application_info.set_client_info('MBANK-0Kernel');
  Globals.UserId := mbfil_admin/*1403*/;
  Globals.BranchId := mbFilId;
-- ��� ��������� ������������� �����
  IF NOT globals.ismaster THEN
    RETURN;
  END IF;
  IF Globals.globalname = 'PRO8.WORLD' THEN/*!!!*/
    RETURN;
  END IF;
  --eoSystemDate := Ptools5.As_Date(global_PARAMETERS.get_param_CFG('SYSTEMDATE'));
  eoSystemDate := to_date('01.08.2020','dd.mm.yyyy'); --Ptools5.As_Date(global_PARAMETERS.get_param_CFG('SYSTEMDATE'));
  begin
    select subdepartment into eoBranch from users where user_id = mbfil_admin/*1403*/;
  exception
    when others then
      eoBranch := mbFilID;
  end;
  eoUser := to_char(mbfil_admin)/*'1403'*/;  --  ���������� �.�.
  eoNum_Group := Ptools5.As_Num(global_PARAMETERS.get_param(TO_NUMBER(eoUser),'�����_����������',eoSystemDate));
 /* HEADER = C 
  SELECT Doc_Reference.Nextval INTO eoRefer FROM DUAL;
  INSERT INTO DOCUMENTS(REFERENCE,BRANCH,OWNER,FOLDER,TYPE_DOC,NUM_GROUP,
                                        STATUS,SUB_TYPE,DOC_NUMBER,
                                        SHIFROPER,DATE_CREATE,DATE_DOCUMENT,DATE_VALUE,DATE_WORK)
  VALUES( eoRefer, eoBranch, TO_NUMBER(eoUser),0,21,
                                eoNum_Group,
                                30,10,'1',
                                '310009',sysdate,eoSystemDate,eoSystemDate,eoSystemDate);
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'NOBALANCE', '1');
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '��������', 'C');
  eoTmp_Num := 1;
  WHILE eoTmp_Num <= 10 LOOP
--    eoResult := PJOURNAL.EVALUATE_C_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'C');
    eoResult := PEVALUATE.EVALUATE_C_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'C');
    IF eoResult IS NULL OR eoResult = '' THEN
      EXIT;
    END IF;
    eoTmp_Num := eoTmp_Num + 1;
  END LOOP;
  IF eoResult IS NOT NULL THEN
    generateerrormessage( '���� ��� ����������' ,substr(eoResult,1,1999));
    p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���� ��� ����������:'||'C',substr(eoResult,1,1999));
  END IF;
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���������', 'C:'||eoTmp_Num);
  COMMIT;
  --*/
  /* HEADER = D 
  eoUser   := to_char(mbfil_admin);  --  ���������� �.�.
  SELECT Doc_Reference.Nextval INTO eoRefer FROM DUAL;
  INSERT INTO DOCUMENTS(REFERENCE,BRANCH,OWNER,FOLDER,TYPE_DOC,NUM_GROUP,
                                        STATUS,SUB_TYPE,DOC_NUMBER,
                                        SHIFROPER,DATE_CREATE,DATE_DOCUMENT,DATE_VALUE,DATE_WORK)
  VALUES( eoRefer, eoBranch, TO_NUMBER(eoUser),0,21,
                                eoNum_Group,
                                30,10,'1',
                                '310009',sysdate,eoSystemDate,eoSystemDate,eoSystemDate);
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'OPERATION', '1');
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '��������', 'D');
  eoTmp_Num := 1;
  WHILE eoTmp_Num <= 10 LOOP
--    eoResult := D_1263.EVALUATE_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'D');   -- memo 30/79 �� 07.2008 PJOURNAL.EVALUATE_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'D');
    eoResult := PEVALUATE.EVALUATE_FORWARDS( eoUser, eoRefer, eoBranch, eoSystemDate, 'D');   -- memo 30/79 �� 07.2008 PJOURNAL.EVALUATE_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'D');
    IF eoResult IS NULL OR eoResult = '' THEN
      EXIT;
    END IF;
    eoTmp_Num := eoTmp_Num + 1;
  END LOOP;
  IF eoResult IS NOT NULL THEN
    generateerrormessage( '���� ��� ����������' ,
                                        substr(eoResult,1,1999)
    );
    p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���� ��� ����������:'||'D',substr(eoResult,1,1999));
  END IF;
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���������', 'D:'||eoTmp_Num);
  COMMIT;
  --*/
  --  /* HEADER = A 
  eoUser   := mbfil_admin;  --  ������� �����
  SELECT Doc_Reference.Nextval INTO eoRefer FROM DUAL;
  INSERT INTO DOCUMENTS(REFERENCE,BRANCH,OWNER,FOLDER,TYPE_DOC,NUM_GROUP,
     STATUS,SUB_TYPE,DOC_NUMBER,
     SHIFROPER,DATE_CREATE,DATE_DOCUMENT,DATE_VALUE,DATE_WORK)
  VALUES( eoRefer, eoBranch, TO_NUMBER(eoUser),0,21,
     eoNum_Group,
     30,10,'1',
     '310009',sysdate,eoSystemDate,eoSystemDate,eoSystemDate);
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'BALANCE', '1');
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '��������', 'A');
  eoTmp_Num := 1;
  WHILE eoTmp_Num <= 10 LOOP
--    eoResult := PJOURNAL.EVALUATE_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'A');
    eoResult := PEVALUATE.EVALUATE_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'A');
    IF eoResult IS NULL OR eoResult = '' THEN
      EXIT;
    END IF;
    eoTmp_Num := eoTmp_Num + 1;
  END LOOP;
  IF eoResult IS NOT NULL THEN
    generateerrormessage( '���� ��� ����������' , substr(eoResult,1,1999) );
    p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���� ��� ����������:'||'A',substr(eoResult,1,1999));
  END IF;
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���������', 'A:'||eoTmp_Num);
  COMMIT;
  --*/
   /* HEADER = B 
  eoUser   := to_char(mbfil_admin);  --  ������� �����
  SELECT Doc_Reference.Nextval INTO eoRefer FROM DUAL;
  INSERT INTO DOCUMENTS(REFERENCE,BRANCH,OWNER,FOLDER,TYPE_DOC,NUM_GROUP,
              STATUS,SUB_TYPE,DOC_NUMBER,
              SHIFROPER,DATE_CREATE,DATE_DOCUMENT,DATE_VALUE,DATE_WORK)
  VALUES( eoRefer, eoBranch, TO_NUMBER(eoUser),0,21,
              eoNum_Group,
              30,10,'1',
              '310009',sysdate,eoSystemDate,eoSystemDate,eoSystemDate);
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'TRUST', '1');
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '��������', 'B');
  eoTmp_Num := 1;
  WHILE eoTmp_Num <= 10 LOOP
--    eoResult := PJOURNAL.EVALUATE_B_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'B');
    eoResult := PEVALUATE.EVALUATE_B_JOURNAL( eoUser, eoRefer, eoBranch, eoSystemDate, 'B');
    IF eoResult IS NULL OR eoResult = '' THEN
      EXIT;
    END IF;
    eoTmp_Num := eoTmp_Num + 1;
  END LOOP;
  IF eoResult IS NOT NULL THEN
    generateerrormessage( '���� ��� ����������' ,
         substr(eoResult,1,1999) );
    p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���� ��� ����������:'||'B',substr(eoResult,1,1999));
  END IF;
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���������', 'B:'||eoTmp_Num);
  COMMIT;
  /* HEADER = G 
-- ���������� ���.��� ��������
  eoUser   := mbfil_admin;  --  ������� �����
  SELECT Doc_Reference.Nextval INTO eoRefer FROM DUAL;
  INSERT INTO DOCUMENTS(REFERENCE,BRANCH,OWNER,FOLDER,TYPE_DOC,NUM_GROUP,
        STATUS,SUB_TYPE,DOC_NUMBER,
        SHIFROPER,DATE_CREATE,DATE_DOCUMENT,DATE_VALUE,DATE_WORK)
  VALUES( eoRefer, eoBranch, TO_NUMBER(eoUser),0,21,
        eoNum_Group,
        30,10,'1',
        '310009',sysdate,eoSystemDate,eoSystemDate,eoSystemDate);
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'HEADER_2075', 'A');
  INSERT INTO VARIABLE_DOCUMENTS (BRANCH,REFERENCE, NAME, VALUE)
  VALUES (eoBranch,eoRefer, 'ACCOUNT_P2075', '1');
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '��������', 'G');
  eoTmp_Num := 1;
  WHILE eoTmp_Num <= 10 LOOP
--    eoResult := P_2075.EVALUATE_ACCOUNT( 'A','','',eoSystemDate, eoRefer, eoBranch, eoUser);
    eoResult := PEVALUATE.EVALUATE_2075( 'A','','',eoSystemDate, eoRefer, eoBranch, eoUser);
    IF eoResult IS NULL OR eoResult = '' THEN
      EXIT;
    END IF;
    eoTmp_Num := eoTmp_Num + 1;
  END LOOP;
  IF eoResult IS NOT NULL THEN
    generateerrormessage( '���� ��� ����������' ,
                 substr(eoResult,1,1999));
    p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���� ��� ����������:'||'G',substr(eoResult,1,1999));
  END IF;
  p_audit.Save('DOCUMENTS', eoBranch,eoRefer, '���������', 'G:'||eoTmp_Num);
  --*/
  --COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END;
/

--����������������� 
declare
        dDate1  DATE;
        cHeader VARCHAR2(100);
begin
        dDate1 := to_date('14.03.2019','dd.mm.yyyy');
 while dDate1 <= to_date('14.03.2019','dd.mm.yyyy') loop
        cHeader := 'A';

delete from bank_balance where header=cHeader and WORK_DATE = dDate1;
insert into bank_balance(HEADER,BAL,CURRENCY,WORK_DATE,
                         DEBIT,RDEBIT,CREDIT,RCREDIT,SALDO,RSALDO)
    select header,BAL,CURRENCY,WORK_DATE,
           sum(debit) debit,sum(rdebit) rdebit,sum(credit) credit,sum(rcredit) rcredit,
           sum(saldo+debit-credit) saldo,sum(rsaldo+rdebit-rcredit) rsaldo
      from (
        select header, substr(code,1,5) bal,currency,dDate1 work_date,
               sum(decode(flag_debit,'+',vsum,0)) debit,
               sum(decode(flag_debit,'+',rsum,0)) rdebit,
               sum(decode(flag_debit,'-',vsum,0)) credit,
               sum(decode(flag_debit,'-',rsum,0)) rcredit,
               0 saldo,0 rsaldo
        from journal where work_date = dDate1
                          and header||''=cHeader
--and ysubdepartment <> 191253
        group by header,substr(code,1,5),currency
        union all
        select HEADER,BAL,CURRENCY,dDate1 work_date,
               0 debit, 0 rdebit, 0 credit,0 rcredit,
               saldo, rsaldo
        from bank_balance
        where work_date = (dDate1-1) and header=cHeader
       )
       group by header,BAL,CURRENCY,WORK_DATE;
 commit;

 dDate1 :=  dDate1 + 1;
 end loop;
end;
/