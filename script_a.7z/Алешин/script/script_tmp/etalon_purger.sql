select * from dba_objects where status = 'INVALID' 
and owner in ('MBANK','EID')
and OBJECT_TYPE not in ('RULE SET','RULE','EVALUATION CONTEXT','TRIGGER')

select * from dba_tables where table_name = 'V_COMMISSION_INFO' 

--���� �������� 40 ����
select * from UNLOAD_FILE
--delete UNLOAD_FILE  
where date_create < '01jan2020' 

alter table UNLOAD_FILE move lob(blob_file) store as (tablespace BANK_MEDIUM);

select * from dba_indexes ii where table_name = 'V_COMMISSION_INFO'
and not exists (select null from dba_ind_partitions where index_name = ii.index_name and owner = ii.owner)
and status = 'INVALID'
/

select * from types where 13834 