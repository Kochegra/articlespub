select * from v$version

grant execute on dbms_defer_query to mbank;
--grant select on  def$_aqerror to mbank;
/

select 'alter '||decode(object_type,'PACKAGE BODY','PACKAGE',object_type)||' '||owner||'.'||object_name||' compile'||decode(object_type,'PACKAGE BODY',' BODY')||';'
,tt.* from dba_objects tt where status = 'INVALID' 
--and owner in ('MBANK')--,'MBANK_AUDIT','MBANK_ADMIN','EID','SYNERGY') 
and owner in ('MBANK')--,'MBANK_AUDIT','MBANK_ADMIN','EID','SYNERGY') 
and not exists (select null from dba_source ss, dba_db_links ll where 1=1 
and ss.owner = tt.owner and ss.name = tt.object_name   
and instr(upper(text),'@'||replace(ll.db_link,'.WORLD','')) > 0
)
and not exists (select null from dba_source ss where 1=1 
and ss.owner = tt.owner and ss.name = tt.object_name   
and ( instr(upper(text),'DBMS_DEFER_QUERY') > 0 or instr(upper(text),'@HYPERIAN') > 0 or instr(upper(text),'FIL_BUF_ADDPARAMS%ROWTYPE') > 0 
or instr(upper(text),'BUF_TRANS%ROWTYPE') > 0 or instr(upper(text),'@ROSTOV') > 0
))
and object_name not in ('ISCLIENTDIA')
 order by object_name--trunc(last_ddl_time,'hh24') desc, object_name

-- 
select * from v$parameter where 1=1 
--and name like '%opti%' 
and name in ('compatible','optimizer_features_enable','plsql_optimize_level')
/


--������
SMGOZ_EXCHANGE ���������� ������ �
alter session set events =  '10946 trace name context forever, level 64';