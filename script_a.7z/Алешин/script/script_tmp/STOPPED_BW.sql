
select 
(
select name from guides g where type_doc=6054 and code=(
select eid.get_data_firma.GetParam(eid, 'CATEGORY') from eid.eid_firma_products where account = payers_account and type_doc=94
                                                       )
) categ,
(
select decode(count(*),0, 0, 1) from callc_calls where reference = d.reference and branch = d.branch 
) tel_call_center,
nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') tel, 
reference,refer_office,doc_number, summa, date_create, payers_account, payers_inn, payers, 
decode(substr(receivers_account,6,3),'000',UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_REAL_ACC'),receivers_account) receivers_account
, receivers_bik, receivers_bank from documents d where type_doc=2
--and date_create>='26-mar-2020'
and refer_office like 'I%'
and status=10 --and folder=88
--and nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') = '1'
--and exists(select * from  zyx_cont_cb where d=to_char(d.reference) )
--and branch<>314
order by date_create
/
select * from cbs_doc_rerun 
--update cbs_doc_rerun set done = 0
where (reference,branch)  in (
select reference,branch from documents d
--update documents folder = 26, 
where reference in 
(select d from zyx_cont_cb where o like '���������������, ���������� �����%')
and status = 10
--and nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') = '1'
)

/

declare
  ver number;
begin
  for dd in (
               select * from documents 
               where 1=1        
               and status = 10
               and nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') = '1'
               --and reference in (select d from zyx_cont_cb where o like '���������������, ���������� �����%')
               and reference in (3901540665) 
               --(3901433439,3903677355,3903677378,3903677428,3903677466,3903677500,3903677798,3903677816)
            )
  loop
    update documents set folder = 26, date_create = trunc(sysdate)
                       , receivers_account=nvl(UNIVERSE.VARIABLE_DOC(branch, reference,'STOPPED_REAL_ACC'),receivers_account)    
    where reference = dd.reference and branch = dd.branch;
    update variable_documents set value = '0'
    where reference = dd.reference and branch = dd.branch and name = 'STOPPED_BW' and value <> '0';
    for vv in (select * from documents where reference = dd.reference and branch = dd.branch)
    loop
      ver := vv.version;
    end loop;
    update cbs_doc_rerun set done = 0, version = ver where reference = dd.reference and branch = dd.branch and done > 1;    
    commit;
  end loop;
end;
/


select 
(
select name from guides g where type_doc=6054 and code=(
select eid.get_data_firma.GetParam(eid, 'CATEGORY') from eid.eid_firma_products where account = payers_account and type_doc=94
                                                       )
) categ,
(
select decode(count(*),0, 0, 1) from callc_calls where reference = d.reference and branch = d.branch 
) tel_call_center,
nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') tel, 
reference,refer_office,doc_number, summa, date_create, payers_account, payers_inn, payers, 
decode(substr(receivers_account,6,3),'000',UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_REAL_ACC'),receivers_account) receivers_account
, receivers_bik, receivers_bank 
,status
from documents d where type_doc=2
and date_create>='10apr2020' and date_document < sysdate and nvl(date_work,trunc(sysdate)) < sysdate
and refer_office like 'I%'
and status=10-- and status not in (30,35,45,1000,36)
and nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'STOPPED_BW'),'0') = '1'
--and exists (select * from  cbs_doc_rerun where reference = d.reference and branch = d.branch and nvl(date_work,trunc(sysdate)) < sysdate )
and not exists (select null from audit_table where reference = d.reference and branch = d.branch and action in ('�����'))
--and nvl(UNIVERSE.VARIABLE_DOC(branch,reference,'USELOAN'),'0') = '0'
--and branch<>314
order by date_create
/


select * from callc_calls


select * from cbs_doc_rerun where reference = 3901540665

select * from audit_table where reference = 3901540665 

select t.* from documents t where reference = 3901540665

1099478555

select * from variable_documents where reference = 3901433439
/


select * from cbs_doc_rerun where sys_date > sysdate-10