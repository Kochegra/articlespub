exp_swift.UnLoadOutSWIFTMsg; 

select * from cbs_dirs where directory like '%CBS_BANK\ICO%'

select * from cbs_dirs where robot_no = 5

select * from archive where related = 3166098745
reference in  (3165566344,3168305469)

select * from documents where related = 3166098745
reference in  (3165566344,3168305469)

--type_doc = 1 and payers_account like '60322%' and receivers_account like '30305%' 
/
select * from variable_documents where
reference in  (3165566344,3168305469,3165565815,3166098745) and branch = 56
/
select * from variable_archive where
reference in  (3166375371,3166375372) and branch = 56
/
--create table zyx_doc as
select * from archive dd where type_doc = 1 and date_work = '26nov2018' and payers_account like '60322%' and receivers_account like '30305%'
--and not exists (select 1 from impex_doc i where i.doc_ref = dd.reference and i.doc_branch = dd.branch) 
and folder = 900 

insert into zyx_doc
select * from archive dd where date_work = '21dec2018' and payers_account like '20202%' and receivers_account like '30305%' --and folder <> 900 
and not exists (select 1 from impex_doc i where i.doc_ref = dd.reference and i.doc_branch = dd.branch) and related > 0

select * from zyx_doc where type_doc = 1
/

/
--insert into zyx_doc
select * from archive a where date_work = '21dec2018' and type_doc = 7 and folder = 900
and exists (select null from tbl_swift_document sd, tbl_swift s where sd.reference = a.reference and sd.branch = a.branch
and s.id = sd.parent_id and s.msg_date > '22dec2018')
/

select * from archive where --reference in (3198965362,3198965361,3198952858 )
doc_number = '21537' and date_work = '21dec2018' and summa = 13159000
/

select * from tbl_swift_document sd, tbl_swift s where (reference,branch) in 
(select reference,branch from archive where --reference in (3198965362,3198965361,3198952858 )
date_work = '21dec2018' and type_doc = 7 and folder = 900
)
and s.id = sd.parent_id and msg_date > '22dec2018'
/
select * from tbl_swift

select * from tbl_swift_document
/

60322810400000000370
60322840700000000370
60322978300000000370
/
select * from guides where type_doc = 4873
/

select * from archive where (reference,branch) in (select reference,branch from zyx_doc)

/
SELECT * FROM ARCHIVE
--update ARCHIVE set date_work = date_value
WHERE (branch,reference) in
(select BRANCH_Related,related  from archive dd where (reference,branch) in (select reference,branch from zyx_doc where type_doc <> 1))
/

PLEDGER.WCOURSE(currency,work_date)
/

--insert into journal_zp
--select vsum*PLEDGER.WCOURSE(currency,work_date) ns,  j.* from journal j
select  j.* from journal j
--delete journal
--where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978))
where (docnum,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
--and currency <> '810' and work_date = '27nov2018'

/
--insert into journal
select j.* from journal_zp j
where (docnum,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
--and users = 1403
/ 
--60322810400000000370
--60322840700000000370
--60322978300000000370

select * from journal_zp
--update journal_zp set work_date = '27nov2018', value_date = '27nov2018'
--update journal_zp set rsum = round(vsum*PLEDGER.WCOURSE(currency,work_date),2)
--update journal_zp set code = decode(substr(code,1,8),'30305810','60322810400000000370',30305840,60322840700000000370,30305978,60322978300000000370,code)
--                      , assist =decode(substr(assist,1,8),'30305810','60322810400000000370',30305840,60322840700000000370,30305978,60322978300000000370,assist) 
where (docnum,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)

/

--����� ������ ������ ����� �������� ���������
select rowid,d.* from archive d
--update  archive set date_work =  '27nov2018', date_value = '27nov2018'--, date_document = '19-jul-2018'
--update  archive set RECEIVERS_ACCOUNT = decode(substr(RECEIVERS_ACCOUNT,1,8),'30305810','60322810400000000370',30305840,60322840700000000370,30305978,60322978300000000370,RECEIVERS_ACCOUNT)
                     --, REAL_RECEIVERS =decode(substr(REAL_RECEIVERS,1,8),'30305810','60322810400000000370',30305840,60322840700000000370,30305978,60322978300000000370,REAL_RECEIVERS)
--update  documents set status = 1000
--where refer_from in (2821660486,2821672220)
where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
/

--������ ����� � ��������� �����������
select rowid,d.* from variable_archive d
--update  variable_archive set VALUE = decode(substr(VALUE,1,8),'30305810','60322810400000000370',30305840,60322840700000000370,30305978,60322978300000000370,VALUE)
where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
and name = 'CASHSYMBOL' and SUBFIELD = 'ACCOUNT'

/

select * from plan_account where bal in ('60322','20202','30305','60323','30301','30220','30232')

select * from journal where docnum  = 3165567472

select * from archive where reference = 3166098424
/
select distinct c.account from corrschema c where nvl(c.block,0) = 0 and account = '30305810200810101001' --c.schemas = pSend
/
  select--+ PUSH_PRED(DD)
     dd.reference,dd.branch, 5 type_check
    from  journal j, v_documents dd, v_documents d
      where d.type_doc in (4800,5113,3369) and dd.date_work = '26nov2018'
        and dd.type_doc in (1,7)-- ���. �������� � �������� ���������� ���������� ������������  � ���������� �� �/� ���
        and d.reference=dd.related and d.branch=dd.branch_related
        and dd.reference=j.docnum and dd.branch=j.branch
        and j.flag_debit = '-' and j.code = '30305810200810101001' and j.work_date = '26nov2018'
        and j.header = 'A' and j.currency  = substr('30305810200810101001',6,3)
        and dd.status = 30 --and pSend  in (11,17)  and nvl(pCash,1) = 1
        --and impex_exptools.chkNoExpFolder(dd.folder) = 1
        --and not exists (select 1 from impex_doc i where i.doc_ref = dd.reference and i.doc_branch = dd.branch)
        
        
 /
 
 select global_parameters.BankDate(trunc(sysdate), -1) from dual
 
 
 select * from corrschema c where nvl(c.block,0) = 0 and account = '30305840500810101001'
 
 select * from guides where type_doc = 581

/
select * from documents where (reference,branch) in (select reference,branch from zyx_doc)

select  
reference, branch, BRANCH_FROM, BRANCH_RELATED, DATE_CREATE, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, MEMO
,NUM_GROUP, OWNER, PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK, PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS, REAL_RECEIVERS, RECEIVERS
, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE, RELATED, SHIFROPER, STATUS
, SUB_TYPE, SUMMA, TYPE_DOC, XSUBDEPARTMENT, XSUMMACREDIT
from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
/
--������������� ������� � �������� 7701
insert into documents (reference, branch, BRANCH_FROM, BRANCH_RELATED, DATE_CREATE, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, MEMO,NUM_GROUP, OWNER,
 PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK,
  PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS
  , REAL_RECEIVERS, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE
, RELATED, SHIFROPER, STATUS , SUB_TYPE, SUMMA, TYPE_DOC, XSUBDEPARTMENT, XSUMMACREDIT)
select DOC_REFERENCE.NEXTVAL,
branch,BRANCH_FROM, BRANCH_RELATED,sysdate,trunc(sysdate),trunc(sysdate),trunc(sysdate),DEPART_PAYERS,DEPART_RECEIVERS,DOC_NUMBER,0,MEMO,NUM_GROUP,OWNER,
'������������� ������� � �������� 7701',decode(payers_currency,'840','60322840700000000370','978','60322978300000000370','60322810400000000370') payers_account,PAYERS_BANK, PAYERS_BIK,
PAYERS_CORACC, PAYERS_CURRENCY, '7702070139' payers_inn,PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, decode(payers_currency,'840','60322840700000000370','978','60322978300000000370','60322810400000000370') real_payers
, REAL_RECEIVERS, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CORACC, RECEIVERS_CURRENCY, '7702070139' receivers_inn, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE 
, RELATED, SHIFROPER, 10 status, SUB_TYPE, SUMMA, 1 type_doc, XSUBDEPARTMENT, XSUMMACREDIT
 from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)
/

insert into variable_documents(NAME,REFERENCE,	BRANCH,VALUE,XDATE)
select va.name,d1.reference,d1.branch,va.value,va.xdate from documents d1, archive d2, variable_archive va  where d1.type_doc = 1
and (d1.related,d1.branch_related) in (select related,branch_related from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7))
and d2.related = d1.related and d2.branch_related = d1.branch_related and d2.type_doc = 7 and d1.summa = d2.summa and d1.doc_number = d2.doc_number
and d2.reference = va.reference and d2.branch = va.branch and name in ('BANKOMAT_ACCOUNT','BANKOMAT_NUMBER')

/

select * from archive
--update archive set date_work = trunc(sysdate)-1
where reference in 
(select related from documents where type_doc = 1
and (related,branch_related) in (select related,branch_related from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7)))
/

select rowid,d.* from documents d
--update  documents set folder = 0
where type_doc = 1
and (related,branch_related) in (select related,branch_related from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7))
--and folder = 901
/
select rowid,d.* from documents d where reference in (3168305467) ,3168305468)
/
declare
   doc_ref number;
   doc_br number;
   j                NUMBER;
   tmp1             VARCHAR2(2000);
   tmp2             VARCHAR2(2000);
begin

for rd in (
select * from documents where type_doc = 1
and (related,branch_related) in (select related,branch_related from archive where (reference,branch) in (select reference,branch from zyx_doc where date_work = '21dec2018' and type_doc = 7))
)
loop                  
   --doc_ref := 3005099381;
   --doc_br :=191;
   mbank.ptools2.short_init_user (rd.owner);  
    j := NULL; tmp1 := NULL; tmp2 := NULL;
    dbms_output.put_line('reference = '||rd.reference||' - '||DOCALGO.EXECDOC(rd.branch,rd.reference,rd.owner, j, tmp1, tmp2));
    commit;
end loop;                     
end; 
/

select * from documents where type_doc = 7 and related > 0 and status > 29 and status < 46 and receivers_account like '30305%'

select * from journal where docnum = 3168305467
 
select * from variable_documents where reference in (3168288338) and branch = 56

select * from variable_archive where reference in 3202346670

select * from tbl_swift_document where reference = 3168305468

select * from tbl_swift where id = 955260976

select * from currency where currency = '981'
/

select * from documents where  memo like '%�%' 

select * from tax where operation = '800735'
/
--��������� ������������
select * from tbl_swift_document sd, tbl_swift s where (reference,branch) in 
(select reference,branch from documents where --reference in (3198965362,3198965361,3198952858 )
date_work = '24dec2018' and type_doc = 1 and (related,branch_related) in (select related,branch_related from zyx_doc where date_work = '21dec2018' and type_doc = 7) 
)
and s.id = sd.parent_id --and msg_date > '22dec2018'
/

select * from documents where reference = 3203480448

/

select * from journal
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3293228527,3293127955,3293127956,3293127959,3293127964,3293228518,3293228524,3293228526))
and header = 'A'
/

--������ �������� (��� �������� ���������)
declare
 dt date;
 j_id number; 
 j_cd varchar2(25);
begin
  dt := trunc(sysdate);
  for jr in (select * from journal
              where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3293228527,3293127955,3293127956,3293127959,3293127964,3293228518,3293228524,3293228526))
             and header = 'A' and flag_debit = '+')
  loop 
    j_id := journal_id.nextval;
    j_cd := '30305810200810101001';
    if jr.flag_debit = '+' and substr(jr.assist,1,5) = '60322' then  
      insert into journal (WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,BRANCH,related
      ,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT,HEADER
      ,CODE,CURRENCY,VSUM,RSUM,FLAG_DEBIT)
                   values (dt,dt,jr.DOCNUM,j_id,jr.OPERATION,jr.TYPE,jr.USERS,jr.BRANCH,null
                    ,j_cd,jr.CURRENCY,jr.YSUBDEPARTMENT,jr.HEADER
                    ,jr.ASSIST,jr.ASSIST_currency,jr.vsum,jr.rsum,'+');
      insert into journal (WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,BRANCH,related
      ,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT,HEADER
      ,CODE,CURRENCY,VSUM,RSUM,FLAG_DEBIT)
                   values (dt,dt,jr.DOCNUM,j_id,jr.OPERATION,jr.TYPE,jr.USERS,jr.BRANCH,null
                    ,jr.ASSIST,jr.ASSIST_currency,jr.YSUBDEPARTMENT,jr.HEADER
                   ,j_cd,jr.CURRENCY,jr.vsum,jr.rsum,'-');             
    end if;                
  end loop;                
end;                  
/