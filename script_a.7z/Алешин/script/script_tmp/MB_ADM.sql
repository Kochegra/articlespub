create or replace package AR13
 function mbkill (usr varchar2) return varchar2
is
 res varchar2(4000);
begin
  for ss in (select * from v$session where username = usr) 
  loop
    begin
      system.kill_session(p_sid => ss.sid, p_serial# => ss.serial#);
    exception when others then
      res := substr(sqlerrm,1,4000);
    end;
  end loop;
  return res;
end; 
/          

grant execute on mbkill to MBANK_ADMIN_ROLE; 


select * from users u, v$session s where s.username = u.user_
/

begin
 dbms_output.put_line('kill > '||mbkill('ALESHIN_RL'));
end;
/

