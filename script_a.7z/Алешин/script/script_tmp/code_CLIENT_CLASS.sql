select * from dba_tab_columns where column_name like 'MID'
and column_name not in ('AID','CID','DID','EID','GID','OID','PID','RID','QID','SID','XID')
/

select * from CLIENTS_CLASS_CB_HISTORY
/


alter table CLIENTS_CLASS_CB_HISTORY add (MBID number);
  
CREATE SEQUENCE CLIENTS_CLASS_CB_HISTORY_ID
  START WITH 1 
  MAXVALUE 1000000000000000000000000000
  MINVALUE 1
  CYCLE
  CACHE 256
  ORDER;

CREATE OR REPLACE TRIGGER MBANK.CLIENTS_CLASS_CB_HISTORY_DFLT
  before insert or update on MBANK.CLIENTS_CLASS_CB_HISTORY
  for each row
  disable
declare
-- %Author  : ALESHIN_RL
-- %Created : 08.07.2021
-- %usage �������� ����� �� ���������

begin
  if :NEW.MBID is null then
    :NEW.MBID := CLIENTS_CLASS_CB_HISTORY_ID.nextval;
  end if;  
end CLIENTS_CLASS_CB_HISTORY_DFLT;
/

alter trigger CLIENTS_CLASS_CB_HISTORY_DFLT enable

begin
  for ss in (select /*+ PARALLEL(6) */ rowid,t.* from CLIENTS_CLASS_CB_HISTORY t where mbid is null order by date_exec, reference)
  loop
    update CLIENTS_CLASS_CB_HISTORY set mbid = null where rowid = ss.rowid;
    commit;
  end loop;
end;
/

create unique index CLIENTS_CLASS_CB_HISTORY_PK on CLIENTS_CLASS_CB_HISTORY
(MBID)
LOGGING TABLESPACE IDX_SMALL;
/

ALTER TABLE MBANK.CLIENTS_CLASS_CB_HISTORY ADD (
  CONSTRAINT CLIENTS_CLASS_CB_HISTORY_PK
  PRIMARY KEY 
  (MBID)
  USING INDEX MBANK.CLIENTS_CLASS_CB_HISTORY_PK
  ENABLE VALIDATE);

--drop index CLIENTS_CLASS_CB_HISTORY_PK

--ALTER TABLE MBANK.CLIENTS_CLASS_CB_HISTORY drop CONSTRAINT CLIENTS_CLASS_CB_HISTORY_PK;

/


