select * from CLIENTS_IMAGES where not_loaded = 1 and state_date > sysdate-0.5
--and image_type = '1' 

select max(SOAPID) from FSSP_JRNL --where status < 1 and date_load > sysdate-3

select t.* from FSSP_JRNL t
WHERE SOAPID > 537154063-100

select max(ORA_ROWSCN) from OTR_FSSP_PACKAGE t

select scn_to_timestamp(10546545449045) from dual

--����� �������� ������
select * from dba_tab_modifications where 1=1 
--and table_owner = 'SMB_BASE'
and table_name like '%WEB_HASH%'
order by timestamp desc 

--�������
select * from dba_tables where 1=1
--and owner = 'SMB_BASE'
--and object_type not in ('INDEX','INDEX PARTITION','TABLE PARTITION','SEQUENCE','LOB','TRIGGER','SYNONYM','TYPE BODY','TYPE','PACKAGE BODY')
and table_name like '%VTB24_HYPO1%'
order by owner

--����������� �� �������
select t.* from DBA_DEPENDENCIES t 
where 1=1 and REFERENCED_OWNER in ('MBANK','EID')
and REFERENCED_NAME = 'WEB_QUESTIONS'
and substr(owner,1,5) not in ('CORP_','CHEVY','DEAL_')
order by owner

--����������� �� �����
select level, t.* from DBA_DEPENDENCIES t 
start with REFERENCED_OWNER = 'BUFF_MOBILE' and owner <> REFERENCED_OWNER --and referenced_name not in ('CLIENT_PC','PK_RECREATE_FIRMA_PK_PC','TOEID','CARD_PC') 
connect by nocycle prior OWNER = REFERENCED_OWNER and prior NAME = REFERENCED_NAME 

select t.* from DBA_DEPENDENCIES t 
where 1=1 and REFERENCED_NAME = 'USERS_SUBDEPARTMENTS' 
order by owner

--�� ����� ������� ���������
select * from dba_constraints where constraint_name in
(select r_constraint_name from dba_constraints where constraint_type = 'R' 
and owner = 'MBANK'
and table_name = 'JOURNAL'
)

--�����
select * from DBA_TAB_PRIVS where 1=1 
and grantee like 'IBANK' 
order by owner,table_name,grantee

--�������
select * from dba_objects where 1=1
and owner = 'INFORMATICA'
and object_type not in ('INDEX','INDEX PARTITION','TABLE PARTITION','SEQUENCE','LOB','TRIGGER','SYNONYM','TYPE BODY','TYPE','PACKAGE BODY')
order by owner

--������
select * from v$session where username = 'SCORING'

--������
select * from v$sqlarea where sql_id = '7h35uxf5uhmm1'

select (select sql_text from v$sqlarea where sql_id = prev_sql_id),s.* from v$session s where username = 'IBANK'

--������������
select * from DBA_USERS where  username = 'MBANK' 

--����
select rowid,u.* from mb_users u where tabn = '-9999'  
and username in (select str3 from ZYX_STORE z where OPER = 'AR_INFO' and tbl = 'TABLE' and str1 is null)
order by username  

--��� DDL
select * from mbank_audit.log_ddl where object_name = 'EFRSB_STAGE'
and ddl_type not in ('GRANT','COMMENT')
order by ddl_date desc
 
select rowid,t.* from mbank.mb_users t where username = 'POST_AQ_BUFFER' 

select * from mbank_audit.mb_audit a, mbank_audit.mb_audit_values va   where own = 'MBANK_ADMIN' and tbl = 'ORA_USER_LOGON'  and a.ref = va.ref(+) and  a.br = va.BR(+) order by a.dt desc
