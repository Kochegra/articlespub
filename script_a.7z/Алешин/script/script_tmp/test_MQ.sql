declare 
  v_objdesc PGM.MQOD;
  v_objectHandle PGM.MQOH;
begin

  --v_objdesc.OBJECTNAME := 'IIB.MBANK.LOADRATES.PUB.Q'; --��� �������
  v_objdesc.OBJECTNAME := 'TEST.Q';
  v_objdesc.DBLINKNAME := 'GATE_DG4OGRESS.WORLD';      --����
  
  PGM.MQOPEN(v_objdesc, PGM_SUP.MQOO_INPUT_AS_Q_DEF, v_objectHandle);
  dbms_output.put_line('MQOPEN '||v_objectHandle.OBJECTHANDLE||' '||v_objectHandle.DBLINKNAME);
  if nvl(v_objectHandle.OBJECTHANDLE,0) = 0 then
     raise_application_error( -20000,  'Cant connect to MQ. '||v_objdesc.OBJECTNAME||' '||v_objdesc.DBLINKNAME  ) ;
  end if; 
 PGM.MQCLOSE(v_objectHandle, PGM_SUP.MQCO_NONE); 
 commit;
 dbms_output.put_line('MQCLOSE '||v_objectHandle.OBJECTHANDLE||' '||v_objectHandle.DBLINKNAME);
  
exception when others then 
     rollback;
     PGM.MQCLOSE(v_objectHandle, PGM_SUP.MQCO_NONE);
     commit;
     dbms_output.put_line('MQERR '||v_objectHandle.OBJECTHANDLE||' '||v_objectHandle.DBLINKNAME||' '||SQLERRM);
     raise_application_error( -20000,SQLERRM ) ;
end;