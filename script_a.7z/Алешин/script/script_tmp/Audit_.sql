select * from (
select * from audit_table where reference > -200000  
and branch = 191 and time > to_date('07.02.2021 03:00','dd.mm.yyyy hh24:mi')-10/24/60 and time < to_date('07.02.2021 03:00','dd.mm.yyyy hh24:mi')
--and programm not in ('sqlplus@v-mbank (TNS V1-V3)') and orauser not in ('MT_QUEUE_CLOB') and osuser not in ('root','oracle')
and osuser <> 'root'
and rownum < 21
union all
select * from audit_table where reference > -200000 
and branch = 191 and time > to_date('07.02.2021 03:00','dd.mm.yyyy hh24:mi') and time < to_date('07.02.2021 03:00','dd.mm.yyyy hh24:mi')+10/24/60
and osuser <> 'root'
and rownum < 21
union all
select * from audit_table where reference > -200000  
and branch = 191 and time > to_date('07.02.2021 06:00','dd.mm.yyyy hh24:mi')-10/24/60 and time < to_date('07.02.2021 06:00','dd.mm.yyyy hh24:mi')
and osuser <> 'root'
and rownum < 21
union all
select * from audit_table where reference > -200000  
and branch = 191 and time > to_date('07.02.2021 06:00','dd.mm.yyyy hh24:mi') and time < to_date('07.02.2021 06:00','dd.mm.yyyy hh24:mi')+10/24/60
and osuser <> 'root'
and rownum < 21
)
order by time