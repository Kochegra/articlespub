DECLARE
xMemo VARCHAR2(2000) := '������� �����������';
--
xSTAGE NUMBER := 1011;
xRET VARCHAR2(2000);
xOD_ID NUMBER := -1;
xDate DATE;
xBranch NUMBER;
BEGIN
  xBranch := mbFilId;
  xDate := global_parameters.DAT_SUBDEPARTMENTS(xBranch, 'SYSTEMDATE');
  xRET := MB_LOCKS.L_TRY('OD.MBANK.'||xBranch||'#'||xSTAGE );
  xOD_ID := P_OPERDAY.ADD_LOG(xDate , xBranch, xSTAGE, xMemo );
  P_AUDIT.SAVE('CLOSE_OD', P_OPERDAY.DAY_ID(xDate), -101, xMemo, xStage);
  COMMIT;
  MBANK.ptools_corp_overdraft.Auto_Common;
  P_OPERDAY.SET_LOG(xOD_ID , 2, xMemo||' SUCCESS!' );
  COMMIT;
  xRET := MB_LOCKS.L_FREE('OD.MBANK.'||xBranch||'#'||xSTAGE );
EXCEPTION
  WHEN OTHERS THEN
    xMemo := xMemo||'. '||SqlErrm;
    P_OPERDAY.SET_LOG(xOD_ID , -1, xMemo );
    COMMIT;
END;