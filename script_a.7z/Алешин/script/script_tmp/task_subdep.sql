select * from eid.v_subdep_all s where id in 
(
select au.obj_id from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
and au.tbl in ('SUBDEPARTMENTS','VARIABLE_SUBDEPARTMENTS') and au.dt > sysdate-13
and (au.oper in ('INSERT','DELETE') or au.oper = 'UPDATE' and auv.field in ('PARENT','VALUE'))
and nvl(au.obj_name,'BOSS_ID') in ('BOSS_ID','BISQUIT_ID') 
)
and type in (300,301) and nvl(BOSS_ID,-1) > 0 and mbfil = mbfilid
and not exists (select null from mbank_audit.audit_table where table_name = 'REPORT' and time > sysdate-31
and branch = -13790003 and reference = s.id)



select rowid,t.* from guides t where type_doc = 13404 and num1 = -3 code like 'REPORT' 
/


select * from mbank_audit.admin_audit where time > sysdate-31 and tablename = 'SUBDEPARTMENTS'
/

select * from variable_subdepartments where name = 'HEAD_CASH' and value = '56'
/

