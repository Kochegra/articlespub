#!/usr/bin/bash
###################################################3
# Parameters in admin.cfg
# SQL_RUNNER_PARALLEL  --default 1 (from 1 to 4)
#
declare      gf_syslib_module=/var/opt/oracle/bmscripts/syslib.lib
declare      gf_admin_module=/var/opt/oracle/admin.cfg
declare      SCRIPT=${0##*/}
declare  	gc_pid
declare		gc_run_flag="YES"
declare 	gf_sql_runner_bin=/var/opt/oracle/bmscripts/sql_runner_p.sh
declare         gc_os=$(uname)
declare      OPTSTRING=":s:m:t:p:v:"
declare		gc_param_string=""
declare		gc_version=1

if [ "$(id -un)" != "oracle" ]
then
	echo "You must be oracle to start script"
	exit
fi


if [ ! -f $gf_syslib_module ]; then
        echo "$(basename $gf_syslib_module) is not found"
        exit $SYS_INTERRUPT_CODE
fi

if [ ! -f $gf_admin_module ]; then
        echo "$(basename $gf_admin_module) is not found"
        exit $SYS_INTERRUPT_CODE
fi

if [ ! -f $gf_sql_runner_bin ] || [ ! -x $gf_sql_runner_bin ]
then
	echo "Can not find $gf_sql_runner_bin"
	exit $SYS_INTERRUPT_CODE
fi

source $gf_syslib_module
source $gf_admin_module
SQL_RUNNER_PARALLEL=${SQL_RUNNER_PARALLEL:-1}
gc_sid=$ORACLE_SID

while getopts  $OPTSTRING opt 
do
        case $opt in 
        s) gc_sid=$OPTARG 
	   gc_param_string="$gc_param_string -s $gc_sid" ;;
        m) gc_proc_number=$OPTARG 
	   gc_param_string="$gc_param_string -m $OPTARG" ;;
        t) gc_interval=$OPTARG 
	   gc_param_string="$gc_param_string -t $OPTARG" ;;
	p) SQL_RUNNER_PARALLEL=$OPTARG ;;
	v) gc_param_string="$gc_param_string -v $OPTARG" ;;
        esac
done

SQL_RUNNER_PARALLEL=${SQL_RUNNER_PARALLEL:-1}
gc_sid=${gc_sid:-$ORACLE_SID}

if ( ! ps -ef|grep smon|grep $gc_sid |grep -v grep >/dev/null )
then
	echo "No instance started or incorrect ORACLE_SID"
	exit $SYS_INTERRUPT_CODE
fi

i=1
while [ $i -le  $SQL_RUNNER_PARALLEL ]
do
	LOCK_FILE_NAME=/tmp/$(basename $gf_sql_runner_bin)_"${i}_$gc_sid.lock"
	
	if   [ ! -f $LOCK_FILE_NAME ] || ( ! ps -ef|grep $(cat $LOCK_FILE_NAME|head -n +1)|grep $gf_sql_runner_bin|grep -v grep >/dev/null 2>&1)  
	then
		nohup $gf_sql_runner_bin -f $i -l $LOCK_FILE_NAME $gc_param_string >/dev/null 2>&1 &
	fi
	i=$((i+1))
done

exit
