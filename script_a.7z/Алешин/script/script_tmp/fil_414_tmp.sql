--������ ����������
select count(*) over(partition by depart) "���-�� ������ � ��"
,(select code||' '||name from cft_depart where code_org = ca.depart) tp_cft 
,code, name , date_op
,(select INN||' / '||FULL_NAME||' / '||universe.namedepart(subdepartment)||' '||subdepartment  from clients where reference = ca.cli_ref and branch = ca.cli_br) "������"
,ar13.Migr_SubId(AR13.SAPID_SUBID(ca.depart),275) tp_mb
,lpad(PSUBDEPARTMENT.GET_BOSS_SUBD(PSUBDEPARTMENT.GET_SUBD_BOSS(ca.depart,'SAP_ID')),4,'0') bis_id
,(select K from TMP_TABLES.ZYX_AR13_XLS where ab = lpad(PSUBDEPARTMENT.GET_BOSS_SUBD(PSUBDEPARTMENT.GET_SUBD_BOSS(ca.depart,'SAP_ID')),4,'0')) POO 
--, ca.* 
from cft_account ca
 where filial_code = '056'  and date_close is null --and subdepartment = 631000
 and substr(code,1,3) not in ('909','474','475','914','603','459','458','478','447','918','917')
 and substr(code,1,4) not in ('4541','4521')
 and substr(code,1,5) not in ('91312')
 and (code like '45_0%' or code like '40_0%' or code like '91317%' or code like '91315%')
 --and substr(code,1,5) not in ('40602','40603','40701','40702','40703','40802','40807'
 --,'45404','45405','45406','45407','45408','45203','45204','45205','45206','45207','45208'
 --,'91317','91315')
--and ar13.Migr_SubId(AR13.SAPID_SUBID(ca.depart),275) = 275000 -- 631000
order by "���-�� ������ � ��" desc

/

select * from users where user_id in (61797,61750)

select rowid,t.* from contracts t where reference = 20929090

select rowid,t.* from account t where contract = 20929090


select * from contracts c where type_doc = 3709 and status in (50,60) and date_open > sysdate-5
and exists (select null from users where user_id = c.owner and job = 31445 and subdepartment <> c.subdepartment)
/

--��������
select * from contracts c where type_doc in (30171,30172,30173,11240,13331,13332,1620,2127) and status in (50)
and subdepartment in (770496) 
--and exists (select null from users where user_id = c.owner and job = 31445 and subdepartment <> c.subdepartment)
/

select t.* from account t where header = 'C' and code like '91317%' 
and close_date is null
and open_date > sysdate-300 
and subdepartment in (191,191000)
--and code = '91315810220460560085'

/

--������ �������� �� ���������
select
ar13.Migr_SubId(AR13.SapId_SubID(cf.sap_id),631) mb_migr, --������������
Psubdepartment.get_subd_boss(cf.sap_id,'SAP_ID') mb_real, --��������
(select code||' '||name from cft_depart where id = cf.SUBDEPARTMENT_CFT) subd, 
cf.* from garanty_cft_mb_done cf where 1=1
and sap_id = 605111
--and reference in (17684487)
--and (reference,branch) in (select reference,branch from contracts c where type_doc in (30171,30172,30173,11240,13331,13332,1620,2127) and status in (50)
--and subdepartment in (770000)) 
/

--������ �������� �� ��������
select
ar13.Migr_SubId(AR13.SapId_SubID(cf.SUBDEPARTMENT),365) mb_migr, --������������
Psubdepartment.get_subd_boss(cf.SUBDEPARTMENT,'SAP_ID') mb_real, --��������  
(select code||' '||name from cft_depart where code_org = cf.SUBDEPARTMENT) subd, 
 cf.* from contracts_cft_kmb cf 
where 1=1 
--and cf.SUBDEPARTMENT = 605111 
and status = 50  
and cf.convert_ref in (18927365)
--and account like '45406810%'
--and (convert_ref,convert_bra) in (select reference,branch from contracts c where type_doc in (30171,30172,30173,11240,13331,13332,1620,2127) and status in (50)
--and subdepartment in (770000)) 

/

--�������� �������� ���
select ar13.Migr_SubId(AR13.SapId_SubID(k.subdepartment),substr(c.subdepartment,1,3)) mb_migr, 
(select code||' '||name from cft_depart where code_org = k.subdepartment) subd, 
c.*,k.* from contracts c, contracts_cft_kmb k  where 1=1 --and c.subdepartment like '%000'
and c.reference = k.convert_ref and c.branch = k.CONVERT_BRA 
and c.status = 50 and c.child = 0 and c.type_doc not in (30176)
and c.subdepartment in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 275) 
--and c.reference = 17681953  
  /
    
  --�������� ������ �������� �� ��������������
select
ar13.Migr_SubId(AR13.SapId_SubID(depart),631) mb_migr, --������������
Psubdepartment.get_subd_boss(depart,'SAP_ID') mb_real, --�������� 
(select name from cft_depart where code_org = cf.depart) subd
,cf.* from cft_account cf where nvl(not_used,0) = 0   and filial_code = '018'
and date_close is null  
--and code like '40702810912564201552' 
--and ar13.Migr_SubId(AR13.BisId_SubID(depart),770) = 770000
and depart in (select code_org from  cft_depart d start with code_org = 605111 connect by prior id =  high) 
 and substr(code,1,3) not in ('909','474','475','914','603','459','458','478','447','918','917')
 and substr(code,1,4) not in ('4541','4521')
 and substr(code,1,5) not in ('91312')
 and (code like '45_0%' or code like '40_0%' or code like '91317%' or code like '91315%')
/
          
select * from bis_account where branch = 275 
and code like '40702810912564201552'
/

--�������������� ��������� �������� � �� ������������ ������
--set serveroutput on; --��� sqlplus
declare
  r_fil number := 365;
  r_bis number := psubdepartment.Get_Boss_Subd(r_fil,'BISQUIT_ID');
  r_subd number;
  r_subd_usr number;
  r_usr number;
  r_cnt number := 0;
 
 function UserCFT_UserID( cft_usr number, mb_sub number) return number
  is
    usr_tab varchar2(50);
  begin  
    for uu in ( 
               select substr(c_username,2) sap from cft_user where id = cft_usr
              )
    loop 
      usr_tab := uu.sap;
    end loop;
    return puser.Get_UserID_SAP(usr_tab,mb_sub);
  end;
  
begin
  if r_bis = 0 then r_bis := 1; end if;
  for cft in (
 -- /* ��������������
             select * from (
               select 'SAP_ID' usr_type , k.convert_ref, k.convert_bra, to_char(k.subdepartment) subdepartment, k.owner from contracts_cft_kmb k 
                 where branch = r_bis and mod(convert_ref,10) = nvl('&1',mod(convert_ref,10))
               union all
               select 'CFT_ID' usr_type ,k.reference convert_ref, k.branch convert_bra, k.sap_id subdepartment, k.owner_cft owner from garanty_cft_mb k
                 where branch_cft = lpad(r_bis,3,'0') and mod(reference,10) = nvl('&1',mod(reference,10))
             ) t where 1=1 
             and  convert_ref in  (16261722)
              --and subdepartment in (select code_org from  cft_depart d start with code_org = 605111 connect by prior id =  high) 
    --*/
    /* ���������������� �������
    select 'SAP_ID' usr_type, k.* from contracts c, contracts_cft_kmb k  where c.reference = k.convert_ref and c.branch = k.CONVERT_BRA 
   --and c.status = 50 
   and c.child = 0 and c.subdepartment = r_fil||'000' 
--and c.reference = 18940625         
--*/
    /* ���������������� ��������
    select 'CFT_ID' usr_type, k.reference convert_ref, k.branch convert_bra, k.sap_id subdepartment, k.owner_cft owner 
    from contracts c, garanty_cft_mb_done k  where c.reference = k.reference and c.branch = k.branch
    --and c.status = 50 
    and c.child = 0  and c.subdepartment = r_fil||'000' 
  --and c.reference = 17681953         
--*/
             )
  loop
    begin    
      r_subd := 365436; -- ar13.Migr_SubId(AR13.SAPID_SUBID(cft.subdepartment),r_fil);
      r_subd_usr := 365436; --psubdepartment.get_subd_boss(cft.subdepartment,'SAP_ID'); --�������� �����
      if cft.usr_type = 'SAP_ID' then
        r_usr:= puser.Get_UserID_SAP(cft.owner,r_subd_usr);
      end if;
      if cft.usr_type = 'CFT_ID' then
        r_usr:= UserCFT_UserID(cft.owner,r_subd_usr);
      end if;       
      if r_usr = 0 then
        r_usr := coalesce(global_parameters.get_param('���_�����_��',r_subd),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;  
      --dbms_output.put_line(cft.convert_ref||' sub_id = '||r_subd||' usr_id = '||r_usr);
      update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner)
      where reference = cft.convert_ref and branch = cft.convert_bra      
        and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
      r_cnt := r_cnt + sql%rowcount;
      if sql%rowcount > 0 then
        update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner) where contract = cft.convert_ref and branch_contract = cft.convert_bra;  
      end if;  
      commit;
    exception when OTHERS then
      r_cnt := r_cnt - sql%rowcount;
      rollback;
      dbms_output.put_line('ref = '||cft.convert_ref||' br = '||cft.convert_bra||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('contracts r_cnt = '||r_cnt);
end;
/

--���������� �������� �������� � ������������
--set serveroutput on; --��� sqlplus
declare
  r_fil number := 770;
  r_subd number;
  r_usr number;
  r_cnt number := 0;
  rec_usr users%rowtype;
begin
  for cc in (
  select c1.reference,c1.branch,c1.owner,c1.subdepartment from contracts c1 
  where 1=1
  and c1.subdepartment in --(select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = r_fil)
    (631484)
   and c1.status < 1001 and c1.child = 0
   and not exists (select null from users where user_id = c1.owner and subdepartment in (c1.subdepartment,psubdepartment.get_subd_boss(psubdepartment.Get_Boss_Subd(c1.subdepartment,'BOSS_ID'),'BOSS_ID')))
 --and c1.reference = 17920642
 --and (reference,branch) in (
 --(select contract,branch_contract from account t where header = 'C' and code like '91315%'  and open_date > sysdate-300 and subdepartment in (191,191000))  )         
--*/
             )
  loop
    begin 
    --�� �������� ����� 
      r_subd := psubdepartment.get_subd_boss(psubdepartment.Get_Boss_Subd(cc.subdepartment,'BOSS_ID'),'BOSS_ID');       
      rec_usr := puser.Get_User(cc.owner);
      r_usr := puser.Get_UserID(rec_usr.params,r_subd);
      if r_usr = 0 then --�� ������
        r_usr := puser.Get_UserID(rec_usr.params,cc.subdepartment);
      end if;  
      if r_usr = 0 then
        r_usr := coalesce(global_parameters.get_param('���_�����_��',cc.subdepartment),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;
     -- dbms_output.put_line(cft.convert_ref||' sub_id = '||r_subd||' usr_id = '||r_usr);
      update contracts set owner = nvl(r_usr,owner) where reference = cc.reference and branch = cc.branch;
      r_cnt := r_cnt + sql%rowcount;
      if sql%rowcount > 0 then
        update account set owner = nvl(r_usr,owner) where contract = cc.reference and branch_contract = cc.branch;  
      end if;  
      commit;
    exception when OTHERS then
      dbms_output.put_line('ref = '||cc.reference||' br = '||cc.branch||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('contracts r_cnt = '||r_cnt);
end;

/

--�������������� �����������
declare 
  r_fil number := 770;
  r_cnt number := 0;
  r_cnt_a number := 0;
  r_usr number;
begin
  for cc in (
  select c1.reference,c1.branch,c1.owner,c0.subdepartment,c0.owner usr from contracts c1, contracts c0 
  where 1=1 
--  and c0.subdepartment in --(select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = r_fil)
--(631484)
   and c0.status < 1001 --and c0.subdepartment <> r_fil||'000'
   and c1.refer_from = c0.reference and c1.branch_from = c0.branch and c1.status < 1001
   and (c0.subdepartment <> c1.subdepartment or not exists (select null from users where user_id = c1.owner and subdepartment in (c0.subdepartment,psubdepartment.get_subd_boss(psubdepartment.Get_Boss_Subd(c0.subdepartment,'BOSS_ID'),'BOSS_ID')) ) )
   and c0.reference = 16742447    
            )
  loop
    begin
      r_usr:= puser.Get_UserID(cc.owner,cc.subdepartment);
      if r_usr = 0 then
        r_usr := puser.Get_UserID(cc.usr,cc.subdepartment);
      end if;  
      if r_usr = 0 then
        r_usr := coalesce(global_parameters.get_param('���_�����_��',cc.subdepartment),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;  
      update contracts set subdepartment = cc.subdepartment, owner = r_usr where reference = cc.reference and branch = cc.branch;
      r_cnt := r_cnt + sql%rowcount;
      update account set subdepartment = cc.subdepartment, owner = r_usr where contract = cc.reference and branch_contract = cc.branch    
        --and subdepartment in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = r_fil)
        ;
      r_cnt_a := r_cnt_a + sql%rowcount;  
      commit;
    exception when OTHERS then
      r_cnt := r_cnt - sql%rowcount;
      rollback;
      dbms_output.put_line('ref = '||cc.reference||' br = '||cc.branch||'  err ='||sqlerrm);
    end;        
  end loop;
  dbms_output.put_line('contracts r_cnt = '||r_cnt||' account r_cnt_a = '||r_cnt_a);
end; 

/

--�������������� ����� �� ���������
--set serveroutput on --��� sqlplus
declare
--  r_fil number := 770; 
--  r_subd_def number := 770000; 
--  r_bis number := psubdepartment.Get_Boss_Subd(r_fil,'BISQUIT_ID');
  r_subd number;
  r_usr number;
  r_cnt number := 0;
begin
  --if r_bis = 0 then r_bis := 1; end if;
  for cft in (
select c.subdepartment sub_id,c.owner usr_id, c.* from contracts c 
where c.status < 1001   
and exists (select /*+ INDEX (AA ACCOUNT_CONTRACT_IDX) */ null from account AA where contract = c.reference and branch_contract = c.branch 
 --and  code = c.account 
 and c.subdepartment <> subdepartment
 ) --and c.subdepartment in (235426,631311,365436,365410,660304)
 and c.reference = 16261722 
             )
  loop
    begin    
      --dbms_output.put_line(cft.convert_ref||' sub_id = '||r_subd||' usr_id = '||r_usr);
      update /*+ INDEX (AA ACCOUNT_CONTRACT_IDX) */ account set subdepartment = nvl(cft.sub_id,subdepartment), owner = nvl(cft.usr_id,owner)
      where contract = cft.reference and branch_contract = cft.branch 
      --and code = cft.account  
        and (nvl(owner,-13) <> nvl(cft.usr_id,-13) or nvl(subdepartment,-13) <> nvl(cft.sub_id,-13));
      r_cnt := r_cnt + sql%rowcount;
      commit;
    exception when OTHERS then
      rollback;
      dbms_output.put_line('ref = '||cft.reference||' br = '||cft.branch||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('account r_cnt = '||r_cnt);
end;
/


/

select * from contracts c, account a where c.status = 50 and c.subdepartment <> 191
and a.contract = c.reference and a.branch_contract = c.branch and A.CODE = c.account
--AND C.SUBDEPARTMENT <> A.SUBDEpartment
and a.subdepartment = 191 and c.date_open > sysdate-100 and type_doc in (30171,30173,2127,7632)


select * from contracts c where c.status = 50 and c.subdepartment in (191,191000)
and c.date_open > sysdate-300 and type_doc in (30171,30173,2127,7422,7632,11240)

select * from contracts c where reference = 15903645

select * from contracts c where c.status = 50 and c.subdepartment in (191,191000)
and c.date_open > sysdate-300 and type_doc in (7422,7632)
/

select * from variable_contracts where reference = 15877055 and branch = 191

--select * from v_subdep where code = '0043'


select * from guides where type_doc = 988 and code = '2514489'

select * from users where user_id = 955012986

declare
  r_subd number;
  r_usr number;
  r_cnt number := 0;
  r_rko varchar2(25);
  rec_usr users%rowtype; 
  rec_subd boss_subdepartments%rowtype;
  rec_cont contracts%rowtype;  
  
  function get_RKO(cl_ref number,cl_br number) return varchar2
  is
    rec_clt clients%rowtype;    
  begin
    if UNIVERSE.GET_CLIENT_REC(cl_ref, cl_br, rec_clt) then    
      for rr in (select cc.* from contracts cc, clients ll where cc.type_doc = 94 and cc.status in (50,60)
         and cc.refer_client = ll.reference and cc.branch_client = ll.branch
         and ll.inn = rec_clt.inn and nvl(ll.DOC_NUMBER,'-13') = nvl(rec_clt.DOC_NUMBER,'-13')
         order by cc.status,cc.date_open desc, nvl(cc.date_close,sysdate+365) desc  
         )
      loop
        return rr.account;
      end loop;   
    end if;
    return null;  
  end;
   
begin
  for cc in (
  --/* 
    select * from contracts c where 1=1
      --and c.status = 50 and c.subdepartment in (191,191000)
      and c.date_open > sysdate-300 
      --and type_doc in (7422,7632,2127,11240)
      --and (reference,branch) in (  (select contract,branch_contract from account t where header = 'C' and code like '91317%' and open_date > sysdate-300 and subdepartment in (191,191000)) )
      and type_doc in 6776 
      and c.status in (60,50) and c.child = 0
     and not exists (select null from users where user_id = c.owner and subdepartment in (c.subdepartment,psubdepartment.get_subd_boss(psubdepartment.Get_Boss_Subd(c.subdepartment,'BOSS_ID'),'BOSS_ID')))
     -- and reference = 21148226
--*/
             )
  loop
    begin    
      rec_usr := PUSER.GET_USER(UNIVERSE.GUIDE(988,UNIVERSE.VARIABLE_CONTRACT(cc.branch,cc.reference,'INSPECTOR'),'CODE1'));
      r_usr := PUSER.Get_UserID(rec_usr.params); --��������
      rec_usr := PUSER.GET_USER(r_usr);
    --  dbms_output.put_line(cc.reference||' subd = '||cc.subdepartment
    --  ||' user_subd = '||eid.p_eid_tools2.get_filial_id(PSUBDEPARTMENT.Get_Subd_Boss(PSUBDEPARTMENT.Get_Boss_Subd(rec_usr.subdepartment,'BOSS_ID')),1)
   --   ||' cont_subd = '||PSUBDEPARTMENT.Get_Subd_Boss(PSUBDEPARTMENT.Get_Boss_Subd(cc.subdepartment,'BOSS_ID'))
   --   ||' r_usr = '||r_usr);
      if coalesce(eid.p_eid_tools2.get_filial_id(PSUBDEPARTMENT.Get_Subd_Boss(PSUBDEPARTMENT.Get_Boss_Subd(rec_usr.subdepartment,'BOSS_ID')),1),191)  
        = coalesce(PSUBDEPARTMENT.Get_Subd_Boss(PSUBDEPARTMENT.Get_Boss_Subd(cc.subdepartment,'BOSS_ID')),191)
      then   
        r_usr := 0;
      end if;
      if r_usr = 0 or r_subd is null then      
        if nvl(cc.assist,'1111') like '40_0%' then
          r_rko := cc.assist;
        else --����� ��� �������
         -- dbms_output.put_line(cc.reference||' get_RKO '||cc.refer_client||' '||cc.branch_client);
          r_rko := get_RKO(cc.refer_client,cc.branch_client);
        end if;    
        if UNIVERSE.GET_CONTRACT_REC(null,null,null,r_rko,94,rec_cont)  then --����� �� ���
           r_subd := rec_cont.subdepartment;
        end if;
      end if;           
      if r_usr = 0 then
        r_usr := coalesce(global_parameters.get_param('���_�����_��',r_subd),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;  
      dbms_output.put_line(cc.reference||' subd = '||cc.subdepartment||' r_subd = '||r_subd||' r_usr = '||r_usr);
     --/* 
      update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner)
      where reference = cc.reference and branch = cc.branch      
        and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
      r_cnt := r_cnt + sql%rowcount;
      if sql%rowcount > 0 then
        update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner) where contract = cc.reference and branch_contract = cc.branch;  
      end if;  
      commit;
    --*/  
    exception when OTHERS then
      rollback;
      dbms_output.put_line('ref = '||cc.reference||' br = '||cc.branch||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('contracts r_cnt = '||r_cnt);
end;
/

--������� ����� ��������� ��������

select * from contracts c where type_doc in (3709) and status in (50,60) and date_open > sysdate-3
and exists (select null from users where user_id = c.owner and job = 31445 and subdepartment <> c.subdepartment)
and refer_from = 0

select * from contracts c where type_doc in (6776) and status in (50,60) and date_open > sysdate-300
and exists (select null from users where user_id = c.owner and job = 31445 and subdepartment <> c.subdepartment)

select global_parameters.get_param('���_�����_��',subdepartment) pp, cc.* from contracts cc where reference = 15829723
/

--��������� owner
--�������������� ��������� �������� � �� ������������ ������ (��������� �������)
--set serveroutput on; --��� sqlplus
declare
  r_subd number;
  r_usr number;
  r_cnt number := 0;
  r_cnt_a number := 0;
  
  function chk_user(f_usr number,f_subd number) return number
  is
    r_usr users%rowtype;
  begin
    r_usr := PUSER.GET_USER(f_usr);
    if r_usr.subdepartment = f_subd then
      return r_usr.user_id;
    end if;
    return null;  
  end;
  
begin
  for cc in (
  --/* ��������������
    select c.* from contracts c
         where subdepartment in (select num4 from  zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (360))
        -- and reference = 24669282
             )
  loop
    begin    
      r_subd := cc.subdepartment;
      r_usr := coalesce(chk_user(cc.owner,r_subd),global_parameters.get_param('���_�����_��',r_subd),global_parameters.get_param_cfg('���_�����_�������'),1403);
     -- dbms_output.put_line(cabs.reference||' sub_id = '||r_subd||' usr_id = '||r_usr);
      update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner)
      where reference = cc.reference and branch = cc.branch      
        and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
      r_cnt := r_cnt + sql%rowcount;
      --if sql%rowcount > 0 then
      update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner) where contract = cc.reference and branch_contract = cc.branch 
      and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13)); 
      r_cnt_a := r_cnt_a + sql%rowcount;
    --  end if;  
      commit;
    exception when OTHERS then
      dbms_output.put_line('ref = '||cc.reference ||' br = '||cc.branch ||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('contracts r_cnt = '||r_cnt||'  r_cnt_a = '||r_cnt_a);
end;