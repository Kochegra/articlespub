select * from mb_od_log where start_time > sysdate-1

select rowid,c.* from config c where name like '%ARCH%'
/

--����� ����
select rowid,c.* from config c where name = 'SYSTEMDATE'
/

select * from variable_subdepartments
--update  variable_subdepartments set value = (select value from config c where name = 'SYSTEMDATE')
where name = 'SYSTEMDATE'
and value not in (select value from config c where name = 'SYSTEMDATE')

/

create table ar13_doc as
select reference,branch,'D' tbl,sysdate dt from documents t where t.type_doc in (2,95,225,226,12107) and folder = 900
/

select t.* from documents t where 
--t.type_doc in (2,95,225,226,12107) and folder = 900
(reference,branch) IN (select reference,branch from ar13_doc)
/

select * from audit_table where reference = 5121873348

--create table ar13_jour as
--insert into ar13_jour
select * from
--select count(*) from
--delete 
journal where (docnum,branch) in (select reference,branch from ar13_doc where tbl = 'A') 
--and work_date > to_date('24.08.2020','dd.mm.yyyy')
/

begin
 for tt in (select reference,branch from ar13_doc) 
 loop
   delete journal where docnum = tt.reference and branch = tt.branch;
   commit;
 end loop;
end;
/

delete ar13_doc t where exists (select null from journal where docnum = t.reference and branch = t.branch and work_date < to_date('24.08.2020','dd.mm.yyyy'))

select * from ar13_jour
--update ar13_jour set work_date = to_date('16.09.2020','dd.mm.yyyy'), value_date = to_date('16.09.2020','dd.mm.yyyy')
where work_date <> to_date('16.09.2020','dd.mm.yyyy')
/

begin
  insert into journal 
    select * from ar13_jour where (docnum,branch) in (select reference,branch from ar13_doc where tbl = 'A')
    and substr(code,9,1) = '&1'; 
    commit;  
end;
/


select * from 
--delete
impex_doc id 
where (doc_ref,doc_branch) in (select reference,branch from ar13_doc)

select * from 
--delete
impex_records r where (fp_Reference,fp_branch) in (select reference,branch from ar13_doc)

select * from documents 
--update documents set folder = 0 , status = 30, date_work = to_date('16.09.2020','dd.mm.yyyy'), date_value = to_date('16.09.2020','dd.mm.yyyy')
where (reference,branch) in (select reference,branch from ar13_doc where tbl = 'A')
and date_work <> to_date('16.09.2020','dd.mm.yyyy')


alter trigger ARCHIVE_INKP_WAIT disable

alter trigger JOURNAL_AD_NOTIFYEVENTS disable

select reference,branch,'D' tbl,sysdate dt from documents t where t.type_doc in (2,95,225,226,12107) and folder = 900

   and not exists(select 1 from impex_doc id where id.doc_ref=d.reference and id.doc_branch=d.branch)
   and not exists(select 1 from impex_records r where r.fp_Reference=d.reference and r.fp_branch=d.branch)
/

--insert into ar13_doc 
select reference,branch,'A', sysdate from archive t where t.type_doc in (2,95,225,226,12107) and folder = 900
and date_work in ('31aug2020','28aug2020','27aug2020')
/

begin
insert into documents 
select * from archive where (reference,branch) in (select reference,branch from ar13_doc where tbl = 'A' and mod(reference,10) = &1);
insert into Variable_documents 
select * from Variable_archive where (reference,branch) in (select reference,branch from ar13_doc where tbl = 'A' and mod(reference,10) = &1);
delete archive where (reference,branch) in (select reference,branch from ar13_doc where tbl = 'A' and mod(reference,10) = &1);
commit;
end;
/

begin
update documents set folder = 0 , status = 30, date_work = to_date('16.09.2020','dd.mm.yyyy'), date_value = to_date('16.09.2020','dd.mm.yyyy')
where (reference,branch) in (select reference,branch from ar13_doc where 1=1
  --and tbl = 'A' 
  and mod(reference,10) = &1)
and date_work <> to_date('16.09.2020','dd.mm.yyyy');
commit;
end;

begin
delete impex_doc where (doc_ref,doc_branch) in (select reference,branch from ar13_doc 
  where 1=1 --and tbl = 'A'
    and mod(reference,10) = &1);
commit;
end;

begin
delete impex_records r where (fp_Reference,fp_branch) in (select reference,branch from ar13_doc 
  where 1=1 --and tbl = 'A' 
    and mod(reference,10) = &1);
commit;
end;
/

declare
  r_cnt number := 0;
begin
  loop
    begin 
     delete journal where (docnum,branch) in (select reference,branch from ar13_doc) --where tbl = 'A')
     and work_date = to_date('17.09.2020','dd.mm.yyyy') and substr(code,9,1) = '&1' and rownum < 1001;
     r_cnt := sql%rowcount;  
     commit;
    exception when OTHERS then
      r_cnt := -1;
    end;   
  exit when r_cnt = 0;
  end loop; 
end;
/


begin 
  for aa in (
    select * from ar13_jour jj where (docnum,branch) in (select reference,branch from ar13_doc 
      where 1=1 --and tbl = 'A'
    )
    and substr(code,9,1) = nvl('&1',substr(code,9,1))
    and not exists (select null from journal where header = jj.header and code = jj.code and currency = jj.currency
    and work_date = jj.work_date and docnum = jj.docnum and branch = jj.branch 
    and journal_id = jj.journal_id and flag_debit = jj.flag_debit))
  loop
    begin
      insert into journal values aa;
      commit;
    exception when OTHERS then
      rollback;
    end;       
  end loop;           
end;
/

begin
  for dd in (
(select d.rowid
from journal j, 
      documents d
where j.code = '30102810000810000411' 
   and j.currency ='810' 
   and j.work_date = '16sep2020'
   and j.header = 'A' 
   and j.flag_debit = '-'
   and d.reference = j.docnum and d.branch = j.branch and d.type_doc in (2,95,225,226,12107)
   and impex_exptools.chkNoExpFolder(d.folder) = 1
   and coalesce(receivers_bik,'044525411') <> '044525411'
   and impex_cv.isBESP(j.docnum, j.branch) = 0
   and d.status=30
   and not exists(select 1 from impex_doc id where id.doc_ref=d.reference and id.doc_branch=d.branch)
   and not exists(select 1 from impex_records r where r.fp_Reference=d.reference and r.fp_branch=d.branch)
  -- and mod(d.reference,10) in (0,1,2,3,4,5,6)
  and mod(d.reference,10) = &1
)
) loop
   update documents set folder = 901 where rowid = dd.rowid;
   commit;
end loop;
end;