--������� ������� �� �� ������ � ������ �� (#etalon #main)

--alter table users drop constraint USERS_FK; 
--alter table user_parameters drop constraint user_params_FK1;
--alter table JOBs_RIGHTS drop constraint JOB_RIGHTS_FK;
--alter table PARAMVALUES drop constraint PARAMVALUES_FK1;

--update mbank.CONFIG set value ='STOP' where name = 'FLAG_PC_WAY4' and value <> 'STOP'
  
--��������� boss_subdepartments
--��������� boss_emp_all
--��������� boss_empall_adrs
--��������� eid.eid_subdepartments
--��������� eid.eid_subdep_variable
--��������� eid.eid_paramvalues

--��������� subdepartments
--��������� variable_subdepartments
--��������� paramgroupmembership
--��������� parameters
--��������� paramvalues

--��������� types
--��������� variable_types

--��������� jobs
--��������� jobs_rights
--��������� job_param_values
--��������� user_parameters
 
--��������� ���������� 13211
--��������� vtb_subdepartments

--��������� groups
--��������� �����

--������������ ����������
--��������� �������������

--��������� boss_subdepartments (��������� ��� ���� ������ ��� ���������)
select ID,DEPT_ID,NAME,D_FROM,D_TO,UNAME,DEPT_LEV,NAME_GEN,NAME_INST,NAME_DAT,NAME_ACC,NAME_PRE,PR_ASSIGNMENT,SORT_NUM,DEPT_TREE,ALT_1_TREE,ALT_2_TREE,ALT_3_TREE,OBJ_ID,SHOW_ITEM,STRONG_HIDE,EID_SUBDEP_ID,REF_CODE,SAP_ID from boss_subdepartments@etalon
minus
select ID,DEPT_ID,NAME,D_FROM,D_TO,UNAME,DEPT_LEV,NAME_GEN,NAME_INST,NAME_DAT,NAME_ACC,NAME_PRE,PR_ASSIGNMENT,SORT_NUM,DEPT_TREE,ALT_1_TREE,ALT_2_TREE,ALT_3_TREE,OBJ_ID,SHOW_ITEM,STRONG_HIDE,EID_SUBDEP_ID,REF_CODE,SAP_ID from boss_subdepartments b
--where id = 121342
/

declare
  cnt number := 0;
begin
 for bb in (
              select ID,DEPT_ID,NAME,D_FROM,D_TO,UNAME,DEPT_LEV,NAME_GEN,NAME_INST,NAME_DAT,NAME_ACC,NAME_PRE,PR_ASSIGNMENT,SORT_NUM,DEPT_TREE,ALT_1_TREE,ALT_2_TREE,ALT_3_TREE,OBJ_ID,SHOW_ITEM,STRONG_HIDE,EID_SUBDEP_ID,REF_CODE,SAP_ID from boss_subdepartments@etalon
              minus
              select ID,DEPT_ID,NAME,D_FROM,D_TO,UNAME,DEPT_LEV,NAME_GEN,NAME_INST,NAME_DAT,NAME_ACC,NAME_PRE,PR_ASSIGNMENT,SORT_NUM,DEPT_TREE,ALT_1_TREE,ALT_2_TREE,ALT_3_TREE,OBJ_ID,SHOW_ITEM,STRONG_HIDE,EID_SUBDEP_ID,REF_CODE,SAP_ID from boss_subdepartments
           )-- where id = 10655)
 loop
   for ss in (select rowid,s.* from boss_subdepartments s where id = bb.id)
   loop 
     delete boss_subdepartments where rowid = ss.rowid;
   end loop;
   begin
     insert into boss_subdepartments(ID,DEPT_ID,NAME,D_FROM,D_TO,UNAME,DEPT_LEV,NAME_GEN,NAME_INST,NAME_DAT,NAME_ACC,NAME_PRE,PR_ASSIGNMENT,SORT_NUM,DEPT_TREE,ALT_1_TREE,ALT_2_TREE,ALT_3_TREE,OBJ_ID,SHOW_ITEM,STRONG_HIDE,EID_SUBDEP_ID,REF_CODE,SAP_ID,MDATE,D_UPLOAD)
      values (bb.ID,bb.DEPT_ID,bb.NAME,bb.D_FROM,bb.D_TO,bb.UNAME,bb.DEPT_LEV,bb.NAME_GEN,bb.NAME_INST,bb.NAME_DAT,bb.NAME_ACC,bb.NAME_PRE,bb.PR_ASSIGNMENT,bb.SORT_NUM,bb.DEPT_TREE,bb.ALT_1_TREE,bb.ALT_2_TREE,bb.ALT_3_TREE,bb.OBJ_ID,bb.SHOW_ITEM,bb.STRONG_HIDE,bb.EID_SUBDEP_ID,bb.REF_CODE,bb.SAP_ID,trunc(sysdate),sysdate);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;         
   commit;   
 end loop;
 dbms_output.put_line('boss_subdepartments cnt = '||cnt);
end; 
/

--��������� boss_emp_all

select TAB_N,L_NAME,F_NAME,M_NAME,D_BIRTH,D_IN,D_OUT,FILIAL,PASSP_SER,PASSP_NUM,NUM_PRIKAZ,DSIGN,E_NAME,EMAIL,DEPT_NAME_1,DEPT_NAME_2,DEPT_NAME_3,DEPT_NAME_4,SEARCH_NAME,SEARCH_DOC,APPOINT_NAME,DEPT_ID,EMP_ID,PASSP_DATE,PASSP_GRANT_P,SEX,ADDR_1,ADDR_2,ADDR_3,M_PHONE,INN,SNN,FLAG_EDIT_HUMAN,EID,PASSP_GRANT,PASSP_HASH,ENTRY_ID,TABN24 from boss_emp_all@etalon
minus
select TAB_N,L_NAME,F_NAME,M_NAME,D_BIRTH,D_IN,D_OUT,FILIAL,PASSP_SER,PASSP_NUM,NUM_PRIKAZ,DSIGN,E_NAME,EMAIL,DEPT_NAME_1,DEPT_NAME_2,DEPT_NAME_3,DEPT_NAME_4,SEARCH_NAME,SEARCH_DOC,APPOINT_NAME,DEPT_ID,EMP_ID,PASSP_DATE,PASSP_GRANT_P,SEX,ADDR_1,ADDR_2,ADDR_3,M_PHONE,INN,SNN,FLAG_EDIT_HUMAN,EID,PASSP_GRANT,PASSP_HASH,ENTRY_ID,TABN24 from boss_emp_all
/

declare
  cnt number := 0;
begin
 for bb in (
            select TAB_N,L_NAME,F_NAME,M_NAME,D_BIRTH,D_IN,D_OUT,FILIAL,PASSP_SER,PASSP_NUM,NUM_PRIKAZ,DSIGN,E_NAME,EMAIL,DEPT_NAME_1,DEPT_NAME_2,DEPT_NAME_3,DEPT_NAME_4,SEARCH_NAME,SEARCH_DOC,APPOINT_NAME,DEPT_ID,EMP_ID,PASSP_DATE,PASSP_GRANT_P,SEX,ADDR_1,ADDR_2,ADDR_3,M_PHONE,INN,SNN,FLAG_EDIT_HUMAN,EID,PASSP_GRANT,PASSP_HASH,ENTRY_ID,TABN24 from boss_emp_all@etalon
            minus
            select TAB_N,L_NAME,F_NAME,M_NAME,D_BIRTH,D_IN,D_OUT,FILIAL,PASSP_SER,PASSP_NUM,NUM_PRIKAZ,DSIGN,E_NAME,EMAIL,DEPT_NAME_1,DEPT_NAME_2,DEPT_NAME_3,DEPT_NAME_4,SEARCH_NAME,SEARCH_DOC,APPOINT_NAME,DEPT_ID,EMP_ID,PASSP_DATE,PASSP_GRANT_P,SEX,ADDR_1,ADDR_2,ADDR_3,M_PHONE,INN,SNN,FLAG_EDIT_HUMAN,EID,PASSP_GRANT,PASSP_HASH,ENTRY_ID,TABN24 from boss_emp_all
 )-- where id = 10655)
 loop
   for ss in (select rowid,s.* from boss_emp_all s where tab_n = bb.tab_n)
   loop 
     delete boss_emp_all where rowid = ss.rowid;
   end loop;
   begin
     insert into boss_emp_all(TAB_N,L_NAME,F_NAME,M_NAME,D_BIRTH,D_IN,D_OUT,FILIAL,PASSP_SER,PASSP_NUM,NUM_PRIKAZ,DSIGN,E_NAME,EMAIL,DEPT_NAME_1,DEPT_NAME_2,DEPT_NAME_3,DEPT_NAME_4,SEARCH_NAME,SEARCH_DOC,APPOINT_NAME,DEPT_ID,EMP_ID,PASSP_DATE,PASSP_GRANT_P,SEX,ADDR_1,ADDR_2,ADDR_3,M_PHONE,INN,SNN,FLAG_EDIT_HUMAN,EID,PASSP_GRANT,PASSP_HASH,ENTRY_ID,TABN24,D_UPLOAD,D_MODIFY)
      values (bb.TAB_N,bb.L_NAME,bb.F_NAME,bb.M_NAME,bb.D_BIRTH,bb.D_IN,bb.D_OUT,bb.FILIAL,bb.PASSP_SER,bb.PASSP_NUM,bb.NUM_PRIKAZ,bb.DSIGN,bb.E_NAME,bb.EMAIL,bb.DEPT_NAME_1,bb.DEPT_NAME_2,bb.DEPT_NAME_3,bb.DEPT_NAME_4,bb.SEARCH_NAME,bb.SEARCH_DOC,bb.APPOINT_NAME,bb.DEPT_ID,bb.EMP_ID,bb.PASSP_DATE,bb.PASSP_GRANT_P,bb.SEX,bb.ADDR_1,bb.ADDR_2,bb.ADDR_3,bb.M_PHONE,bb.INN,bb.SNN,bb.FLAG_EDIT_HUMAN,bb.EID,bb.PASSP_GRANT,bb.PASSP_HASH,bb.ENTRY_ID,bb.TABN24,sysdate,sysdate);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ tab_n = '||bb.tab_n||' l_name = '||bb.l_name||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('boss_emp_all cnt = '||cnt);
end; 
/

--��������� boss_empall_adrs
select TAB_NUM,EXT_PHONE,INT_PHONE,FAX,COUNTRYCODE,COUNTRY,ZIPCODE,REGIONCODE,REGION,REGIONSHORT,DISTRICTCODE,DISTRICT,DISTRICTSHORT,CITYCODE,CITY,CITYSHORT,TOWNCODE,TOWN,TOWNSHORT,STREETCODE,STREET,STREETSHORT,HOUS,BUILDING,ROOM,ADDRESS_ID,ADDRESS,DT_FROM,DT_TO,IKS_TAB_NUM,SAP_TAB_NUM,BRANCH_NAME,ROO_NAME,OO_NAME,CITY_NAME 
  from boss_empall_adrs@etalon --where tab_num = '0320046'
minus
select TAB_NUM,EXT_PHONE,INT_PHONE,FAX,COUNTRYCODE,COUNTRY,ZIPCODE,REGIONCODE,REGION,REGIONSHORT,DISTRICTCODE,DISTRICT,DISTRICTSHORT,CITYCODE,CITY,CITYSHORT,TOWNCODE,TOWN,TOWNSHORT,STREETCODE,STREET,STREETSHORT,HOUS,BUILDING,ROOM,ADDRESS_ID,ADDRESS,DT_FROM,DT_TO,IKS_TAB_NUM,SAP_TAB_NUM,BRANCH_NAME,ROO_NAME,OO_NAME,CITY_NAME 
  from boss_empall_adrs
/

declare
  cnt number := 0;
begin
 for bb in (
            select TAB_NUM,EXT_PHONE,INT_PHONE,FAX,COUNTRYCODE,COUNTRY,ZIPCODE,REGIONCODE,REGION,REGIONSHORT,DISTRICTCODE,DISTRICT,DISTRICTSHORT,CITYCODE,CITY,CITYSHORT,TOWNCODE,TOWN,TOWNSHORT,STREETCODE,STREET,STREETSHORT,HOUS,BUILDING,ROOM,ADDRESS_ID,ADDRESS,DT_FROM,DT_TO,IKS_TAB_NUM,SAP_TAB_NUM,BRANCH_NAME,ROO_NAME,OO_NAME,CITY_NAME 
              from boss_empall_adrs@etalon --where tab_num = '0320046'
            minus
            select TAB_NUM,EXT_PHONE,INT_PHONE,FAX,COUNTRYCODE,COUNTRY,ZIPCODE,REGIONCODE,REGION,REGIONSHORT,DISTRICTCODE,DISTRICT,DISTRICTSHORT,CITYCODE,CITY,CITYSHORT,TOWNCODE,TOWN,TOWNSHORT,STREETCODE,STREET,STREETSHORT,HOUS,BUILDING,ROOM,ADDRESS_ID,ADDRESS,DT_FROM,DT_TO,IKS_TAB_NUM,SAP_TAB_NUM,BRANCH_NAME,ROO_NAME,OO_NAME,CITY_NAME 
              from boss_empall_adrs
 )-- where id = 10655)
 loop
   for ss in (select rowid,s.* from boss_empall_adrs s where TAB_NUM = bb.TAB_NUM and address_id = bb.address_id)
   loop 
     delete boss_empall_adrs where rowid = ss.rowid;
   end loop;
   begin 
     insert into boss_empall_adrs(TAB_NUM,EXT_PHONE,INT_PHONE,FAX,COUNTRYCODE,COUNTRY,ZIPCODE,REGIONCODE,REGION,REGIONSHORT,DISTRICTCODE,DISTRICT,DISTRICTSHORT,CITYCODE,CITY,CITYSHORT,TOWNCODE,TOWN,TOWNSHORT,STREETCODE,STREET,STREETSHORT,HOUS,BUILDING,ROOM,ADDRESS_ID,ADDRESS,DT_FROM,DT_TO,IKS_TAB_NUM,SAP_TAB_NUM,BRANCH_NAME,ROO_NAME,OO_NAME,CITY_NAME)
        values (bb.TAB_NUM,bb.EXT_PHONE,bb.INT_PHONE,bb.FAX,bb.COUNTRYCODE,bb.COUNTRY,bb.ZIPCODE,bb.REGIONCODE,bb.REGION,bb.REGIONSHORT,bb.DISTRICTCODE,bb.DISTRICT,bb.DISTRICTSHORT,bb.CITYCODE,bb.CITY,bb.CITYSHORT,bb.TOWNCODE,bb.TOWN,bb.TOWNSHORT,bb.STREETCODE,bb.STREET,bb.STREETSHORT,bb.HOUS,bb.BUILDING,bb.ROOM,bb.ADDRESS_ID,bb.ADDRESS,bb.DT_FROM,bb.DT_TO,bb.IKS_TAB_NUM,bb.SAP_TAB_NUM,bb.BRANCH_NAME,bb.ROO_NAME,bb.OO_NAME,bb.CITY_NAME);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ tab_num = '||bb.tab_num||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('boss_empall_adrs cnt = '||cnt);
end; 
/

--��������� eid.eid_subdepartments
select ID,NAME,PARENT,TYPE,TIME_ZONE,ID_SELS,PARENT_R,DELETED,BOSS_SUBDEP_ID,BOSS_SUBDEP_NAME from eid.eid_subdepartments@etalon
minus
select ID,NAME,PARENT,TYPE,TIME_ZONE,ID_SELS,PARENT_R,DELETED,BOSS_SUBDEP_ID,BOSS_SUBDEP_NAME from eid.eid_subdepartments 
/

declare
  cnt number := 0;
begin
 for bb in (
            select ID,NAME,PARENT,TYPE,TIME_ZONE,ID_SELS,PARENT_R,DELETED,BOSS_SUBDEP_ID,BOSS_SUBDEP_NAME from eid.eid_subdepartments@etalon where id in (405,772,775)
            minus
            select ID,NAME,PARENT,TYPE,TIME_ZONE,ID_SELS,PARENT_R,DELETED,BOSS_SUBDEP_ID,BOSS_SUBDEP_NAME from eid.eid_subdepartments
            )
 loop
   begin
     merge into eid.eid_subdepartments s
     using (select bb.ID from dual) t on (s.id = bb.id)
     when matched then update set 
       NAME = bb.NAME
      ,PARENT = bb.PARENT
      ,TYPE = bb.TYPE
      ,TIME_ZONE = bb.TIME_ZONE
      ,ID_SELS = bb.ID_SELS
      ,PARENT_R = bb.PARENT_R
      ,DELETED = bb.DELETED
      ,BOSS_SUBDEP_ID = bb.BOSS_SUBDEP_ID
      ,BOSS_SUBDEP_NAME = bb.BOSS_SUBDEP_NAME
     when not matched then insert(ID,NAME,PARENT,TYPE,TIME_ZONE,ID_SELS,PARENT_R,DELETED,BOSS_SUBDEP_ID,BOSS_SUBDEP_NAME) 
                           values(bb.ID,bb.NAME,bb.PARENT,bb.TYPE,bb.TIME_ZONE,bb.ID_SELS,bb.PARENT_R,bb.DELETED,bb.BOSS_SUBDEP_ID,bb.BOSS_SUBDEP_NAME);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('eid.eid_subdepartments cnt = '||cnt);
end;
/

--��������� eid.eid_subdep_variable
select * from eid.eid_subdep_variable@etalon
minus
select * from eid.eid_subdep_variable 
/

declare
  cnt number := 0;
begin
 for bb in (
            select * from eid.eid_subdep_variable@etalon where subd_id in (405,772,775)
            minus
            select * from eid.eid_subdep_variable
            )
 loop
   for ss in (select rowid,s.* from eid.eid_subdep_variable s where subd_id = bb.subd_id and date_modify = bb.date_modify and priority = bb.priority and type = bb.type)
   loop 
     delete eid.eid_subdep_variable where rowid = ss.rowid;
   end loop;
   begin
     insert into eid.eid_subdep_variable values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.subd_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('eid.eid_subdep_variable cnt = '||cnt);
end;
/

--��������� eid.eid_paramvalues
select * from eid.eid_paramvalues@etalon
minus
select * from eid.eid_paramvalues
/

declare
  cnt number := 0;
begin
 for bb in (
            select * from eid.eid_paramvalues@etalon where departid in (405,772,775)
            minus
            select * from eid.eid_paramvalues
            )
 loop
   begin
     merge into eid.eid_paramvalues pv
     using (select bb.PARAM_NAME, bb.PARAMGROUPID, bb.DEPARTID,	bb.ACTIVATED from dual) t
       on (pv.PARAM_NAME = bb.PARAM_NAME and pv.PARAMGROUPID = bb.PARAMGROUPID and pv.DEPARTID = bb.DEPARTID and pv.ACTIVATED = bb.ACTIVATED) 
     when not matched then insert values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ PARAM_NAME = '||bb.PARAM_NAME||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('eid.eid_paramvalues cnt = '||cnt); 
end;
/


--��������� subdepartments
select ID,NAME,PARENT,CFU_CODE,TYPE,DATE_OPEN,DATE_CLOSE,DEPART_NAME,DEPART_KIND,DEPART_KIND_SHORT from subdepartments@etalon
minus
select ID,NAME,PARENT,CFU_CODE,TYPE,DATE_OPEN,DATE_CLOSE,DEPART_NAME,DEPART_KIND,DEPART_KIND_SHORT from subdepartments
/

--���� ��� ���������
declare
  cnt number := 0;
  db_name varchar2(300);
begin
 select global_name into db_name from global_name;
 for bb in (
            select ID,NAME,PARENT,CFU_CODE,TYPE,DATE_OPEN,DATE_CLOSE,DEPART_NAME,DEPART_KIND,DEPART_KIND_SHORT from subdepartments@etalon where id in (405,772,775)
            minus
            select ID,NAME,PARENT,CFU_CODE,TYPE,DATE_OPEN,DATE_CLOSE,DEPART_NAME,DEPART_KIND,DEPART_KIND_SHORT from subdepartments
            )
 loop
   begin
     merge into subdepartments s
     using (select bb.ID from dual) t on (s.id = bb.id)
     when matched then update set 
       NAME = bb.NAME
      ,PARENT = bb.PARENT
      ,CFU_CODE = bb.CFU_CODE
      ,TYPE = bb.TYPE
      ,DATE_OPEN = bb.DATE_OPEN
      ,DATE_CLOSE = bb.DATE_CLOSE
      ,DEPART_NAME = bb.DEPART_NAME
      ,DEPART_KIND = bb.DEPART_KIND
      ,DEPART_KIND_SHORT = bb.DEPART_KIND_SHORT
     when not matched then insert (ID,NAME,PARENT,CFU_CODE,TYPE,DATE_OPEN,DATE_CLOSE,DEPART_NAME,DEPART_KIND,DEPART_KIND_SHORT,SERVER_ADDRESS,PARENT_ADDRESS) 
                           values(bb.ID,bb.NAME,bb.PARENT,bb.CFU_CODE,bb.TYPE,bb.DATE_OPEN,bb.DATE_CLOSE,bb.DEPART_NAME,bb.DEPART_KIND,bb.DEPART_KIND_SHORT,db_name,db_name);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('subdepartments cnt = '||cnt);
end;
/

--��������� variable_subdepartments
select * from variable_subdepartments@etalon
minus
select * from variable_subdepartments
/

declare
  cnt number := 0;
begin
 for bb in (
            select * from variable_subdepartments@etalon where depart_id in (405,772,775)
            minus
            select * from variable_subdepartments
            )
 loop
   begin
     merge into variable_subdepartments vs
     using (select * from dual) t
       on (vs.NAME = bb.NAME and vs.DEPART_ID = bb.DEPART_ID and vs.ROWNUMBER = bb.ROWNUMBER)        
     when not matched then insert values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ NAME = '||bb.NAME||' DEPART_ID = '||bb.DEPART_ID||' err = '||sqlerrm);  
   end;    
   commit;  
 end loop;
 dbms_output.put_line('variable_subdepartments cnt = '||cnt);
end;


--��������� paramgroupmembership
select * from paramgroupmembership@etalon
minus
select * from paramgroupmembership
/

declare
  cnt number := 0;
begin
 for bb in (
            select * from paramgroupmembership@etalon where depart_id in (405,772,775)
            minus
            select * from paramgroupmembership
            )
 loop
   begin
     insert into paramgroupmembership values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ depart_id = '||bb.depart_id||' group_id = '||bb.group_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('paramgroupmembership cnt = '||cnt);
end;
/

--��������� parameters
select * from parameters@etalon
minus
select * from parameters
/

declare
  cnt number := 0;
begin 
  for bb in (
            select * from parameters@etalon --where departid in (245,612)
            minus
            select * from parameters
            )
  loop
    for ss in (select rowid,s.* from parameters s where id = bb.id or name = bb.name)
    loop 
      delete parameters where rowid = ss.rowid;
    end loop;
    begin
      insert into parameters values bb;
      cnt := cnt + sql%rowcount;
    exception when OTHERS then
      dbms_output.put_line('������ ID = '||bb.ID||' err = '||sqlerrm);  
    end;    
    commit;   
  end loop;
  dbms_output.put_line('parameters cnt = '||cnt);
end;
/

--��������� paramvalues
select * from paramvalues@etalon where 
  paramid not in (select ID from mbank.parameters@etalon p where SUBSTR(name,1,8) IN ('SMS_HOST','APP_SERV','CKKI_APP'))
  and value not like '%//%' and value not like '%\\%' and value not like '%:\%'
minus
select PARAMID,	PARAMGROUPID,	DEPARTID,VALUE,	ACTIVATED from paramvalues
/

declare
  cnt number := 0;
begin
 execute immediate 'alter trigger PARAMVALUES_IP disable';
 for bb in (
            select * from paramvalues@etalon 
              where paramid not in (select ID from mbank.parameters@etalon p where SUBSTR(name,1,8) IN ('SMS_HOST','APP_SERV','CKKI_APP'))
                    and value not like '%//%' and value not like '%\\%' and value not like '%:\%'
                    and departid in (405,772,775)
            minus
            select PARAMID,	PARAMGROUPID,	DEPARTID,VALUE,	ACTIVATED from paramvalues
            )
 loop
   for ss in (select rowid,s.* from paramvalues s where PARAMID = bb.PARAMID and PARAMGROUPID = bb.PARAMGROUPID and DEPARTID = bb.DEPARTID and ACTIVATED = bb.ACTIVATED)
   loop 
     delete paramvalues where rowid = ss.rowid;
   end loop;
   begin
     insert into paramvalues(PARAMID,	PARAMGROUPID,	DEPARTID,VALUE,	ACTIVATED) 
     values (bb.PARAMID,	bb.PARAMGROUPID,	bb.DEPARTID,bb.VALUE,	bb.ACTIVATED);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ PARAMID = '||bb.PARAMID||' DEPARTID = '||bb.DEPARTID||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 execute immediate 'alter trigger PARAMVALUES_IP enable';
 dbms_output.put_line('paramvalues cnt = '||cnt);
end;
/

--��������� types
select * from types@etalon
minus
select * from types
/

declare
  cnt number := 0;
begin 
 for bb in (
            select * from types@etalon  -- where departid = 1
            minus
            select * from types
            )
 loop
   begin
     merge into types
     using (select bb.type_id s_id from dual) on (type_id = bb.type_id)
     when matched then update set  
       name = bb.name
       ,SHORTNAME = bb.SHORTNAME
       ,MANUAL = bb.MANUAL
       ,CODE = bb.CODE
       ,ACTION = bb.ACTION
       ,PRIORITY = bb.PRIORITY
      when not matched then insert values bb;  
      cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ type_id = '||bb.type_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('types cnt = '||cnt);
end;
/

--��������� variable_types
select * from variable_types@etalon
minus
select * from variable_types
/

declare
  cnt number := 0;
begin 
 for bb in (
            select * from variable_types@etalon  -- where departid = 1
            minus
            select * from variable_types
            )
 loop
   for ss in (select rowid,s.* from variable_types s where type = bb.type and name = bb.name and rownumber = bb.rownumber)
   loop 
     delete variable_types where rowid = ss.rowid;
   end loop;
   begin
     insert into variable_types values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ type = '||bb.type||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('variable_types cnt = '||cnt);
end;
/

--��������� jobs
select * from jobs@etalon
minus
select * from jobs
/

declare
  cnt number := 0;
begin 
  execute immediate 'alter trigger JOBS_A disable';
 for bb in (
            select * from jobs@etalon  -- where departid = 1
            minus
            select * from jobs
            )
 loop
   for ss in (select rowid,s.* from jobs s where job_id = bb.job_id)
   loop 
     delete jobs where rowid = ss.rowid;
   end loop;
   begin
     insert into jobs values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ job_id = '||bb.job_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 execute immediate 'alter trigger JOBS_A enable';
 dbms_output.put_line('jobs cnt = '||cnt);
end;
/

--��������� jobs_rights
select * from jobs_rights@etalon
minus
select * from jobs_rights

declare
  cnt number := 0;
begin 
  execute immediate 'alter trigger JOBS_RIGHTS_A disable';
 for bb in (
            select * from jobs_rights@etalon  -- where departid = 1
            minus
            select * from jobs_rights
            )
 loop
   for ss in (select rowid,s.* from jobs_rights s where id = bb.id)
   loop 
     delete jobs_rights where rowid = ss.rowid;
   end loop;
   begin
     insert into jobs_rights values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 execute immediate 'alter trigger JOBS_RIGHTS_A enable';
 dbms_output.put_line('jobs_rights cnt = '||cnt);
end;
/


--��������� job_param_values
select * from job_param_values@etalon
minus
select * from job_param_values
/

declare
  cnt number := 0;
begin 
  execute immediate 'alter trigger JOB_PARAM_VALUES_A disable';
 for bb in (
            select * from job_param_values@etalon  -- where departid = 1
            minus
            select * from job_param_values
            )
 loop
   for ss in (select rowid,s.* from job_param_values s where id = bb.id)
   loop 
     delete job_param_values where rowid = ss.rowid;
   end loop;
   begin
     insert into job_param_values values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 execute immediate 'alter trigger JOB_PARAM_VALUES_A enable';
 dbms_output.put_line('job_param_values cnt = '||cnt);
end;
/

--��������� user_parameters
select * from user_parameters@etalon
minus
select * from user_parameters
/

declare
  cnt number := 0;
begin 
 for bb in (
            select * from user_parameters@etalon  -- where departid = 1
            minus
            select * from user_parameters
            )
 loop
   for ss in (select rowid,s.* from user_parameters s where depart_id = bb.depart_id and name = bb.name or id = bb.id)
   loop 
     delete user_parameters where rowid = ss.rowid;
   end loop;
   begin
     insert into user_parameters values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('user_parameters cnt = '||cnt);
end;
/

--��������� ���������� 13211
select * from guides@etalon where type_doc in (13211,14009,13884,6041, 13654, 12889, 12890 )
minus
select * from guides where type_doc in (13211,14009,13884,6041, 13654, 12889, 12890 )
/

declare
  cnt number := 0;
begin 
 for bb in (
            select * from guides@etalon where type_doc in (13211,14009,13884,6041, 13654, 12889, 12890, 6814, 6041, 10139)
            minus
            select * from guides where type_doc in (13211,14009,13884,6041, 13654, 12889, 12890, 6814, 6041,10139 )
            )
 loop
   for ss in (
              select rowid,s.* from guides s where reference = bb.reference and branch = bb.branch 
                                                or type_doc = bb.type_doc and date_work = bb.date_work and code = bb.code and code1 = bb.code1
             )                                               
   loop 
     delete guides where rowid = ss.rowid;
   end loop;
   begin
     insert into guides values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ reference = '||bb.reference||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop; 
 dbms_output.put_line('guides cnt = '||cnt);
end;
/

--��������� ���������� 589
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,NAME,DATE1,CODE1 from guides@etalon where type_doc in (589)
minus
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,NAME,DATE1,CODE1 from guides where type_doc in (589)
/

declare
  cnt number := 0;
begin 
 for bb in (
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,NAME,DATE1,CODE1 from guides@etalon where type_doc in (589)
minus
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,NAME,DATE1,CODE1 from guides where type_doc in (589)
            )
 loop
     begin
       merge into guides
       using (select bb.type_doc g_id from dual) on (FOLDER = bb.folder and TYPE_DOC = bb.type_doc 
               and DATE_WORK = bb.date_work and CODE = bb.code and CODE1 = bb.code1)
       when matched then update set  
         status = bb.status
        ,owner = bb.owner
        ,name = bb.name
        ,date1 = bb.date1    
      when not matched then insert(reference,branch,FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,NAME,DATE1,CODE1)
                            values (guides_reference.nextval,191,bb.FOLDER,bb.TYPE_DOC,bb.STATUS,bb.OWNER,bb.DATE_WORK,bb.CODE,bb.NAME,bb.DATE1,bb.CODE1);  
      cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ code = '||bb.code||' err = '||sqlerrm);  
   end;   
end loop; 
 dbms_output.put_line('guides cnt = '||cnt);
end;
/

--3420
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,DATE1,nvl(str3,'ar'),nvl(num1,-1),nvl(num2,-1),nvl(code1,'ar') from guides@etalon where type_doc in (3420)
minus
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,DATE1,nvl(str3,'ar'),nvl(num1,-1),nvl(num2,-1),nvl(code1,'ar') from guides where type_doc in (3420)
/


declare
  cnt number := 0;
begin 
 for bb in (
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,DATE1,nvl(str3,'ar') str3 ,nvl(num1,-1) num1,nvl(num2,-1) num2 ,nvl(code1,'ar') code1 from guides@etalon where type_doc in (3420)
minus
select FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,DATE1,nvl(str3,'ar') str3 ,nvl(num1,-1) num1,nvl(num2,-1) num2 ,nvl(code1,'ar') code1 from guides where type_doc in (3420)
            )
 loop
     begin
       merge into guides
       using (select bb.type_doc g_id from dual) on (FOLDER = bb.folder and TYPE_DOC = bb.type_doc 
               and DATE_WORK = bb.date_work and CODE = bb.code and nvl(CODE1,'ar') = bb.code1)
       when matched then update set  
         status = bb.status
        ,owner = bb.owner
        ,date1 = bb.date1 
        ,str3 = decode(bb.str3,'ar',null,bb.str3)
        ,num1 = decode(bb.num1,-1,null,bb.num1)
        ,num2 = decode(bb.num2,-1,null,bb.num2)   
      when not matched then insert(reference,branch,FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,str3,DATE1,CODE1,num1,num2)
                            values (guides_reference.nextval,191,bb.FOLDER,bb.TYPE_DOC,bb.STATUS,bb.OWNER,bb.DATE_WORK,bb.CODE,decode(bb.str3,'ar',null,bb.str3),bb.DATE1
                                   ,decode(bb.CODE1,'ar','',bb.code1),decode(bb.num1,-1,null,bb.num1),decode(bb.num2,-1,null,bb.num2));  
      cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ code = '||bb.code||' err = '||sqlerrm);  
   end;   
end loop; 
 dbms_output.put_line('guides cnt = '||cnt);
end;

/
--��������� vtb_subdepartments 
select * from vtb_subdepartments@etalon
minus
select * from vtb_subdepartments
/

declare
  cnt number := 0;
begin 
 for bb in (
            select * from vtb_subdepartments@etalon
            minus
            select * from vtb_subdepartments
            )
 loop
   for ss in (
              select rowid,s.* from vtb_subdepartments s where id = bb.id
             )                                               
   loop 
     delete vtb_subdepartments where rowid = ss.rowid;
   end loop;
   begin
     insert into vtb_subdepartments values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ id = '||bb.id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop; 
 dbms_output.put_line('vtb_subdepartments cnt = '||cnt);
end;
/

select * from groups@etalon  -- where departid = 1
minus
select * from groups
/

--��������� groups
declare
  cnt number := 0;
begin 
 for bb in (
            select * from groups@etalon  -- where departid = 1
            minus
            select * from groups
            )
 loop
   begin
     merge into groups
     using (select bb.group_id g_id from dual) on (group_id = bb.group_id)
     when matched then update set  
       group_ = bb.group_
      when not matched then insert values bb;  
      cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ group_id = '||bb.group_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('groups cnt = '||cnt);
end;
/

select * from 
--delete 
groups where --group_ = '�������� ���'
group_ in 
(select GROUP_ from groups@etalon where group_id in (1357, 31608, 31753, 1225, 1230))
/

--��������� �����
select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights@etalon  where id_type < -1
minus
select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights
/

declare
  cnt number := 0;
begin 
 for bb in (
            select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights@etalon  where id_type < -1
            minus
            select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights
            )
 loop
   begin
     merge into object_rights
     using (select null from dual) on (ID = bb.ID and ID_TYPE = bb.ID_TYPE and OBJ_ID = bb.OBJ_ID and OBJ_TYPE = bb.OBJ_TYPE)
     when matched then update set  
       RIGHTS = bb.RIGHTS
      when not matched then insert (ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS) values (bb.ID,bb.ID_TYPE,bb.OBJ_ID,bb.OBJ_TYPE,bb.RIGHTS);  
      cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ ID = '||bb.ID||'  '||bb.OBJ_ID||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('object_rights cnt = '||cnt);
end;
/

--������������ ����������
select * from zyx_store@etalon where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (191,240,540,360)
minus
select * from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS'
/

declare
  cnt number := 0;
begin
 for bb in (
            select * from zyx_store@etalon where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (191,775)
            minus
            select * from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS'
            )
 loop
   begin
     insert into zyx_store values bb;
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ ORER = '||bb.OPER||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('zyx_store cnt = '||cnt); 
end;
/

select rowid,z.* from 
--delete
zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 775
and str1 is not null
and exists (select null from zyx_store where oper = z.oper and tbl = z.tbl and num1 = z.num1 and num4 = z.num4 and num3 =z.num3 and str1 is not null)
--and dt1 < '12sep2020'
/

--��������� �������������
select * from users@etalon where subdepartment in (select num4 from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 235) 

select user_id from users@etalon where job in (1,31445)--subdepartment in (select num4 from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 240) 
minus
select user_id from users
/

declare
  cnt number := 0;
  db_name varchar2(300);
begin
 select global_name into db_name from global_name;
 for bb in (
select user_id from users@etalon where 
--job in (1,31445)
subdepartment in (select num4 from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 775 )
--and user_id = 58103) 
minus
select user_id from users
            )
 loop
   begin
     merge into users s
     using (select * from users@etalon where --job in (1,31445) and user_id = bb.user_id) t 
     subdepartment in (select num4 from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 775 and user_id = bb.user_id)) t 
     on (s.user_id = t.user_id)
 /*    when matched then update set 
USER_ = t.USER_
,USER_NAME = t.USER_NAME
,JOB = t.JOB
,PARAMS = t.PARAMS
,SUBDEPARTMENT = t.SUBDEPARTMENT
--*/
     when not matched then insert values(t.USER_,t.USER_NAME,t.USER_ID,t.PASSWORD,t.JOB,t.PARAMS,t.RIGHTS,t.SUBDEPARTMENT);
     cnt := cnt + sql%rowcount;
   exception when OTHERS then
     dbms_output.put_line('������ user_id = '||bb.user_id||' err = '||sqlerrm);  
   end;    
   commit;   
 end loop;
 dbms_output.put_line('users cnt = '||cnt);
end;
/

/

select * from users where subdepartment in 
(select num4 from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 544)
/

insert into zyx_cont_cb
select * from zyx_cont_cb@etalon

delete zyx_cont_cb
/

--MQ-�������

select ID,SEND_ID,QID,STATE,CREATE_DT,MOD_DT,ASK_ID,URL,EOBJ_ID from TBL_QUEUE_SCANNER_MQ_MB@etalon
minus
select ID,SEND_ID,QID,STATE,CREATE_DT,MOD_DT,ASK_ID,URL,EOBJ_ID from TBL_QUEUE_SCANNER_MQ_MB

--insert into TBL_QUEUE_SCANNER_MQ_MB
select * from TBL_QUEUE_SCANNER_MQ_MB@etalon where id = 7300694289

