--270,2233,203,226,990,11419,5087,4215,3445,11422,1,5098,9035,6389,95,8568

--���������
select count(*) from documents d where 1=1 
--AND date_create < trunc(sysdate)
and nvl(date_work,sysdate-1) <= trunc(sysdate)-1
and status not in (22,27,35,-3000,1000)

--06.05.2021  5295680
--����������
select type_doc,status,count(*) from documents
where status not in (22,27,35,-3000,1000) and (date_work is null or date_work < trunc(sysdate)-1)
and type_doc not in (270,2233,203,226,990,11419,5087,4215,3445,11422,1,5098,9035,6389,95,8568,225,6722,12221,4236,233,4434,2,11606,1342)
--and type_doc = 203
--and branch = -1
group by type_doc,status
order by count(*) desc 
/

select rowid,d.* from documents d 
--update documents d set date_work = nvl(date_work,date_document), date_value = nvl(date_value,date_document), folder = decode(folder,910,0,folder)
where type_doc = 990
--and branch > -1 
--and status = 20
--and folder <> 910 
and (date_work is null or date_work < trunc(sysdate)-1)
and date_create < trunc(sysdate)-13
--and exists (select null from journal where docnum = d.reference and branch = d.branch )
--and exists (select null from collector_contracts where docnum = d.reference and zbranch_docnum = d.branch)
--and exists (select null from (select * from documents union all select * from archive) where status >= 30 and status < 50 and (refer_from = d.reference and branch_from = d.branch or related = d.reference and branch_related = d.branch) )
--and not exists (select null from journal where docnum = d.reference and branch = d.branch ) 
--and not exists (select null from collector_contracts where docnum = d.reference and zbranch_docnum = d.branch) and not exists (select null from (select * from documents union all select * from archive) where status >= 30 and (refer_from = d.reference and branch_from = d.branch or related = d.reference and branch_related = d.branch) )
order by date_work desc

--update documents set status = 1000
where type_doc in (270,2233,203,5087,6722,4434,11606)
and status in (10,1001,20,21) 
and date_create < trunc(sysdate)-13

--c ����������
--update documents d set status = 1000
where type_doc in (226)
and status in (10,1001,20,21,23,24) 
and date_create < sysdate-13
and not exists (select null from journal where docnum = d.reference and branch = d.branch ) 

--update documents d set status = 30
where type_doc in (226)
and status in (23) 
and date_create < sysdate-13
and exists (select null from journal where docnum = d.reference and branch = d.branch ) 

--� collector_contracts

--update documents d set status = 1000
where type_doc in (990,3247,4215,3445,1432,1,5098,9035,6389,95,8568,225,12221,4236,233,2,1342)
and status in (10,15,20,21,23,1001)
and date_create < trunc(sysdate)-13
and not exists (select null from journal where docnum = d.reference and branch = d.branch )
and not exists (select null from collector_contracts where docnum = d.reference and zbranch_docnum = d.branch)
and not exists (select null from (select * from documents union all select * from archive) where status >= 30 and status < 50 and (refer_from = d.reference and branch_from = d.branch or related = d.reference and branch_related = d.branch) )

--update documents d set status = 30, date_work = nvl(date_work,date_document)
where type_doc in (990,3247,4215,3445,1432,1,5098,9035,6389,95,8568,225,12221,4236,233,2)
and status in (10,15,20,21,23,1001)
and date_create < trunc(sysdate)-13
and (exists (select null from journal where docnum = d.reference and branch = d.branch )
     or exists (select null from collector_contracts where docnum = d.reference and zbranch_docnum = d.branch)
     or exists (select null from (select * from documents union all select * from archive) where status >= 30 and status < 50 and (refer_from = d.reference and branch_from = d.branch or related = d.reference and branch_related = d.branch) )
)
/

--delete documents
where status in (0)
and type_doc in (270,226,990,5087,3445,1432,9035,6389,8568,225,233,4434,2,11606,1342)
and date_create < trunc(sysdate)-13
/

select * from 
--documents
archive 
where type_doc = 270 and date_work = to_date('11.12.2021','dd.mm.yyyy') and payers_account = '40702810200250003239'

select * from archive d where type_doc = 203 and date_work > sysdate-10
and refer_from = 0
and exists (select null from collector_contracts where docnum = d.reference and zbranch_docnum = d.branch)

--������ ���������      
select * from documents d
--update documents d set status = 30, date_work = (select min(work_date) from journal where docnum = d.reference and branch = d.branch)
--, date_value = (select min(work_date) from journal where docnum = d.reference and branch = d.branch)
 where (reference,branch) in
(select reference,branch from tmp_biv_10)
and exists (select null from journal where docnum = d.reference and branch = d.branch )
and date_work is null
/

select * from journal where docnum = 1239116950

select rowid,d.* from documents d where reference = 1239116950

select * from archive where reference = 1264996780
/

begin
  P_OPERDAY.MOVEDOCUMENTS(to_date('01.01.2022','dd.mm.yyyy'), to_date('07.01.2022','dd.mm.yyyy'));
end;  
  
  
select * from documents d
--delete documents d
where 1=1 
and BRANCH not IN ---1
      ( SELECT id FROM subdepartments WHERE (server_address = (select global_name from global_name) or id= mbGoID)) 
AND  STATUS = 1000
and exists (select null from documents_delete where reference= d.reference and branch = d.branch) --not � ���   
and date_create < sysdate-15       
and not exists (select null from journal where docnum = d.reference and branch = d.branch )
and not exists (select null from (select * from documents union all select * from archive) 
            where (refer_from = d.reference and branch_from = d.branch) or (related = d.reference and branch_related = d.branch) )
/


declare 
  mdCommitCount number := 0;
  mdDocAmount number := 0; 
begin
  INSERT INTO MOVE_DOCS_GTMP  SELECT REFERENCE, BRANCH FROM documents
  where type_doc = 990  
  and branch = -1
  and status = 30 and date_work < trunc(sysdate);
  COMMIT;
  for recMove in ( SELECT Reference,Branch FROM MOVE_DOCS_GTMP)
    loop
      begin
        INSERT INTO archive SELECT * from DOCUMENTS
         Where Reference = recMove.Reference and Branch = recMove.Branch;
        INSERT INTO variable_archive SELECT *  FROM variable_documents
          Where Reference = recMove.Reference and Branch = recMove.Branch;
        DELETE  DOCUMENTS
         Where Reference = recMove.Reference and Branch = recMove.Branch;
        mdCommitCount := mdCommitCount + 1;
        mdDocAmount := mdDocAmount + 1;
        if mdCommitCount >= 1000 then
           mdCommitCount := 0;
           COMMIT;
        end if;
      exception when others then
        Rollback;
      end;
    end loop;
end;    