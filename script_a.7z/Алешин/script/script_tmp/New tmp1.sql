--IMAGES_DOC_ANKETS

select cnt_all-(cnt_scor_n+cnt_scor+cnt_hypo+cnt_IB_key+cnt_fl+cnt_hyp24+cnt_old+cnt_act) cnt_other
 , t.*  from (
select count(*) over() cnt_all
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = 'scoring_request_bm' --and (refer_obj,branch_obj) in (select reference_REQ,branch_REQ from sco_anketa.TBL_SCORING_REF )
     )) over() cnt_scor_n
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '3' and (refer_obj,branch_obj) in (select reference,branch from scoring_forms ))) over() cnt_scor
--,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
--     and operation = '3' and (refer_obj,branch_obj) not in (select reference,branch from scoring_forms ))) over() cnt_doc_and_lost   
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '0' and (refer_obj,branch_obj) in (select reference,branch from hypo_forms))) over() cnt_hypo
--,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
--     and operation = '0' and (refer_obj,branch_obj) not in (select reference,branch from hypo_forms))) over() cnt_hypo_lost
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type     
     and operation = 'ECP_SCAN' )) over() cnt_IB_key
,sum((select count(distinct reference||'-'||branch) from eid.eid_picture  where reference = d.reference and branch = d.branch and d.image_subtype =1)) over() cnt_fl  
,sum((select count(distinct refer_image||'-'||branch_image||'-'||doc_type_id) from IMAGES_DOC_ANKETS where refer_image = d.reference and branch_image = d.branch and doc_type_id = d.image_type 
  )) over() cnt_hyp24 
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation in ('CA_SMB','CARD_APPL','777','COUNTERFOIL_CERTIFICAT','MOSBROKER','PIF_TRUSTS','SCAN_PAYROLL','VIP_DECISIONS','VYSOTA_PKG') )) over() cnt_old
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation in ('SCAN_DOVER','SIGN_SCAN_MODIFY','SAFEPACK','EID_VALCONTROL','SALARY_REESTR_SCAN','EID_499P_SCAN','EID_CLIENT_PHOTO','EID_SCAN')  )) over() cnt_act
--,sum((select count(distinct refer_image||'-'||branch_image) from tmp_tables.zyx_hypo where refer_image = d.reference and branch_image = d.branch)) over() cnt_hypo_old          
,d.*
 from images_doc d --where branch = 174 and reference < 170000 
)
t
/
-- ������
--CARD_APPL --��������� �� �������� �� 
--CA_SMB -- ������ ������ ������ �������

-- ���������
--SCAN_DOVER --������ �������������   
--SALARY_REESTR_SCAN --����� ��������� �� �/� �������� 

--�������� � images_DOC  image_type : 
--INNER_MAIL 
--ZP_FILE
/
select 
(select count(*) from images_doc) cnt
,(select count(*) from images_doc where (reference,branch) in (select reference,branch from eid.eid_picture) and image_subtype =1) eid 
,(select count(*) from images_doc where (reference,branch) in (select refer_image,branch_image from TMP_TABLES.ZYX_IMAGES_HYPO)) hypo
,(select count(*) from images_doc where (reference,branch,image_type) in (select /*+ INDEX (II IMAGE_PARENT_PK) */ refer_image,branch_image,p_type from IMAGES_PARENT II 
   where operation = 'scoring_request_bm' and (refer_obj,branch_obj) in (select reference_REQ,branch_REQ from sco_anketa.TBL_SCORING_REF ))) sc_n
,(select count(*) from images_doc where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT 
   where operation = '3' and (refer_obj,branch_obj) in (select reference,branch from scoring_forms ))) sc
,(select count(*) from images_doc where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT 
   where operation = 'ECP_SCAN' and refer_obj in (select eid from eid.eid_firma ) and branch_obj = 0)) ul 
from dual
/
--group by reference,branch order by count(*) desc

select * from images_doc where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT 
   where operation = '3' and p_type_id = 7 and (refer_obj,branch_obj) not in (select reference,branch from scoring_forms ))-- and reference = 23273747

select * from guides where type_doc = 4146

select max(date_modify) from images_doc where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT 
   where operation = '0' and (refer_obj,branch_obj) not in (select reference,branch from hypo_forms )) 
/
select refer_image,branch_image,p_type from IMAGES_PARENT
 where (refer_obj,branch_obj,operation) in (select reference_REQ,branch_REQ,'scoring_request_bm' from sco_anketa.TBL_SCORING_REF )
intersect     

select refer_image,branch_image,p_type,count(*) from IMAGES_PARENT 
where (refer_obj,branch_obj,operation) in (select reference_REQ,branch_REQ,'scoring_request_bm' from sco_anketa.TBL_SCORING_REF )
--where (refer_obj,branch_obj,operation) in (select reference,branch,'3' from scoring_forms )
group by refer_image,branch_image,p_type order by count(*) desc

--select refer_image,branch_image,p_type from IMAGES_PARENT 
--where (refer_obj,branch_obj,operation) in (select eid,0,'ECP_SCAN' from eid.eid_firma)
select reference||'-'||branch) from eid.eid_picture  where reference = d.reference and branch = d.branch
/

select * from IMAGES_PARENT where operation = '0' and branch_obj = 191359
--group by branch_obj 
/

--insert into zyx_cont_cb(c,d)
--select reference,branch from IMAGES_DOC
--minus
select refer_image,branch_image from IMAGES_PARENT
intersect
select reference,branch from eid.eid_picture
--intersect
--select reference,branch from eid.eid_picture
/
select max(d.date_modify),substr(image_type,1,6),count(*) from 
--select * from 
--delete 
IMAGES_DOC d where 1=1 
and (reference,branch) in (select ref,br from tmp_tables.zyx_hypo)
--and image_type in (select code from guides where type_doc = 3527) 
--and image_type like 'EHMOD%'
--and rownum < 100000
--group by substr(image_type,1,5)
--and date_modify < sysdate-1500
--and date_modify > sysdate-100
--and branch = 104000
--and branch in (select id from subdepartments start with id = 191 connect by prior id = parent)  
--and (reference,branch) in (select refer_image,branch_image from tmp_tables.zyx_hypo)
group by substr(image_type,1,6)
/

select refer_image,branch_image from tmp_tables.zyx_hypo
intersect
--select ref,br from tmp_tables.zyx_images_hypo

select refer_image,branch_image from IMAGES_PARENT
intersect
--select reference,branch from eid.eid_picture
select refer_image,branch_image from IMAGES_DOC_ANKETS

select e.* from eid.eid_picture e where p_id = '4510734235' EHMOD_25554844/4619712539

select max(d.date_modify),operation,count(*) from IMAGES_PARENT i, images_doc d where 1=1 --d.reference in (16751771) and d.branch in (191359)
and i.refer_image = d.reference and i.branch_image = d.branch
--and i.operation not in ('scoring_request_bm','3','0','SCAN_DOVER','CA_SMB','CARD_APPL','SALARY_REESTR_SCAN','ECP_SCAN')
and i.operation = 'ECP_SCAN' 
-- and (refer_obj,branch_obj) in ( select reference,branch from smb_forms) 
--and d.date_modify > sysdate-10
group by operation


select * from IMAGES_PARENT i, images_doc d where 1=1
--and d.reference in (16751771) and d.branch in (191359)
and i.refer_image = d.reference and i.branch_image = d.branch
and i.operation = 'ECP_SCAN' 
and d.date_modify > sysdate-10


--update IMAGES_PARENT set operation = 'scoring_request_bm' where operation = 'SCORING_REQUEST_BM' 


select * from IMAGES_DOC where (reference,branch) in (select refer_image,branch_image from tmp_tables.zyx_hypo)
--and date_modify > '22mar2020'
/

  delete IMAGES_DOC TT  where (reference,branch) in (select refer_image,branch_image from tmp_tables.zyx_hypo)
   and rownum < 10001 returning max(DATE_MODIFY) into dt_min;

select * from 
delete tmp_tables.zyx_hypo where (refer_image,branch_image) in (select reference,branch from eid.eid_picture)
/

select * from IMAGES_PARENT where operation = '0' and (refer_obj,branch_obj) not in (select reference,branch from hypo_forms)

   and operation = '0' and (refer_obj,branch_obj) not in (select reference,branch from hypo_forms)))

select result_status,type_credit,s.* from scoring_forms s where TYPE_CREDIT = 2112 and RESULT_STATUS = 30 and status <> 30  
 
select * from IMAGES_PARENT ii, scoring_forms ff where ii.operation = '3' and ii.refer_obj = ff.reference and ii.branch_obj = ff.branch 
and ff.refer_contract = 0 and ff.TYPE_CREDIT <> 2112 and ff.refer_client = 0


select result_status,type_credit,refer_contract,s.* from hypo_forms s where status = 30 and RESULT_STATUS <> 700

select * from IMAGES_PARENT ii, hypo_forms ff where ii.operation = '0' and ii.refer_obj = ff.reference and ii.branch_obj = ff.branch 
and ff.status <> 30

select * from guides where type_doc = 3558 --RESULT_STATUS


select s.* from sco_anketa.TBL_SCORING_REF s where
reference_req = 4191751 and branch_req = 191368 


select sysdate,t.* from sco_anketa.TBL_SCORING_REQUEST t where reference = 4191751 and branch = 191368

and operation = 'scoring_request_bm' --and (refer_obj,branch_obj) in (select reference_REQ,branch_REQ from sco_anketa.TBL_SCORING_REF )


select t.*,s.* from sco_anketa.TBL_SCORING_REF s, sco_anketa.TBL_SCORING_REQUEST t  where nvl(s.REFER_CONTRACT,0) = 0 
and t.reference = s.reference_req and t.branch = s.branch_req
and type_credit = 2112
 
select sysdate,t.* from sco_anketa.TBL_SCORING_REQUEST t where reference = 3040745

select * from IMAGES_PARENT ii, sco_anketa.TBL_SCORING_REQUEST ff where ii.operation = 'scoring_request_bm' and ii.refer_obj = ff.reference and ii.branch_obj = ff.branch 
and nvl(ff.status,0) <> 30 and nvl(ff.result_status,0) not in (30,45,40,39) 

select sysdate,t.* from sco_anketa.TBL_SCORING_REQUEST t where nvl(status,0) <> 30 and nvl(result_status,0) not in (30,45,40,39) 

select * from images_doc where (reference,branch) in (select reference,branch from eid.eid_picture)
reference = 53832	and branch = 372000

select rowid,e.* from eid.eid_picture e where (reference,branch) in (select reference,branch from images_doc)
and subdepartment in (191) 4508812724

select * from images_parent where refer_image  = 53836	and branch_image = 372000
/

--��� ������� ����������� � EID_PICTURE
select * from
--delete 
eid.eid_picture_modify where --date_modify < sysdate -40
(reference,branch) in (select reference,branch from eid.eid_picture)  

--������������
select * from
--delete 
images_doc 
where (reference,branch) in (select reference,branch from eid.eid_picture_modify where date_modify < sysdate -40)

--����������
select * from
--delete 
eid.eid_picture where eid = -1 and p_id in  
(select p_id from eid.eid_picture e where subdepartment in (191) and eid <> -1)

--��������������� 
select (select max(eid) from eid.EID_DOCUMLIST where search_doc = e.p_id) ee, e.* from eid.eid_picture e
--update eid.eid_picture e set eid = (select max(eid) from eid.EID_DOCUMLIST where search_doc = e.p_id)
where eid = -1 
--and p_id = '00609L032876'
and exists (select null from eid.EID_DOCUMLIST where search_doc = e.p_id) 

--��������� ������� �� images_doc � ����� �� eid_picture
--delete eid.eid_picture where eid = -1


--delete eid.eid_picture_modify where date_modify < sysdate -40

select * from images_doc_user where (reference,branch) in (select reference,branch from eid.eid_picture_modify where date_modify < sysdate -40)

reference = 53832	and branch = 372000
select reference,branch from eid.eid_picture_modify where date_modify < sysdate -40
/


select * from clients_images ii where 1=1
--and (reference,branch) in (select reference,branch from hypo_forms)
and not exists (select null from clients where type_doc in (4,7535,2004,5004,861,2264) and reference = ii.reference and branch = ii.branch)
and exists (select null from clients where type_doc in (5,2287) and reference = ii.reference and branch = ii.branch)
and reference = 101830985