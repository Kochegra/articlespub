--drop MATERIALIZED VIEW AUDIT_ARCHIVE$RDF 

--drop materialized view log on AUDIT_ARCHIVE
/

--drop table AUDIT_ARCHIVE$RDF purge
/

CREATE TABLE MBANK_AUDIT.AUDIT_ARCHIVE$RDF
(
  REFERENCE   NUMBER                            NOT NULL,
  TABLE_NAME  VARCHAR2(30 BYTE)                 NOT NULL,
  ACTION      VARCHAR2(2000 BYTE)               NOT NULL,
  FIELD_NAME  VARCHAR2(30 BYTE),
  OLD_VALUE   VARCHAR2(2000 BYTE),
  TIME        DATE                              NOT NULL,
  USER_ID     NUMBER                            NOT NULL,
  ROWNUMBER   NUMBER,
  COLNUMBER   NUMBER,
  SUBFIELD    VARCHAR2(30 BYTE),
  BRANCH      NUMBER,
  ORAUSER     VARCHAR2(30 BYTE),
  OSUSER      VARCHAR2(2000 BYTE),
  TERM        VARCHAR2(2000 BYTE),
  PROGRAMM    VARCHAR2(2000 BYTE)
)
NOCOMPRESS 
TABLESPACE BANK_AUD_ARC
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            BUFFER_POOL      DEFAULT
           )
partition by range (TIME) INTERVAL( NUMTOYMINTERVAL(6,'MONTH'))
subPARTITION BY list (TABLE_NAME)
 subPARTITION template
  (SUBPARTITION SP_AA_DOCUMENTS VALUES ('DOCUMENTS','VARIABLE_DOCUMENTS','DOCUMENTS_DELETE','ARCHIVE','VARIABLE_ARCHIVE')
   ,SUBPARTITION SP_AA_CONTRACTS VALUES ('CONTRACTS','CONTRACTS$','PERCENT_CONTRACTS','VAR_CONTR_$')      
   ,SUBPARTITION SP_AA_CLIENTS VALUES ('CLIENTS','CLIENTS_CLASS_CB_HISTORY','CLIENTS_IMAGES')
   ,SUBPARTITION SP_AA_ACCOUNTS VALUES ('ACCOUNT','VARIABLE_ACCOUNT')
   ,SUBPARTITION SP_AA_REPORTS VALUES ('REPORTS','SF_REPORTS','REMOTE_REPORTS','SERVICE','SERVICE$')
   ,SUBPARTITION SP_AA_GUIDES VALUES ('GUIDES','GUIDE$','CALENDAR','RATE')
   ,SUBPARTITION SP_AA_EID_FIRMA VALUES ('EID_FIRMA','EID_FIRMA_PROSPECTUS')
   ,SUBPARTITION SP_AA_EID_HUMAN VALUES ('EID_HUMAN','EID_CHECK_FILL','EID_HUMAN_MOD','EID_ANKETA_115FZ')
   ,SUBPARTITION SP_AA_USERS VALUES ('USERS','Kill OraUser','Invalid pass','Cant find username','Logon user','Logoout user','Logout user'
                                      ,'Launch from external app','User Created/Recreated','Remove old MBANK users','ALIEN_COMPUTER')
   ,SUBPARTITION SP_AA_SHED VALUES ('SHED','SHED_JOBS','CHANGE_OD','CLOSE_OD','VARIABLE_SUBDEPARTMENTS')  
   ,SUBPARTITION SP_DEFAULT VALUES (DEFAULT)
  ) 
 ( PARTITION VALUES LESS THAN  (to_date('01.01.2010','dd.mm.yyyy'))
    TABLESPACE BANK_AUD_ARC
PCTUSED    97
PCTFREE    2
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64M
            NEXT             64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      RECYCLE
           )
LOGGING 
NOCOMPRESS 
  (SUBPARTITION SP_AA_DOCUMENTS VALUES ('DOCUMENTS','VARIABLE_DOCUMENTS','DOCUMENTS_DELETE','ARCHIVE','VARIABLE_ARCHIVE')
   ,SUBPARTITION SP_AA_CONTRACTS VALUES ('CONTRACTS','CONTRACTS$','PERCENT_CONTRACTS','VAR_CONTR_$')      
   ,SUBPARTITION SP_AA_CLIENTS VALUES ('CLIENTS','CLIENTS_CLASS_CB_HISTORY','CLIENTS_IMAGES')
   ,SUBPARTITION SP_AA_ACCOUNTS VALUES ('ACCOUNT','VARIABLE_ACCOUNT')
   ,SUBPARTITION SP_AA_REPORTS VALUES ('REPORTS','SF_REPORTS','REMOTE_REPORTS','SERVICE','SERVICE$')
   ,SUBPARTITION SP_AA_GUIDES VALUES ('GUIDES','GUIDE$','CALENDAR','RATE')
   ,SUBPARTITION SP_AA_EID_FIRMA VALUES ('EID_FIRMA','EID_FIRMA_PROSPECTUS')
   ,SUBPARTITION SP_AA_EID_HUMAN VALUES ('EID_HUMAN','EID_CHECK_FILL','EID_HUMAN_MOD','EID_ANKETA_115FZ')
   ,SUBPARTITION SP_AA_USERS VALUES ('USERS','Kill OraUser','Invalid pass','Cant find username','Logon user','Logoout user','Logout user'
                                      ,'Launch from external app','User Created/Recreated','Remove old MBANK users','ALIEN_COMPUTER')
   ,SUBPARTITION SP_AA_SHED VALUES ('SHED','SHED_JOBS','CHANGE_OD','CLOSE_OD','VARIABLE_SUBDEPARTMENTS')  
   ,SUBPARTITION SP_DEFAULT VALUES (DEFAULT)
  )
)
/

CREATE INDEX MBANK_AUDIT.AUDIT_ARCHIVE_INDEX ON MBANK_AUDIT.AUDIT_ARCHIVE
(REFERENCE, BRANCH, TIME, TABLE_NAME)
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    2
INITRANS   5
MAXTRANS   255
STORAGE    (
            INITIAL          64M
            NEXT             64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


           /CREATE INDEX MBANK_AUDIT.AUDIT_ARCH_USER  ON MBANK_AUDIT.AUDIT_ARCHIVE
(USER_ID)
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );
           
           
           
/

  
  
--alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238716 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 

alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238731 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238694 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238652 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238513 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238477 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238457 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
alter table AUDIT_ARCHIVE modify SUBPARTITION SYS_SUBP5238423 add VALUES ('RESTRUCT','DOCUM','DOCUMENTS_VN'); 
/

alter INDEX MBANK_AUDIT.AUDIT_ARCHIVE_INDEX rebuild;
alter INDEX MBANK_AUDIT.AUDIT_ARCH_USER rebuild;


CREATE INDEX MBANK_AUDIT.AUDIT_ARCHIVE_INDEX ON MBANK_AUDIT.AUDIT_ARCHIVE
(REFERENCE, BRANCH, TIME)  
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    2
INITRANS   5
MAXTRANS   255
STORAGE    (
            INITIAL          16 M
            NEXT             16 M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
 global
partition by range ( REFERENCE )
 (
 partition p_aa_idxref_1 values less than (1) ,
 partition p_aa_idxref_2 values less than (10000000),
 partition p_aa_idxref_3 values less than (80000000),
 partition p_aa_idxref_4 values less than (160000000),
 partition p_aa_idxref_5 values less than (240000000),
 partition p_aa_idxref_6 values less than (320000000),
 partition p_aa_idxref_7 values less than (400000000),
 partition p_aa_idxref_8 values less than (480000000), 
 partition p_aa_idxref_9 values less than (560000000),
 partition p_aa_idxref_10 values less than (800000000),
 partition p_aa_idxref_11 values less than (1300000000),  
 partition p_aa_idxref_12 values less than (1500000000),
 partition p_aa_idxref_13 values less than (2000000000),
 partition p_aa_idxref_14 values less than (2500000000),
 partition p_aa_idxref_15 values less than (3000000000),
 partition p_aa_idxref_16 values less than (3500000000),
 partition p_aa_idxref_17 values less than (4000000000), 
 partition p_aa_idxref_18 values less than (4500000000),
 partition p_aa_idxref_19 values less than (5000000000),
 partition p_aa_idxref_20 values less than (5500000000),
 partition p_aa_idxref_21 values less than (6000000000),
 partition p_aa_idxref_22 values less than (8000000000),
 partition p_aa_idxref_23 values less than (10000000000),     
 partition p_aa_idxref_x values less than (maxvalue)
 )
 

 /
 
 
 CREATE INDEX MBANK_AUDIT.AUDIT_ARCH_USER  ON MBANK_AUDIT.AUDIT_ARCHIVE
(time,USER_ID) local
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL         1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );
           /
 
 
 ----- variant 2
 
 
CREATE TABLE MBANK_AUDIT.AUDIT_ARCHIVE$RDF
(
  REFERENCE   NUMBER                            NOT NULL,
  TABLE_NAME  VARCHAR2(30 BYTE)                 NOT NULL,
  ACTION      VARCHAR2(2000 BYTE)               NOT NULL,
  FIELD_NAME  VARCHAR2(30 BYTE),
  OLD_VALUE   VARCHAR2(2000 BYTE),
  TIME        DATE                              NOT NULL,
  USER_ID     NUMBER                            NOT NULL,
  ROWNUMBER   NUMBER,
  COLNUMBER   NUMBER,
  SUBFIELD    VARCHAR2(30 BYTE),
  BRANCH      NUMBER,
  ORAUSER     VARCHAR2(30 BYTE),
  OSUSER      VARCHAR2(2000 BYTE),
  TERM        VARCHAR2(2000 BYTE),
  PROGRAMM    VARCHAR2(2000 BYTE)
)
NOCOMPRESS 
TABLESPACE BANK_AUD_ARC
PCTUSED    80
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16 M
            NEXT             128 M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT            
           )         
partition by range ( REFERENCE )
subPARTITION BY list (TABLE_NAME)
 subPARTITION template
  (SUBPARTITION SP_AA_DOCUMENTS VALUES ('DOCUMENTS','VARIABLE_DOCUMENTS','DOCUMENTS_DELETE','ARCHIVE','VARIABLE_ARCHIVE','RESTRUCT','DOCUM','DOCUMENTS_VN')
   ,SUBPARTITION SP_AA_CONTRACTS VALUES ('CONTRACTS','CONTRACTS$','PERCENT_CONTRACTS','VAR_CONTR_$','COLLECTOR','COLLECTOR_CONTRACTS','VARIABLE_CONTRACTS')      
   ,SUBPARTITION SP_AA_CLIENTS VALUES ('CLIENTS','CLIENTS_CLASS_CB_HISTORY','CLIENTS_IMAGES','CLIENTS_AUDIT','CLIENTS_MODIFY'
   ,'EID_FIRMA','EID_FIRMA_PROSPECTUS','EID_HUMAN','EID_CHECK_FILL','EID_HUMAN_MOD','EID_ANKETA_115FZ','EID_STOP')
   ,SUBPARTITION SP_AA_ACCOUNTS VALUES ('ACCOUNT','VARIABLE_ACCOUNT','DOCUMENT_AUDIT','ACCOUNT_AUDIT')
   ,SUBPARTITION SP_AA_ACTIONS VALUES ('REPORTS','SF_REPORTS','REMOTE_REPORTS','SERVICE','SERVICE$','GUIDES','GUIDE$','CALENDAR','RATE','BANK_DATE')
   ,SUBPARTITION SP_AA_USERS VALUES ('USERS','Kill OraUser','Invalid pass','Cant find username','Logon user','Logoout user','Logout user'
                                      ,'Launch from external app','User Created/Recreated','Remove old MBANK users','ALIEN_COMPUTER')
   ,SUBPARTITION SP_DEFAULT VALUES (DEFAULT)
  )   
 (
 partition p_aa_ref_0 values less than (1) ,
 partition p_aa_ref_1 values less than (10000000),
 partition p_aa_ref_2 values less than (80000000),
 partition p_aa_ref_3 values less than (160000000),
 partition p_aa_ref_4 values less than (240000000),
 partition p_aa_ref_5 values less than (320000000),
 partition p_aa_ref_6 values less than (400000000),
 partition p_aa_ref_7 values less than (480000000), 
 partition p_aa_ref_8 values less than (560000000),
 partition p_aa_ref_9 values less than (800000000),
 partition p_aa_ref_10 values less than (1300000000),  
 partition p_aa_ref_11 values less than (1500000000),
 partition p_aa_ref_12 values less than (2000000000),
 partition p_aa_ref_13 values less than (2500000000),
 partition p_aa_ref_14 values less than (3000000000),
 partition p_aa_ref_15 values less than (3500000000),
 partition p_aa_ref_16 values less than (4000000000), 
 partition p_aa_ref_17 values less than (4500000000),
 partition p_aa_ref_18 values less than (5000000000),
 partition p_aa_ref_19 values less than (5500000000),
 partition p_aa_ref_20 values less than (6000000000),
 partition p_aa_ref_21 values less than (8000000000),
 partition p_aa_ref_22 values less than (10000000000),     
 partition p_aa_ref_max values less than (maxvalue)
 )           
/

CREATE INDEX MBANK_AUDIT.AUDIT_ARCHIVE_INDEX ON MBANK_AUDIT.AUDIT_ARCHIVE
(REFERENCE, BRANCH, TIME, TABLE_NAME)  
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    2
INITRANS   5
MAXTRANS   255
STORAGE    (
            INITIAL          1 M
            NEXT             16 M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
 local
 
 --�� ��������
  CREATE INDEX MBANK_AUDIT.AUDIT_ARCH_USER  ON MBANK_AUDIT.AUDIT_ARCHIVE
(table_name,USER_ID) local
LOGGING
TABLESPACE IDX_AUD_ARC
PCTFREE    2
INITRANS   5
MAXTRANS   255
STORAGE    (
            INITIAL         1M
            NEXT             8M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );
           
--drop index  AUDIT_ARCH_USER       

--alter table AUDIT_ARCHIVE set
subPARTITION template
  (SUBPARTITION SP_AA_DOCUMENTS VALUES ('DOCUMENTS','VARIABLE_DOCUMENTS','DOCUMENTS_DELETE','ARCHIVE','VARIABLE_ARCHIVE','RESTRUCT','DOCUM','DOCUMENTS_VN','OTMIV')
   ,SUBPARTITION SP_AA_CONTRACTS VALUES ('CONTRACTS','CONTRACTS$','PERCENT_CONTRACTS','VAR_CONTR_$','COLLECTOR','COLLECTOR_CONTRACTS','VARIABLE_CONTRACTS','CONTRACTS_OPEN')      
   ,SUBPARTITION SP_AA_CLIENTS VALUES ('CLIENTS','CLIENTS_CLASS_CB_HISTORY','CLIENTS_IMAGES','CLIENTS_AUDIT','CLIENTS_MODIFY'
   ,'EID_FIRMA','EID_FIRMA_PROSPECTUS','EID_HUMAN','EID_CHECK_FILL','EID_HUMAN_MOD','EID_ANKETA_115FZ','EID_STOP','EID_FIRMA_CATEGORY','EID_HUMAN.WORK_PLACE')
   ,SUBPARTITION SP_AA_ACCOUNTS VALUES ('ACCOUNT','VARIABLE_ACCOUNT','DOCUMENT_AUDIT','ACCOUNT_AUDIT')
   ,SUBPARTITION SP_AA_ACTIONS VALUES ('REPORTS','SF_REPORTS','REMOTE_REPORTS','SERVICE','SERVICE$','GUIDES','GUIDE$','CALENDAR','RATE','BANK_DATE')
   ,SUBPARTITION SP_AA_USERS VALUES ('USERS','Kill OraUser','Invalid pass','Cant find username','Logon user','Logoout user','Logout user'
                                      ,'Launch from external app','User Created/Recreated','Remove old MBANK users','ALIEN_COMPUTER','Impersonate')
   ,SUBPARTITION SP_DEFAULT VALUES (DEFAULT)
  ) 