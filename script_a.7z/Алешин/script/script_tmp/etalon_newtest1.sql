--������ ��� �����
--eid

truncate table PFR_INFO_RILS drop STORAGE -- 20 min

truncate table PFR_ANLZ_1_DAYS drop STORAGE -- 20 min

truncate table PFR_ANLZ_2_QUART drop STORAGE  

truncate table PFR_ICNN drop STORAGE

truncate table PFR_ANLZ_3_YEARS drop STORAGE

truncate table LOG_OPERATIONS drop STORAGE

truncate table EID_PRODUCTS_VARIABLE drop STORAGE

truncate table EID_PRODUCTS drop STORAGE

truncate table EID_SERVICE_OBJ_LIST drop STORAGE

truncate table LOG_ACTIONS drop STORAGE

truncate table EID_CARD_COLLECTOR drop STORAGE

truncate table EID_ANKETA_115FZ_LOG drop STORAGE

truncate table EID_FIRMA_MANAGER_HISTORY drop STORAGE

truncate table LOAD_DELAY_PC drop STORAGE

truncate table DISTRIB_FEATURES drop STORAGE

truncate table EID_CARD_OPER drop STORAGE

truncate table PIF_AMOUNTS drop STORAGE;

truncate table EID_CHECK_EXTREMISM_HISTORY drop STORAGE;

truncate table EID_HUMAN_LOG drop STORAGE;

--Mbank

truncate table ICB_CONTENTOUTPUT drop STORAGE 

truncate table MBANK_LOG drop STORAGE 

truncate table GIS_GMP_EXCHAGE drop STORAGE

truncate table TBL_DEILT_MESSAGE drop STORAGE

truncate table IMPEX_RECORDS drop STORAGE

truncate table TBL_PWD_SWIFT_VALIDATION_LOG drop STORAGE

truncate table VAR_IMPEX_DOC drop STORAGE

truncate table TBL_SWIFT_DOCUMENT drop STORAGE

truncate table TBL_SWIFT_ACK drop STORAGE

alter table TBL_SWIFT_DOCUMENT disable constraint FK_SWIFT_DOCUMENT$SWIFT;
alter table TBL_SWIFT_ACK disable constraint FK_SWIFT_ACK$SWIFT;
truncate table TBL_SWIFT drop STORAGE;
alter table TBL_SWIFT_DOCUMENT enable constraint FK_SWIFT_DOCUMENT$SWIFT;
alter table TBL_SWIFT_ACK enable constraint FK_SWIFT_ACK$SWIFT;

truncate table IMPEX_EXPORT_FILES drop STORAGE

truncate table TBL_PWD_SWIFT_VALIDATION drop STORAGE

truncate table TBL_MQ_TOOLS_LOG drop STORAGE

truncate table TBL_SWIFT_STATUS_HIST drop STORAGE

truncate table TBL_SWIFT_ACK drop STORAGE

truncate table V_COMMISSION_INFO drop STORAGE

truncate table VAR_IMPEX_DOC drop STORAGE

alter table VAR_IMPEX_DOC disable constraint VAR_IMPEX_DOC_FK;
truncate table IMPEX_DOC drop STORAGE;
alter table VAR_IMPEX_DOC enable constraint VAR_IMPEX_DOC_FK;

truncate table IMP_RECORD drop STORAGE;

alter table IMPEX_DOC disable constraint IMPEX_DOC_SEANS;
alter table IMP_RECORD disable constraint IMP_RECORD_FK_REIS;
truncate table IMPEX_LOG drop STORAGE;
alter table IMPEX_DOC enable constraint IMPEX_DOC_SEANS;
alter table IMP_RECORD enable constraint IMP_RECORD_FK_REIS;

truncate table IMP_DOC drop STORAGE;

truncate table IMPEX_ARM_FILES drop STORAGE

truncate table SKHOD_DOC drop STORAGE 

truncate table CHG_OBJ drop STORAGE;
truncate table SHED_LOG drop STORAGE;
truncate table REPORT_PREVIEW_DATA drop STORAGE;
truncate table IMPEX_ED807_ACCOUNTS drop STORAGE;
truncate table TBL_SWIFT_DOCUMENT drop STORAGE;
truncate table SHED_HIST drop STORAGE;
truncate table CROS_XML drop STORAGE;
truncate table XML_DOC drop STORAGE;
truncate table BIP_LOAD$FL_LOG drop STORAGE;

truncate table DOCUMENTS_INNS drop STORAGE;

truncate table CACHE_DOCUMENTS drop STORAGE;

truncate table PREPARE_IMPORT_REQUEST drop STORAGE;

truncate table IN_QUERY1 drop STORAGE;

truncate table TBL_QUEUE_SWA_MQ_MB drop STORAGE;




