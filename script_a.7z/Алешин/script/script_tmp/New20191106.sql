select DISTINCT SUBDEPARTMENT
           from CONTRACTS
           where TYPE_DOC in (94,326,2037,2038,2039,2041,2042,5787,5788,6833,7621, 12575/*, 12606*/, 12579, 12580, 12581, 12582, 12583) and CURRENCY = '810'
             and STATUS = 50 and DATE_OPEN <= sysdate
             and SUBSTR(ACCOUNT,1,3) in ('405','406','407','408')
          /
          
          mbank.oracle_job_params
          
          exec_load_client_from_job
          /
         begin globals_ext.short_init_admin(191); begin D_COMMISSIONALLPP.exec_commission_central_dep(191329,'�� �.�������� ��.�� 19 ����������(old)','20.05.2020','14.06.2020',10); end; end;
/
         
 select * from dba_jobs  where instr(upper(what),upper('D_COMMISSIONALLPP')) > 0 --and this_date < sysdate-1/96
          --and job = 15010224
          /
                   
    --������ �����      
begin          
     for jj in (select * from dba_jobs  where instr(upper(what),upper('D_COMMISSIONALLPP')) > 0 --and this_date < sysdate-1/96 
          )   
     loop          
       dbms_job.remove(jj.job);
     end loop;
     end;
/
 
          select * from v$session where username = 'MBANK' -- and sid = 633
          --and module like '%(855700_855701%' and logon_time < sysdate
          and program like 'oracle@p-mbank (J___)'
          /


--������� ������          
begin
 for ss in ( select * from v$session where username = 'MBANK' -- and sid = 633
            and module like '%(855700_855701%' and logon_time < sysdate
            )
 loop
     BEGIN
        SYSTEM.Kill_Session(p_sid => ss.sid, p_serial# => ss.serial#);
      EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.Put_Line(SQLERRM);
      END;
 end loop;           
end;
/


