declare
 i number;
 cnt number;
 t number;
 i0 number;
begin
cnt := 0;
i0 := guides_reference.nextval;
for rec in (                                                 
            select rowid,g.* from guides g where reference > i0 and branch <> 0 
            and not exists (select null from variable_guides where reference = g.reference and branch = g.branch)
            --and type_doc = 3454
            )
loop
  if cnt > 5000 then
    commit;
    cnt := 0;        
  else
    --dbms_output.put_line('re = '||rec.reference);    
    i := guides_reference.nextval;
    cnt := cnt + 1;
    t := 0;
    for g in (select * from guides where branch = rec.branch and reference = i)
    loop
     t := 1;
    end loop;
    if t = 0 then
      update guides set reference = i where rowid = rec.rowid;
    end if;
  end if;  
end loop; 
end;

/

select guides_reference.nextval from dual
/

select type_doc,count(*) from guides g where reference > 106352743 and branch <> 0
and exists (select null from variable_guides where reference = g.reference and branch = g.branch)
group by  type_doc

select rowid,g.* from guides g where reference > 106352743 and branch <> 0
and not exists (select null from variable_guides where reference = g.reference and branch = g.branch)
--and id = 848158558


select * from variable_guides where id = 102376644


select * from variable_guides where reference =  1002410473

/
select * from guides where id = 848158558
/

--���� ��������� id
declare
 i number;
 cnt number;
 t number;
begin
cnt := 0; t := 1;
while t = 1 and cnt < 100
loop
 i := guides_reference.nextval;
 cnt := cnt + 1;
 t := 0;
 for rec in (select * from guides where branch = 0 and reference = i)   -- dbms_output.put_line('id = '||id||' t = '||t||' cnt='||cnt);
 loop
   t := 1;
 end loop;
end loop;
  dbms_output.put_line('sid = '||i||' t = '||t||' cnt='||cnt);  
end;
/

declare
 i number;
 cnt number;
 t number;
 i0 number;
 dt date;
begin
cnt := 0;
i0 := guides_reference.nextval;
for rec in (                                                 
            select rowid,g.* from guides g where reference > i0 and branch <> 0 
            and exists (select null from variable_guides where reference = g.reference and branch = g.branch)
            --and id = 848158558
            )
loop
  if cnt > 5000 then
    commit;
    cnt := 0;        
  else
    --dbms_output.put_line('re = '||rec.reference);    
    i := guides_reference.nextval;
    cnt := cnt + 1;
    t := 0;
    for g in (select * from guides where branch = rec.branch and reference = i)
    loop
     t := 1;
    end loop;
    if t = 0 then
      dt := rec.DATE_WORK;
      insert into guides(REFERENCE,BRANCH,ID,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1)
      values(i,rec.BRANCH,rec.ID,rec.FOLDER,rec.TYPE_DOC,rec.STATUS,rec.OWNER,rec.VERSION,rec.CHILD,sysdate,rec.CODE,rec.NAME,rec.STR1,rec.STR2,rec.STR3,rec.STR4,rec.STR5,rec.NUM1,rec.NUM2,rec.NUM3,rec.NUM4,rec.NUM5,rec.DATE1,rec.DATE2,rec.DATE3,rec.CODE1);
      update variable_guides set reference = i where reference = rec.reference and branch = rec.branch;
      delete guides where reference = rec.reference and branch = rec.branch;
      update guides set DATE_WORK = dt where reference = i and branch = rec.branch;
    end if;
  end if;  
end loop; 
end;
/

--BRANCH,ID,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1
