--��������� groups
select * from groups@etalon where substr(group_,1,2) not in ('�/','�/', '��', '��','��','�D','��')
minus
select * from groups
/

merge into groups gg 
  using (select * from (select * from groups@etalon where substr(group_,1,2) not in ('�/','�/', '��', '��','��','�D','��')
         minus
         select * from groups) t where not exists (select null from groups where t.group_ = group_) ) ee on (gg.group_id = ee.group_id)
     when matched then update set group_ = ee.group_
     when not matched then insert values (ee.group_,ee.group_id) ;  
/

--��������� �����
select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights@etalon where id_type in (-3,-4)
minus
select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights
/

merge into object_rights gg 
  using (select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights@etalon where id_type in (-3,-4)
            minus
         select ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS from object_rights ) ee on (gg.id = ee.id and ee.ID_TYPE = gg.ID_TYPE and ee.OBJ_ID = gg.OBJ_ID and ee.OBJ_TYPE = gg.OBJ_TYPE)
     when matched then update set rights = ee.rights
     when not matched then insert(ID,ID_TYPE,OBJ_ID,OBJ_TYPE,RIGHTS) values (ee.ID,ee.ID_TYPE,ee.OBJ_ID,ee.OBJ_TYPE,ee.RIGHTS);  
     /
     
    /
    
    select * from eid.eid_firma where eid = 3342425
    
    select * from clients where reference = 181344 and branch = 203
    
    select * from contracts where reference = 597871 and branch = 203
    
    select * from eid.eid_firma where eid = 21752437
    
    select * from clients where reference = 365495 and branch = 191
    
    select * from contracts where refer_from = 597871 and branch_from = 203 
    /
    
    update contracts set refer_client = 365495, branch_client = 191 
    where reference = 597871 and branch = 203
    
    update account set client = 365495, branch_client = 191 where contract =  597871 and branch_contract = 203
    
    begin
      for rr in (select * from contracts where refer_from = 597871 and branch_from = 203)
      loop
        update contracts set refer_client = 365495, branch_client = 191 
         where reference = rr.reference and branch = rr.branch;
        update account set client = 365495, branch_client = 191 where contract =  rr.reference and branch_contract = rr.branch;
      end loop;   
    end;
    /
    
    select * from chg_obj 