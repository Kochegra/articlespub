select * from boss_emp_all where 
--tabn24 = '20013881'
entry_id in (236231)

             select (select count(*) from v$session where username = u.user_) act
             ,null subd_new 
                        --  ,   ( select val_old from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
    --and tbl = 'USERS' and au.dt > sysdate-1/24 and auv.field = 'SUBDEPARTMENT' and val_new = 275 and obj_id = u.user_id) subd_new  
             ,u.*,b.* from users u, boss_emp_all b where job not in (31445) and subdepartment <> 191 
             and u.params = b.tab_n and b.dept_id in (select id from boss_subdepartments start with id in 144282--(174543,165997)
              connect by prior id = dept_id)
             and instr(upper(dept_name_4),'������') = 0
             and u.subdepartment in (select id from subdepartments start with id = 191 connect by prior id = parent)
             and not exists (select null from zyx_store where num1 = 775 and num4 = u.subdepartment and oper = 'FIL_MIGR'  and tbl = 'SUBDEPARTMENTS') 
             /
             
             
select * from config
/

select
ar13.Migr_SubId(AR13.SapId_SubID(depart),775) mb_migr, --������������
Psubdepartment.get_subd_boss(depart,'SAP_ID') mb_real, --�������� 
(select name from cft_depart where code_org = cf.depart) subd
,cf.* from cft_account cf where nvl(not_used,0) = 0 --  and filial_code = '056'
--and date_close is null  
and code like '40706810200510022561' 
/

with tt as (select ar13.Migr_SubId(AR13.VTBId_SubID(b.depart),branch) mb_migr ,
 b.* from cabs_account b where branch = 775
and code in ('42102810303800026132')
-- 40702810708240004928'
--and code like '5230%'
--and code like '40_0%'
--and depart_id <> 1667207645
--and depart = '702780'
--and date_close is null
)
select * from tt
--where mb_migr = 775000
/

select * from contracts where reference = 27656526

select * from (
select subdepartment from contracts cc where refer_from = 27540780 and branch_from = 775
group by subdepartment
order by count(*) desc
) where rownum < 2

select max(count(*)) from   contracts cc where refer_from =27540780 and branch_from = 775
group by subdepartment

select * from (
select (select subdepartment from (select subdepartment,refer_from,branch_from from contracts cc group by subdepartment,refer_from,branch_from order by count(*) desc)
 where rownum < 2 and refer_from = c.reference and branch_from = c.branch  ) ll,
c.* from contracts c where status in (50) and type_doc in (94,12306) and subdepartment = 775000 and child = 0
and exists (select null from contracts where refer_from = c.reference and branch_from = c.branch) --and status = 50)  
) where ll <> 775000
/

select c.* from contracts c where reference = 27815380
-- status in (50) and type_doc in (94,12306) and subdepartment = 775000 and child = 0


           
          select rowid,t.* from account t where code like '91317810103800000055' 
          /
          
          select c.*,c.reference,c.branch, a.subdepartment, a.owner from contracts c, account a where c.status in (50) and c.type_doc not in (935,921,12616) and c.subdepartment = 775000 and c.child = 0
and c.assist = a.code and a.HEADER = 'A'
              and contract > 0 and mod(contract,10) = nvl('&1',mod(contract,10))



select reference, branch, ll subdepartment, coalesce(global_parameters.get_param('���_�����_��',ll),global_parameters.get_param_cfg('���_�����_�������'),'1403') owner from (
select (select subdepartment from (select subdepartment,refer_from,branch_from from contracts cc group by subdepartment,refer_from,branch_from order by count(*) desc)
 where rownum < 2 and refer_from = c.reference and branch_from = c.branch  ) ll,
c.* from contracts c where status in (50) and type_doc in (6776) 
and subdepartment in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 775) 
and child = 0
and exists (select null from contracts where refer_from = c.reference and branch_from = c.branch) --and status = 50)  
) where 1=1 and ll <> subdepartment and ll <> 775000    
--and reference = 27465063

/

declare
  r_fil number := 775;
  r_subd number;
  r_usr_id number;
  r_cnt number := 0;
  r_cnt_a number := 0;
begin
  for aa in (
  select c.reference,c.branch, 775403 subdepartment, 70304 owner from contracts c where status in (50) and type_doc in (30173,30171) and subdepartment = 775000 and child = 0        
  /*
          select c.reference,c.branch, a.subdepartment, a.owner from contracts c, account a where c.status in (50) and c.type_doc not in (935,921,12616) and c.subdepartment = 775000 and c.child = 0
and c.assist = a.code and a.HEADER = 'A'
              and contract > 0 and mod(contract,10) = nvl('&1',mod(contract,10))              
            -- and code = '40702810303300003060'            
            /*
select reference, branch, ll subdepartment, coalesce(global_parameters.get_param('���_�����_��',ll),global_parameters.get_param_cfg('���_�����_�������'),'1403') owner from (
select (select subdepartment from (select subdepartment,refer_from,branch_from from contracts cc group by subdepartment,refer_from,branch_from order by count(*) desc)
 where rownum < 2 and refer_from = c.reference and branch_from = c.branch  ) ll,
c.* from contracts c where status in (50) and type_doc in (6776) 
and subdepartment in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 775) 
and child = 0
and exists (select null from contracts where refer_from = c.reference and branch_from = c.branch) --and status = 50)  
) where 1=1 and ll <> subdepartment and ll <> 775000      
--*/         
             )
  loop
    begin
      r_subd := aa.subdepartment;
      r_usr_id := aa.owner;      
      --dbms_output.put_line(cft.code||' sub_id = '||sub_id||' usr_id = '||usr_id);
      update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr_id,owner)
      where reference = aa.reference and branch = aa.branch
        and (nvl(owner,-13) <> nvl(r_usr_id,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
      r_cnt := r_cnt + sql%rowcount;
      update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr_id,owner)
      where contract = aa.reference and branch_contract = aa.branch
      and (nvl(owner,-13) <> nvl(r_usr_id,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
      r_cnt_a := r_cnt_a + sql%rowcount;
      commit;
    exception when OTHERS then
      dbms_output.put_line(' contract = '||aa.reference||'  err ='||sqlerrm);
    end;    
  end loop; 
  dbms_output.put_line('contracts r_cnt = '||r_cnt||' account r_acc = '||r_cnt_a);
end;
/

select reference, branch, ll subdepartment, coalesce(global_parameters.get_param('���_�����_��',ll),global_parameters.get_param_cfg('���_�����_�������'),'1403') owner from (
select (select subdepartment from (select subdepartment,refer_from,branch_from from contracts cc group by subdepartment,refer_from,branch_from order by count(*) desc)
 where rownum < 2 and refer_from = c.reference and branch_from = c.branch  ) ll,
c.* from contracts c where status in (50) and type_doc in (6776) and subdepartment = 775000 and child = 0
and exists (select null from contracts where refer_from = c.reference and branch_from = c.branch) --and status = 50)  
) where ll <> 775000


              select * from (
            --  select 'BISQUIT_ID' subd_type, substr(depart,3) subd, otv, code, header, not_used from bis_account a where filial_code = r_bis
             -- union all
            --  select 'SAP_ID' subd_type,to_char(depart) subd, to_char(otv)otv, code, header, not_used from cft_account a where filial_code = decode(lpad(r_bis,3,'0'),'000','001',lpad(r_bis,3,'0'))
            --  union all
              select 'CABS_ID' subd_type,to_char(depart) subd, to_char(otv) otv, code, header, not_used from cabs_account a where branch = 775
                --       and depart = '772521'
                and date_close is null
              )
              where nvl(not_used,0) = 0 and substr(code,9,1) = nvl('&1',substr(code,9,1)) -- � ������������ ������� �� ������ �� �����
              and code in (select code from account where branch = 775 --and close_date is null 
                             and (nvl(owner,1403) in (1403,0) or nvl(subdepartment,775000) in (775000,mbfilid,0) )
--                            and subdepartment not in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = r_fil)
                             )   
                             /
                             
                             
select rowid,a.* from account a where code  in ('40702810600030004281')

select c.SUBDEPARTMENT sub_id,c.owner usr_id, a.* from account a, contracts c 
where 1=1 -- a.subdepartment in (235000,544000,780000,365000,660000,631000)
--and a.subdepartment <> c.subdepartment 
and a.contract = c.reference and a.branch_contract = c.branch and a.code = c.account
--and mod(c.reference,10) = nvl('&1',mod(c.reference,10))
--and c.subdepartment in (select num4 from zyx_store z where  oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (775) )
--and type_doc in (30172) 
and c.reference = 27815380



select c.* from contracts c 
where 1=1 -- a.subdepartment in (235000,544000,780000,365000,660000,631000)
and c.reference in (27815516,27815380)

44607810100800000003

select c.SUBDEPARTMENT sub_id,c.owner usr_id, a.* from account a, contracts c 
where 1=1 -- a.subdepartment in (235000,544000,780000,365000,660000,631000)
and a.subdepartment <> c.subdepartment
 and a.contract = c.reference and a.branch_contract = c.branch --and a.code = c.account
and mod(c.reference,10) = nvl('&1',mod(c.reference,10))
and c.subdepartment in (select num4 from zyx_store z where  oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (775) )
and type_doc in (30173) 
--and code = '44607810100800000003'
/


  select c1.reference,c1.branch,c0.subdepartment,c0.owner from contracts c1, contracts c0 
  where c0.subdepartment in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (775)) 
   and c0.subdepartment <> 775000
   and c0.status < 1001 
   and c1.refer_from = c0.reference and c1.branch_from = c0.branch and c1.status < 1001
   and c0.subdepartment <> c1.subdepartment
   and mod(c0.reference,10) = nvl('&1',mod(c0.reference,10))
   and c0.reference = 27820345



select * from (
select ar13.Migr_SubId(AR13.VTBId_SubID(c.depart),c.branch) mb_migr, global_parameters.get_param('���_�����_��',ar13.Migr_SubId(AR13.VTBId_SubID(c.depart),c.branch)) own
,c.otv,a.subdepartment subd,a.owner usr, a.* from account a, cabs_account c  
where a.header = c.header and a.code =c.CODE and a.currency = substr(c.code,6,3)
and filial_code = '80' and nvl(not_used,0) = 0 
and c.otv is not null and c.otv > 0
--and c.otv not in (236231)
--and a.close_date is null
)
where 1=1 -- and usr = own 



89451,32763,99886,26199,20562


grant delete on documents_delete to mbank_support_role 