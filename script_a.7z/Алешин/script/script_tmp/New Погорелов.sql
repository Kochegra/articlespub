insert into zyx_cont_cb (a,b,c)
select  decode(eid.get_data_firma.getparam(ff.eid,'UIK_MDM'),null,0,1) MDM_YES
,(select count(*) from variable_contracts where reference = pp.reference and branch = pp.branch and name = 'MIGR_NUMBER_CFT') migr
,ff.eid from eid.eid_firma ff, eid.eid_firma_products pp where ff.eid = pp.eid and pp.status = 50 
              and pp.type_doc in (select type from variable_types where name = 'PRODUCT' and value in ( 'CURRENT','CURRENT.'))
 

/

select c,count(*) from ( 
select distinct a,b,c from zyx_cont_cb
) group by c order by count(*) desc
/

select * from zyx_cont_cb z
--delete zyx_cont_cb z
where b = '0'
and exists (select * from zyx_cont_cb where c = z.c and b = '1')
/

select sum(A),sum(b),count(*) from zyx_cont_cb z

select sum(A),sum(b),count(*) from zyx_cont_cb z where b = '0'

select * from zyx_cont_cb z where b = '0' and a = '0'
/

select rowid,t.* from documents t where  payers_currency <> receivers_currency
and status in (30,45)
and type_doc not in (1161,1990,5811,5128,5444) 
/

4193836856

select rowid,t.* from variable_documents t where reference = 4193836856