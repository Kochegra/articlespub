select * from users where user_ like 'ALESHIN_R%'

select * from documents

select * from all_tables where table_name like '%MEMBERSHI%'  


drop table users_jobs

--������� ����� ������������ 
create table users_jobs 
(
user_id number,
job_id number,
date_start date, 
date_finish date,
date_modify date default sysdate,
doc_number varchar2(4000), --����� ������
info_add  varchar2(4000) --���. ����������
--,priority number default 0 --��������� ����� ������� � jobs
)

CREATE UNIQUE INDEX MBANK.users_jobs_PK ON users_jobs 
(user_ID,job_id)
LOGGING
TABLESPACE IDX_SMALL
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      KEEP
           )
NOPARALLEL;

--user_id job_id - ����������

--��������� ������� JOBS
alter table jobs add (
name varchar2(256) --������������ �� ��
,priority number default 0 --��������� 
,date_start date --������ �������� ���� 
,date_finish date 
,date_modify date default sysdate
,doc_number varchar2(4000) --������/���������
,info_add  varchar2(4000) --���. ����������
)

select * from jobs

--��������� ������� users
alter table users add (
dt_start date --������ �������� �� 
,dt_finish date --  
,dt_modify date default sysdate
,doc_number varchar2(4000) --������/���������
,info_add  varchar2(4000) --���. ����������
)
/
alter table users rename column date_modify to dt_modify 
/
select * from users


--�� tools.pas function getRights
/*
('select object_id,rights, code from jobs_rights where code in (4,5,6) and job_id in (select job from users where user_id=' + inttostr(_UserID) +
///13.08.2009      ') and object_id not in (' + 'select object_id from users_rights where user_id=' + inttostr(UserID) +
    ') and object_id not in (' + 'select object_id from users_rights where user_id=' + inttostr(_UserID) +
    ' and code in (4,5,6))');
*/    
    
select object_id,rights, code from jobs_rights jr where code in (4,5,6) 
and job_id in (select job from users where user_id= :user_id)
--and object_id not in (select object_id from users_rights where user_id= :user_id)
and not exists (select null from users_rights where user_id= :user_id and code = jr.code and object_id = jr.object_id)
/
select * from jobs_rights
/
--� ������ ����������� � ������� �������� ����
select jr.object_id,jr.rights,jr.code from users u, jobs j, users_jobs uj, jobs_rights jr 
where u.user_id = :user_id 
and j.job_id in (u.job,uj.job_id)
and jr.code in (4,5,6) and JR.JOB_ID = j.job_id 
and not exists (select null from users_rights where user_id= u.user_id and code = jr.code and object_id = jr.object_id)
--and nvl(j.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
--    and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(j.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
and nvl(uj.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
    and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(uj.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
and u.user_id = uj.user_id(+)  
order by nvl(uj.priority,0) desc ,jr.rights desc

--�������� ����� function CheckRights1 ������ ��������� object_id.
/
--������� view
/*
   SELECT "TYPE_ID",
          "NAME",
          "SHORTNAME",
          "MANUAL",
          "CODE",
          "ACTION",
          "PRIORITY"
     FROM types
    WHERE code = 4
          AND type_id IN
                 (SELECT object_id
                    FROM jobs_rights
                   WHERE code = 4
                         AND job_id IN
                                (SELECT job
                                   FROM users
                                  WHERE user_id = (SELECT user_id
                                                     FROM users
                                                    WHERE user_ = :USER_))
                  MINUS
                  SELECT object_id
                    FROM users_rights
                   WHERE     user_id = (SELECT user_id
                                          FROM users
                                         WHERE user_ = :USER_)
                         AND code = 4
                         AND operation > 0
                  UNION
                  SELECT object_id
                    FROM users_rights
                   WHERE     user_id = (SELECT user_id
                                          FROM users
                                         WHERE user_ = :USER_)
                         AND code = 4
                         AND operation < 1)
--*/
--�1
   SELECT "TYPE_ID",          "NAME",          "SHORTNAME",          "MANUAL",          "CODE",          "ACTION",          "PRIORITY"
     FROM types
    WHERE code = 4
          AND type_id IN
                 (SELECT object_id
                    FROM jobs_rights jr, users u
                   WHERE jr.code = 4 AND jr.job_id = u.job and u.user_ = :USER_
                  MINUS
                  SELECT object_id  FROM users_rights ur, users u 
                   WHERE  ur.user_id = u.user_id and u.user_ = :USER_  AND ur.code = 4  AND ur.operation > 0
                  UNION
                  SELECT object_id
                    FROM users_rights ur, users u
                   WHERE ur.user_id = u.user_id and u.user_ = :USER_  AND ur.code = 4  AND ur.operation < 1  
                   )
                   
/      
--�2 ��������� operation
select  "TYPE_ID",          "NAME",          "SHORTNAME",          "MANUAL",          "CODE",          "ACTION",          "PRIORITY" 
FROM types t
   where  code = 4 
    and nvl((select operation from ( 
        (select u0.user_id,u0.user_,100 priority,ur0.object_id,ur0.code,ur0.operation,ur0.rights from users u0,users_rights ur0 where u0.user_id = ur0.user_id
              union
              select u0.user_id,u0.user_,0 priority,jr0.object_id,jr0.code,jr0.operation,jr0.rights from users u0, jobs_rights jr0
              where u0.job = jr0.JOB_ID
              ) order by priority desc,operation desc,rights desc  )
             where user_ = 'ALESHIN_RL' and code = t.code and object_id = t.type_id and rownum < 2),1) < 1 --������ ������ �� ������ ������ ��������� 
                       
/

select * from types t where
code = 4 --and type_id in (1440,6702,1)
and nvl((select operation from (
             (select u0.user_id,u0.user_,100 priority,ur0.object_id,ur0.code,ur0.operation,ur0.rights from users u0,users_rights ur0 where u0.user_id = ur0.user_id
              union
              select u0.user_id,u0.user_,nvl(uj0.priority,0) priority,jr0.object_id,jr0.code,jr0.operation,jr0.rights from users u0, jobs j0, users_jobs uj0, jobs_rights jr0
              where j0.job_id in (u0.job,uj0.job_id) and jr0.JOB_ID = j0.job_id
              --and nvl(j0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              --and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(j0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and nvl(uj0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(uj0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and u0.user_id = uj0.user_id(+)  
              ) order by priority desc,operation desc,rights desc  )
             where user_ = 'ALESHIN_RL' and code = t.code and object_id = t.type_id and rownum < 2),1) < 1 --������ ������ �� ������ ������ ���������
/

select * from types t where
code = 4 --and type_id in (1440,6702,1)
and nvl((select operation from (
             (select u0.user_id,u0.user_,100 priority,ur0.object_id,ur0.code,ur0.operation,ur0.rights from users u0,users_rights ur0 where u0.user_id = ur0.user_id
              union
              select u0.user_id,u0.user_,nvl(uj0.priority,0) priority,jr0.object_id,jr0.code,jr0.operation,jr0.rights from users u0, jobs j0, users_jobs uj0, jobs_rights jr0
              where j0.job_id in (u0.job,uj0.job_id) and jr0.JOB_ID = j0.job_id
              --and nvl(j0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              --and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(j0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and nvl(uj0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(uj0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and u0.user_id = uj0.user_id(+)  
              ) order by priority desc,operation desc,rights desc  )
             where user_ = 'ALESHIN_RL' and code = t.code and object_id = t.type_id and rownum < 2),1) < 1 --������ ������ �� ������ ������ ���������
/

select support_tools.CheckRights('ALESHIN_RL',t.code,t.type_id),t.* from types t 
where code = 4 --and type_id in (1440,6702,1)
and support_tools.CheckRights('ALESHIN_RL',t.code,t.type_id) <> 0
/
/*
CREATE OR REPLACE PACKAGE MBANK.SUPPORT_TOOLS
IS
        FUNCTION CheckRights(f_user_ varchar2, f_code number, f_object_id number) return number; 
END SUPPORT_TOOLS;
/
*/
/*
CREATE OR REPLACE PACKAGE BODY MBANK.SUPPORT_TOOLS IS



CREATE OR REPLACE FUNCTION CheckRights(f_user_ varchar2, f_code number, f_object_id number) return number
-- 04.04.2018 ����� ����� 
   is 
   res number; 
 BEGIN
   res := 0;
   for rec in (select * from (select u0.user_id,u0.user_,100 priority,ur0.object_id,ur0.code,ur0.operation,ur0.rights from users u0,users_rights ur0 where u0.user_id = ur0.user_id
              union
              select u0.user_id,u0.user_,nvl(uj0.priority,0) priority,jr0.object_id,jr0.code,jr0.operation,jr0.rights from users u0, jobs j0, users_jobs uj0, jobs_rights jr0
              where j0.job_id in (u0.job,uj0.job_id) and jr0.JOB_ID = j0.job_id
              --and nvl(j0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              --and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(j0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and nvl(uj0.date_start,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')) >= to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY')
              and to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY') <= nvl(uj0.date_finish,to_date(global_parameters.get_param_cfg('SYSTEMDATE'),'DD.MM.YYYY'))
              and u0.user_id = uj0.user_id(+)  
              ) 
              where user_ = f_user_ and code = f_code and object_id = f_object_id 
             -- where user_ = 'ALESHIN_RL' 
              order by priority desc,operation desc,nvl(rights,-100) desc
             )   
   loop
      if rec.operation < 1 then
        res := nvl(rec.rights,1);   
      end if;
      exit;
   end loop;            
   return res;
 END CheckRights;
-- *************************************************************

END SUPPORT_TOOLS;
/
--*/

select * from MBANK_AUDIT.LOG_DDL where ddl_date > sysdate-1/24

select * from dba_objects where status <> 'VALID' and owner in ('MBANK','EID','INTER_MBANK')

select * from jobs

select * from users

select * from job_param_values