--chin
--truncate table DABUG_TABLE
--truncate table PBS_DELIVERY_from
--truncate table  V_COMMISSION_INFO
--truncate table MBANK_LOG

truncate table TBL_MQ_TOOLS_LOG


--mbk
--truncate table V_COMMISSION_INFO
-- truncate table GIS_GMP_EXCHAGE
--truncate table TBL_QUEUE_SUBORPP_NOTIFY_MB_MQ
--truncate table TBL_DEILT_MESSAGE
--truncate table DDL_LOG
--truncate table TBL_PWD_SWIFT_VALIDATION_LOG
--truncate table DOCUMENTS_INNS
--truncate table MBANK_LOG
--truncate table TBL_MQ_TOOLS_LOG
--truncate table LOG_TECH_OPERATIONS
--truncate table PREPARE_IMPORT_REQUEST
--truncate table IMPEX_EXPORT_FILES
--truncate table DABUG_TABLE
--truncate table EFR_LOG

truncate table SMTP_MESSAGES