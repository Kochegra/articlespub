select * from MBANK.FNS_CHANGED_JL

select * from MBANK.CARDS_TO_FNS_CHNG
select * from MBANK.FNS_ACCOUNT_TYPES
select * from MBANK.FNS_AUTO_SEND_AUDIT where as_date > sysdate-10

select * from MBANK.FNS_MESSAGE_AUDIT where mes_date > sysdate-10 

select * from MBANK.FNS_MESSAGE_EDIT

select * from MBANK.FIL_INFO_LOAN_1

select * from MBANK.SMB_SEND_TEMPLATES

select * from EID.EID_WEB_TEMP_LOGINS

select * from MBANK.MEMOTEMPLATE

select * from MBANK.PREPORT_SRV_1000_TEMPLATES

select * from MBANK.MONITOR_QUEUE_DATA_TMP

select * from MBANK.COLLECTOR_CLIENTS_DEL_TMP

select * from EID.TMP_LOG_FIN_OPER

select * from MBANK.TEMPLATES

select * from MBANK.TEMP_TRUST

select * from EID.EID_PAYROLLS
select * from EID.EID_PAYROLLS_JR
select * from EID.EID_PAYROLL_FILES where MODIFY_AT_DATETIME > sysdate-300
select * from EID.EID_PAYROLL_PARAMS
select * from EID.EID_PAYROLL_STATES
select * from EID.EID_PAYROLL_USERS
select * from MBANK.FIL_INFO_LOAN_1

select * from MBANK.SVK_6001

select * from MBANK.SVK_700X

select * from MBANK.SVK_FLAGS_6001 where date_work >= trunc(trunc(sysdate,'yyyy')-1,'yyyy')
select * from MBANK.SVK_OK_TABLE 
select * from MBANK.SVK_PASP_KOMM
select * from MBANK.SVK_PKVK
select * from MBANK.SVK_TASK
select * from MBANK.S_DOC_SVK


select * from MBANK.ASVKB_DATA

select * from MBANK.ASVKB_FILES

select * from MBANK.SVK_6001

select * from MBANK.SVK_6001_CL

select * from MBANK.TEMP_SVK_DOP_PARAM

select * from MBANK.TBL_CORR_SCHEMA_PARAM_ARH

select * from MBANK.TBL_ENTITY_ACTION_PARAM_ARH

select * from MBANK.ORACLE_JOB_PARAMS

select * from MBANK.ROLE_PARAM_VALUES

select * from MBANK.PFR_XML_TEMPLATE

select * from MBANK.MESSAGES_PFRF

select * from MBANK.KLADR_SEARCH_TEMP

select * from MBANK.KLADR_ALT

select * from MBANK.KLADR_ALTNAMES
select * from MBANK.KLADR_ALT_1
select * from MBANK.KLADR_ALT_DIST
select * from MBANK.KLADR_ALT_DISTINCT

select * from MBANK.TMP_FILE_ENTITY

select * from MBANK.TMP_CLOBTOVTB

select * from MBANK.TMP_COURSE where work_date > SYSDATE-1

select * from U4936_BF_ADR
select * from U4936_BF_FIZ


select * from U4936_DATA
select * from U4936_DOC
select * from U4936_FILES
select * from U4936_FILES_CLOB
select * from U4936_FORMAT
select * from U4936_GROUP
U4936_TMP
U4936_TREE


select * from MBANK.KRM_ADDPARAMS_TMP
select * from MBANK.KRM_LOAD_LOG

select * from MBANK.BILL_PARAMS_GTMP
select * from MBANK.CLIENT_GTMP
select * from MBANK.JOURNAL_GTMP
select * from MBANK.KVIT_GTMP
select * from MBANK.KVIT_SVOD_OD1_GTMP
select * from MBANK.KVIT_SVOD_OD2_GTMP
select * from MBANK.LIQR_PIP_GTMP
select * from MBANK.MOVE_DOCS_GTMP
select * from MBANK.MOVE_DOCS_MAIN_GTMP
select * from MBANK.TEST_GTMP

select * from MBANK.CLIENTPARAMETERS

select * from MBANK.U_KVIT_PARAM_ALL
select * from MBANK.U_ORG_PARAM_ALL
select * from MBANK.U_PARAMS_ALL
select * from TBL_SCCASH_PARAMS

select * from MBANK.EDK_CHECK_COM_VERSION
select * from MBANK.EDK_COMMENTS_BY_TYPES
select * from MBANK.EDK_ROUTE_GROUP
select * from MBANK.EDK_TYPES_BY_GROUP
select * from MBANK.EDK_TYPE_PARAM

select * from MBANK.EDK_TYPE_PARAMS_LIST

select * from MBANK.EDK_TYPICAL_COMMENTS

select * from MBANK.CONTRACT_DEAL_MONITOR

select * from MBANK.CONTRACTS_COMISSIONS

select * from MBANK.CONTRACTS_COMISSIONS_EXT where date_create > sysdate-10 

select * from MBANK.CONTRACTS_MT940_PARAMS

select * from MBANK.DR$IDXKLADR_FULL$I
select * from MBANK.DR$IDXKLADR_FULL2$I

select * from MBANK.DR$IDX_CHECK_LOG$PARAMS$I
select * from MBANK.DR$IDX_CHECK_LOG$PARAMS$K
select * from MBANK.DR$IDX_CHECK_LOG$PARAMS$N
select * from MBANK.DR$IDX_CHECK_LOG$PARAMS$R

select * from MBANK.SHED_STAT_PARAM

select * from MBANK.TBL_QUEUE_ROUTE
select * from MBANK.TBL_INTGR_SERVICE
select * from MBANK.TBL_SWIFT_STATUS


select * from MBANK.KVITSTAT

select * from MBANK.KVIT_PCF_FILES

select * from MBANK.KVIT_PCF_DOCS

select * from MBANK.PCF_LOG where date_insert > sysdate-300

select * from MBANK.CLIENTS_LOYAL_PC_BACK where id_client > 11348861-10

select * from MBANK.TMP_KVIT_PC_DOCS where work_date > sysdate-10000

select * from MBANK.PC_GUIDE_EXCEPTION
select * from MBANK.PC_GUIDE_COLLECTOR
select * from MBANK.PC_GUIDE_NINTER

select * from MBANK.CPC_OPERATIONS
select * from MBANK.CPC_DOCUMENTS

select * from MBANK.PC_XML_CNT where PC_XML_CNT_ID > 500

select * from MBANK.PC_XML where date_work > sysdate-60

select * from MBANK.PC_XML_HEAD

select * from MBANK.AXIOMA_FOBO_SHED where mess_dt > sysdate-1

select * from MBANK.AXIOMA_REQUEST_FROM_FILIAL
select * from MBANK.AXIOMA_LOAD_DEALS_SHED
select * from MBANK.TBL_ESCROW_AXIOMA

select * from MBANK.TBL_AXIOMA_RATES

select * from MBANK.AXIOMA_SENT_DOC where sys_date > sysdate-1

select * from MBANK.AXIOMA_ASK_COURSE where sys_date > sysdate-1

select * from MBANK.AXIOMA_EXEC_DOC
select * from MBANK.AXIOMA_SETTINGS

select * from MBANK.TMP_BANKS
select * from MBANK.TMP_BANKS_ALL_021208
select * from MBANK.ITB_BANKS
select * from MBANK.DWH_ACCOUNT_SBO

select * from MBANK.DWH_CURRENCY_SBO
select * from MBANK.CURRENCY_DSS

select * from sms_cards_tmp

select * from EID.OPEN_CARD_HIST
select * from EID.OPEN_CARD_HISTS
select * from EID.OPEN_CARD_SCRIPTS
select * from EID.OPEN_CARD_SERVICE
select * from EID.OPEN_CARD 

select * from EID.SMS_NOTE 

select * from EID.SMS_NOTE_PHONE 

select * from PRC_LOADER.CARDS_TO_FNS where work_date>='01jan2022'

select * from MBANK.CACHE_DOCUMENTS

select * from EID.EID_MDM 

select * from EID.XX_LOAD_PARTS

select * from MBANK.BANK_BALANCE 

select * from EID.BLOCKED_EID

select * from MBANK.ACCOUNTS_LOYAL

select * from CENTROSMSG

select * from MBANK.UNPERS_CARDS
select * from MBANK.UNPERS_CARDS_HISTORY
select * from MBANK.UNPERS_INHERITANCE
select * from MBANK.UNPERS_NOTARYREQUESTS
select * from MBANK.UNPERS_PARTINHERITANCE
select * from MBANK.UNPERS_PERMISSIONS
select * from MBANK.UNPERS_SPECIAL_MARKS
select * from MBANK.UNPERS_WARRANTS
select * from MBANK.UNPERS_WARRANTS_AUDIT
select * from MBANK.UNPERS_WARRANT_ACTIONS

select * from MBANK.FNO_FILE_STORAGE

select * from MBANK.FNO_ANSW_CNT
select * from MBANK.FNO_FILE_STORAGE
select * from MBANK.FNO_FIL_ACCOUNTS

select * from FNO_FIELDS_MAP

select * from MBANK.DEMAND_CROSS 

select * from MBANK.SERVICE_9098
select * from MBANK.SERVICE_GTMP_14315

select * from MBANK.SERVICE_LIST_TYPE
select * from MBANK.SERVICE_RUN_COM
select * from MBANK.SERVICE_USER

select * from MBANK.SERVICE_PARAMS_2

select * from MBANK.SERVICE_DOC_LIST

select * from MBANK.SERVICE_OBJ_LIST

select * from MBANK.TBL_QUEUE_ACBNO_MQ_MB_TMP_LOG

select * from MBANK.TBL_QUEUE_SEMAPHORE

select * from MBANK.TBL_QUEUE_KFT_MB_MBFIL

select * from MBANK.TBL_QUEUE_MQ_ENCOD

select * from MBANK.TBL_QUEUE_SRVCANCEL_MKC_SPTR

select * from MBANK.TBL_QUEUE_DELETE

select * from MBANK.USERS_44FZ

select * from MBANK.USER_APP_PARAMS

select * from MBANK.USER_SETTINGS

select * from MBANK.USER_PARAM_VALUES_ARCH

select * from MBANK.USERS_V


select max(id_version) from EDK_DOC_VERSION --where date_create > sysdate-1


select * from EDK_DOC_VERSION where id_version > 21682682


select rowid,e.* from eid.EID_CARD_COLLECTOR e where work_date > sysdate-1/24

select rowid,e.* from eid.EID_CARD_COLLECTOR e where pk = '1'

select t.* from CF_COLLECTOR t where work_date > sysdate-1and docnum = 7163910390


select max(id) from EDK_FILES_RECEIVED

select * from EDK_FILES_RECEIVED where id > 29287554

select max(id) from TBL_ENTITY_OBJECT_ATTR_LOG

select * from TBL_ENTITY_OBJECT_ATTR_LOG where id > 2602022591

select * from PRC_LOADER.PCARD_RESERV_DAY

select * from BO_CONTENTINPUT

select * from MIS.TBL_DWH_TRANSACTIONS where TRANS_DATE > sysdate-1000

select max(TRANS_DATE) from MIS.TBL_DWH_TRANSACTIONS 

select * from PRC_LOADER.PCARD_NEW

select * from POOL.CM_OBJHISTORY

select max(ID) from LOAD_ANKETA_SITE_LOG

select * from LOAD_ANKETA_SITE_LOG where id > 202105271391-1000000

select * from MBANK.BSS_LST_CACHE where  date_work > sysdate-2

select * from BILL_PARAMS_DATA

select max(id) from REESTRNEW.LOANS

select * from REESTRNEW.LOANS where id > 700013724-100

select max(rep_id),max(created) from BUDGET2.B2L_AENT1_ARC

select max(created) from BUDGET2.B2L_AENT1_ARC where rep_id > 2208293679-10

select rowid,t.* from BUDGET2.B2L_AENT1_ARC t where  reference = 1267640746 and branch = 145

select * from TBL_SUBO_FILTER_XML

select * from OPS44.TR44_REQ

select max(rep_point) from PRC_LOADER.CLIENTS_PCARD 

select * from EID.EID_MDM

select * from TRADE_44FZ_REQ

select * from AXIOMA_FOBO_SHED_DEPOSIT

select max(id) from TBL_SWIFT_STATUS_HIST 

select * from TBL_SWIFT_STATUS_HIST where id > 2818181846-10

select * from PRC_LOADER.ACQ_TRANSACTIONS where POSTING_DATE > sysdate-10

select * from PRC_LOADER.ACQ_TRANSACTIONS_INS where POSTING_DATE > sysdate-10

select * from MBANK.MKT_OPERATIONS_EXTERNAL where date_reg > sysdate-15

select max(id) from SCD_DOCUMENTS_HIST 

select * from SCD_DOCUMENTS_HIST where id > 1029305609-10

select max(id_record) from eid.EID_FIRMA_MANAGER_HISTORY 

select * from eid.EID_FIRMA_MANAGER_HISTORY where id_record > 172758446

select  max(id) from eid.EID_FIRMA_VARIABLE 

select * from eid.EID_FIRMA_VARIABLE where id > 1197996347

select max(id) from TBL_ENT_OBJ_ON_ROUT

select * from TBL_ENT_OBJ_ON_ROUT where  id > 501476995

select max(id) from TBL_ENT_OBJ_ON_ROUT_HIST

select * from TBL_ENT_OBJ_ON_ROUT_HIST where  id > 501474279-10

select * from EID.EID_FIRMA_CHANGE_LOG 

select * from FSSP_HISTORY WHERE timestart > sysdate-1

select max(id) from PBS_BF_DOCUMENT

select * from PBS_BF_DOCUMENT where id > 209508284-10

select max(id) from EID.EID_PRODUCTS_VARIABLE 

select * from EID.EID_PRODUCTS_VARIABLE where id > 457537507-100

select * from EID_ACTIVITY_LOG where date_work > sysdate-1 and task_id = 1

select max(reference_obj) from EID.EID_SERVICE_OBJ_LIST 

select * from EID.EID_SERVICE_OBJ_LIST where reference_obj > 7165421406-1000

select * from RESERVE_MSFO_POS_HIST where work_date > sysdate-80

select max(VTB_TRAN_ID) from SYNERGY_QUERIES_REESTR where VTB_TRAN_ID like 'SP%'

select * from SYNERGY_QUERIES_REESTR where VTB_TRAN_ID = 'SP.3275976'

select * from SYNERGY_QUERIES where VTB_TRAN_ID = 'SP.3275976'

select * from OPAY.OUT_PAYMENT_LOG

select * from EID.EFRSB_LOAD_FROM_FTP

select * from MIS.TBL_DICT_TRANSACTION_MAPPING

select * from PRC_LOADER.UKM_PCARD_HISTORY where rep_point > sysdate-10

select * from OPAY.OUT_PAYMENT_RELATION

select * from MBANK.WORK_LOG_ARCHIVE where date_message > sysdate-100

select max(ID) from MBANK.SWMESSAGES

select * from MBANK.SWMESSAGES where id > 260751835-10

select * from PRC_LOADER.PCARD_RESERV where rep_point > sysdate-30

select * from MBANK.TREPORT_664_HIST_DATA where date_value > sysdate-1

select max(id) from MBANK.TMP_LEGOSTEV

select * from MBANK.TMP_LEGOSTEV where id > 972707493441-10
 
select * from EID.FAST_PAYMENT where date_create > sysdate-1

select * from EID.FAST_PAYMENT_KVIT where date_kvit > sysdate-3

select max(message) from MBANK.BO_CONTENTOUTPUT

select * from MBANK.BO_CONTENTOUTPUT where message > 870439918-10

select max(reference) from MBANK.VARIABLE_CLIENTS where branch = 191

select * from MBANK.VARIABLE_CLIENTS where branch = 191 and reference > 118214255

select * from MBANK.SVK_TASK_BLOB where create_date > sysdate-60

select max(id) from CR_DOCS.TBL_EL_DOC_CERTIFICATE

select * from CR_DOCS.TBL_EL_DOC_CERTIFICATE where id > 45640170-10

select max(id) from EID.EID_ANKETA_115FZ_LOG

select max(id_anketa) from EID.EID_ANKETA_115FZ 

select * from EID.EID_ANKETA_115FZ where id_anketa > 180356941-10

select max(reference) from MBANK.TBL_PLAN_EVENT 

select * from MBANK.TBL_PLAN_EVENT where reference > 8780827570-100

select * from SCORING.SAS_OPERDAY_CARD where on_date > sysdate-120

select max(ID) from MBANK.U4936_DATA

select * from MBANK.U4936_DATA where id > 558789561-10

select max(ID) from MBANK.K2_LOGS

select * from MBANK.K2_LOGS where id > 273051669-10

select * from MBANK.BO_TITLEOUTPUT where initdate > sysdate-80

select * from MBANK.MQ_EVENTS where date_create >  sysdate-3

select * from MBANK.JOURNAL_DELETE where work_date > sysdate-80

select * from MBANK.FNS_MESSAGE_ARC where mes_date > sysdate-10

select * from MBANK.TBL_QUEUE_BO_GETACCSUML_MB_MQ

select max(id_rec), min(id_rec) from EID.EID_FIRMA_MDM_UPLOAD

select * from EID.EID_FIRMA_MDM_UPLOAD where id_rec > 406386902	

select * from EID.EID_FIRMA_MDM_UPLOAD where id_rec <= 5303+1000

select max(id) from MBANK.UNIPAY_REQUEST

select id,status,date_start,date_finish,terminal,inquiry,substr(xml_in,1,4000),substr(xmldata,1,4000),substr(xml_out,1,4000) from MBANK.UNIPAY_REQUEST where id > 4605383-10

select MAX(MOD_DT) from TBL_QUEUE_IIB_ACCCHANGE_MB_MQ

select * from tbl_queue_iib_accchange_mb_mq where mod_dt > sysdate-1

select * from SYS.AUD_BM$

select max(doc_date) from MBANK.PBS_DOCUMENT_MAP

select max(file_id) from PBS_BF_ACCOUNT

select * from PBS_BF_ACCOUNT where file_id > 98045-1

select * from USERS_SUBDEPARTMENTS
/

select * from ACCOUNT where header = 'p' and close_date is null


select * from JOURNAL 

select * from EID.EID_CARD_PIN_JOURNAL

select * from STATUS_PLAN_ACCOUNT

select * from EID.EID_FIRMA_MAN_TYPEREF

select * from ACNT_INTENTION_GROUP

select * from  TBL_ENTITY_GROUP
select * from TBL_ENT_TABLE_COPY_GROUP
select * from TBL_GROUP_OPERATION_ATTR

select * from  TBL_ROUT_CHECK_VISIBLE_GROUP
select * from TBL_ROUT_CHECK_VISIBLE_GROUP_A

select * from  SMS_COMISSIONS

select * from EID.EID_TAXES

select max(id) from IMPEX_DOC 

select * from IMPEX_DOC where id > 3529182542-100
