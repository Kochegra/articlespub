select * from guides_all gd where type_doc = 7372

/

select tbl,priority,min(date_modify),sysdate,60*24*round(sysdate-min(date_modify),3) "����� ��������",count(*)
,(select num1||'_CHG_OBJ' from guides_all gd where type_doc = 7372 and code = ch.tbl) "���"
 from chg_obj ch where status = 0 
 --and trunc(date_modify) >= trunc(sysdate)
group by tbl,priority
/


select count(*) over(),c.*  from chg_obj c
--update chg_obj set priority = mod(reference,2)
where tbl = 'CONTRACTS' and mod(reference,2) = 0 and status = 0
/

declare
  xStr varchar2(2000);
begin
  xStr :=  ptools_eid_export.EXEC_EXPORT(nStreamID => 3,nPriority => 9 );
  commit;
exception
  when others then
    null;
end;
/

select * from account a
--update account a set SUBDEPARTMENT = SUBDEPARTMENT 
where 1=1 
and not exists (select null from eid.eid_account where code = a.code and currency = a.currency and header = a.header)
and not exists (select null from eid.eid_firma_account where code = a.code and currency = a.currency and header = a.header)


select substr(doc_number,3),a.* from contracts a
--update contracts a set doc_number = '__'||doc_number
--update contracts a set doc_number = substr(doc_number,3)
where 1=1 
and not exists (select null from eid.eid_products where reference = a.reference and branch = a.branch)
and not exists (select null from eid.eid_firma_products where reference = a.reference and branch = a.branch)
and substr(doc_number,1,2) = '__' 

select * from eid.eid_products 

select * from eid.eid_firma_products