
select * from guides
--update guides set str1 = '#'||str1  
where type_doc = 13826
-- and date1 > sysdate 

select rowid,z.* from zyx_cont_cb z

select * from zyx_cont_cb z, v_subdep@nsibirsk s where s.bis_id = z.a
and status = 50

select * from v_subdep
/

--insert into guides@nsibirsk (BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK,CODE,STR1,CODE1,date1)
select * from (select mbfilid@nsibirsk,0,13826 type_doc ,0 st,978042,to_date('01.01.1990','dd.mm.yyyy') DATE_WORK,to_char(s.id) code,to_char(s.id) STR1, z.a CODE1
,to_date(z.e,'dd.mm.yyyy') dt 
 from zyx_cont_cb z, v_subdep@nsibirsk s where s.bis_id = z.a and s.status = 50
 --and to_date(z.e,'dd.mm.yyyy') < to_date('15.02.2020','dd.mm.yyyy')
) g
where not exists (select null from  guides@nsibirsk where type_doc = g.type_doc and code = g.code and str1 = g.str1) 
/


select rowid,z.* from zyx_cont_cb@dss z
/

--insert into documents@dss
select * from documents where reference = 3789990942

--insert into variable_documents@dss
select * from variable_documents where reference = 3789990942

select * from documents where reference = 3789990942

insert into clients@dss
select * from clients where reference = 114872251 and branch =  631310

insert into variable_clients@dss
select * from variable_clients where reference = 114872251 and branch =  631310

--insert into contracts@dss 
--select * from contracts where reference = 15823727 and branch =  631310
select * from contracts as OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '100' MINUTE) where reference = 15823755 and branch =  631310


--insert into variable_contracts@dss 
--select * from variable_contracts where reference = 15823727 and branch =  631310
select * from variable_contracts as OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '100' MINUTE) where reference = 15823755 and branch =  631310
/

--select * from account where contract = 15823755 and branch_contract =  631310

--insert into eid.eid_firma@dss
select * from eid.eid_firma where reference = 114872251 and branch = 631310
 eid = 6189818

--insert into eid.eid_firma_variable@dss
select * from eid.eid_firma_variable where eid in (6193955,6186513)

--insert into eid.EID_FIRMA_ADDRESS@dss
select * from eid.EID_FIRMA_ADDRESS where eid = 6186513

--insert into eid.EID_FIRMA_CLASSIF@dss
select * from eid.EID_FIRMA_CLASSIF where eid = 6193955

--insert into eid.EID_FIRMA_MANAGER@dss
select * from eid.EID_FIRMA_MANAGER where eid = 6186513

--insert into eid.EID_FIRMA_CONTACTS@dss
select * from eid.EID_FIRMA_CONTACTS where eid = 6190396

--insert into eid.EID_MANAGER_DELEGATE_DOCS@dss
select docs.*  FROM eid.EID_MANAGER_DELEGATE_DOCS docs where 
   docs.parent_id in (select mh.id_record from eid.eid_firma_manager mh where eid in (6186513) and mh.status=1 )
      AND docs.status = 1  

--select * from eid.EID_FIRMA_RELATION where eid_to = 6190396

select * from eid.EID_MANAGER where manager_eid in (33982053,33982052)

select * from eid.EID_MANAGER_DELEGATE_DOCS

select * from dba_tables where table_name like 'EID_MANAG%'