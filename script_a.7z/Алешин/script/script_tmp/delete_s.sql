 SELECT distinct
 'INFO'
 ,'DB'
 ,TRUNC(sum(bytes) over()/1024/1024/1024,2) GB
 ,owner 
 ,TRUNC(sum(bytes) OVER (PARTITION BY owner)/1024/1024/1024,2) sch_GB
 ,table_name 
 ,TRUNC(sum(bytes) OVER (PARTITION BY owner,table_name)/1024/1024/1024,2) tbl_GB
 ,seg_type
 ,TRUNC(sum(bytes) OVER (PARTITION BY owner,table_name,seg_type)/1024/1024/1024,2) seg_GB
 ,TRUNC(sum(bytes) OVER (PARTITION BY owner,table_name,seg_type),2) seg_Bytes
 ,sysdate
 --,sum(bytes) B
 --,ROUND( ratio_to_report( sum(bytes) ) over () * 100) Percent
FROM
(SELECT 'TABLE' seg_type, segment_name table_name, owner, bytes
 FROM dba_segments
 WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
 UNION ALL
 SELECT 'INDEX' seg_type,i.table_name, i.owner, s.bytes
 FROM dba_indexes i, dba_segments s
 WHERE s.segment_name = i.index_name
 AND s.owner = i.owner
 AND s.segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
 UNION ALL
 SELECT 'LOB' seg_type,l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.segment_name
 AND s.owner = l.owner
 AND s.segment_type IN ('LOBSEGMENT', 'LOB PARTITION', 'LOB SUBPARTITION')
 UNION ALL
 SELECT 'LOBINDEX' seg_type,l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.index_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBINDEX')
WHERE 1=1 
--owner in ('MBANK','EID') and table_name in 
and table_name like 'AUDIT_TABLE%'
--and table_name in ('PERCENT_CONTRACTS_AUDIT')
--GROUP BY table_name, owner, seg_type
ORDER BY tbl_GB DESC,table_name,seg_gb desc
/

select (select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabsubpart$', 'HIBOUNDVAL', t.rowid) from sys.tabsubpart$ t, dba_objects tb where tb.OBJECT_ID = t.obj# 
 and tb.object_name = tt.segment_name and tb.subobject_name= tt.partition_name) ss ,
 (select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabcompart$', 'HIBOUNDVAL', t.rowid) from sys.tabcompart$ t, dba_objects tb, sys.tabsubpart$ ss where tb.OBJECT_ID = ss.obj# 
 and ss.pobj# = t.obj# and tb.object_name = tt.segment_name and tb.subobject_name= tt.partition_name) ss ,
tt.* from (
SELECT TRUNC(sum(bytes) OVER (PARTITION BY owner,partition_name)/1024/1024/1024,2) tbl_GB, bytes/1024/1024, t.*
 FROM dba_segments t
 WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION') and segment_name like 'AUDIT_ARCHIVE'
) tt order by  tbl_GB desc
 --and partition_name = 'SYS_SUBP5238694' 1 906 476 693

select * from dba_tab_partitions where table_name = 'AUDIT_ARCHIVE'

select * from sys.obj$ where name = 'AUDIT_ARCHIVE'
 
 select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabsubpart$', 'HIBOUNDVAL', t.rowid) ff, 
 t.*, tb.* from sys.tabsubpart$ t, dba_objects tb where tb.OBJECT_ID = t.obj# and tb.object_name = 'AUDIT_ARCHIVE'
 
  select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabcompart$', 'HIBOUNDVAL', t.rowid) ff, 
 t.*, tb.* from sys.tabcompart$ t, dba_objects tb, sys.tabsubpart$ ss
  where tb.OBJECT_ID = ss.obj# and tb.object_name = 'AUDIT_ARCHIVE' and ss.pobj# = t.obj#

  select * from sys.tabpart$ where obj# IN  
  (select obj#  from sys.obj$ where name = 'AUDIT_ARCHIVE')
  
  select * from sys.tabcompart$ where obj# IN  
  (select obj#  from sys.obj$ where name = 'AUDIT_ARCHIVE')
   
  /
  
 select --'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''RESTRUCT'',''DOCUM'',''DOCUMENTS_VN''); ' sql
 --'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''COLLECTOR'',''COLLECTOR_CONTRACTS'',''VARIABLE_CONTRACTS''); ' sql
-- 'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''CLIENTS_AUDIT'',''CLIENTS_MODIFY''); ' sql
-- 'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''DOCUMENT_AUDIT'',''ACCOUNT_AUDIT''); ' sql
-- 'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''EID_STOP''); ' sql
-- 'alter table AUDIT_ARCHIVE modify SUBPARTITION '||partition_name||' add VALUES (''BANK_DATE''); ' sql
'alter table AUDIT_ARCHIVE truncate SUBPARTITION '||partition_name||' drop storage; ' sql
-- ,substr(sub,11,10)
 , a.* from ( 
  select (select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabsubpart$', 'HIBOUNDVAL', t.rowid) from sys.tabsubpart$ t, dba_objects tb where tb.OBJECT_ID = t.obj# 
 and tb.object_name = tt.segment_name and tb.subobject_name= tt.partition_name) ss ,
 (select sys.dbms_metadata_util.long2varchar(2000, 'sys.tabcompart$', 'HIBOUNDVAL', t.rowid) from sys.tabcompart$ t, dba_objects tb, sys.tabsubpart$ ss where tb.OBJECT_ID = ss.obj# 
 and ss.pobj# = t.obj# and tb.object_name = tt.segment_name and tb.subobject_name= tt.partition_name) sub ,
tt.* from (
SELECT TRUNC(sum(bytes) OVER (PARTITION BY owner,partition_name)/1024/1024/1024,2) tbl_GB, bytes/1024/1024, t.*
 FROM dba_segments t
 WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION') and segment_name like 'AUDIT_ARCHIVE'
)tt ) a
where --instr(ss,'DOCUMENTS') > 0 or instr(ss,'CONTRACTS') > 0 or instr(ss,'CLIENTS') > 0 or instr(ss,'ACCOUNT') > 0 or  instr(ss,'EID_HUMAN') > 0 or instr(ss,'GUIDES') > 0   
 instr(ss,'DEFAULT') > 0 or instr(ss,'SHED') > 0
--and substr(sub,11,10) > '2016-07-01'
 order by sub desc,ss 
 / 

  select * from dba_indexes where table_name = 'AUDIT_ARCHIVE'
  
   select * from dba_indexes i , dba_segments s where i.table_name = 'ARCHIVE'
   and s.segment_name = i.index_name
   
   /
   
       select bytes/1024/1024, s.*, i.* from dba_indexes i , dba_segments s where i.table_name = 'AUDIT_ARCHIVE'
   and s.segment_name = i.index_name 
   --and segment_name = 'AUDIT_ARCHIVE_INDEX' 
   order by s.bytes desc
   
   
