create table konkin_test_paccount as 
select distinct 
       a.header
       ,a.bal
       ,a.currency
       ,substr(a.code, 10, 4) as cfu
       ,lpad('0',20,'0') as acc
  from account a
/

select * from konkin_test_paccount
/

declare
    g_bal varchar2(4000) := 'test-create-acc-ar1';
    l_elapsed number;
    l_res varchar2(100);
    i number := 0;
    l_start pls_integer;
  
   
    function ar_get_free_tail( i_hdr varchar2, i_bal varchar2, i_curr varchar2, i_cfu varchar2, i_min number default 1, i_max number default 9999999 )
        return varchar2 is
        l_tail varchar2(7); 
        nLsNum number;        
    begin 
      nLsNum := i_min;
      for aa in (select /*+ INDEX(account account_pk) */ * from account a 
                        where header = i_hdr and currency = i_curr
                              and  code like i_bal || i_curr || '_' || i_cfu || '%' 
                              and to_number(substr(code,14)) between i_min and i_max                               
                        order by to_number(substr(code,14))        
             )
    loop
      if to_number(substr(aa.code,14)) > nLsNum then
        exit;
      else
        nLsNum := to_number(substr(aa.code,14)) + 1;        
      end if;
    end loop;   
    if nLsNum <= i_max then
      l_tail := LPAD(LTRIM(RTRIM(TO_CHAR(nLsNum))),7,'0');
    end if;      
    return l_tail; 
    end;
    
    
begin
    delete from balance b where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', g_bal));
    commit;
    for r in (
        select * from konkin_test_paccount --where bal = 42102 and cfu = '0000' and currency = '810'
        order by header, bal, currency, cfu
    ) loop
        i := i + 1;
        l_start := dbms_utility.get_time();
        insert into balance ( bal, currency, operation, work_date, id, users, bal_str2, active_in)
        values(r.bal,r.currency,g_bal,sysdate,'konkin-ka',1005546 ,r.header||r.bal||r.currency||r.cfu,i );
        commit;
        --l_res := loc_get_free_tail( r.header, r.bal, r.currency, r.cfu );
        l_res := ar_get_free_tail( r.header, r.bal, r.currency, r.cfu );
        l_elapsed := (dbms_utility.get_time() - l_start)/100;
       update balance set passive_in = l_elapsed, bal_str1 = l_res 
       where operation = g_bal and active_in = i and id = 'konkin-ka' and users = 1005546 and currency = r.currency and bal = r.bal
       and bal_str2 = r.header||r.bal||r.currency||r.cfu;
        commit;
    end loop; 
end; 
/


select bal_str1 as tail
       ,substr(bal_str2, 1, 1) as header
       ,substr(bal_str2, 2, 5) as balance
       ,substr(bal_str2, 6, 3) as currency
       ,substr(bal_str2, 10, 4) as cfu
       ,bal_str3 as seconds
  from balance b 
 where (b.users, b.id, b.bal) = ((1005546, 'konkin-ka', 'test-modern-create-acc-v2'))
/


select bal_str1 as tail
       ,substr(bal_str2, 1, 1) as header
       ,substr(bal_str2, 2, 5) as balance
       ,substr(bal_str2, 6, 3) as currency
       ,substr(bal_str2, 10, 4) as cfu
       ,bal_str3 as seconds
  from balance b 
 where (b.users, b.id, b.bal) = ((1379, 'ar', 'test-modern-create-acc-v2'))