select z.* from zyx_cont_cb z

/
select z.a from zyx_cont_cb z 
--update zyx_cont_cb z set a = (select b from doc_3 where b is not null and a = z.a)
where a in (select a from doc_3 where b is not null)

select * from doc_3 where b is null 

--insert into doc_3(a)
select * from zyx_cont_cb z, eid.eid_firma_account a where 
z.a = a.code(+)
--regexp_replace(z.a,'[[:digit:]]','0',9,1) = regexp_replace(a.code,'[[:digit:]]','0',9,1)
--and z.a <> a.code
--and rownum < 10
and z.d is not null
/

begin 
  for rr in (select * from zyx_cont_cb z, eid.eid_firma_account a where z.a = a.code(+) and z.d is null)-- and rownum < 2)
  loop
    update zyx_cont_cb z set d = to_char(rr.subdepartment), e = (select name from eid.eid_subdepartments where id = rr.subdepartment) 
    where rr.a = z.a ;
    commit;
  end loop;
end; 
/

begin 
  for rr in (select rowid,z.* from zyx_cont_cb z where f is null and d is not null)-- and rownum < 3)
  loop
    update zyx_cont_cb z set f = (select b.ref_code from boss_subdepartments b, eid.eid_subdepartments e where e.boss_subdep_id = b.id and to_char(e.id) = rr.d)  
    --  to_char(rr.subdepartment), e = (select name from eid.eid_subdepartments where id = rr.subdepartment) 
    where rowid = rr.rowid;
    commit;
  end loop;
end; 
/
/
select rowid,z.* from zyx_cont_cb z where z.f is not  null
/
select * from eid.eid_firma_account a, doc_3 z  where a.header = 'A' and currency = '810' and code = regexp_replace(z.a,'[[:digit:]]',substr(code,9,1),9,1)
and rownum < 3
/

update doc_3 z set b = (select code from eid.eid_firma_account a where a.header = 'A' and currency = '810' and code = regexp_replace(z.a,'[[:digit:]]',substr(code,9,1),9,1))
/
select * from account
--update account set subdepartment = subdepartment 
where code in (
select a from zyx_cont_cb z, eid.eid_firma_account a where z.a = a.code(+)
and code is null
)
/

select * from zyx_cont_cb z where a in ( 
select a from zyx_cont_cb z
group by a
having count(*) > 1 
)
and c = '��-����' 


select regexp_replace(a,'[[:digit:]]','0',9,1), z.* from zyx_cont_cb z where a = '40702810200470015020'