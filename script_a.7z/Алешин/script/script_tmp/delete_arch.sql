select * from mon.exceptions
--where recrowid = 'AAI6y4AC8AABcxxABl'
order by committimestamp desc
 

select max(dt_mod),count(*) from zyx_store

select sysdate,max(ref),max(dt),count(*) from mbank_audit.mb_audit

select * from mbank_audit.mb_audit where tbl = 'USERS' and dt > sysdate-1/24
and obj_id in (70357,21)

select count(*) from users

select * from users where user_id = 1150706

select rowid,u.* from users u where 
--user_id = 1150706
user_ like '%ROM'

select max(work_date),count(*) from CF_COLLECTOR where work_date > trunc(sysdate)-1
/

select max(id),count(*) from GROUP_MEMBERSHIP

select max(modify_date),count(*) from ACCOUNT

select max(DATE_CREATE),min(DATE_CREATE),max(reference),min(reference),count(*) from ARCHIVE
where date_work > trunc(sysdate)-2

select max(DATE_MODIFY),min(DATE_MODIFY),max(reference),min(reference),count(*) from CLIENTS

select max(work_date),min(work_date),max(RECORD_ID),min(RECORD_ID),count(*) from COLLECTOR_CLIENTS

select max(DATE_CREATE),min(DATE_CREATE),max(reference),min(reference),count(*) from DOCUMENTS

select max(work_date),min(work_date),max(journal_id),min(journal_id),count(*) from JOURNAL
where work_date < '01jan2000'

select sysdate,max(work_date),min(work_date),max(journal_id),min(journal_id),count(*) from JOURNAL
where --work_date > '08mar2021'
journal_id > 3311426134

select max(WORK_DATE),min(WORK_DATE),count(*) from LEDGER
where WORK_DATE > trunc(sysdate)-2

select * from LEDGER
where WORK_DATE > trunc(sysdate)-2

select count(*) from USER_PARAMETERS

select * from USER_PARAMETERS

select count(*) from USER_PARAM_values

select count(*) from eid.EID_SUBDEP_VARIABLE
/

select * from IMAGES_PARENT where refer_obj = 89018 and branch_obj = 108000

select * from images_doc where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT where refer_obj = 89018 and branch_obj = 108000)
/

select count(*),max(date_modify) from IMAGES_PARENT i
   where 1=1 
   --and operation = '3' and (refer_obj,branch_obj) in (select reference,branch from scoring_forms )
   --and operation = 'scoring_request_bm' and exists (select null from sco_anketa.TBL_SCORING_REF where reference_REQ = i.refer_obj and branch_REQ = i.branch_obj)
--       and operation = '0' and exists (select null from mbank.hypo_forms where reference = i.refer_obj and branch = i.branch_obj )
   and operation in ('CA_SMB','CARD_APPL','777','COUNTERFOIL_CERTIFICAT','MOSBROKER','PIF_TRUSTS','SCAN_PAYROLL','VIP_DECISIONS','VYSOTA_PKG')   
   --and branch_obj = 108000 and refer_obj >= 86000  and refer_obj < 100000
   --and refer_obj = 5577598 and branch_obj = 47022
/
 
1205814
      
  select count(*) from images_doc
   where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT i where 1=1 
   --and operation = '3' and (refer_obj,branch_obj) in (select reference,branch from scoring_forms )
   --and operation = 'scoring_request_bm' and exists (select null from sco_anketa.TBL_SCORING_REF where reference_REQ = i.refer_obj and branch_REQ = i.branch_obj)
   -- and operation = '0' and exists (select null from mbank.hypo_forms where reference = i.refer_obj and branch = i.branch_obj )
   and operation in ('CA_SMB','CARD_APPL','777','COUNTERFOIL_CERTIFICAT','MOSBROKER','PIF_TRUSTS','SCAN_PAYROLL','VIP_DECISIONS','VYSOTA_PKG')   
 --and branch_obj = 108000 and refer_obj >= 86000  and refer_obj < 100000
   --and refer_obj = 5577598 and branch_obj = 47022
   )
   
247163
  

select count(*) from IMAGES_PARENT i
   where operation = '3'
   and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj ) 
   and branch_obj <= 50
      
  select count(*) from images_doc
   where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT i
   where operation = '3' 
   and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj ) 
  -- and branch_obj <= 50
   ) 
   
   
   select * from IMAGES_PARENT i
   where operation = '3' 
   --and (refer_obj,branch_obj) in (select reference,branch from scoring_forms )
   and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj ) 
   and branch_obj <= 50-- and refer_obj < 100000 
 
  select * from images_doc
   where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT i
   where operation = '3' --and (refer_obj,branch_obj) in (select reference,branch from scoring_forms )
   and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj ) 
   --and branch_obj = 108000 and refer_obj < 120000
   and branch_obj <= 50
   )
   /
   
   select * from SCORING.SAS_CONTRACTS_120208
   
   /
   
   select * from dba_objects where LAST_DDL_TIME is not null
   order by LAST_DDL_TIME desc 