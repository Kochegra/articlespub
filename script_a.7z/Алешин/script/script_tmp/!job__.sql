--������ �������� (����������) � ����������� �������� > 51��� 
select * from subo_movements where n_part in ('28','27') and code = '40701840096000004346'
and journal_id = 3505740307
/

select * from journal where code = '40701840096000004346' and work_date = to_date('28.07.2021','dd.mm.yyyy')
and operation = '519002'
--docnum = 6567326550 and journal_id = 3505740307 

��� ������, ��������� ������ ����� �������� �������� ��� ��������� ������, ����� ���������� ������ �� ���������.

--����������
select * from subo_movements where n_part in ('28','27','24','26','25') 
and journal_id = 3502397551
/

select * from journal _delete where docnum = 6557053624 and journal_id = 3502397551

SYSDATE - TO_DATE('01.01.2000','dd.mm.yyyy')


select ( select value from v$parameter where name like 'parallel_max_servers') -
(select count(*) from v$px_process where status='IN USE') FREE_PARALLEL_SERV from dual;


select * from v$parameter where name like 'parallel_max_servers'

select value from v$parameter where name = 'job_queue_processes' like '%job%'

select * from v$px_process order by status DESC 

select * from v$session

select /* +parallel (40) */ * from documents

select * from dba_jobs_running

select * from dba_jobs_running_hist

select * from dba_objects where object_name like 'DBA_SCHEDULER%'


select (select value from v$parameter where name = 'job_queue_processes') 
- (select count(*) from dba_scheduler_running_jobs) 
- (select count(*) from dba_jobs_running) cnt from dual
/

select * from dba_scheduler_running_jobs

select * from DBA_SCHEDULER_JOB_LOG where log_date > sysdate-1

select count(*) over() cnt, count(*) over(partition by owner,job_name) cnt_j,  t.* from DBA_SCHEDULER_JOB_RUN_DETAILS t 
where log_date > to_date('26.07.2021','dd.mm.yyyy') and log_date < to_date('27.07.2021','dd.mm.yyyy')
order by 2 desc

select count(*) over() cnt, count(*) over(partition by owner,job_name) cnt_j
,actual_start_date+run_duration
,trunc(actual_start_date+run_duration,'hh24')
,  t.* from DBA_SCHEDULER_JOB_RUN_DETAILS t 
where log_date > to_date('26.07.2021','dd.mm.yyyy') and log_date < to_date('27.07.2021','dd.mm.yyyy')
and owner = 'MBANK'
order by 2 desc

select to_date('26.07.2021','dd.mm.yyyy')+1/24*level from dual connect by level < 24

select count(*),trunc(actual_start_date+run_duration,'mi') from DBA_SCHEDULER_JOB_RUN_DETAILS t 
where log_date > to_date('26.07.2021 11','dd.mm.yyyy hh24') and log_date < to_date('26.07.2021 14','dd.mm.yyyy hh24')
--and owner in ('MBANK','EID')
group by trunc(actual_start_date+run_duration,'mi')
order by count(*) desc

select dd,(select count(*) from DBA_SCHEDULER_JOB_RUN_DETAILS t 
          where actual_start_date <= dd and (actual_start_date+run_duration) >= dd+1/(24*60) and owner = 'MBANK')
from (select to_date('26.07.2021','dd.mm.yyyy')+1/(24*60)*level dd from dual connect by level <= 24*60)
where  dd >= to_date('26.07.2021 12','dd.mm.yyyy hh24') and dd <= to_date('26.07.2021 13','dd.mm.yyyy hh24')
/

select count(*) over() cnt,actual_start_date+run_duration fin, t.* from DBA_SCHEDULER_JOB_RUN_DETAILS t 
where actual_start_date <= to_date('26.07.2021 12:01','dd.mm.yyyy hh24:mi') and actual_start_date+run_duration >= to_date('26.07.2021 12:02','dd.mm.yyyy hh24:mi')
and owner in ('MBANK','EID')


select * from DBA_SCHEDULER_JOB_RUN_DETAILS t, DBA_SCHEDULER_JOB_RUN_DETAILS tt where 
tt.log_date > to_date('26.07.2021 11','dd.mm.yyyy hh24') and tt.log_date < to_date('26.07.2021 14','dd.mm.yyyy hh24')
and tt.job_name like 'KMB_6560737037_3'
and t.ACTUAL_START_DATE <= tt.ACTUAL_START_DATE and t.ACTUAL_START_DATE + t.RUN_DURATION >= tt.ACTUAL_START_DATE
/

select * from dba_jobs_running
/
3205	8257512

select * from dba_jobs where job = '8257512'

select * from DBA_SCHEDULER_JOB_RUN_DETAILS where log_date > sysdate-1 and job_name like 'KMB_6583356681%'
/

select * from DBA_SCHEDULER_JOB_RUN_DETAILS where log_date > sysdate-1 and job_name like 'KMB%'
order by log_date desc
/

select * from dba_scheduler_running_jobs where job_name like 'KMB%'
/

select * from v$session where username like 'BUFF_FSSP%'

select * from dba_users where username = 'BUFF_FSSP'

select * from dba_profiles where profile = 'BUFF_FSSP_PROFILE'