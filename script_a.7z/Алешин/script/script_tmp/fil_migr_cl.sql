--���������� �������� 

select rowid,a.* from account a where code = '20309A98301110000021'

select * from clients where reference  = 36089 and branch = 138

select * from chg_obj where reference = 457274 and branch = 104016

select * from eid.eid_account where code = '42301810801110012032'

--insert into tmp_tables.client_48_2020(BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN ) 
select BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN from clients@nsibirsk cl where type_doc in (4,5) and reference > 0 and status = 310
and exists (select null from account@nsibirsk where client = cl.reference and branch_client = cl.branch) 
minus
select BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN from clients 

--� ����� tmp_tables
create table client_48_2020
as select BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN  from mbank.clients where rownum < 1000

truncate table client_48_2020

grant insert,update,delete,select on client_48_2020 to mbank;



select BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN from tmp_tables.client_104_2020
minus
select BRANCH,REFERENCE,TYPE_DOC,DOC_NUMBER,DATE_OPEN from clients
/

select * from clients@ekburg where reference = 420849 and branch = 192 
union all
select * from clients where reference = 420849 and branch = 192

select * from variable_clients@ekburg where reference = 64278 and branch = 104 
minus
select * from variable_clients where reference = 64278 and branch = 104


select * from types where type_id = 861 


select * from tmp_tables.client_104_2020_not tt where branch > 0
and exists (select null from account where client = tt.REFERENCE and branch_client = tt.branch)  
and reference = 64278

/

select * from tmp_tables.client_48_2020
/

select * from account@ekburg where client = 311130 and branch_client = 660001 
/

declare
  cnt number := 0;
  cnt_v number := 0; 
  own_id number := 1403;
  subdep number := 191;
  sub_def number := 191588;
  fil number := mbfilid@nsibirsk;
    --������ ���������
  function get_fil(subdfrom number) return number
  is
  res number;
  begin
    for tt in (SELECT MIN(id) fil FROM eid.eid_subdepartments WHERE TYPE = 400 AND parent = 0
               START WITH id = subdfrom CONNECT BY id = PRIOR parent)
    loop
      res := tt.fil;
    end loop;       
    return res;     
  end;
  
    --��������� ��������
  function mirg_subdep(subdfrom number) return number
  is
  fil number;
  res number; 
  begin
    fil := get_fil(subdfrom);
    for tt in (select * from zyx_store z where OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = fil and num2 = subdfrom)
    loop
      res := tt.num4;
    end loop;
    for tt in (select * from zyx_store z where OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = fil and num2 = 0 and res is null) --��������� �� �������
    loop
      res := tt.num4;
    end loop; 
    return res;
  end;
  
  function new_user_id(us_id varchar2, sub_id varchar2) return number is
  v_us number;
  v_us_sub number;
  v_sub number;
  v_user number:=-1;
begin 
  v_user:=-1;
  --�������� ������� ������, ��� ��� ��������
  begin
    v_us:=to_number(nvl(trim(us_id),'zzz'));       
    select br_to into v_us_sub from --����� ������������� ������������
                                   (select nvl(z.num2,s.id) br_from, nvl(z.num4,sub_def) br_to
                                      from subdepartments@nsibirsk s
                                        left join zyx_store z on (OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and s.id=z.num2)
                                      where s.parent=fil
                                    union all
                                    select fil,sub_def from dual
                                   ) sub
                               where sub.br_from in (select subdepartment from users@nsibirsk where user_id=v_us);  
    v_sub:=to_number(coalesce(trim(sub_id),v_us_sub,sub_def));                                   
  exception
    when OTHERS then v_sub:=to_number(coalesce(trim(sub_id),sub_def)); 
  end;   
  --dbms_output.put_line('v_sub='||v_sub);
  for a in (select um.user_id as us_id_main ,um.subdepartment as us_sub_main,um.params as us_tab_main,
                   us.user_id as us_id_spb,us.subdepartment as us_sub_spb,us.params as us_tab_spb
              from (select nvl(z.num1,s.parent) fil_from, nvl(z.num2,s.id) br_from, nvl(z.num3,mbfilid) fil_to, nvl(z.num4,sub_def) br_to
                             from subdepartments@nsibirsk s
                               left join zyx_store z on (OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and s.id=z.num2)
                             where s.parent=fil 
                    union all
                    select fil,fil,mbfilid,sub_def from dual                              
                   ) sub_mig,
              users_all ua 
              left join users um on (um.params=ua.tab_n and um.job<>'30809')  
              left join users@nsibirsk us on (us.user_id=ua.user_id and us.params=ua.tab_n)                 
            where (ua.subdepartment=sub_mig.br_from /*or ua.subdepartment=sub_mig.br_to*/) and ua.tab_n not in ('-9999','0000')
                   and (us.subdepartment=sub_mig.br_from or um.subdepartment=sub_mig.br_to)
                   and us.user_id=v_us
                   and exists(select null from boss_emp_all b where b.tab_n=us.params and d_out>trunc(sysdate))
                   and um.subdepartment=v_sub--!!! ������� ��� ���������� ������ � ����� �������� ����������
            group by um.user_id,um.subdepartment,um.params,us.user_id,us.subdepartment,us.params  
           )
  loop 
    v_user:=nvl(a.us_id_main,-1);  
    --dbms_output.put_line(us_id||' - '||v_us||' - '||a.us_id_main||' - '||v_user);      
  end loop;  
  if v_user=-1 then v_user:=nvl(global_parameters.get_param('���_�����_��',v_sub),-1); end if;             
  return v_user;      
end;

  
begin
  for rr in (
              select * from tmp_tables.client_48_2020 tt where branch > 0
               and exists (select null from account where client = tt.REFERENCE and branch_client = tt.branch)
               --and reference = 12500
             )
  loop     
     merge into clients cl       
     using (select * from clients@nsibirsk where branch = rr.branch and reference = rr.reference) t 
      on (cl.reference = t.reference and cl.branch = t.branch)
     when matched then update set 
REFER_FROM = t.REFER_FROM 
,RELATED= t.RELATED
,FOLDER= t.FOLDER
,TYPE_DOC= t.TYPE_DOC
,SUB_TYPE= t.SUB_TYPE
,STATUS= t.STATUS
,CODE= t.CODE
,SHORT_NAME= t.SHORT_NAME
,FULL_NAME= t.FULL_NAME
,L_NAME= t.L_NAME
,FULL_L_NAME= t.FULL_L_NAME
,DOC_SERIA= t.DOC_SERIA
,DOC_NUMBER= t.DOC_NUMBER
,REG_ATTR= t.REG_ATTR
,DATE_REG= t.DATE_REG
,DATE_OPEN= t.DATE_OPEN
,INN= t.INN
,COUNTRY= t.COUNTRY
,REGION= t.REGION
,POSTING= t.POSTING
,ADRES= t.ADRES
,PHONE= t.PHONE
,FAX= t.FAX
,DATE_CREATE= t.DATE_CREATE
,DATE_END= t.DATE_END
,DATE_MODIFY= t.DATE_MODIFY
,OWNER= t.OWNER
,DATE_WORK= t.DATE_WORK
,CHILD= t.CHILD
,BRANCH_RELATED= t.BRANCH_RELATED
,BRANCH_FROM= t.BRANCH_FROM
,SUBDEPARTMENT= t.SUBDEPARTMENT
,ADDRESS_REAL= t.ADDRESS_REAL
      when not matched then insert(BRANCH,REFERENCE,REFER_FROM,RELATED,FOLDER,TYPE_DOC,SUB_TYPE,STATUS,CODE,SHORT_NAME,FULL_NAME,L_NAME,FULL_L_NAME,DOC_SERIA,DOC_NUMBER,REG_ATTR,DATE_REG,DATE_OPEN,INN,COUNTRY,REGION,POSTING,ADRES,PHONE,FAX,DATE_CREATE,DATE_END,DATE_MODIFY,OWNER,DATE_WORK,CHILD,BRANCH_RELATED,BRANCH_FROM,SUBDEPARTMENT,ADDRESS_REAL) 
        values (t.BRANCH,t.REFERENCE,t.REFER_FROM,t.RELATED,t.FOLDER,t.TYPE_DOC,t.SUB_TYPE,t.STATUS,t.CODE,t.SHORT_NAME,t.FULL_NAME,t.L_NAME,t.FULL_L_NAME,t.DOC_SERIA,t.DOC_NUMBER,t.REG_ATTR,t.DATE_REG,t.DATE_OPEN,t.INN,t.COUNTRY,t.REGION,t.POSTING,t.ADRES,t.PHONE,t.FAX,t.DATE_CREATE,t.DATE_END,t.DATE_MODIFY,t.OWNER,t.DATE_WORK,t.CHILD,t.BRANCH_RELATED,t.BRANCH_FROM,t.SUBDEPARTMENT,t.ADDRESS_REAL);      
cnt := cnt + sql%rowcount;
begin
     merge into variable_clients cl       
     using (select * from variable_clients@nsibirsk where branch = rr.branch and reference = rr.reference) t 
      on (cl.reference = t.reference and cl.branch = t.branch and cl.name = t.name and cl.SUBNUMBER = t.SUBNUMBER and cl.ROWNUMBER = t.ROWNUMBER and cl.COLNUMBER = t.COLNUMBER and nvl(cl.SUBFIELD,'#13') = nvl(t.SUBFIELD,'#13'))
     when matched then update set 
value = t.value 
      when not matched then insert(name,BRANCH,REFERENCE,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD) 
        values (t.name,t.BRANCH,t.REFERENCE,t.SUBNUMBER,t.ROWNUMBER,t.COLNUMBER,t.VALUE,t.SUBFIELD);        
cnt_v := cnt_v + sql%rowcount;
exception when OTHERS then
  dbms_output.put_line('ref = '||rr.reference||' br = '||rr.branch||' err = '||sqlerrm);   
end;
for t in (select * from clients@nsibirsk where reference = rr.reference and branch = rr.branch)
loop
  SUBDEP := mirg_subdep(t.SUBDEPARTMENT);
  own_id := new_user_id(t.owner,SUBDEP);
  update clients set SUBDEPARTMENT = nvl(SUBDEP,SUBDEPARTMENT), owner = nvl(own_id,owner) where reference = t.reference and branch = t.branch;
end loop;  
--update clients set SUBDEPARTMENT = nvl(SUBDEP,SUBDEPARTMENT), owner = nvl(own_id,owner) where reference = rr.reference and branch = rr.branch; 
    commit;                   
  end loop;
      dbms_output.put_line('cnt = '||cnt||' cnt_v = '||cnt_v);             
end;
/

select * from variable_clients 

SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD


--BRANCH,REFERENCE,REFER_FROM,RELATED,FOLDER,TYPE_DOC,SUB_TYPE,STATUS,CODE,SHORT_NAME,FULL_NAME,L_NAME,FULL_L_NAME,DOC_SERIA,DOC_NUMBER,REG_ATTR,DATE_REG,DATE_OPEN,INN,COUNTRY,REGION,POSTING,ADRES,PHONE,FAX,DATE_CREATE,DATE_END,DATE_MODIFY,OWNER,DATE_WORK,CHILD,BRANCH_RELATED,BRANCH_FROM,SUBDEPARTMENT,ADDRESS_REAL

/


begin
  for rr in (
              select * from tmp_tables.client_48_2020 tt where branch > 0
               and exists (select null from account where client = tt.REFERENCE and branch_client = tt.branch)
              -- and reference = 64278
             )
  loop   
    for aa in (select * from account where client = rr.reference and branch_client = rr.branch)
    loop
      INSERT INTO CHG_OBJ (tbl, REFERENCE, BRANCH, DATE_MODIFY, SUBD_MODIFY, OWNER_MODIFY, STATUS, PRIORITY)
         VALUES ('ACCOUNT', aa.REFERENCE, aa.BRANCH, sysdate, aa.subdepartment, aa.owner, 0, 1);
    end loop;  

    for cc in (select * from contracts where refer_client = rr.reference and branch_client = rr.branch)
    loop
         INSERT INTO CHG_OBJ(tbl, REFERENCE, BRANCH, DATE_MODIFY, SUBD_MODIFY, OWNER_MODIFY, STATUS, OWNER_ID_MODIFY, Priority)
         VALUES (decode(cc.Type_Client,0,'CONTRACTS',5,'CONTRACTS','CONTRACTS_UR'),cc.REFERENCE, cc.BRANCH, sysdate, cc.subdepartment, universe.nameowner(cc.owner), 0, cc.owner, 1);
    end loop;  
    
  end loop;
end;
/

select * from chg_obj where 1=1
--and reference = 513438 and branch = 104031  
and date_modify > sysdate-1/24/2
and tbl in ('ACCOUNT','CONTRACTS','CONTRACTS_UR')
/

select * from contracts where reference = 573263


select tbl,priority,count(*) from chg_obj 
group by tbl,priority