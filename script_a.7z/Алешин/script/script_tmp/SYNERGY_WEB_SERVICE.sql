SYNERGY_WEB_SERVICE


SYNERGY_CAPS_SPEKTRUM
/



select rowid,d.* from variable_documents d where (reference,branch) in --((5102797372,544426))
(select DOCNKO_reference,DOCNKO_BRANCH from tmp_tables.ar13_20200827)
and value = '631'

 select t.* from synergy_transactions t where docnko_reference = 5072203382

(select * from
    (select universe.variable_part(d.reference, d.branch, 'SPEKTRUM_RECEIVERS_ABS') ABS, d.* from documents d
        where type_doc=13359
        and status=30
        and receivers_bik not in (select BIK from eid.v_filial_all where id in  (200)) --775,360,665,270,635,540,245,240,  044030704
        order by date_create desc)
    where abs = 'MBANK'
 )  
 /
 
 grant execute synergy_web_service_temp to st_mbank
 /
 
 select t.* from synergy_transactions t where (DOCNKO_reference,DOCNKO_BRANCH) in
(select DOCNKO_reference,DOCNKO_BRANCH from tmp_tables.ar13_20200827 where st = 2 )
 
 
 select * from documents where (reference,branch) in (select DOCNKO_reference,DOCNKO_BRANCH from tmp_tables.ar13_20200827 where DOCNKO_reference = 5086924391)
 --and RECEIVERS_BIK not in ('044030704')
 --and reference = 5071984818
 /
 
 
 (select * from
    (select universe.variable_part(d.reference, d.branch, 'SPEKTRUM_RECEIVERS_ABS') ABS, d.* from documents d
        where type_doc=13359
        and status=30
        and receivers_bik in (select BIK from eid.v_filial_all where id in
        (631,660,235,780,544,365)  
        --(775,360,665,270,635,540,245,240,200,208)
        ) --  044030704
        order by date_create desc)
    where abs = 'BISQUIT'
 )  
 /
 
 declare  
   r_cnt number;
 begin
   for dd in (
            select * from documents d where (reference,branch) in (select DOCNKO_reference,DOCNKO_BRANCH from tmp_tables.ar13_20200827 
             where st = 2    )            
             --and reference not in (5071984818)
            --and receivers_bik = '044030704'
             --and reference =  5072077578
             )           
   loop           
     select count(*) into r_cnt from eid.v_filial_all where bik = dd.receivers_bik and id in (235,544,780,365,660,631,200,208);
     if r_cnt > 0 then      
       universe.INPUT_VAR_DOC(dd.branch,dd.reference,'SPEKTRUM_RECEIVERS_ABS','MBANK');
       universe.INPUT_VAR_DOC(dd.branch,dd.reference,'SPEKTRUM_OPERATION','0094.MB');
       universe.INPUT_VAR_DOC(dd.branch,dd.reference,'SPEKTRUM_RECEIVERS_CODE','191');
       for aa in (select * from account where header = 'A' and code like substr(dd.RECEIVERS_ACCOUNT,1,8)||'_'||substr(dd.RECEIVERS_ACCOUNT,10) and close_date is null)
       loop 
         update documents set RECEIVERS_ACCOUNT = aa.code, REAL_RECEIVERS = aa.code
           ,RECEIVERS_BIK = '044525411', RECEIVERS_CORACC = '30101810145250000411', RECEIVERS_BANK = '������ "�����������" ����� ��� (���)'
         where branch = dd.branch and reference = dd.reference;
         update variable_documents set value = aa.code where branch = dd.branch and reference = dd.reference and value = dd.receivers_account;
         update variable_documents set value = '044525411' where branch = dd.branch and reference = dd.reference and value = dd.RECEIVERS_BIK;
       end loop;          
     end if;  
     select count(*) into r_cnt from eid.v_filial_all where bik = dd.receivers_bik and fil_abs = 2;
     if r_cnt > 0 then
       universe.INPUT_VAR_DOC(dd.branch,dd.reference,'SPEKTRUM_RECEIVERS_ABS','CABS');
       universe.INPUT_VAR_DOC(dd.branch,dd.reference,'SPEKTRUM_OPERATION','0094.MB');
     end if;     
     update tmp_tables.ar13_20200827 set st = 0 where DOCNKO_reference = dd.reference and DOCNKO_BRANCH = dd.BRANCH;
     update synergy_transactions set DOCNKO_reference = -DOCNKO_reference where  DOCNKO_reference = dd.reference and DOCNKO_BRANCH = dd.BRANCH and vtb_tran_id like 'SP%';
     update documents set status = 23 where reference = dd.reference and BRANCH = dd.BRANCH and status = 30;
     for cc in (select universe.VARIABLE_CLIENT(branch_client,refer_client,'TAXCODE') val from contracts 
            where reference = UNIVERSE.VARIABLE_DOC(dd.branch,dd.reference, 'CONTRACTS.REFERENCE')
              and branch = uNIVERSE.VARIABLE_DOC(dd.branch,dd.reference, 'CONTRACTS.BRANCH')
              and universe.VARIABLE_CLIENT(branch_client,refer_client,'TAXCODE') is not null
          )
      loop  
       -- dbms_output.put_line(cc.val);  
        universe.INPUT_VAR_DOC(dd.branch,dd.reference,'CLIENT_KPP',cc.val);
      end loop; 
      dbms_output.put_line('dd >'||dd.reference); 
   end loop;   
end;
 
 
select * from tmp_tables.ar13_20200827 where 
DOCNKO_reference = 5072101323
--st = 0
/


select  t.* from synergy_transactions t where (DOCNKO_reference,DOCNKO_BRANCH) in
 (select DOCNKO_reference,DOCNKO_BRANCH from tmp_tables.ar13_20200827) 
 /
 
 select * from contracts where reference = 5075214174
 
 select rowid,t.* from documents t where refer_from = 5075214174
 /
 
 
  
 (select * from
    (select universe.variable_part(d.reference, d.branch, 'SPEKTRUM_RECEIVERS_ABS') ABS, d.* from documents d
        where type_doc=13359
        and status=30 
        and doc_number = '6959'
        --and receivers_bik in (select BIK from eid.v_filial_all where id in  (775,360,665,270,635,540,245,240,200,208)) --  044030704
        order by date_create desc)
   -- where abs = 'BISQUIT'
 )  
 
 /
 
 
 --�������� ������
 --insert into tmp_tables.ar13_20200827
select VTB_TRAN_ID,	VTB_TRAN_DATE,	DOCNKO_REFERENCE,	DOCNKO_BRANCH, 	null ST, null MEMO from mbank.synergy_transactions where (DOCNKO_reference,DOCNKO_BRANCH) in
 (select reference,branch from
    (select mbank.universe.variable_part(d.reference, d.branch, 'SPEKTRUM_RECEIVERS_ABS') ABS, d.* from mbank.documents d
        where type_doc=13359
        and status=30
        and receivers_bik in (select BIK from eid.v_filial_all where id in
        (631,660,235,780,544,365)  
        --(775,360,665,270,635,540,245,240,200,208)
        ) --  044030704
        order by date_create desc)
    where abs = 'BISQUIT'
    )