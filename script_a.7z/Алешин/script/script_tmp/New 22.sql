--�������� ������ �����
select rowid,z.* from zyx_cont_cb z

select z.a,b,c,d,s.id,name,deleted,boss_subdep_id from zyx_cont_cb z, eid.eid_subdepartments s where z.a = s.id(+)
/

declare
  b_id varchar2(100);
begin
  for tt in (select z.rowid,z.a,b,c,d,s.id,name,deleted,boss_subdep_id from zyx_cont_cb z, eid.eid_subdepartments s where z.a = s.id(+)) 
  loop
    if nvl(tt.boss_subdep_id,-1) > -1 then
      b_id := tt.boss_subdep_id;
    else
      for rr in (select * from boss_subdepartments where ref_code = tt.d)
      loop
        b_id := rr.id;
      end loop; 
    end if;
    if b_id is not null then
      update zyx_cont_cb set b = b_id where rowid = tt.rowid;
    end if;     
  end loop;
end;
/

select (select ref_code from boss_subdepartments where id = z.b and ref_code <> z.D) ref_id,
z.*  from zyx_cont_cb z where d = '763000'

--update zyx_cont_cb z set f = (select name from eid.eid_subdepartments s where z.a = id)  



select rowid,vs.* from variable_subdepartments vs where depart_id in
(191197)
--(select z.a  from zyx_cont_cb z where d = '768000')
and name = 'BOSS_ID'   
/


     merge into variable_subdepartments v
     using (
            select 166478 boss_id, s.* from subdepartments s where --name like '%������%' and parent = 191
            id in (354, 104, 47, 76, 192, 48, 49)
            ) t
             on (depart_id = t.id and v.name = 'BOSS_ID')
     when matched then update set value = t.boss_id    
     when not matched then insert (NAME,DEPART_ID,VALUE) values ('BOSS_ID',t.id,t.boss_id);  



select * from chg_obj where 1=1 
--branch = 100000
and tbl = 'SUBDEPARTMENTS' 
and date_modify > sysdate-1/24 
/

select * from eid.eid_subdepartments
--update eid.eid_subdepartments e set boss_subdep_id = 166478 --(select z.b from zyx_cont_cb z where z.a = e.id)
where id in (354, 104, 47, 76, 192, 48, 49) --(select z.a from zyx_cont_cb z )
 --(select id from subdepartments s where name like '%������%' and parent = 191)
and nvl(boss_subdep_id,-1) = -1
/

update variable_subdepartments vs set value = (select BOSS_SUBDEP_ID from eid.eid_subdepartments where id = vs.depart_id)  
where  depart_id in (191531, 191536, 191511, 191549) and name = 'BOSS_ID'  
/

select 
(select count(*) from account where subdepartment = s.id) acc_cnt
,(select count(*) from account where subdepartment = s.id and close_date is null) acc_cnt_50
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 4) con_ur_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 4) cl_ur_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 5) con_fl_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 5) cl_fl_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50) con_50_cnt
,(select count(*)||'/'||sum((select count(*) from all_users where username = u.user_)) from users u where subdepartment = s.id) usr_cnt
,s.* from subdepartments s 
where id in 
(191197)
--(select num4 br_to from zyx_store z where  OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS'  and num1 in (47))
--(select num4 from zyx_store z where tbl = 'SUBDEPARTMENTS' and oper = 'FIL_191' and num1 = 192)
--and id not in (48119,48153,48170,48177,48179,544663) 
start with id = mbfilid connect by prior id = parent

/

select 
COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) "�������",  
a.* from account a where subdepartment in (191197)
 and close_date is null
and header not in ('p','a')
/

select rowid,t.* from account t where subdepartment = 405
--and close_date is null 
--code like '47804810700005471501'

select * from journal where code = '77777756100330000437'

select * from ledger where code = '77777756100330000437' order by work_date desc

select * from account a
--update account a set close_date = trunc(sysdate)
where close_date is null and subdepartment = 191197 
and COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
                  (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) = 0
and header not in ('p','a') 
 and bal in ('55555','77777','70601','47408','47407')
-- and not exists (select null from contracts where reference = a.CONTRACT and branch = a.branch_contract and type_doc not in (5436))   

/

select * from plan_account where bal in ('55555','44444','77777')
/
select distinct d from zyx_cont_cb z
where d not in (select to_char(id) from eid.v_subdep_all s)

select * from eid.v_subdep_all z
where to_char(id) in (select d from zyx_cont_cb s)


select c.* from contracts c where --type_doc = 935 and status = 50
reference = 7161881
                  and exists (select null from account where code = c.assist and nvl(close_date,sysdate) < '01jun2019')
                  and COALESCE((select wrest from ledger l WHERE header = 'A' and code = c.account and currency = c.currency and rest_id = 0 and work_date =
                  (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) = 0


select * from contracts c
--update  contracts c set status = 60, date_close = trunc(sysdate)
where subdepartment = 191197 and status = 50
and not exists (select null from account where contract = c.reference and branch_contract = c.branch and close_date is null and code <> c.account)
and COALESCE((select wrest from ledger l, account a WHERE l.header = a.header and l.code = a.code and l.currency = a.currency and l.rest_id = 0 
                   and l.work_date =(select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)
                   and a.contract = c.reference and a.branch_contract = c.branch and a.code = c.account
                   ),0) = 0
                  


select a.* from account a
--update account a set close_date = trunc(sysdate) 
where close_date is null and subdepartment = 191197
and exists (select null from contracts where reference = a.contract and branch = a.branch_contract and status = 60)
and not exists (select null from account where contract = a.contract and branch_contract = a.branch_contract and close_date is null and code <> a.code)
and COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
                  (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) = 0

