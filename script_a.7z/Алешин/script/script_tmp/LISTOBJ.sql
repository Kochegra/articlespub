begin
  --puser.init(978042);
 -- puser.init(994351);  
 -- puser.init(192012711);
 --globals.TypesList := globals.EmptyList;  
 --globals.INIT_USER_EXT('GRUZ');
 --globals.INIT_USER_EXT('VINOGRADOVA_NV'); 
 globals.INIT_USER_EXT('BYKOVA_EV');
 --globals.INIT_USER_EXT('SHAMARINAMA');
  --globals.INIT_USER_EXT('ADMIN_235444');
 --BYKOVA_EV
  --dbms_output.put_line('chkParam - '||puser.chk_param('������_�������','1'));
   dbms_output.put_line('Globals.UserID - '||Globals.UserID);
  dbms_output.put_line('admin.CurrentUserId - '||  admin.CurrentUserId);
end;
/

--insert into config@DSS select c.* from config c where name like 'USER_H%'
select rowid,c.* from config c where name like 'USER_%'

--insert into config
select * from (select 'USER_INIT_VER' name, '1' val, '������ ��������� ������������� ������������' mem�, null flag from dual) t
where not exists (select null from config where name = t.name)
/
--insert into config
select * from (select 'USER_INIT_SCHEMA' name, 'MBANK' val, '������� ����� � ��' mem�, null flag from dual) t
where not exists (select null from config where name = t.name)
/

grant execute on PUSER to ST_MBANK; 
grant execute on PUSER to ST_ADM_MBANK;
grant execute on PSUBDEPARTMENT to ST_ADM_MBANK; 
grant execute on PSUBDEPARTMENT to ST_MBANK;
grant execute on PSUBDEPARTMENT to MBANK_ADMIN;
grant execute on PUSER to MBANK_ADMIN;
grant execute on MBSYSDATE to MBANK_ADMIN;
grant execute on MBFILID to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on users to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on user_param_values to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on group_membership to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on groups_rights to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on groups to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on boss_emp_all to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on jobs to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on users_jobs to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on types to MBANK_ADMIN;
grant SELECT,INSERT,UPDATE,DELETE on variable_types to MBANK_ADMIN;

/

 SELECT TYPE_ID FROM CLIENT_TYPES;
 SELECT FOLDER_ID FROM CLIENT_FOLDERS WHERE TYPE = 0 AND CHAPTER IS NULL;
/

select CHECK_CLIENT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER),
CHECK_CLIENT.CHECK_OBJ(4, 310, 2) 
,t1.* from CLIENTS T1 where reference = 102845364
/

SELECT object_id
                        FROM jobs_rights
                       WHERE     code = 6
                             AND job_id IN
                                     (SELECT job
                                        FROM users
                                       WHERE user_id = admin.CurrentUserId)
/

select * from types where PUSER.GET_RIGHT_TYPE(type_id) < 0
and code = 6 
/
                                       
/* Formatted on 22.05.2020 14:43:18 (QP5 v5.300) */
  SELECT /*+ INDEX (T1, CLIENT_NAME_INDEX)*/
        T1.ROWID,T1.*,
         get_obj_info (T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER,'')
             AS INFO_OBJ, 255 AS ACCESS_OBJ
    FROM CLIENTS T1
   WHERE     T1.CHILD < 1 AND T1.STATUS < 1000
         AND T1.Full_L_Name LIKE '%DFSDF%'
         AND (   T1.TYPE_DOC <> 5 OR (    T1.TYPE_DOC = 5
                 AND EXISTS (SELECT NULL FROM DUAL WHERE GLOBALS.check_subuser (T1.OWNER) = 1)))
         AND EXISTS (SELECT NULL FROM DUAL WHERE CHECK_CLIENT.CHECK_OBJ (T1.TYPE_DOC,T1.STATUS,T1.FOLDER) = 1)
         AND ROWNUM <= 4000
ORDER BY T1.FULL_NAME
/


SELECT  T1.RowId, T1.*, cl.INN,  (select FULL_NAME from clients c where c.reference = T1.refer_client and c.branch = T1.branch_client) NAME_CLIENT
,  (select name from types t where t.type_id = T1.TYPE_DOC) as NAME_DOC  , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ
,  255 as ACCESS_OBJ FROM CONTRACTS T1  left join clients cl on cl.reference = T1.refer_client and cl.branch = T1.branch_client 
WHERE  T1.CHILD < 1  AND T1.STATUS < 1000  AND T1.SUBDEPARTMENT IN (235306,191589,192,192031,235588) 
AND CHECK_CONTRACT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1) AND ROWNUM <= 100
/

--������ ���������
SELECT * FROM CONTRACTS T1 WHERE T1.CHILD < 1  AND T1.STATUS < 1000 
AND CHECK_CONTRACT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1
AND GLOBALS.CHECK_SUBUSER(T1.OWNER) = 1
AND SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
/

--������ ���������
SELECT --puser.get_right_contract(t1.reference,t1.branch) con,
--puser.get_right_client(t2.reference,t2.branch) cl, 
T1.*,T2.*
  FROM CONTRACTS T1, CLIENTS T2 WHERE T1.CHILD < 1  AND T1.STATUS < 1000 
AND CHECK_CONTRACT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1
AND GLOBALS.CHECK_SUBUSER(T1.OWNER) = 1
AND T1.SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
and T1.REFER_CLIENT = T2.REFERENCE and T1.BRANCH_CLIENT = T2.BRANCH
and T2.REFERENCE = T2.REFERENCE and T2.BRANCH = T2.BRANCH
and t1.status = 50
and rownum < 100000
and t1.doc_number = '0000/20/01-001052'
/

--������ ���������
SELECT puser.get_right_contract(t1.reference,t1.branch) con,
--puser.get_right_client(t2.reference,t2.branch) cl,
 T1.*, T2.* FROM CONTRACTS T1, CLIENTS T2 WHERE T1.CHILD < 1  AND T1.STATUS < 1000 
AND puser.get_right_contract(t1.reference,t1.branch) < 0
AND exists (select null from dual where GLOBALS.check_subuser(T1.OWNER) = 1)
AND T1.SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
and T1.REFER_CLIENT = T2.REFERENCE and T1.BRANCH_CLIENT = T2.BRANCH
and T2.REFERENCE = T2.REFERENCE and T2.BRANCH = T2.BRANCH
and rownum < 10000
--and t1.folder = 1 
and t1.status = 50 
--and t1.doc_number = '0000/20/01-001052'
/

--������ ��������
SELECT /*+ INDEX (T1, CLIENT_NAME_INDEX)*/
puser.get_right_client(t1.reference,t1.branch) rights,
T1.RowId, T1.* , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ, 255 as ACCESS_OBJ 
FROM CLIENTS T1 WHERE  1=1
and T1.CHILD < 1  AND T1.STATUS < 1000  
AND puser.get_right_client(t1.reference,t1.branch) < 0
 --and inn = '3015091447'
-- AND T1.Full_L_Name LIKE '%DFSDF%'
AND ROWNUM <= 1000 ORDER BY T1.FULL_L_NAME
/


select puser.get_right_client(100006855,191) from dual
/

                 SELECT * FROM CONTRACTS T1 
                 WHERE T1.CHILD < 1 and t1.status in (50,70)
                   AND puser.get_right_contract(t1.reference,t1.branch) < 0
                   and T1.REFER_CLIENT = 100006855 and T1.BRANCH_CLIENT = 191
/


SELECT puser.get_right_contract(t1.reference,t1.branch), t1.* FROM CONTRACTS T1 WHERE T1.CHILD < 1  AND T1.STATUS < 1000
and PUSER.GET_RIGHT_CONTRACT(T1.REFERENCE,T1.BRANCH) < 0

select * from FOLDERS where PUSER.GET_RIGHT_TYPE(FOLDER_ID) < 0
/

select * from TYPES where PUSER.GET_RIGHT_TYPE(TYPE_ID) < 0
/

select * from SUBDEPARTMENTS where GLOBALS.check_subdepartments(id) = 1
/

select * from Users where PUSER.GET_RIGHT_USER(user_ID) < 0
/

select * from FOLDERS where PUSER.GET_RIGHT_TYPE(978042,FOLDER_ID,CODE) < 0
/

--������ ��������
SELECT * FROM CONTRACTS T1, CLIENTS T2 WHERE T1.CHILD < 1  AND T1.STATUS < 1000 
AND CHECK_CONTRACT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1
AND GLOBALS.CHECK_SUBUSER(T1.OWNER) = 1
AND T1.SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
and T1.REFER_CLIENT = T2.REFERENCE and T1.BRANCH_CLIENT = T2.BRANCH
and T2.REFERENCE = T2.REFERENCE and T2.BRANCH = T2.BRANCH
/


SELECT T1.RowId, T1.* , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ, 255 as ACCESS_OBJ FROM CLIENTS T1
 WHERE  T1.CHILD < 1  AND T1.STATUS < 1000  and T1.type_doc in (4)  
 AND exists (select null from dual where GLOBALS.check_subuser(T1.OWNER) = 1)  
AND T1.SUBDEPARTMENT IN (544644) 
AND exists (select null from dual where CHECK_CLIENT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1) 
AND ROWNUM <= 100 ORDER BY T1.FULL_NAME

SELECT T1.RowId, T1.* , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ, 255 as ACCESS_OBJ FROM CLIENTS T1
 WHERE  T1.CHILD < 1  AND T1.STATUS < 1000  and T1.type_doc in (4) 
  AND T1.SUBDEPARTMENT IN (544644,191588,48) --���� �������� ������_��������� 
  AND exists (select null from dual where CHECK_CLIENT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1)
  AND ROWNUM <= 100 ORDER BY T1.FULL_NAME
/

SELECT --T1.RowId, T1.* , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ, 255 as ACCESS_OBJ 
* FROM CLIENTS T1
 WHERE  T1.CHILD < 1  AND T1.STATUS < 1000  and T1.type_doc in (4)  
 --AND (select null from dual where GLOBALS.check_subuser(T1.OWNER) = 1)
 --and puser.get_right_user(T1.OWNER) < 0 
-- and puser.get_right_subdep(T1.SUBDEPARTMENT) < 0 
--AND GLOBALS.check_subdepartments(T1.SUBDEPARTMENT) = 1
AND CHECK_CLIENT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1 
--AND ROWNUM <= 100 
ORDER BY T1.FULL_NAME



select * from contracts where 


begin
  --puser.init(240418960);
   puser.init(978042);
  --GLOBALS.INIT_USER_EXT('BAKUSHEVA_SO');
end;

select puser.get_right_user(user_id), u.* from users u where 1=1
and GLOBALS.check_subuser(user_id) = 1

select puser.get_right_subdep(id), u.* from subdepartments u where 1=1
and GLOBALS.check_subdepartments(id) = 1


SELECT  T1.RowId, T1.*, cl.INN,  (select FULL_NAME from clients c where c.reference = T1.refer_client and c.branch = T1.branch_client) NAME_CLIENT
,  (select name from types t where t.type_id = T1.TYPE_DOC) as NAME_DOC  , get_obj_info(T1.STATUS,T1.FOLDER,T1.SUBDEPARTMENT,T1.OWNER, '') as INFO_OBJ
,  255 as ACCESS_OBJ FROM CONTRACTS T1  left join clients cl on cl.reference = T1.refer_client and cl.branch = T1.branch_client 
WHERE  T1.CHILD < 1  AND T1.STATUS < 1000  
AND GLOBALS.check_subuser(T1.OWNER) = 1
--and puser.get_right_user(T1.OWNER) < 0  
--AND T1.SUBDEPARTMENT IN (544644) 
--AND GLOBALS.check_subdepartments(t1.subdepartment) = 1
AND t1.subdepartment in (select id from subdepartments where GLOBALS.check_subdepartments(id) = 1)
AND exists (select null from dual where CHECK_CONTRACT.CHECK_OBJ(T1.TYPE_DOC, T1.STATUS, T1.FOLDER) = 1)
 AND ROWNUM <= 10000
/

--�����
SELECT T1.ROWID, T1.*, cl.INN, s.NAME as SUBDEP_NAME, u1.user_id as user_open_id, u2.user_id as user_close_id, u1.user_name as user_open
, u2.user_name as user_close, (select P1.TYPE_BAL from plan_account p1 where P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) as TYPEBAL 
, get_obj_info(-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) as INFO_OBJ, 255 as ACCESS_OBJ, '{58BCDB73-F6FB-4AB8-964F-1900AC23B584}' as TMP 
, 0.00 WSALDO, 0.00 RSALDO  FROM ACCOUNT T1  left join clients cl on cl.reference = T1.client and cl.branch = T1.branch_client  
  left join subdepartments s on s.id = T1.subdepartment  
  left join users u1 on u1.user_id = T1.owner  
  left join users u2 on u2.user_id = T1.owner 
  --and T1.close_date is not null  
  WHERE  T1.HEADER IN ('A','C','D','V','Z') and T1.CODE LIKE '4742381_200609081184' and T1.CLOSE_DATE is null 
  AND ( (exists (select null from dual where GLOBALS.check_subuser(T1.OWNER) = 1) 
 -- AND T1.SUBDEPARTMENT IN (235306,191589,192,192031,235588)
  )
   -- and T1.SUBDEPARTMENT in (select obj_id from object_rights_user where user_id = 978042 and obj_type = -3) 
    and T1.SUBDEPARTMENT in (select s.id from subdepartments s, object_rights_user r where r.user_id = 978042 and r.obj_type = -3 and r.obj_id = s.id)
 --  OR exists (SELECT null FROM BALACCOUNT WHERE BAL = t1.bal and OPERATION = 0)
--   OR exists (SELECT null FROM USERACCOUNT WHERE reference = t1.reference and branch = t1.branch and OPERATION = 0)
)
 -- AND not exists (SELECT null FROM BALACCOUNT WHERE BAL = t1.bal and OPERATION = 1)
 -- AND not exists (SELECT null FROM USERACCOUNT WHERE reference = t1.reference and branch = t1.branch and OPERATION = 1)
  AND ROWNUM <= 1000 ORDER BY T1.BAL, T1.LSNUM, T1.CURRENCY
/
--/* +INDEX(T1 ACCOUNT_SUBDEP_IDX)*/
/
--����� ar
SELECT 
 T1.ROWID, T1.*, cl.INN
 , universe.namedepart(t1.subdepartment) as SUBDEP_NAME
-- , u1.user_id as user_open_id, u2.user_id as user_close_id, u1.user_name as user_open, u2.user_name as user_close
, (select P1.TYPE_BAL from plan_account p1 where P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) as TYPEBAL 
, get_obj_info(-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) as INFO_OBJ, 255 as ACCESS_OBJ, '{58BCDB73-F6FB-4AB8-964F-1900AC23B584}' as TMP 
, 0.00 WSALDO, 0.00 RSALDO  FROM ACCOUNT T1  left join clients cl on cl.reference = T1.client and cl.branch = T1.branch_client  
  --left join subdepartments s on s.id = T1.subdepartment  
  --left join users u1 on u1.user_id = T1.owner  
 -- left join users u2 on u2.user_id = T1.owner 
 -- and T1.close_date is not null  
  WHERE  1=1 
  and T1.HEADER IN (select chapter from folders where code = 7)
  and T1.CODE LIKE '40702%' 
  --and t1.currency in (select currency from currency)
  and T1.CLOSE_DATE is null 
  --and GLOBALS.check_subuser(T1.OWNER) = 1
 -- AND T1.SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
  AND puser.Get_Right_Account(T1.CODE,t1.header) < 0
 -- and t1.code in ('40702156700230000002','40702810000440000064')
  AND ROWNUM <= 1000 ORDER BY T1.BAL, T1.LSNUM, T1.CURRENCY

/

ALTER INDEX MBANK.ACCOUNT_SUBDEP_IDX INVISIBLE

ALTER INDEX MBANK.ACCOUNT_NUM_IDX INVISIBLE

ALTER INDEX MBANK.ACCOUNT_BAL_IDX VISIBLE

/

SELECT 
T1.ROWID, T1.*, CL.INN, UNIVERSE.NAMEDEPART(T1.SUBDEPARTMENT) SUBDEP_NAME ,NVL(UNIVERSE.VARIABLE_ACC(T1.BRANCH,T1.REFERENCE,'USEROPEN'),T1.OWNER) 
USER_OPEN_ID ,NVL(UNIVERSE.VARIABLE_ACC(T1.BRANCH,T1.REFERENCE,'USERCLOSE'),T1.OWNER) USER_CLOSE_ID 
,UNIVERSE.NAMEOWNER(NVL(UNIVERSE.VARIABLE_ACC(T1.BRANCH,T1.REFERENCE,'USEROPEN'),T1.OWNER)) USER_OPEN 
,UNIVERSE.NAMEOWNER(NVL(UNIVERSE.VARIABLE_ACC(T1.BRANCH,T1.REFERENCE,'USERCLOSE'),T1.OWNER)) USER_CLOSE 
,(SELECT P1.TYPE_BAL FROM PLAN_ACCOUNT P1 WHERE P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) TYPEBAL 
, get_obj_info(-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) as INFO_OBJ, 255 as ACCESS_OBJ, '{AFD35D5A-2145-405F-970A-076B242D4545}' as TMP 
, PLEDGER.SALDO(T1.HEADER, T1.CODE,T1.CURRENCY, TO_DATE('11.06.2020','DD.MM.YYYY'), 0) WSALDO
, DECODE(T1.CURRENCY,'810',0,PLEDGER.RSALDO(T1.HEADER, T1.CODE,T1.CURRENCY, TO_DATE('11.06.2020','DD.MM.YYYY'), 0)) RSALDO  
FROM ACCOUNT T1  LEFT JOIN CLIENTS CL ON CL.REFERENCE = T1.CLIENT AND CL.BRANCH = T1.BRANCH_CLIENT  
WHERE T1.HEADER IN (SELECT CHAPTER FROM FOLDERS WHERE CODE = 7 AND PUSER.GET_RIGHT_FOLDER(FOLDER_ID) < 0)  
AND PUSER.GET_RIGHT_FOLDER(DECODE(T1.CLOSE_DATE,NULL,110,100)) < 0  AND GLOBALS.CHECK_SUBUSER(T1.OWNER) = 1  
AND (T1.CONTRACT = 0 OR PUSER.GET_RIGHT_CONTRACT(T1.CONTRACT, T1.BRANCH_CONTRACT) < 0)  
AND T1.SUBDEPARTMENT IN (SELECT ID FROM SUBDEPARTMENTS WHERE GLOBALS.CHECK_SUBDEPARTMENTS(ID) = 1)
--AND T1.HEADER = 'A' 
--and T1.CODE LIKE '47423810_00609081184%' 
--and exists (select null from subdepartments s, object_rights_user r where r.user_id = 978042 and r.obj_type = -3 and r.obj_id = s.id and s.id = T1.SUBDEPARTMENT)
--and exists (select null from object_rights_user where user_id = 978042 and obj_type = -3 and obj_id = T1.SUBDEPARTMENT) 
--and T1.SUBDEPARTMENT in (select s.id from subdepartments s, object_rights_user r where r.user_id = 978042 and r.obj_type = -3 and r.obj_id = s.id)
and T1.CLOSE_DATE is null AND ROWNUM <= 100 ORDER BY T1.BAL, T1.LSNUM, T1.CURRENCY
/
/*+ INDEX_FFS (T1 ACCOUNT_PK)*/ /*+ ALL_ROWS PARALLEL_INDEX (T1 ACCOUNT_PK)*/ /*+ INDEX (T1 ACCOUNT_PK)*/
/*+ INDEX_FFS (T1 ACCOUNT_PK)*/ 
/ /*+ PARALLEL_INDEX (T1 ACCOUNT_SUBDEP_IDX, 6)*/
//*+ INDEX (T1 ACCOUNT_BAL_IDX) INDEX (T1 ACCOUNT_PK) */
 /*+ PARALLEL_INDEX (T1 ACCOUNT_PK 12) PARALLEL(T1 6) */ 
 /*+ INDEX (T1 ACCOUNT_CLOSE_IDX)*/ 
/* Formatted on 13.06.2020 7:55:51 (QP5 v5.300) */

 

begin
 globals.INIT_USER_EXT('ALESHIN_RL');
 --globals.INIT_USER_EXT('BYKOVA_EV');
end;
/ /*+ index (t1 ACCOUNT_PK) */

  SELECT /*+ index (t1 ACCOUNT_PK) */
        T1.ROWID, T1.*,  CL.INN,
         UNIVERSE.NAMEDEPART (T1.SUBDEPARTMENT) SUBDEP_NAME,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'), T1.OWNER)      USER_OPEN_ID,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),       T1.OWNER)       USER_CLOSE_ID,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'),                  T1.OWNER))             USER_OPEN,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),                  T1.OWNER))             USER_CLOSE,
         (SELECT P1.TYPE_BAL FROM PLAN_ACCOUNT P1   WHERE P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) TYPEBAL
         , get_obj_info (-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) AS INFO_OBJ, 255  AS ACCESS_OBJ
         ,'{6EF47ACA-FBB3-4506-8F89-86DE05E570F3}' AS TMP,
         PLEDGER.SALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'), 0) WSALDO,
         DECODE (T1.CURRENCY,'810', 0,PLEDGER.RSALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'),0)) RSALDO
    FROM ACCOUNT T1 LEFT JOIN CLIENTS CL ON CL.REFERENCE = T1.CLIENT AND CL.BRANCH = T1.BRANCH_CLIENT            
   WHERE  1=1 
       and T1.HEADER IN (SELECT /*+ index (f FOLDER_UNIQUE) */ CHAPTER FROM FOLDERS f WHERE CODE = 7 AND PUSER.GET_RIGHT_FOLDER (FOLDER_ID) < 0)
       AND PUSER.GET_RIGHT_FOLDER (DECODE (T1.CLOSE_DATE, NULL, 110, 100)) <  0
       AND (T1.CONTRACT = 0 OR PUSER.GET_RIGHT_CONTRACT (T1.CONTRACT, T1.BRANCH_CONTRACT) < 0)
       AND GLOBALS.CHECK_SUBUSER (T1.OWNER) = 1  
       AND GLOBALS.CHECK_SUBDEPARTMENTS (T1.SUBDEPARTMENT) = 1                                  
       --AND T1.CODE LIKE '40817810_00650126993' and SUBSTR(T1.CODE,1,1) like '_'
        --AND T1.CODE LIKE '40%' and SUBSTR(T1.CODE,1,1) like '_'
       --AND T1.CLOSE_DATE IS NULL
      --  AND T1.OPEN_DATE >= sysdate-100
        --AND T1.HEADER = 'A'
        AND T1.CURRENCY = '810'
      --and UPPER(T1.NAME) LIKE '%������%'      
       AND T1.BAL IN (SELECT BAL FROM PLAN_ACCOUNT) AND SUBSTR(T1.BAL,1,1) like '_'    
        and T1.SUBDEPARTMENT in (select obj_id from object_rights_user where user_id = 978042 and obj_type = -3)
       AND ROWNUM <= 6000
ORDER BY T1.BAL, T1.LSNUM, T1.CURRENCY

/

select puser.get_right_user(user_id) from users u where user_id > 2000000000
/
select * from variable_account where reference = 81135 and branch = 50
/

SELECT * FROM USERACCOUNT WHERE reference = t1.reference and branch = t1.branch and OPERATION = 1

select * from BALACCOUNT � USERACCOUNT

select PSUBDEPARTMENT.Get_Group_Name(id,null,3),s.* from subdepartments s  
/

select * from users_rights where code in (8,12)
/

select * from types where code in (8,12)
/

begin
  dbms_output.put_line(PSUBDEPARTMENT.Get_Group_Name(191060,null,3));
end;

/

CREATE GLOBAL TEMPORARY TABLE MBANK.USER_ACCOUNT
(
  branch number not null, 
  reference number not null  
)
/
drop table user_objects_tmp

CREATE GLOBAL TEMPORARY TABLE user_objects_tmp
(
  obj_id       number not null,
  obj_type     number not null,
  obj_group    number not null,
  obj_right    number   
)
ON COMMIT PRESERVE ROWS
NOCACHE;
/

CREATE UNIQUE INDEX user_objects_tmp_pk ON MBANK.user_objects_tmp
(obj_type, obj_id, obj_group);
/

ALTER TABLE MBANK.user_objects_tmp ADD (
  CONSTRAINT user_objects_tmp_pk
  PRIMARY KEY
  (obj_type, obj_id, obj_group)
  USING INDEX user_objects_tmp_pk
  ENABLE VALIDATE);
/

select * from user_objects_tmp
/


begin
 dbms_output.put_line(puser.set_user_object_tmp(978042));
 commit;
end;

select puser.get_right_object(978042,-1,id,-3),s.* from SUBDEPARTMENTS s where 1=1
and GLOBALS.check_subdepartments(s.id) = 1
--and id in (select obj_id from user_objects_tmp where obj_type = -3)

/

alter table groups add ( group_type number, group_ref number);



select puser.get_right_object(978042,-1,g.group_id,-4),g.* from groups g where nvl(group_type,-1) > -1

select * from groups
update groups set group_type = 2
where group_ like '����%'
/


select puser.get_right_object(978042,-1,id,-3)
,puser.get_right_object(978042,-1,g.group_id,-4)
,s.* from SUBDEPARTMENTS s, groups g where 1=1
and GLOBALS.check_subdepartments(s.id) = 1
and nvl(g.group_type,-1) > -1
and puser.get_right_object(g.group_id,-4,s.id,-3) < 0
/


select puser.get_right_object(978042,-1,g.group_id,-4),g.* from groups g where nvl(group_type,-1) > -1
/



/
CREATE OR REPLACE FORCE VIEW MBANK.USER_SUBDEP_GROUPS
(
    subd_id,
    group_id
)
AS
   with rr as (select obj_id subd_id, connect_by_root obj_id group_id from object_rights
                 where nvl(rights,0) > -16 
                 and obj_type = -3
                 and connect_by_root obj_type = -4
                 start with id = admin.CurrentUserId and id_type = -1
                 connect by nocycle prior obj_id = id
                                and prior obj_type = id_type
                                and prior nvl(rights,0) > -16
                                and id_type < -1 --������� ������
                                )
  select id subd_id,-1 group_id from subdepartments where GLOBALS.check_subdepartments(id) = 1
  minus                          
  select  subd_id, -1 group_id  from rr
  union all
  select  subd_id, group_id  from rr    
                             ;
/

grant select on USER_SUBDEP_GROUPS to st_mbank;


select distinct group_id
,(select count(*) from object_rights_user where user_id = admin.CurrentUserId and obj_id = uu.subd_id and obj_type = -3) used
,(select group_ from groups where group_id = uu.group_id) name
  from USER_SUBDEP_GROUPS uu
  order by name


select * from object_rights_user where user_id = 978042
obj_type = -4 and obj_id <> 191 


select group_id parent_id, id obj_id
,(select count(*) from object_rights_user where user_id = admin.CurrentUserId and obj_id = uu.id and obj_type = -3) used
,universe.namedepart(id) name
  from v_USER_SUBDEP_GROUPS uu
  order by name
             
             select rowid,g.* from groups g where group_id = -1
             /
             
             
begin delete from object_rights_user where user_id = 978042 and obj_type = -3; insert into object_rights_user(user_id,obj_type,obj_id) select 978042 as user_id, -3 as obj_type, s.id as obj_id from subdepartments s where s.id in (191188,191048,191217,191205,191208,191196,191221,191242,191243,191244,19,191247,191248,191246,8,15000,191241,191252,191239,191240,191245,191187,191206,191220,191177,191172,25,191202,191251,191237,191198,191258,191203,191199,191218,297,191212,191216,127,191171,191211,191044,191201,191319,191321,191322,191323,245000,270000,191305,191327,191337,191290,191293,191294,191288,191287,191291,191575,315,9,191256,191506,191209,777001,191367,191295,777003,191180,777004,777002,191353,190,191197,780319,180001,191231,293,191501,191296,16,232,191193,191190,191195,180002,180003,180004,180005,180006,180007,180008,180009,180010,191034,191414,191025,191032,191181,191027,191286,191035,191341,191332,191333,191360,191316,191331,191324,191340,191033,191284,191023,191024,191213,191234,191250,191464,191455,191465,180000,180011,191405,191301,191289,27,131,273000,191049,86,84,159,15001,15002,93,151,326,191029,191030,191045,191046,294000,294001,68,134,77,11000,80,331000,331001,331002,31,140,29,191003,191036,191047,70,5000,5001,5002,5003,191022,191167,26,141,3000,39,120,153,44,75,13000,34,132,143,191017,191019,30,106,73,107,42,137,144,160,165,133000,133001,133002,191004,191005,191015,191020,191026,88,129,130,126000,90,169,32,295000,295001,40,142,148000,28,125,172,317,149000,149001,149002,149003,94,41,37,43,145000,145001,145002,145003,33,135,62,162,59000,82,35,190000,190001,190002,191357,191302,191335,191584,191587,191586,191585,235325,191318,191320,152,105,191438,319,360000,665000,540000,775000,635000,240000,360008,191363,191334,191014,191053,191553,191006,191007,191008,191011,191009,191012,191010,191013,18,191054,191055,191056,191057,36,274,85,83,92,191037,191038,22,78,79,61,63,64,65,66,124,69,6,55,74,123,121,191018,103,72,168,87,191050,191051,191052,89,231,128,150,170,171,102,101,14,21,7,1,67,60,81,122,191058); end;
---------------
/
/*+ index (t1 ACCOUNT_PK) */
/

--CREATE OR REPLACE force view V_USER_ACCOUNT as
--explain plan set statement_id = 'ar13' for 
  SELECT /*+ index (t1 ACCOUNT_PK) */
       -- T1.ROWID RID, 
        T1.*,  CL.INN,
         UNIVERSE.NAMEDEPART (T1.SUBDEPARTMENT) SUBDEP_NAME,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'), T1.OWNER)      USER_OPEN_ID,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),       T1.OWNER)       USER_CLOSE_ID,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'),                  T1.OWNER))             USER_OPEN,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),                  T1.OWNER))             USER_CLOSE,
         (SELECT P1.TYPE_BAL FROM PLAN_ACCOUNT P1   WHERE P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) TYPEBAL
         , get_obj_info (-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) AS INFO_OBJ, 255  AS ACCESS_OBJ
         ,'{6EF47ACA-FBB3-4506-8F89-86DE05E570F3}' AS TMP,
         PLEDGER.SALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'), 0) WSALDO,
         DECODE (T1.CURRENCY,'810', 0,PLEDGER.RSALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'),0)) RSALDO
    FROM ACCOUNT T1 LEFT JOIN CLIENTS CL ON CL.REFERENCE = T1.CLIENT AND CL.BRANCH = T1.BRANCH_CLIENT            
   WHERE  1=1 
       and T1.HEADER IN (SELECT /*+ index (f FOLDER_UNIQUE) */ CHAPTER FROM FOLDERS f WHERE CODE = 7 AND PUSER.GET_RIGHT_FOLDER (FOLDER_ID) < 0)
       AND PUSER.GET_RIGHT_FOLDER (DECODE (T1.CLOSE_DATE, NULL, 110, 100)) <  0
       AND (T1.CONTRACT = 0 OR PUSER.GET_RIGHT_CONTRACT (T1.CONTRACT, T1.BRANCH_CONTRACT) < 0)
       AND GLOBALS.CHECK_SUBUSER (T1.OWNER) = 1  
       AND GLOBALS.CHECK_SUBDEPARTMENTS (T1.SUBDEPARTMENT) = 1                                  
       --AND T1.CODE LIKE nvl(ar13.get_param('ACCOUNT_CODE'),T1.CODE)
      AND T1.CODE LIKE nvl('40702810_00230000006',T1.CODE)
       --AND T1.CODE LIKE nvl(:acc,T1.CODE)
       --AND T1.CLOSE_DATE IS NULL
      --  AND T1.OPEN_DATE >= sysdate-100
       --AND T1.HEADER = nvl(ar13.get_param('ACCOUNT_CODE'),T1.HEADER) 
      -- AND T1.BAL IN (SELECT BAL FROM PLAN_ACCOUNT)   
       -- AND T1.CURRENCY = '810'
      --and UPPER(T1.NAME) LIKE '%������%'      
    --   AND T1.BAL IN (SELECT BAL FROM PLAN_ACCOUNT) AND SUBSTR(T1.BAL,1,1) like '_'    
     --  and T1.SUBDEPARTMENT in (select obj_id from object_rights_user where user_id = admin.CurrentUserId and obj_type = -3)
       --AND ROWNUM <= 6000
--ORDER BY T1.BAL, T1.LSNUM, T1.CURRENCY
/
with pp as (select ar13.get_param('ACCOUNT_CODE') code  from dual)

select * from account t1 where T1.CODE like nvl(ar13.get_param('ACCOUNT_CODE',T1.CODE)

select * from table(dbms_xplan.display(table_name => 'PLAN_TABLE',statement_id => 'ar13'))

--explain plan set statement_id = 'ar13' for 
select * from v_user_account --where code like '40817810%'
/

begin
 globals.INIT_USER_EXT('GRUZ');
-- globals.INIT_USER_EXT('BYKOVA_EV');
  AR13.ParamList.delete;
  AR13.ParamList('ACCOUNT_CODE') := '40702810_00230000006';
  --AR13.ParamList('ACCOUNT_HEADER') := 'A';
 -- AR13.ParamList('ACCOUNT_CLOSE') := '01.01.2020';
 -- AR13.ParamList('ACCOUNT_OPEN') := '407%';
end;  

select ar13.get_param('ACCOUNT_CODE') ,ar13.chk_param('ACCOUNT_CODE') , ar13.chk_param('ACCOUNT_CODE','ff')
 from dual
  
--explain plan set statement_id = 'ar13' for  
with acc as (
   SELECT /*+ index (t1 ACCOUNT_PK) */
        T1.*,
        --  CL.INN,
         UNIVERSE.NAMEDEPART (T1.SUBDEPARTMENT) SUBDEP_NAME,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'), T1.OWNER)      USER_OPEN_ID,
         NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),       T1.OWNER)       USER_CLOSE_ID,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USEROPEN'),                  T1.OWNER))             USER_OPEN,
         UNIVERSE.NAMEOWNER (NVL (UNIVERSE.VARIABLE_ACC (T1.BRANCH, T1.REFERENCE, 'USERCLOSE'),                  T1.OWNER))             USER_CLOSE,
         (SELECT P1.TYPE_BAL FROM PLAN_ACCOUNT P1   WHERE P1.HEADER = T1.HEADER AND P1.BAL = T1.BAL) TYPEBAL
         , get_obj_info (-1,-1,T1.SUBDEPARTMENT,T1.OWNER,T1.HEADER) AS INFO_OBJ, 255  AS ACCESS_OBJ
         ,'{6EF47ACA-FBB3-4506-8F89-86DE05E570F3}' AS TMP,
         PLEDGER.SALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'), 0) WSALDO,
         DECODE (T1.CURRENCY,'810', 0,PLEDGER.RSALDO (T1.HEADER,T1.CODE,T1.CURRENCY,TO_DATE ('12.06.2020', 'DD.MM.YYYY'),0)) RSALDO
         ,(select INN from clients where  REFERENCE = T1.CLIENT AND BRANCH = T1.BRANCH_CLIENT) INN
         ,(select NAME from clients where  REFERENCE = T1.CLIENT AND BRANCH = T1.BRANCH_CLIENT) CL_NAME
    FROM ACCOUNT T1            
   WHERE  1=1 
          AND T1.CODE LIKE nvl(ar13.get_param('ACCOUNT_CODE'),T1.CODE)
)
select * from acc tt
where 
       Tt.HEADER IN (SELECT /*+ index (f FOLDER_UNIQUE) */ CHAPTER FROM FOLDERS f WHERE CODE = 7 AND PUSER.GET_RIGHT_FOLDER (FOLDER_ID) < 0)
       AND PUSER.GET_RIGHT_FOLDER (DECODE (Tt.CLOSE_DATE, NULL, 110, 100)) <  0
       AND (Tt.CONTRACT = 0 OR PUSER.GET_RIGHT_CONTRACT (Tt.CONTRACT, Tt.BRANCH_CONTRACT) < 0)
       AND GLOBALS.CHECK_SUBUSER (Tt.OWNER) = 1  
       AND GLOBALS.CHECK_SUBDEPARTMENTS (Tt.SUBDEPARTMENT) = 1                                  
       --AND Tt.CODE LIKE nvl(ar13.get_param('ACCOUNT_CODE'),Tt.CODE)
 