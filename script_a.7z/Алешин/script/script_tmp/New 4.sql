--insert into zyx_store(OPER,TBL,NUM4,NUM5,STR1,STR2,STR3,STR4,STR5,DT1,status,DT_MOD,NUM6)
--insert into zyx_store(OPER,TBL,NUM4,NUM5,STR1,STR2,STR3,STR4,STR5,DT1,status,DT_MOD,NUM6,num3)
select 'AR_INFO' oper,'TABLE' tbl,0 num4,0 num5,TABLE_NAME str1
,'�������. �����. Way4 24. '||(select comments from dba_tab_comments where table_name = t.table_name and owner = t.owner) str2  
, owner str3,'����� �' str4, '' str5
--'�� ���������, truncate' str5 
,null,0,sysdate,0--,0
from DBA_tables t where 1=1
--and owner = 'EID' 
and table_name like 'CORP_CARD_WAY24_DOC_LOG%' 
--and table_name in ('PAYMENTS_NEW','PAYMENTS_CP','PCARD')
--and owner = 'SCO_ANKETA'
--and (owner,table_name) in (select table_owner,table_name from dba_triggers where owner = 'CDCS' and status = 'ENABLED')
and not exists (select null from ZYX_STORE z where oper = 'AR_INFO' and tbl = 'TABLE' and str1 = t.table_name and str3 = t.owner)
--and (exists (select null from DBA_DEPENDENCIES t where (name like '%MIGR%' or name in ('CFT2_JL','CFT2_MBANK_ARREST')) and  REFERENCED_TYPE = 'TABLE' and REFERENCED_OWNER = t.owner and REFERENCED_NAME = t.table_name)
--or not exists (select null from DBA_DEPENDENCIES t where type in ('PACKAGE BODY','PACKAGE') and REFERENCED_TYPE = 'TABLE' and REFERENCED_OWNER = t.owner and REFERENCED_NAME = t.table_name) )
--and exists (select null from dba_tables dd where table_name like '%INT' and owner = t.owner and  table_name =  t.table_name
--                and exists (select null from dba_tables where owner = dd.owner and table_name = substr(dd.table_name,1,length(dd.table_name)-4)))
/


--������ ������ �������������
select OWNER,table_name,(select comments from dba_tab_comments where table_name = t.table_name and owner = t.owner) comm from dba_TABLES t where 1=1
--and table_name in ('OPERATION','DEALS_CUR_EXCHANGE')
and (OWNER,table_name) in (select a,b from zyx_cont_cb)
and not exists (select null from ZYX_STORE z where oper = 'AR_INFO' and tbl = 'TABLE' and str1 = t.table_name and str3 = t.owner )

select rowid,z.* from ZYX_STORE z where oper = 'AR_INFO' and tbl = 'TABLE' 
and (str1,str3) in  (select b,a from zyx_cont_cb)
and num3 = 0


select str3 Owner, str1 table_name, decode(num3,0,'���','��') "������������� � �����", decode(status,1,'��', '���') "������ �������"
--, z.* 
from ZYX_STORE z where oper = 'AR_INFO' and tbl = 'TABLE' 
and (str1,str3) in  (select b,a from zyx_cont_cb)

--alter table audit_archive truncate partition P_AA_REF_21 
--audit_table

    alter index audit_time invisible   
    /
    
alter session set ddl_lock_timeout=13

--SHED_AUDIT

--alter table audit_table truncate partition SYS_P5384122

select * from all_tab_partitions where table_name = 'AUDIT_TABLE'