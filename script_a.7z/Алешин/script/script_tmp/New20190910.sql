select * from subdepartments where id in  (select distinct num4 from zyx_store z where OPER = 'FIL_MIGR')

785076
/


select * from (select p.id paramid,p.group_id paramgroupid,s.id departid,v.value,to_date('01.09.2019','dd.mm.yyyy') activated
from parameters p, subdepartments s, paramgroupmembership pg, (select '40000' value from dual) v 
 where 1=1 and pg.depart_id = s.id and pg.group_id = p.group_id 
 --and s.id in (select distinct num4 from zyx_store z where OPER = 'FIL_MIGR')
  and s.id in (785076,49132)
  and nvl(date_close,sysdate) > trunc(sysdate)    
 and p.name = '���_����������_�����'
 ) t
where not exists (select null from paramvalues where  paramid = t.paramid and paramgroupid = t.paramgroupid and departid = t.departid and value = t.value and activated = t.activated)
--and exists (select null from paramvalues where  paramid = t.paramid and paramgroupid = t.paramgroupid and departid = t.departid)
 /
 
 D_4748
 
 select rowid,t.* from archive t where 
 reference = 3535075966
 type_doc = 4205 and date_work > sysdate-300 
 /
 
 select rowid,t.* from documents t where reference = 3536840300  
 
 /
 
 select * from taxs_contracts where operation = '21010107'
 
  select * from taxs_contracts where operation = '210401'
  
    select * from taxs where operation = '21010107' and type_contract = 5142
    
    select * from parameters where name like '���_���%'
    
    
     select rowid,pv.* from paramvalues pv where departid in (777,770) and paramid in (427)
    

select rowid,e.* from eid.EID_PARAMVALUES e where departid in (777,770) and paramid in (427)

select * from vtb_subdepartments where debt_type = '4'

select * from all_tables where table_name like 'EID_PARAM%' 



select rowid, t.* from synergy_transactions t 
where 
vtb_tran_date > trunc(sysdate) - 3
and vtb_tran_id in (
'4652060867127117_1-1TEKLKJJ_20190908124200'
) 
order by vtb_tran_date desc


synergy_operations.closeCard
/

--insert into synergy_query_send(vtb_tran_id,status)
--select vtb_tran_id,-1
select (select SYNERGY_TOOLS.GETPARAM('obj_number',query_params) from synergy_queries_reestr where  vtb_tran_id = t.vtb_tran_id and rownum < 2) card,
(select SYNERGY_TOOLS.GETPARAM('sum_credit',query_params) from synergy_queries_reestr where  vtb_tran_id = t.vtb_tran_id and rownum < 2) sum,
vtb_tran_id, to_char(vtb_tran_date,'dd.mm.yyyy hh24:mi:ss') dt
--(select count(*) from synergy_queries_reestr where  vtb_tran_id = t.vtb_tran_id) s,
 --t.* 
 from synergy_transactions t 
where 
vtb_tran_date > trunc(sysdate) - 3 and vtb_tran_date < trunc(sysdate) 
and substr(vtb_tran_id,1,4) in ('4652','5417','2200','5282') 
--and substr(vtb_tran_id,1,16) in ('4272308252082607') 
and doc303_reference is null --and status = 1
and (select SYNERGY_TOOLS.GETPARAM('sum_credit',query_params) from synergy_queries_reestr where  vtb_tran_id = t.vtb_tran_id and rownum < 2) <> '0'
--and not exists (select null from zyx_cont_cb where a = t.vtb_tran_id)
order by vtb_tran_date desc
/

declare
CtrNumber    varchar2(500);
DateProc     date;
CtrCurr      varchar2(500);
CtrStatus    varchar2(500);
TotalDebts   number;
TotalPayment number; 
begin
  --dbms_output.put_line('ss >' ||CardAccPredictions@proc('5417157589974801',sysdate,CtrNumber,DateProc,CtrCurr,CtrStatus,TotalDebts,TotalPayment));
  --dbms_output.put_line('ss >' ||CardAccPredictions_deb1@proc('5417157589974801',sysdate));
  dbms_output.put_line('ss >' ||get_status_card('5417157589974801'));
  dbms_output.put_line('CtrCurr = '||CtrCurr||' CtrStatus = '||CtrStatus||' TotalDebts = '||TotalDebts||' TotalPayment = '||TotalPayment);
end;
/


  r_card_header mbank.p_types.t_card_head;
  r_card_itog mbank.p_types.t_card_itog;
  r_card_oper mbank.p_types.t_tab_card_oper;
  r_card_oper_auth mbank.p_types.t_tab_trans_auth;
  cikl Number;
Begin
  v_result := --mbank.get_card_statement(5577486993351678, to_date('29032019','ddmmyyyy'), Sysdate, r_card_header, r_card_oper, r_card_oper_auth, r_card_itog, null, TRUE);
                mbank.get_card_statement(5298846303608968, to_date('29032019','ddmmyyyy'), Sysdate, r_card_header, r_card_oper, r_card_oper_auth, r_card_itog, null, TRUE);


declare
ret varchar(200);
AmountAvailable varchar(200);
ccCardNum varchar(200);
begin
ccCardNum:='5577484545772277';
   execute immediate 'begin :1 := analyser.GET_CARD_AMOUNT_AVAILABLE@proc(:2, :3); end;' using out ret, in ccCardNum, out AmountAvailable ;
   DBMS_OUTPUT.PUT_LINE(AmountAvailable);
end;




--���� �� �������
1)	���� ��������� ����� � ���������� ������� �������� ���������� ������������
function CardAccPredictions(
CardNumber   in  bwx.dtypt.ContractNumber  %Type,
DateTo       in  bwx.dtype.CurrentDate     %Type,
CtrNumber    out bwx.dtypt.ContractNumber  %Type,
DateProc     out bwx.dtype.CurrentDate     %Type,
CtrCurr      out bwx.dtypt.CurrencyCode    %Type,
CtrStatus    out bwx.dtype.Name            %Type,
TotalDebts   out bwx.dtypt.Money           %Type,
TotalPayment out bwx.dtypt.Money           %Type) return varchar2--bwx.dtype. ErrorMessage %Type

1)	���� ����� ��������� ��� ��������� � ������� ���������� (������������)


function CardAccPredictions_deb1
         (CardNumber in  bwx.dtypt.ContractNumber  %Type
         ,DateTo     in  bwx.dtype.CurrentDate     %Type
         )
return number


/

select 
SYNERGY_TOOLS.GETPARAM('obj_number',query_params)
,SYNERGY_TOOLS.GETPARAM('sum_credit',query_params) s,r.* from synergy_queries_reestr r 
where vtb_tran_id like '4652180063491982%'
/

select * from zyx_cont_cb 

select distinct vtb_tran_id--, query_params 
                   from synergy_queries_reestr sr 
                   where vtb_tran_date >= to_date('08.09.2019 21:00:00', 'dd.mm.yyyy hh24:mi:ss') 
                         and vtb_tran_date < to_date('11.09.2019 07:00:00', 'dd.mm.yyyy hh24:mi:ss')
                         --and OPER_CODE = 'synergy-transfer-accountcardpay'
                         and synergy_tools.getParam('vtb24_card', sr.query_params) > 0 
                         and synergy_tools.getParam('sum_credit', sr.query_params) > 0
/

select * from zyx_cont_cb where a not in 
(select 
vtb_tran_id 
  from synergy_transactions t 
where 
vtb_tran_date > trunc(sysdate) - 3
and substr(vtb_tran_id,1,4) in ('4652','5417','2200') 
and doc303_reference is null and status = 1
and (select SYNERGY_TOOLS.GETPARAM('sum_credit',query_params) from synergy_queries_reestr where  vtb_tran_id = t.vtb_tran_id and rownum < 2) <> '0')
/

select * from synergy_transactions where substr(vtb_tran_id,1,16) in 
(select substr(vtb_tran_id,1,16) from synergy_query_send)
and vtb_tran_date > trunc(sysdate)
/

select * from users_rights

