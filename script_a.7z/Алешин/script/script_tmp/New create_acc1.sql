select bal_str1 as tail
       ,substr(bal_str2, 1, 1) as header
       ,bal as balance
       ,substr(bal_str2, 7, 3) as currency
       ,substr(bal_str2, 10, 4) as cfu       
       ,bal_str2
       ,passive_in
  from balance b 
 where (b.users, b.id, b.operation) = 
-- ((1005546, 'konkin-ka', 'test-create-acc-ar'))
--((1005546, 'konkin-ka', 'test-create-acc-ar_f'))
((1005546, 'konkin-ka', 'test-create-acc-ar1'))
and currency = '810' 
and substr(bal_str2, 10, 4) = '8065'
and bal = '40817' 

 --delete balance b 
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar'))

select bal_str3 as seconds, b.*
  from balance b 
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar'))
 and BAL_STR1 is null

 select count(*)
  from balance b 
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar1'))
 
 
 select count(*)
  from balance b 
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar'))
 
  select count(*)
  from balance b 
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar_f'))

 
 select * from konkin_test_paccount where bal = '31502'
 
 select * from account a where  currency = '810' and header = 'A' 
 and code like '31502810_0000%'
/


--select lpad(nvl(lsnum,:l_min)+1,7,'0') lsnum from ( 
select /*+ INDEX(a account_pk) */  
                   min(substr(a.code, 14)) lsnum
              from account a
             where a.header = :i_hdr
               and a.code like :i_bal|| :i_curr || '_' || :i_cfu || '%'
               and a.currency = :i_curr
               --and to_number(substr(a.code, 14)) >= :i_min and :i_max >= to_number(substr(a.code, 14))
               and not exists ( 
                    select /*+ INDEX(a1 account_pk) */null from account a1
                     where a1.header = :i_hdr
                       and a1.code like :i_bal || :i_curr || '_' || :i_cfu || '%'
                       and a1.currency = :i_curr
                       and substr(a1.code, 14) = lpad((substr(a.code, 14)+1), 7, '0'))                      
--)


select /*+ INDEX(a account_pk) */  
                   count(*)
              from account a
             where a.header = :i_hdr
               and a.code like :i_bal|| :i_curr || '_' || :i_cfu || '%'
               and a.currency = :i_curr
               /
               
               
               
               select b.bal_str1 as tail
       ,substr(b.bal_str2, 1, 1) as header
       ,b.bal as balance
       ,substr(b.bal_str2, 7, 3) as currency
       ,substr(b.bal_str2, 10, 4) as cfu       
       ,b.bal_str2
       ,b.passive_in
       ,b2.bal_str3
       ,b2.bal_str1
  from balance b, balance b2
 where (b.users, b.id, b.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar'))
--and (b2.users, b2.id, b2.operation) = ((1005546, 'konkin-ka', 'test-create-acc-ar_f'))
and (b2.users, b2.id, b2.bal) = ((1005546, 'konkin-ka', 'test-modern-create-acc-v0.0.2'))
and b.bal = substr(b2.bal_str2, 2, 5) and b.bal_str2 = b2.bal_str2
and  b.bal_str1 <> '0000001' and b.bal_str1 <> b2.BAL_STR1