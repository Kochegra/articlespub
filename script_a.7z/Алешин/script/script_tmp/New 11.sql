select * from account where subdepartment in  
(select num4 from zyx_store@etalon where oper = 'FIL414' and TBL = 'SUBDEP')
/


insert into zyx_store
select * from zyx_store@etalon where oper = 'FIL414' and TBL = 'SUBDEP'
/

select substr(code,10,4),count(*) from account where modify_date > to_date('01.01.2020','dd.mm.yyyy') 
and close_date is null and substr(code,1,5) = '40702'
group by substr(code,10,4)

select * from all_tables@cft