select 
  USER
  ,sys_context('USERENV','DB_NAME') DB
    ,sys_context('USERENV','DB_DOMAIN') DB
 ,sys_context('USERENV','HOST') HOST
 ,sys_context('USERENV','IP_ADDRESS') IPADDRESS
 ,sys_context('USERENV','NETWORK_PROTOCOL') net
 ,sys_context('USERENV','CLIENT_IDENTIFIER') AUTH
  ,sys_context('USERENV','ACTION') AUTH
 ,sys_context('USERENV','OS_USER') OSUSER
 ,sys_context('USERENV','TERMINAL') TERMINAL 
  ,sys_context('USERENV','CLIENT_INFO') PROGRAM
    ,sys_context('USERENV','CURRENT_SCHEMA') PROGRAM
 ,sys_context('USERENV','SESSIONID') AUDSID
  ,sys_context('USERENV','MODULE') MODULE
 ,lpad(substr(:ip,1,instr(:ip,'.')-1),3,'0') IP_1
 ,lpad(substr(:ip,instr(:ip,'.')+1,instr(:ip,'.',1,2)-instr(:ip,'.')-1),3,'0') IP_2
 ,lpad(substr(:ip,instr(:ip,'.',1,2)+1,instr(:ip,'.',1,3)-instr(:ip,'.',1,2)-1),3,'0') IP_3
 ,lpad(substr(:ip,instr(:ip,'.',1,3)+1),3,'0') IP_3
 ,instr(:ip,'.') dd
 ,instr(:ip,'.',1,2) dd
 ,instr(:ip,'.',1,3) dd
 ,:ip ip
 --,lpad(substr(sys_context('USERENV','IP_ADDRESS'),instr(sys_context('USERENV','IP_ADDRESS'),'.',2)+1
 --      ,instr(sys_context('USERENV','IP_ADDRESS'),'.')+1 )
-- ,3,'0') IP_2
from dual

select * from session_context
/

select * from (
select distinct upper(osuser) OSUSR  from v$session v where 1=1 
--username = user
and username = 'MBANK'
and osuser not in ('oracle','tomcat','grid','root','robot_retailreport','robot_retailReport','mcirobot','bki_user','shod_svc_user')
and osuser not in ('Nikonorov_IV','Novozhilov_ds2','mokrushin','tkachev_al','vasilev_ev')
and program not in ('AdminLight.exe','admin_light.exe','Admin_Light.exe','perevod_p.exe','tkachev_al')
and upper(program) not like 'ADMINLIGHT%'
and not exists (select null from v$session vv, users u, boss_emp_all bb where osuser = v.osuser and vv.username = u.user_ 
         and bb.dept_name_4 = '������ ��������� � ����' and bb.tab_n = u.params) 
         ) t where not exists (select null from MBANK_ADMIN.ORAUSER_LOGON where orauser = 'MBANK'and OSUSER = t.OSUSR)                  
order by osusr
/

--��� �������� ��� MBANK
select sysdate,(select min(logon_time) from  v$session where osuser = v.osuser) min_logon_time, osuser,count(*),program
, (select max(user_name) from v$session vv, users u where osuser = v.osuser and vv.username = u.user_) usr   
from v$session v where 1=1 
--and upper(osuser) like 'VTB%'
and username = 'MBANK' and status <> 'KILLED'
and osuser not in ('oracle','tomcat','grid','root','robot_retailreport','robot_retailReport','mcirobot','bki_user','shod_svc_user')
and osuser not in ('mokrushin','tkachev_al','vasilev_ev','dehtyarev_sn','gavrilenko_vs','jakovlev','rogachev_vs','VYRODOV_DA'
,'khoroshaeva_mp','Kurlaeva_EA','novikova_tn','katalymova','Dubikova','nikolashev_as','podneks_ae','R_IRINA','VTB93556','yakovlev_pa','Dolganyuk_MG')
and osuser not in ('aleshin_rl','Kozlenko','menkov_sv','cherenkov_is','gorodnov_dm')
and program not in ('AdminLight.exe','admin_light.exe','Admin_Light.exe','perevod_p.exe','ReportBulder.exe','JDBC Thin Client','shed.exe')
and upper(program) not like 'ADMINLIGHT%' and upper(program) not like 'PYTHON3.7%' 
and not exists (select null from v$session vv, users u, boss_emp_all bb where osuser = v.osuser and vv.username = u.user_ 
         and bb.dept_name_4 = '������ ��������� � ����' and bb.tab_n = u.params)          
group by osuser,program
order by upper(osuser)
/

with bb as (select level lvl,sys_connect_by_path(s.name,'/') pth,s.* from boss_subdepartments s start with id = 177201 connect by prior id = dept_id)
select bb.lvl,ee.l_name||' '||ee.f_name||' '||ee.m_name FIO,ee.appoint_name,substr(bb.pth,61) dept,tab_n,email
,decode((select count(*) from mb_users where tabn = ee.tab_n and db_name = 'MAIN' and DB_ROLE = 'MBANK_READ_ROLE'),0,null,1) MBANK_READ_ROLE
,decode((select count(*) from mb_users where tabn = ee.tab_n and db_name = 'MAIN' and DB_ROLE = 'MBANK_SUPPORT_ROLE'),0,null,1) MBANK_SUPPORT_ROLE
,ee.*,bb.* 
from boss_emp_all ee, bb where 1=1
--l_name like '������'
and dept_name_3 = '���������� �������� ������ ��������-��������� ������������'
and d_out > sysdate
and bb.id = ee.dept_id
order by d_out 
/

select * from v$session vv, users U where osuser = 'Nikonorov_IV' and vv.username = u.user_
 
select * from boss_emp_all WHERE TAB_N = '10103' AND dept_name_4 = '������ ��������� � ����'
/

select max(NTIMESTAMP#),min(NTIMESTAMP#) from sys.aud$ where 1=1 --userid = 'MBANK'
--and NTIMESTAMP# > to_timestamp(sysdate-6)
--order by NTIMESTAMP# desc
/


create table zyx_mbank_logon as  
select 
SESSIONID,ENTRYID,STATEMENT,USERID,USERHOST,ACTION#,RETURNCODE,SES$TID,	LOGOFF$LREAD,	LOGOFF$PREAD,	LOGOFF$LWRITE,	LOGOFF$DEAD,	LOGOFF$TIME
,COMMENT$TEXT,PRIV$USED,CLIENTID,SESSIONCPU,NTIMESTAMP#,INSTANCE#,PROCESS# 
from sys.aud$ where userid = 'MBANK'
and NTIMESTAMP# > to_timestamp(sysdate-20)
/

select * from zyx_mbank_logon

--drop table zyx_mbank_logon
/

select to_timestamp(sysdate-80), TIMESTAMP#
SESSIONID,ENTRYID,STATEMENT,USERID,USERHOST,ACTION#,RETURNCODE,SES$TID,	LOGOFF$LREAD,	LOGOFF$PREAD,	LOGOFF$LWRITE,	LOGOFF$DEAD,	LOGOFF$TIME
,COMMENT$TEXT,PRIV$USED,CLIENTID,SESSIONCPU,NTIMESTAMP#,INSTANCE#,PROCESS# 
from sys.aud$ where userid = 'MBANK'
--and NTIMESTAMP# > to_timestamp(sysdate-80)
--and TIMESTAMP# is not null
and LOGOFF$TIME > to_timestamp(sysdate-84)
and rownum < 10

/
select * from all_views where view_name like 'DBA%'
/

--create table ORAUSER_LOGON
(orauser varchar2(30) 
,osuser varchar2(2000)
,term varchar2(2000)
,ip_addr varchar2(15)
,dt_from date
,dt_to date
,memo varchar(4000)
,access_prior number default 0
,dt_mod date default sysdate
)
/
--10.172.8.106 aleshin_rl

select rowid,t.* from MBANK_admin.ORAUSER_LOGON t

/


select 
--nvl(orauser,'#') orauser, nvl(osuser,'#') osuser, nvl(term,'#') term, nvl(ip_addr,'#') ip_addr, nvl(dt_from,sysdate-1) dt_from, nvl(dt_to,sysdate+1) dt_to
tt.* 
     from ORAUSER_LOGON tt 
where :USR like nvl(orauser,:USR)
   and upper(sys_context('USERENV','OS_USER')) like nvl(osuser,upper(sys_context('USERENV','OS_USER')))
   and upper(sys_context('USERENV','TERMINAL')) like nvl(term,upper(sys_context('USERENV','TERMINAL')))
   and sys_context('USERENV','IP_ADDRESS') like nvl(ip_addr,sys_context('USERENV','IP_ADDRESS'))  
order by access_prior desc
/

--������� �������� �������� �� ������ ����� (like) ��� ���������� ���������� ������������ ���� ������ �� ��������� ��� 
--�������� ����� IP 10.172.8.100 ���������� ��� %10.172.%8.100
--create or replace trigger user_logon after logon on DATABASE 
declare
-- %Author  : ����� �.�.
-- %Created : 19.02.2020
-- %Usage : ����������� ������� ����� � �� ��� ����������� ��
 usr_ora  varchar2(30);
 usr_os   varchar2(2000);
 usr_term varchar2(2000);
 usr_ip   varchar2(15);
 usr_access boolean;
begin
  usr_ora := USER;
  --usr_ora := 'MBANK';
  usr_os := upper(sys_context('USERENV','OS_USER'));
  usr_term := upper(sys_context('USERENV','TERMINAL'));
  usr_ip := sys_context('USERENV','IP_ADDRESS');
  if usr_ora not in ('SYS') then    
    for tt in (
               select * from MBANK_ADMIN.ORAUSER_LOGON 
               where usr_ora like nvl(orauser,usr_ora) and usr_os like nvl(osuser,usr_os)
                 and usr_term like nvl(term,usr_term) and usr_ip like nvl(ip_addr,usr_ip)  
               order by access_prior desc
               )
    loop
      usr_access := (nvl(tt.dt_from,sysdate-1) < sysdate and nvl(tt.dt_to,sysdate+1) > sysdate); 
      exit;     
    end loop;    
    if not usr_access then  
      raise_application_error(-20000, 'Access is denied to �ou!');
    end if;
  end if;    
end;
/

     -- insert into mbank_audit.user_logon(ORAUSER,OSUSER,PROGRAM,TERMINAL,MACHINE,LOGTIME,IPUSER,INFO)
     -- values(usr_ora,usr_os,sys_context('USERENV','MODULE'),usr_term,sys_context('USERENV','HOST'),sysdate,usr_ip,'DENIED');


grant select,insert on user_logon to MBANK_ADMIN
alter table user_logon add (IPUSER varchar2(15), info varchar2(2000)) 

--grant ADMINISTER DATABASE TRIGGER to MBANK_ADMIN
/

select * from mbank_audit.user_logon 
/

select * from config
/

oud
10.172.10.87  msk-033850.main.mmbank.ru
10.172.9.17   msk-032763.main.mmbank.ru Smirnova_lg
10.173.15.152 msk-032490.main.mmbank.ru deshina_im
10.173.14.170 msk-034610.main.mmbank.ru Timofeeva_is
10.173.16.15  msk-034104.main.mmbank.ru
10.173.15.140 msk-033164.main.mmbank.ru


/

select * from v$session where upper(machine) like '%MSK-033164%'   