select * from documents where reference = 3787820480

select * from variable_documents where reference = 3787820480


select * from variable_missions where value = 3787820480 and subfield = 'DOC_RF'

select * from zyx_store where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 235



--������ ������������ ���������
select num1 fil_from, num2 br_from, num3 fil_to, num4 br_to, s.name 
from zyx_store z, subdepartments s 
where OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num4 = s.id
and num1 = :fil and :s_id in (num2,num4)
 /
 
 select * from eid.eid_firma_account where code = '41802810689000000000'
 
 
 select * from eid.eid_firma_products where reference = 566548
 
 --
 select rowid,c.* from config c where name = 'MODERN_PACCOUNT'
 /
 
 
 select rowid,a.* from account a where open_date >= trunc(sysdate)
 
 /
 
 select * from contracts where reference = 2920888
/

declare
  cBal_Tail varchar2(20); 
  cAccount varchar2(25);
begin
 cBal_Tail := firma_contracts_tools.bal_tail(dSystemDate => trunc(sysdate), dDate_From => trunc(sysdate), dDate_To => trunc(sysdate) + 1
       ,d_ip => ptools_7500_ext.client_field(114872251, 631310, 'sub_type'));-- ��� �������������� ���������������� ���������� ����� + 7
  dbms_output.put_line('cBal_Tail = '||cBal_Tail);
  --cAccount := paccount.create_account('A', '42103', '810', trunc(sysdate), 994542, 114872251, 631310,
  --              SUBSTR(ptools_7500_ext.client_field(114872251, 631310, 'full_name'),1,80));
  cAccount := paccount.create_account('A', '47426', '810', trunc(sysdate), 994542, 114872251, 631310,
                SUBSTR(ptools_7500_ext.client_field(114872251, 631310, 'full_name'),1,80));
  
  dbms_output.put_line('cAccount = '||cAccount);
  rollback;
end;
/


select * from account where code = '42102810700490000022'
/

select * from documents where reference = 3789990942

�������� ����� 
/

--���������� ���������
declare
     doc_owner number;
      n                NUMBER;
   tmp1             VARCHAR2(2000);
   tmp2             VARCHAR2(2000);
   
begin
  for dd in (select * from documents where reference = 3789990942)
  loop 
    --doc_owner := dd.owner;
    doc_owner := 994542; 
    mbank.ptools2.short_init_user(doc_owner); 
   n := NULL; tmp1 := NULL; tmp2 := NULL;
   --dbms_output.put_line('dd > '||start_process.WORKING(1, 11, dd.branch, dd.reference, null, n)); --11 �������
   dbms_output.put_line('dd > '||start_process.WORKING(1, 5, dd.branch, dd.reference, null, n)); --5 ����������
  -- dbms_output.put_line('dd > '||start_process.WORKING(1, 10112, dd.branch, dd.reference, null, n)); --���������� � ���������
   --dbms_output.put_line('dd > '||DOCALGO.execdoc(dd.branch, dd.reference, dd.owner, n, v1, v2));
    --dbms_output.put_line('D_4215 > '||D_4215.RUN_DOC(0,dd.reference,dd.branch));
    commit;                   
  end loop; 
end;