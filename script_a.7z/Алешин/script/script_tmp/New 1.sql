--insert into zyx_store(OPER,TBL,num1,num2,dt_mod)
select 'FIL_OLD' OPER, 'SUBDEPARTMENTS' TBL, 48,id,sysdate DT_MOD from ( 
--select * from (
select 
(select count(*) from account where subdepartment = s.id) acc_cnt
,(select count(*) from account where subdepartment = s.id and close_date is null) acc_cnt_50
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 4) con_ur_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 4) cl_ur_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 5) con_fl_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 5) cl_fl_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50) con_50_cnt
,(select count(*)||'/'||sum((select count(*) from all_users where username = u.user_)) from users u where subdepartment = s.id) usr_cnt
,s.* from subdepartments s start with id = mbfilid connect by prior id = parent
) where acc_cnt > 10 and type = 301
and id in (48000,48001,48013,48019,48021,48032,48051,48052,48053,48067,48069,48070,48071,48075,48077,48078,48079,540011,544149,544163)

/

select * from (
select 
(select count(*) from account where subdepartment = s.id) acc_cnt
,(select count(*) from account where subdepartment = s.id and close_date is null) acc_cnt_50
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 4) con_ur_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 4) cl_ur_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 5) con_fl_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 5) cl_fl_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50) con_50_cnt
,(select count(*)||'/'||sum((select count(*) from all_users where username = u.user_)) from users u where subdepartment = s.id) usr_cnt
,s.* from subdepartments s start with id = mbfilid connect by prior id = parent
) where acc_cnt > 10 and type = 301
and id in (48000,48001,48013,48019,48021,48032,48051,48052,48053,48067,48069,48070,48071,48075,48077,48078,48079,540011,544149,544163)
