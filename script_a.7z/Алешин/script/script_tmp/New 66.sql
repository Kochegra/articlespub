
select * from DBA_TAB_PRIVS where 1=1 
and grantee in
(
select username usr from dba_users u where u.username = 'VTB_MIGR'
union all
select granted_role usr from DBA_ROLE_PRIVS where grantee = 'VTB_MIGR'
)
order by table_name,grantee,owner

select * from dba_objects tt where object_name in 
('CLIENTS','CONTRACTS','ACCOUNT','GUIDES','FNS_MESSAGE_ARC','VARIABLE_CONTRACTS','VARIABLE_ARCHIVE','V_DOCUMENTS','UNIVERSE','PLEDGER','FNS_MESSAGE','GET_NALOG_OPEN_DATE_SZRC'
,'MBANK_CFT_MIGR','PUSER')
and object_type in ('TABLE','PACKAGE','VIEW','FUNCTION')
and owner in ('MBANK','EID','TMP_TABLES') 
and not exists ( select null from DBA_TAB_PRIVS where table_name = tt.OBJECT_NAME and owner = tt.owner
and grantee in
(
select username usr from dba_users u where u.username = 'VTB_MIGR'
union all
select granted_role usr from DBA_ROLE_PRIVS where grantee = 'VTB_MIGR'
) )


select * from DBA_ROLE_PRIVS where 
--granted_ROLE in ('PUBLIC','SELECT_CATALOG_ROLE','EXECUTE_CATALOG_ROLE')
--grantee like 'DBMS_REDEFINITION'
--granted_ROLE like 'MT_WEB%'
grantee = 'VTB_MIGR'


select username usr from dba_users u where u.username = 'VTB_MIGR'
union all
select granted_role usr from DBA_ROLE_PRIVS where grantee = 'VTB_MIGR' 

and u.username = rl.grantee(+) 
and t.grantee in (u.username,rl.grantee)


grant execute on GET_NALOG_OPEN_DATE_SZRC to MBANK_READ_ROLE
MBANK_CFT_MIGR


select pledger.saldo(header,code,currency,sysdate) sld,
(select count(*) from ledger where header = a.header and code = a.code and currency = a.currency and work_date > sysdate-30) cnt_30,
 a.code,a.open_date,name,(select count(*) from status_account where status_id = '����������' and code = a.code) "1-����������" 
 --,(select count(*) from status_account where code = a.code) "������� �����������"
  from account a where code like '40_02%' and contract = 0 and close_date is null