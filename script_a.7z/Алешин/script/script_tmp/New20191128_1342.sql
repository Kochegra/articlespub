select rowid,t.* from documents t where reference in (5510181,5510230,5508661) 

select rowid,t.* from variable_documents t where reference in (5510181)--,5508661)-- (5508661) 

/

select * from text_files where file_name in ('P0112102.332','P0112101.332') --.332
/

select rowid,t.* from archive t where reference in (5510181,5510230,5508661) 

select rowid,t.* from variable_archive t where reference in (5510230)
/
--insert into journal_zp
select * from
--delete 
journal_delete j where docnum = 5510230

select rowid,j.* from journal j where docnum = 5510230  

select * from eid.eid_products where reference = '4652069082113828'
/

m_filial.run_doc_1342

select * from error_execute where reference = 5510181
/

select variable_doc_id.nextval from dual
/

--������� �������� 1342 ����� ��������
--� ������ ��������� ��������� ��������� name � ��������� �� ��������
--PK_CURRENCY
--DISTRIB_TRAN
--� ����� ��������� refer_office ������ ���������� � EI- � ������ =  
DECLARE 
  rec_doc DOCUMENTS%ROWTYPE;
  
    FUNCTION GetTerminal(pi_Branch NUMBER, pi_CardFinInst VARCHAR2) RETURN VARCHAR2 IS
    vi_Result VARCHAR2(4000);
    CURSOR vi_CrsGuides(cpi_TypeDoc  NUMBER,
                        cpi_Branch   NUMBER) IS
      SELECT g.code1
        FROM guides_all g
       WHERE g.type_doc = cpi_TypeDoc
         AND g.code != 'FORM_STORAGE'
         AND g.code = to_char(cpi_Branch)
       ORDER BY g.date_work DESC;
  BEGIN
/*    FOR crs IN vi_CrsGuides(12481, pi_Branch)
    LOOP
      vi_Result := crs.code1;
      EXIT;
    END LOOP;*/
    IF pi_Branch = 405008 THEN
      vi_Result := '45205006';
    ELSIF pi_CardFinInst = '111' THEN
      vi_Result := '45205011';
    ELSIF pi_CardFinInst = '112' THEN
      vi_Result := '45190012';
    ELSIF pi_CardFinInst = '999' THEN
      vi_Result := '45147204';
    END IF;

    RETURN vi_Result;
  END;
    
  
    FUNCTION CallMBGOPart(pi_document IN documents%ROWTYPE) RETURN VARCHAR2 IS
     vi_DataCloud   VARCHAR2(32000);
     vi_result      VARCHAR2(32000);
     vi_DateExp     VARCHAR2(4);
     vi_TerminalID  VARCHAR2(32000);
     vi_CardNum     VARCHAR2(4000);
     vi_CardFinInst VARCHAR2(4000);
  BEGIN
     IF nvl(universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'VERSION'),'0') != '0' THEN
       vi_CardNum := REPLACE(universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'PK_Number'),' ');
       IF mbfilID = mbvtbmainid THEN
         vi_CardFinInst := pckmfilialutil.GetCardFI(vi_CardNum);
         vi_TerminalID  := COALESCE(GetTerminal(Globals.BranchID, vi_CardFinInst),universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'TERMINAL_ID'));
         universe.INPUT_VAR_DOC(pi_document.branch,pi_document.reference,'TERMINAL_ID',vi_TerminalID);
         universe.INPUT_VAR_DOC(pi_document.branch,pi_document.reference,'CARDFININST',vi_CardFinInst);
       END IF;
/*       IF Globals.BranchID = 405003 THEN
          universe.INPUT_VAR_DOC(pi_document.branch,pi_document.reference,'TERMINAL_ID','45147204');
       ELSIF Globals.BranchID = 405000 THEN
          universe.INPUT_VAR_DOC(pi_document.branch,pi_document.reference,'TERMINAL_ID','45147201');
       END IF;*/
       vi_DateExp  := nvl(universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'PC_ENDDATE'),
                          to_char(to_date(universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'PK_DATEEXP'),'dd.mm.yyyy'),'YYMM'));
       ptools6.set_value(vi_DataCloud,'CARDNUM',vi_CardNum);
       ptools6.set_value(vi_DataCloud,'EXPIREDATE',vi_DateExp);
       ptools6.set_value(vi_DataCloud,'TERMINALID',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'TERMINAL_ID'));
       ptools6.set_value(vi_DataCloud,'AMOUNT',to_char(pi_document.xsummacredit,'fm9999999999990.00'));
       ptools6.set_value(vi_DataCloud,'CURR',to_char(pi_document.receivers_currency));
       ptools6.set_value(vi_DataCloud,'GUID',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'PC_CORRID'));
       ptools6.set_value(vi_DataCloud,'REFERENCE',to_char(pi_document.reference));
       ptools6.set_value(vi_DataCloud,'BRANCH',to_char(pi_document.branch));
       ptools6.set_value(vi_DataCloud,'BRANCHCALL',mbfilid);
       ptools6.set_value(vi_DataCloud,'FIO',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'FIO'));
       ptools6.set_value(vi_DataCloud,'PC_BRANCH',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'PC_BRANCH'));
       ptools6.set_value(vi_DataCloud,'EARLY_PAYMENT',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'EARLY_PAYMENT'));
       ptools6.set_value(vi_DataCloud,'EARLY_PAYMENT_SUM',universe.VARIABLE_DOC(pi_document.branch,pi_document.reference,'EARLY_PAYMENT_SUM'));
       IF Plink.Need_Connection(mbgoid) = 1 THEN
           vi_result := ptools_by_utl.call_web_func_str(mbgoid, 'm_filial.run_doc_1342', 1,vi_DataCloud);
       ELSE
          EXECUTE IMMEDIATE 'BEGIN
                                :v1 := m_filial.run_doc_1342(:v2);
                             END;'
           USING OUT vi_result, IN vi_DataCloud;
       END IF;
     ELSE
       vi_result := '������ d_1342.CallMBGOPart: ���������������� ����� VERSION';
     END IF;
     RETURN vi_result;
end;


BEGIN
  GLOBALS_EXT.SHORT_INIT_ADMIN(405);
  
  
  select *
  INTO rec_doc
    from documents
    where reference = 5510230 AND BRANCH = 405011;
    
   dbms_output.put_line(CallMBGOPart(rec_doc));
  COMMIT;  
END;


