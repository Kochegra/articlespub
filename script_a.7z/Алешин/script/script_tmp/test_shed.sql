declare
  ii number := 0;
  dt date := sysdate;
  gr number := nvl(&1,0);
   
PROCEDURE get_info(p_task_name IN VARCHAR2, p_job_name IN VARCHAR2,
                    job_state OUT VARCHAR2, job_info OUT VARCHAR2, job_sess_id OUT VARCHAR2, percent OUT VARCHAR2,
                    job_fin_date OUT DATE, job_start_date OUT DATE, job_error_msg OUT VARCHAR2, p_marked OUT VARCHAR2, p_disabled OUT VARCHAR2)
 IS
 BEGIN
   job_state := 'NOT_WORKED';
   job_fin_date   := null;
   job_start_date := null;
   job_info       := null;
   job_sess_id    := null;
   percent        := null;
   job_error_msg  := null;
   FOR jj IN ( 
 --  SELECT  /*+ FIRST_ROWS INDEX_DESC( hh SHED_HIST_PK ) */ hh.* FROM SHED_HIST hh WHERE TASK_NAME = p_task_name AND JOB_NAME = p_job_name and rownum = 1  
 select * from (select h.* from shed_hist h  where task_name = p_task_name and job_name = p_job_name ORDER BY STARTED DESC) where rownum = 1  
   --select * from shed_hist where task_name = p_task_name and job_name = p_job_name order by started desc 
   ) LOOP
     IF jj.finished IS NULL THEN
       job_state := 'WORKING';
     ELSE
       job_fin_date := jj.finished;
       IF jj.error_msg IS NULL THEN
         job_state := 'FIN_SUCCESS';
       ELSE
         job_state := 'FIN_ERROR';
         job_error_msg  := jj.error_msg;
       END IF;
     END IF;
     job_start_date := jj.started;
     job_info := jj.info;
     job_sess_id := jj.sess_id;
     IF jj.max_cnt IS NOT NULL AND jj.cur_cnt IS NOT NULL AND jj.max_cnt > 0 THEN
       IF jj.cur_cnt = 0 THEN
         percent := '0';
       ELSE
         percent := round(100 * jj.cur_cnt / jj.max_cnt);
       END IF;
     END IF;
     EXIT;
   END LOOP;

   FOR bb IN (select * from shed_jobs where task_name = p_task_name and job_name = p_job_name) LOOP
     p_disabled := bb.disabled;   -- NULL/'DISABLE_SUCC'/'DISABLE_ERR'
     p_marked := bb.marked;       -- NULL,'START','STOP_SUCCESS','STOP_ERROR'
   END LOOP;
 END;

 PROCEDURE get_state(p_task_name IN VARCHAR2, p_job_name IN VARCHAR2,
                     job_state OUT VARCHAR2, job_fin_date OUT DATE, job_disabled OUT VARCHAR2, job_sess_id OUT VARCHAR2, job_marked OUT VARCHAR2, job_start_date OUT DATE)
 IS
   info_            VARCHAR2(2000);
   percent          NUMBER;
   error_msg        VARCHAR2(4000);
 BEGIN
   get_info(p_task_name, p_job_name, job_state, info_, job_sess_id, percent, job_fin_date, job_start_date, error_msg, job_marked, job_disabled);
 END;

 PROCEDURE dispatch_(p_task_name IN VARCHAR2, p_grp IN NUMBER)
 IS
   mins         NUMBER;
   s1           NUMBER;
   s2           NUMBER;
   CURSOR job_cur IS select * from shed_jobs where task_name = p_task_name /*and disabled is null*/
                                               order by decode(marked,'START',0,1), nvl(tryed, sysdate-300);
   job_rec      job_cur%ROWTYPE;
   job_state    VARCHAR2(20);
   job_fin_date DATE;
   job_sess_id  VARCHAR2(50);
   job_marked   VARCHAR2(50);
   dep_state    VARCHAR2(20);
   dep_fin_date DATE;
   job_start_date DATE;
   dep_disabled VARCHAR2(50);
   job_disabled VARCHAR2(50);
   st           VARCHAR2(32000);
   st1          VARCHAR2(2000);
   by_hand      VARCHAR2(20);
   fil_id       NUMBER;
   admin_id     NUMBER;
  -- CURSOR lock_cur IS SELECT job_name FROM shed_jobs WHERE task_name = job_rec.task_name AND job_name = job_rec.job_name FOR UPDATE NOWAIT;

 BEGIN
   OPEN job_cur;
   FETCH job_cur INTO job_rec;
   WHILE job_cur%FOUND LOOP
     by_hand := null;
    -- BEGIN
       get_state(job_rec.task_name, job_rec.job_name, job_state, job_fin_date, job_disabled, job_sess_id, job_marked, job_start_date);  -- NOT_WORKED, WORKING, FIN_ERROR, FIN_SUCCESS

       IF job_state = 'WORKING' THEN
         st := '0';
         FOR ww IN (
   --      select sid from v$session where audsid = to_number(-job_sess_id)
           select sid from v$session where sid = to_number(job_sess_id) and serial# = to_number(job_sess_id)
         ) LOOP
           st := '1';
         END LOOP;
         GOTO skp;
       END IF;

       IF job_rec.start_1 <> ':' AND job_rec.start_2 <> ':' AND job_disabled IS NULL THEN
         mins := to_number(to_char(sysdate,'hh24')) * 60 + to_number(to_char(sysdate,'mi'));
         s1 := to_number( substr(job_rec.start_1,1,2) ) * 60 + to_number( substr(job_rec.start_1,4,2) );
         s2 := to_number( substr(job_rec.start_2,1,2) ) * 60 + to_number( substr(job_rec.start_2,4,2) );
         IF s1 <= s2 THEN
           IF NOT mins BETWEEN s1 AND s2 THEN
             GOTO skp;
           END IF;
         ELSE
           IF NOT ( mins >= s1 OR mins <= s2 ) THEN
             GOTO skp;
           END IF;
         END IF;
       END IF;

       -- �� ����� ����� �������
       FOR deps IN (select * from shed_depends where task_name = job_rec.task_name and job_name = job_rec.job_name order by ord) LOOP
         get_state(deps.task_name, deps.dep_name, dep_state, dep_fin_date, dep_disabled, st, st1, job_start_date);
           IF NOT ( ( dep_state = 'FIN_SUCCESS' AND (dep_fin_date >= job_fin_date OR job_fin_date IS NULL) ) OR
                    ( dep_state IN('NOT_WORKED') AND deps.dep_name = deps.job_name )     -- ������� ���� �� ����, ��� ����� � ������ ��� �� ����������.
                  ) THEN                                                                 -- ���� ����������� ���������, �� ������� ��� �� ���������� - ����� ������� ������
             GOTO skp;
           END IF;
           IF dep_state = 'FIN_SUCCESS' THEN
             IF deps.dep_wait = ':' THEN
               deps.dep_wait := '0000:00';
             END IF;
             IF (sysdate - dep_fin_date) * 24 * 60 < to_number( substr(deps.dep_wait,1,4) ) * 60 + to_number( substr(deps.dep_wait,6,2) ) THEN
               GOTO skp;
             END IF;
           END IF;
         --END IF;
       END LOOP;

       <<m_start>>
       -- �������� ������ � ������
       CLOSE job_cur;
       EXIT;

       <<skp>>
    
     IF NOT job_cur%ISOPEN THEN
       EXIT;
     END IF;

     FETCH job_cur INTO job_rec;
   END LOOP;

   IF job_cur%ISOPEN THEN
     CLOSE job_cur;
   END IF;
   
 END;


 PROCEDURE dispatch(p_grp IN NUMBER := null)
 IS
  TYPE tbl_table IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER;
  tbl               tbl_table;
  mx                NUMBER;
  sys_date          DATE;
  dlt               NUMBER;
  agn               BOOLEAN;
 BEGIN
  mx := -1;
  FOR cc IN( select * from shed_tasks where active is not null and ( nvl(grp,0) = p_grp or p_grp is null )
              order by nvl(t_tryed, sysdate-300)
           ) LOOP
    mx := mx + 1;
    tbl(mx) := cc.task_name;
  END LOOP;

  dlt := 0;
  agn := true;
  WHILE agn LOOP
    FOR i IN 0..mx LOOP
      sys_date := sysdate;
      dispatch_(tbl(i), p_grp);
      IF sysdate - sys_date > 5/(24*60*60) THEN     -- 5 ������ ������, dispatch_() ���-�� �����. � ��������, ��� ����� �������� ������ ������.
        agn := false;                               -- ������ �����
        EXIT;
      END IF;
      dlt := dlt + 1/(24*60*60);
    END LOOP;
    EXIT;
  END LOOP;
 END;

begin
  while ii < 300 
  loop   
    dispatch(gr);
    ii := ii + 1;
  end loop;
  dbms_output.put_line('V0 grp = '||gr||' sec = '||trunc((sysdate-dt)*24*60*60));   
end;