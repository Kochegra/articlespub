select 1 a
--EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_STRING') adr
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_REGION') reg
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') city
,(select trim(translate(upper(value),'0123456789,',' ')) --upper(value) 
        from eid.eid_paramvalues pv where departid = s.id 
      and param_name = '�����_���������'
      and activated = (select max(activated) from eid.eid_paramvalues where departid= pv.departid and param_name = pv.param_name and activated < sysdate)) adr 
,s.*   
from eid.eid_subdepartments s where 1=1 and s.type = 301 and parent in 
(47,48,76,354,104,192,191,405,200,208,777,360,365,770,660,665,635,540,544,235,240,275,631,780,245,775,270) 
and EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') is null
and nvl(deleted,0) = 0 
--and id = 365030
/

select 1 a
--EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_STRING') adr
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_REGION') reg
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') city
--,eid.P_EID_PARAMVALUES.Get_Param('�����_���������',s.id) adr
--,eid.P_EID_PARAMVALUES.Get_Param('������_���������',s.id) reg
,(select upper(value) from eid.eid_paramvalues pv where departid = s.id 
      and param_name = '�����_���������'
      and activated = (select max(activated) from eid.eid_paramvalues where departid= pv.departid and param_name = pv.param_name and activated < sysdate)) adr 
,g.name
,g.code
,g.code1
--,substr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id))
--  ,instr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id)),'�.')
 -- ,instr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id)),','
 --   ,instr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id)),'�.'))
 --   -instr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id)),'�.')
 -- ) ccc
--,eid.P_EID_PARAMVALUES.Get_Param('�����_���������',id)
,s.*   
from eid.eid_subdepartments s, guides g where 1=1 and s.type = 301 and parent in 
(47,48,76,354,104,192,191,405,200,208,777,360,365,770,660,665,635,540,544,235,240,275,631,780,245,775,270) 
--and s.id like '133%'
and g.type_doc = 1364 and g.str2 = '�'
--and instr(upper(eid.P_EID_PARAMVALUES.Get_Param('�����_���������',s.id)),'�.'||upper(g.name)) > 0
and (select instr(trim(translate(upper(value),'0123456789,',' ')),'����� '||upper(g.name)||' ')
      from eid.eid_paramvalues pv where departid = s.id 
      and param_name = '�����_���������'
      and activated = (select max(activated) from eid.eid_paramvalues where departid= pv.departid and param_name = pv.param_name and activated < sysdate)) > 0 
--and rownum < 10
and EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') is null
--and s.id in (780573)
/

begin
  for rec in (select g.code,g.code1,s.*   
              from eid.eid_subdepartments s, guides g where 1=1 and s.type = 301 and parent in 
                  (47,48,76,354,104,192,191,405,200,208,777,360,365,770,660,665,635,540,544,235,240,275,631,780,245,775,270) 
                   and g.type_doc = 1364 and g.str2 = '�'                   
                   and (select  
                          instr(trim(translate(upper(value),'0123456789,',' ')),'����� '||upper(g.name)||' ')
                        from eid.eid_paramvalues pv where departid = s.id 
                         and param_name = '�����_���������'
                         and activated = (select max(activated) from eid.eid_paramvalues where departid= pv.departid and param_name = pv.param_name and activated < sysdate)) > 0 
                   --and rownum < 10
                   and EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') is null
            )       
 loop
   EID.P_EID_TOOLS_SUBDEP.LoadVariable(rec.id,sysdate,'������ �.�.',mbfilid,1,0,'ADR_CITY',rec.code1);
   EID.P_EID_TOOLS_SUBDEP.LoadVariable(rec.id,sysdate,'������ �.�.',mbfilid,1,0,'ADR_REGION',rec.code);
   commit;
 end loop;  
end; 
/


select * from eid.eid_subdepartments where type = 400 and nvl(deleted,0) = 0 
/

select rowid,s.* from eid.eid_subdep_variable s where
 subd_id in (275002,275035,275003)
--type like '%ADR%'

select upper(value) from eid.eid_paramvalues pv where departid = 133 
and param_name = '�����_���������'
and activated = (select max(activated) from eid.eid_paramvalues where departid= pv.departid and param_name = pv.param_name and activated < sysdate) 
/

select value from eid.eid_subdep_variable sv where sv.subd_id = nSUBD_ID and sv.status = 1
                  and sv.type = upper(sType) and ((sv.priority = nOnlyPriority) or (nOnlyPriority = 0))
                  and ((sv.reference_obj = nReferenceOuter and nReferenceOuter is not null) or (nReferenceOuter is null))
                  and ((sv.branch_obj = nBranchOuter and nBranchOuter is not null) or (nBranchOuter is null))
                  and sv.date_exec <= dDateExec_r
                  order by priority desc, date_exec desc, date_modify desc

select * from guides where type_doc = 1364 and str2 = '�'
 and upper(name) = '��������'
/

select rowid,z.* from zyx_guides z
--update zyx_guides set name = trim(name) 
 where type_doc = -1000 
 --and code like '14%' 

select * from guides where type_doc = 1362  and name like '%����%'

select * from guides where type_doc = 1363 and name like '�������%'
/

select * from guides where type_doc = 1364 and name like '������������' --  code = 14 
/

select z.name,g.name,g.*,z.* from zyx_guides z, guides g where 
g.type_doc = 1362
--g.type_doc = 1363 and g.code = '14' 
and instr(' '||z.name||' ',' '||g.name||' ') > 0 
--and instr(upper(z.name),upper(g.str2)) > 0 
--and z.name like '���������%' 
and z.code = '1' and z.type_doc = -1000 --and z.name like '%�����' 
/

select (select count(*) from guides g where 1=1 --g.type_doc = 1362 
and instr(' '||z.name||' ',' '||g.name||' ') > 0 
--and instr(upper(z.name),upper(g.str2)) > 0
 and g.type_doc = 1363 and g.code = '14' 
)
,z.* from zyx_guides z 
where z.code = '1' and z.type_doc = -1000
and z.name like '%�����' 
/
/
update zyx_guides z set code = nvl((select code1 from guides g where 1=1 --g.type_doc = 1362 
and instr(' '||z.name||' ',' '||g.name||' ') > 0 
 and g.type_doc = 1363 and g.code = '14' 
),code)
where z.code = '14' and z.type_doc = -1000
and z.name like '%�����' 
/

--��������� ���������  ������� ������
--insert into guides(BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,NUM1,CODE1)
select * from (select branch,folder,8929 type_doc,978042 owner,date_work,code,name,num1,substr(code,1,2) code1 from zyx_guides z where type_doc = -1000) g
where not exists (select null from guides where type_doc = g.type_doc and code = g.code and code1 = g.code1) 

select * from guides where type_doc = 8929
/

select * from parameters where name like '�����_���'

select rowid,z.* from variable_subdepartments z where name = 'TIME_ZONE' and depart_id in (275002,275035,275003,275502,275535,275503)
/


--��������� TIME_ZONE
select 1 a
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_STRING') adr
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_REGION') reg
,EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') city
,coalesce((select code from guides where type_doc = 8929 and code = EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'))
         ,(select code from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,5))
         ,(select code from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,2))
         ) ggg
,coalesce((select num1 from guides where type_doc = 8929 and code = EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'))
         ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,5))
         ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,2))
         ) tm          
,s.*   
from eid.eid_subdepartments s where 1=1 and s.type = 301 and parent in 
(47,48,76,354,104,192,191,405,200,208,777,360,365,770,660,665,635,540,544,235,240,275,631,780,245,775,270) 
and EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') is not null
and nvl(time_zone,100) <> coalesce((select num1 from guides where type_doc = 8929 and code = EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'))
         ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,5))
         ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,2))
         ,100)     
/

begin
  for rec in (
               select coalesce((select num1 from guides where type_doc = 8929 and code = EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'))
                      ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,5))
                      ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,2))
                       ) tmzone          
                    ,s.*   
                    from eid.eid_subdepartments s where 1=1 and s.type = 301 and parent in 
                      (47,48,76,354,104,192,191,405,200,208,777,360,365,770,660,665,635,540,544,235,240,275,631,780,245,775,270) 
                       and EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY') is not null
                     and nvl(time_zone,100) <> coalesce((select num1 from guides where type_doc = 8929 and code = EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'))
                                                       ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,5))
                                                       ,(select num1 from guides where type_doc = 8929 and code = substr(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'ADR_CITY'),1,2))
                                                       ,100)  
                                                     --  and rownum < 10
            )       
 loop
   update eid.eid_subdepartments set time_zone = rec.tmzone where id = rec.id;
  -- dbms_output.put_line('s.id = '||rec.id);     
   commit;
 end loop;  
end; 
/

select * from guides where type_doc = 8929 and code1 = 28

--�������� ���������
 select * from eid.eid_subdepartments s where 
 (id,parent) in (select id,parent from subdepartments start with id = 191 connect by prior id=parent)
 and time_zone is not null
/

declare
  res varchar2(4000);
  function add_paramvalues(depart number,p_name varchar2,p_value varchar2,p_date date := trunc(sysdate)) return varchar2
  is   
  begin   
    insert into PARAMVALUES  
    select * from (select p.id paramid,p.group_id paramgroupid,s.id departid,p_value value,p_date activated
                 from parameters p, subdepartments s, paramgroupmembership pg  
                 where 1=1 and pg.depart_id = s.id and pg.group_id = p.group_id
                   and s.id = depart  
                   and p.name = p_name
                  ) t
      where not exists (select null from paramvalues where  paramid = t.paramid and paramgroupid = t.paramgroupid and departid = t.departid and value = t.value and activated = t.activated);     
      return to_char(sql%rowcount);
  exception when OTHERS then
      return 'MB_ERROR '||sqlerrm;
  end;      
       
begin
  for rec in (
              select * from eid.eid_subdepartments s where 
               (id,parent) in (select id,parent from subdepartments start with id = 191 connect by prior id=parent)
                and time_zone is not null
                --and id = 2
              )
  loop
    insert into variable_subdepartments
    select * from (select 'TIME_ZONE' name, rec.id depart_id, 0 rownumber, to_char(rec.time_zone) value from dual) t
     where not exists (select null from variable_subdepartments where name = t.name and depart_id = t.depart_id);
    res := add_paramvalues(rec.id,'�����_���',to_char(rec.time_zone));
    commit;
  end loop;            
end; 
/

select global_parameters.get_param('�����_���',depart_id) tm,v.* from variable_subdepartments v where depart_id = 631312

select * from parameters where name like '�����_���'

select rowid,pv.* from paramvalues pv where paramid = 10279 and departid in (275002,275035,275003,275502,275535,275503)

select * from variable_subdepartments where name = 'TIME_ZONE' 
/

--��������� �� ��� ���������� 
select 
(select time_zone from eid.eid_subdepartments s where boss_subdep_id = e.boss_subdep_id and  time_zone is not null and id <> e.id and rownum < 2) dd 
,e.* from eid.eid_subdepartments e
--update eid.eid_subdepartments e set time_zone = (select time_zone from eid.eid_subdepartments s where boss_subdep_id = e.boss_subdep_id and  time_zone is not null and id <> e.id and rownum < 2)
where time_zone is null and boss_subdep_id in
(select boss_subdep_id from eid.eid_subdepartments s where time_zone is not null and nvl(boss_subdep_id,-1) <> -1)
/

select global_parameters.get_param('�����_���',id) TM, s.* from subdepartments s where 1=1 
--and global_parameters.get_param('�����_���',id) is not null
and id in (select num4 from zyx_store z where num1 = 47 and tbl = 'SUBDEPARTMENTS' and oper = 'FIL_191')
--and nvl(global_parameters.get_param('�����_���',id),'0') < 6
/



