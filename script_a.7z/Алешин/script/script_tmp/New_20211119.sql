/


select * from TMP_TABLES.ZYX_AR13_XLS z where 1=1 and ab = '4316' 
/

select * --mbfilid filial,'NAME_SUBDEP_FORMAL' name,s.id depart_id, z.c value 
from eid.v_subdep_all s, TMP_TABLES.ZYX_AR13_XLS z where 1=1 
and lpad(s.BIS_CODE,4,0) = z.ae
--and ref_code not in (768000,775000,776000,778000,773000,772000,771000,779000,422445)
and s.id = 191272
/

--�������� � eid ��������� BISQUIT_ID � DEPART_OUT c MAIN ������ ������
begin
  for rec in (
select mbfilid filial,'NAME_SUBDEP_FORMAL' name,s.id depart_id, z.c value from eid.v_subdep_all s, TMP_TABLES.ZYX_AR13_XLS z where 1=1 
and lpad(s.BIS_CODE,4,0) = z.ae
and ref_code not in (768000,775000,776000,778000,773000,772000,771000,779000,422445)
 )
  loop
    EID.P_EID_TOOLS_SUBDEP.LoadVariable(rec.depart_id,sysdate,'������ �.�.',rec.filial,1,0,rec.name,rec.value);
    commit;
  end loop;  
end;
/
)

select pledger.saldo('A',acc,'810',sysdate) ss, acc,sum(sld),count(*) from (
select COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) sld
 ,global_parameters.get_param(preport_fiz2.get_param_426(a.CONTRACT,a.BRANCH_CONTRACT,a.CODE),a.subdepartment,sysdate)  acc
 ,a.* from account a where header = 'X' and code like '40817%' and close_date is null
and currency = '810'
) group by acc

/

select * from (
select global_parameters.get_param(a.subdepartment,'����_40817_810',sysdate) a
,global_parameters.get_param(191,'����_9_40817_810',sysdate) a9cc
 ,a.* from account a where header = 'X' and code like '40817%' and close_date is null
and currency = '810'
) where acc is not null

select * from parameters where name like '����_0%'
--Id in (629,1364,1511,1366,4909)
--(5063,5130,5131,5132)
order by name

select paramid,value,count(*) from paramvalues where 1=1
--and value like '40817810%'
--and paramid not in (629,1364,1511,1366,4909) --,5063,5130,5131,5132)
and paramid = 2027
group by paramid,value



select * from contracts where type_doc = 12488


SELECT * FROM s_files_ovp s WHERE s.file_name = 'S0001OVP.211' 
AND reference = 4564706272 --505��
and s.assist_id = 205516919 --�� ���� ��������


select * from mb_od_log where start_time > sysdate-1
order by start_time

select * from mb_od_log where start_time > to_date('04.01.2021','dd.mm.yyyy') and start_time < to_date('08.01.2021','dd.mm.yyyy')
and stage = 2
order by start_time
/


select ptools_dep_info.retIDbyBIK('044525411') from dual
/
'���_�������'


select  code,decode(eid.p_eid_tools_subdep.getparam(code,'DEPART_OUT'),1,'BISQUIT',2,'CABS',7,'CFT','MBANK') abs
                        from table(eid.p_eid_tools_subdep.get_subdep_list_all(p_root=>0, tp1=>400, flags=>'ACCESS_MODE=-1'))
                        where CODE<>'405'
                        and BIK='044525411'
                        
                        
                        select ptools_dep_info.retCodeABS4BIK('') from dual
                        
                        ptools_dep_info.retAllDepartInfo(mbfilid, 'BIK') 
                        
                        ptools_dep_info.retCodeABS4BIK('044525411')