�� 13.03.2021 = 97583.48 GB
�� 20.03.2021 = 83277,37 GB (TBL_TASK_REPORT)
�� 04.04.2021 = 84649,53 GB

--delete script + redifination
EDK_DOC_VERSION
FILES_STORAGE
CROS_XML
CROS_XML_OUTPUT
BILL_PARAMS_DATA

--delete script archive + redifination
IMPEX_RECORDS
OTR_FSSP_PACKAGE
FSSP_QUERY
ZNO_ANSWER
EID.LOG_OPERATIONS

--delete + redifination
MBANK.GIS_GMP_EXCHAGE
MBANK.SKHOD_UNLOAD

--redefination
MBANK.IMAGES_DOC
MBANK.CLOB_BILL_PARAMS
MBANK.EDK_DOC_VERSION
MBANK.TBL_QUEUE_44FZDOCS_MB_MQ
MBANK.TBL_QUEUE_SKHOD_P497_MB_MQ --+
MBANK.FILES_STORAGE
REPORT_SRV.TBL_TASK_RESULT
OPAY.VARIABLE_OUT_PAYMENT
OPAY.OUT_PAYMENT
SMB_BASE.TBL_SMB_BASE
MBANK.CROS_XML
AXIOMA_FOBO_DEPOSIT_DATA 
AXIOMA_FOBO_SHED_DEPOSIT


--archive delete
select * from ZNO_ANSWER where zno_id 
select * from ZNO where date_load < trunc(sysdate)-180
select * from eid.LOG_OPERATIONS where date_work < '01jan2018'
select * from eid.log_actions where date_work < '01jan2018'

--archive truncate
select 'truncate table '||z.str3||'.'||z.str1||';'
--'drop table '||z.str3||'.'||z.str1||' purge;', replace(str5,'truncate','drop')
--select rowid
,z.* from ZYX_STORE z 
--update ZYX_STORE z set str5 = replace(str5,'truncate','drop'), status = -1 --str8 = 'DUMP'
where OPER = 'AR_INFO' and tbl = 'TABLE' 
and num3 = 0 and status = 1 and num6 = 1 
and str5 like '%truncate%' and nvl(num2,1) > 0 and str5 not like '%�������� redifination%'
--and dt_mod >= to_date('21.03.2021','dd.mm.yyyy')
and exists (select null from zyx_cont_cb where a= z.str3 and b = z.str1) 
and exists (select null from DBA_DEPENDENCIES where referenced_name = z.str1 and referenced_owner = z.str3)-- and referenced_type = 'TABLE' and name like 'SAS%')
and not exists (select null from DBA_DEPENDENCIES where referenced_name = z.str1 and referenced_owner = z.str3 and OWNER like 'CDCS%')
--and not exists (select null from sforms s where instr(upper(text),upper(z.str3||'.'||z.str1))>0)


select z.* from dba_tables z 
--update ZYX_STORE z set str5 = replace(str5,'truncate','drop'), status = -1 --str8 = 'DUMP'
where table_name like 'IN_QUERY1_OLD%'
--and exists (select null from zyx_cont_cb where a= z.str3 and b = z.str1) 
and not exists (select null from DBA_DEPENDENCIES where referenced_name = z.table_name and referenced_owner = z.owner)
and not exists (select null from sforms s where instr(upper(text),upper(z.table_name))>0)
and not exists (select null from shed_jobs s where instr(upper(text),upper(z.table_name))>0 or instr(upper(text1),upper(z.table_name))> 0 or instr(upper(text2),upper(z.table_name))> 0 )


select * from SCO_ANKETA.TBL_SCORING_RTDM
select * from MBANK_AUDIT.SCORING_FORMS_AUDIT where time > sysdate - 1

TB_LOG_TABLE
EID.WS_BLOB_OBJECTS

/
select * from zyx_cont_cb

--drop table AUDIT_TABLE_OLD purge; --���� �������

--������ �� ������
'IMAGES_DOC','OTR_FSSP_PACKAGE','IMPEX_RECORDS','VAR_IMPEX_DOC','FSSP_QUERY','ZNO_ANSWER','IMP_DOC'
,'TBL_SWIFT','TBL_SWIFT_STATUS_HIST','TBL_SWIFT_ACK','LOG_OPERATIONS','LOG_ACTIONS','B2L_AENT1_ARC'

eid.LOG_OPERATIONS
eid.LOG_ACTIONS

BUDGET2.B2L_AENT1_ARC
/


--������ IMAGES_PARENT � IMAGES_DOC
  declare 
     r_cnt_img number := 0;
     r_cnt number := 0;
     r_max number := 20001;
     dt_start date;          
     r_dt date;
     r_ref number;
     r_br number;
     r_dt_m date;
     r_ref_m number;
     r_br_m number;
   begin
     if USER <> 'MBANK_ARCH' then
       dbms_output.put_line('������ ����� ����������� ������ ������������� MBANK_ARCH');
       return; 
     end if;
     loop
       dbms_output.put_line('������� �������� ������� '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
       r_cnt_img := 0;
       r_cnt := 0; 
       dt_start := sysdate;
       r_dt := to_date('01.01.1990','dd.mm.yyyy');    
       r_dt_m := r_dt;   
       for ii in (select rowid rid,i.* from mbank.IMAGES_PARENT i where 1=1
--                 and operation = '3' and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj ) 
                   and operation = 'scoring_request_bm' and exists (select null from sco_anketa.TBL_SCORING_REF where reference_REQ = i.refer_obj and branch_REQ = i.branch_obj)
            --       and refer_obj = 5577598 and branch_obj = 47022
                   and rownum < r_max 
                 )
       loop
         delete mbank.IMAGES_DOC where reference = ii.refer_image and branch= ii.branch_image and image_type = ii.p_type;
         r_cnt_img :=  r_cnt_img + sql%rowcount;
         delete mbank.IMAGES_PARENT where rowid = ii.rid returning date_modify,refer_obj,branch_obj into r_dt,r_ref,r_br;
         if r_dt_m < r_dt then
           r_dt_m := r_dt; 
           r_ref_m := r_ref;
           r_br_m := r_br;
         end if;         
         r_cnt :=  r_cnt + sql%rowcount;
         commit;
       --  exit when r_cnt >= r_max;  
       end loop;
       if r_cnt > 0 then
         insert into mbank.zyx_store(OPER,TBL,str1,str2,num2,dt2,dt3,dt1,num1,num3,str3) values('INFO','DB_CLEAR','MBANK','IMAGES_PARENT',r_cnt,sysdate,dt_start,r_dt_m,r_ref_m,r_br_m,'scoring_request_bm');
       end if;
       if r_cnt_img > 0 then
         insert into mbank.zyx_store(OPER,TBL,str1,str2,num2,dt2,dt3,dt1,num1,num3,str3) values('INFO','DB_CLEAR','MBANK','IMAGES_DOC',r_cnt_img,sysdate,dt_start,r_dt_m,r_ref_m,r_br_m,'scoring_request_bm');
       end if;  
       commit;
       exit when r_cnt <= 0;
     end loop; 
     dbms_output.put_line('������� �������� �������� '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));            
   end; 
/


--��������������� 
set serveroutput on                                                               
begin
  for rr in (
  with tt as (select REFERENCE,IMAGE_TYPE,BRANCH from IMAGES_DOC_bmtst@MAINB)
       select d.rowid rid from IMAGES_DOC d, IMAGES_PARENT i
   where d.reference = i.refer_image and d.branch = i.branch_image and d.image_type = i.p_type 
   and i.operation = '3'
    and (i.branch_obj,i.refer_obj) in
     (select /*+ INDEX (sf SCORING_FORMS_PK)*/ branch,reference from mbank.scoring_forms sf where 1=1
--and branch > 50 and branch < 1000
--and branch >= 1000 and branch < 100000 
--and branch >= 100000 and branch < 191200 and branch <> 108000 
--and branch >= 191200 and branch < 191400
  and branch >= 191400
      and mod(reference,10) = nvl(&1,mod(reference,10))      
   )
   and not exists (select null from tt where REFERENCE = d.REFERENCE and branch = d.branch and IMAGE_TYPE = d.IMAGE_TYPE)
   )
  loop  
   insert into IMAGES_DOC_bmtst@mainb select * from IMAGES_DOC where rowid = rr.rid;
   commit;
  end loop;
  commit;
  rollback; 
  dbms_session.close_database_link('MAINB'); 
end;

/

begin
  for ii in (select rowid rid from IMAGES_DOC_BMTST d where 1=1 
             and not exists (select null from IMAGES_DOC where REFERENCE = d.REFERENCE and branch = d.branch and IMAGE_TYPE = d.IMAGE_TYPE)
             and mod(reference,10) = nvl(&1,mod(reference,10)) 
          )
  loop
    begin
      insert into IMAGES_DOC select * from IMAGES_DOC_BMTST where rowid = ii.rid;
      commit;
    exception when OTHERS then
      rollback;
    end;
  end loop;           
end;
/






declare 
  dt timestamp;
  nn number;
begin
  for rr in (select z.* from ZYX_STORE z where OPER = 'AR_INFO' and tbl = 'TABLE' 
              and num3 = 0 and status = 1 and num6 = 1 
             and str5 like '%truncate%' and nvl(num2,1) > 0 and str5 not like '%�������� redifination%'
    and exists (select null from zyx_cont_cb where a= z.str3 and b = z.str1) 
   and exists (select null from DBA_DEPENDENCIES where referenced_name = z.str1 and referenced_owner = z.str3)-- and referenced_type = 'TABLE' and name like 'SAS%')
   and exists (select null from DBA_DEPENDENCIES where referenced_name = z.str1 and referenced_owner = z.str3 and OWNER like 'CDCS%')
            )
loop
  begin
    execute immediate 'select max(DML_TS),count(*) from CDCS.CDC_LOG$'||rr.str1 into dt,nn;    
    dbms_output.put_line(rr.str3||'.'||rr.str1||' -> '||to_char(dt,'dd.mm.yyyy')||'  -- '||nn);
  exception when OTHERS then
    dbms_output.put_line(rr.str3||'.'||rr.str1||' -> '||sqlerrm);
  end;  
end loop;
end