drop table TMP_YAG_PARAMVALUES_BAD 
drop table TMP_YAG_PARAMVALUES_CURRENT  
drop table TMP_YAG_PARAMVALUES_GOOD
/

select t.* from B2_HR.bmv_mbank_emp@BOSS t 
where d_in > sySdate-10
 
l_name = '������' and f_name = '�����'


select t.* from B2_HR.bmv_mbank_portal@BOSS t 
where d_in > sySdate-10


 SELECT * FROM B2_HR.bmv_mbank_portaldept@boss where id = 149842
 
 select * from boss_subdepartments where sap_id is not null --50188871
 /
 
select rowid,t.* from account t where code like '40820978_10444002014' 
/

SELECT * FROM MESSAGES
/

insert into guides@vtbmain
select * from guides where type_doc = 14009
/      
         
              select * from audit_table where reference = -24 and table_name not in ('USERS') and time > sysdate-3  
              
              select trunc(date_load), count(*) from text_files
              group by trunc(date_load)
              
              
                Administrative_Tools.PurgeAudit;
                /
                
delete PACKAGE_CARDS
                
truncate table TBL_QUEUE_SPR_RNCB_MQ_MB

               select * from TBL_QUEUE_PAYFIND_SZRC_MB_MQ  --where INS_DATE < sysdate-1000

select min(mod_dt),max(mod_dt) from TBL_QUEUE_PKB_CLIENT_MB_MQ
  
 select * from dba_dependencies where type not in ('SYNONYM')
 and referenced_name = 'CONT_FIN_STATE'                         
 
PKG_INTGR_BPMOSNOR
               select * from UIDS where guid = 'ZmY5MDQ3MjYzOWExMTFlOTkyODgwMDUw'
               
               send_id is not null
               ask_id is not null
               --update TBL_QUEUE_KFT_MB_MQ set mod_dt = create_dt 
                                            
               select min(mod_dt),max(mod_dt) from TBL_QUEUE_SMGOZ_MB_MQ
                              
               select count(*) from TBL_QUEUE_EFR_MB_MQ
                
                /
    P_AXIOMA_DEALS         
--  delete TBL_QUEUE_EFR_MB_MQ where mod_dt is null and rownum < 13001                
                
                truncate table balance
                
                select * from text_files
                /
                
                select dbms_metadata.get_ddl('TABLE','TEXT_FILES','MBANK') from dual
                /
                
            
          select rowid,t.* from documents t where reference in (4661182236,4660850008,4662763364,4661202829,4664671599,4661216616)
          
          
       select * from boss_subdepartments
       /
       
       
      select str1 from ZYX_STORE z where OPER = 'AR_INFO' and tbl = 'TABLE' and nvl(num4,0) = 0 
       
       select * from dba_objects where status = 'INVALID' and owner in ('MBANK','EID') order by last_ddl_time desc
       /
       
       select code,str3,str4 from guides t where type_doc = 11888 and nvl(date2,sysdate) > trunc(sysdate) 
       /
       
       select * from eid.v_filial_all
       /
       
       select rowid,t.* from documents t where reference = 4752096275
       
       select rowid,t.* from audit_table t where reference = 4745812333
       /
insert into  journal
--     
     
     select related+to_date('01.01.2000','dd.mm.yyyy'),trunc(sysdate)-400-to_date('01.01.2000','dd.mm.yyyy'), d.* from journal_delete d where docnum = 4745812333
     /
   
  select  from journal_delete j where related < (trunc(sysdate)-400-to_date('01.01.2000','dd.mm.yyyy'))
     
    select 
  /*+ FIRST_ROWS INDEX_ASC ( TT JOURNAL_DEL_RELATED_IDX) */ * from journal_delete TT
    where related < (trunc(sysdate)-400-to_date('01.01.2000','dd.mm.yyyy')) and rownum < 10001
   
  /
     select t.* from TBL_QUEUE t where 1=1 and nvl(STORAGE_DEPTH,0) = 0 and enbl = 1
     

select * from 

--drop table CONTRACTS_PEN_SCORE purge
/

--truncate table zyx_cont_cb 
--insert into zyx_cont_cb(A,B)
select substr(image_type,1,5),count(*) from IMAGES_DOC
 where (reference,branch) in (select reference,branch from eid.eid_picture) -- where eid = 5771981)
group by substr(image_type,1,5)
 
/

select * from zyx_cont_cb 
/

select * from eid.eid_picture
/

select t.*, cnt_all-cnt_scor_new-cnt_scor-cnt_ul  from (
select count(*) over() cnt_all
,sum((select count(distinct reference_REQ||'-'||branch) from sco_anketa.TBL_SCORING_REF where reference_REQ = i.refer_obj and branch_REQ = i.branch_obj and i.operation = 'scoring_request_bm')) over() cnt_scor_new
,sum((select count(distinct reference||'-'||branch) from scoring_forms where reference = i.refer_obj and branch = i.branch_obj and i.operation = '3')) over() cnt_scor
,sum((select count(distinct eid) from eid.eid_firma where eid = i.refer_obj and i.branch_obj = 0 and i.operation = 'ECP_SCAN')) over() cnt_UL
from  IMAGES_PARENT i
) t
/

select cnt_all-(cnt_scor_n+cnt_scor+cnt_ul+cnt_fl+cnt_zp+cnt_doc_and_lost+cnt_hypo_lost+cnt_kmb) cnt_other
 , t.*  from (
select count(*) over() cnt_all
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = 'scoring_request_bm' --and (refer_obj,branch_obj) in (select reference_REQ,branch_REQ from sco_anketa.TBL_SCORING_REF )
     )) over() cnt_scor_n
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '3' and (refer_obj,branch_obj) in (select reference,branch from scoring_forms ))) over() cnt_scor
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '3' and (refer_obj,branch_obj) not in (select reference,branch from scoring_forms ))) over() cnt_doc_and_lost   
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '0' and (refer_obj,branch_obj) in (select reference,branch from hypo_forms))) over() cnt_hypo
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = '0' and (refer_obj,branch_obj) not in (select reference,branch from hypo_forms))) over() cnt_hypo_lost
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type     
     and (refer_obj,branch_obj,operation) in (select eid,0,'ECP_SCAN' from eid.eid_firma))) over() cnt_UL
,sum((select count(distinct reference||'-'||branch) from eid.eid_picture  where reference = d.reference and branch = d.branch and d.image_subtype =1)) over() cnt_fl  
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type and operation = 'SALARY_REESTR_SCAN')) over() cnt_zp
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = 'CA_SMB'  )) over() cnt_kmb --������ ������ ������ �������
,sum((select count(distinct refer_image||'-'||branch_image||'-'||p_type) from IMAGES_PARENT where refer_image = d.reference and branch_image = d.branch and p_type = d.image_type
     and operation = 'SCAN_DOVER'  )) over() cnt_dov --������ �������������    
,d.*
 from images_doc d --where branch = 174 and reference < 170000 
)
t

 
select refer_image,branch_image,count(*) from TMP_TABLES.ZYX_IMAGES_HYPO
group by refer_image,branch_image order by count(*) desc

select * from eid.eid_picture p, images_doc d where p.reference = d.reference and p.branch = d.branch 
and image_subtype = 1 
/

select refer_image,branch_image from images_doc_hypo
minus
select reference,branch from IMAGES_DOC d

/
SAFE_SCAN
SALARY_REESTR_SCAN
SIGN_SCAN_MODIFY
VYSOTA_PKG
777

select * from IMAGES_DOC d, IMAGES_PARENT p
where p.refer_image = d.reference and p.branch_image = d.branch 
and (refer_obj,branch_obj) in
 (select eid,0 from eid.eid_firma) and operation = 'ECP_SCAN' 

select * from IMAGES_PARENT p
where (refer_obj,branch_obj) in
 --(select reference_REQ,branch_REQ from sco_anketa.TBL_SCORING_REF s) and operation <> 'scoring_request_bm'
-- (select reference,branch from scoring_forms ) and operation = '3'
(select eid,0 from eid.eid_firma) and operation = 'ECP_SCAN'
--and refer_obj = 6136237
 
select rowid,i.* from IMAGES_PARENT i where refer_obj in (4207624,4207624,4207624,4207624)

select reference,branch from scoring_forms where open_date > sysdate -1000 
/
select * from guides where type_doc = 5146 

select code from guides where type_doc = 441
/
select * from eid.eid_human where eid = 320
/

select * from 
--delete
images_doc d where 
--(reference,branch)  in 
--(select reference,branch from eid.eid_picture p )
--and image_subtype <> 1 
(select refer_image,branch_image from TMP_TABLES.ZYX_IMAGES_HYPO)

select * from eid.eid_picture p, images_doc d where p.reference = d.reference and p.branch = d.branch 
and image_subtype = 1 and 

select * from images_doc_hypo i, images_doc d where d.reference = i.refer_image and d.branch = i.branch_image 

select refer_image,branch_image from images_doc_hypo
minus
select refer_image,branch_image from IMAGES_PARENT where operation not in ('scoring_request_bm','3','0','777')
--minus
--select reference,branch from eid.eid_picture -- where reference = d.reference and branch = d.branch and d.image_subtype =1

select * from images_doc_hypo where  refer_image = 875152 and branch_image = 10  
refer_hypo = 241 and branch_hypo = 191189 

select * from hypo_forms where reference = 241 and branch = 191189

select * from IMAGES_PARENT where refer_image = 311000 and branch_image = 373000 
311000	373000	23	15

select * from images_doc where branch = 191189 and reference in (302,303,304,305,306,307,308)

select * from eid.eid_picture


select * from IMAGES_PARENT where operation = 'SALARY_REESTR_SCAN'

 and image_type not in (select code from guides where type_doc = 441) and image_type not like 'EHMOD%'
and d.date_modify = to_date('19.06.2020 17:58:50','dd.mm.yyyy hh24:mi:ss')

(select * from eid.eid_firma where eid = 2587)



 
