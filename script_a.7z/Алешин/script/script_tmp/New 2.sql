--select * from mb_od_log where start_time >= '14mar2019'
select round(vsum*pledger.WCOURSE(currency,work_date),2) V, j.* from journal j where docnum in 188760347--(188760295,188760297,188760298,188760347)
order by journal_id
/
select rowid,d.* from config d where name = 'ARCHIVE_CLOSE_DATE'
/
--insert into journal_zp 
select * from journal
--delete journal
--where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978))
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (188760295,188760297,188760298,188760347)
)
--and header = 'X'
/
72,63 70606810400654620101

--insert into journal
select * from journal_zp
--select rowid,j.* from journal_zp j
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in
(188760295,188760297,188760298,188760347) 
)
/

--insert into journal
select j.* from journal_delete j
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3113523276,3113550890))
--and users = 1403

/


select
round(debit*pledger.WCOURSE(currency,work_date),2) d
,round(credit*pledger.WCOURSE(currency,work_date),2) c 
,round(saldo*pledger.WCOURSE(currency,work_date),2) s
,b.* from bank_balance b where bal = 42301 and currency = '840' and work_date = '13mar2019'