select * from config

select * from zyx_excel1

select * from account where modify_date > sysdate-10
/

select * from bank_balance 
/

truncate table zyx_excel reuse STORAGE cascade;
truncate table zyx_cont_cb drop STORAGE 

truncate table zyx_excel1 drop STORAGE cascade;
/

truncate table account drop STORAGE 
/

select max(related) from journal 

select * from PERCENT_CONTRACTS --where related > 7353

----


truncate table JOURNAL drop STORAGE  --9 min

truncate table LEDGER drop STORAGE  -- < 1 min

--truncate table ICB_LEDGER drop STORAGE  -- ����� �����-�� ������

truncate table VARIABLE_ACCOUNT drop STORAGE  -- < 1 min

alter table VARIABLE_ACCOUNT disable constraint VAR_ACCOUNT_FK;
alter table JOURNAL disable constraint JOURNAL_FK;
alter table LEDGER disable constraint LEDGER_FK;
alter table ICB_LEDGER disable constraint ICB_LEDGER_FK;
truncate table ACCOUNT drop STORAGE;
alter table VARIABLE_ACCOUNT enable constraint VAR_ACCOUNT_FK;
alter table JOURNAL enable constraint JOURNAL_FK;
alter table LEDGER enable constraint LEDGER_FK;
alter table ICB_LEDGER enable constraint ICB_LEDGER_FK;

truncate table VARIABLE_ARCHIVE drop STORAGE --6 min

alter table VARIABLE_ARCHIVE disable constraint VAR_ARC_FK;
truncate table ARCHIVE drop STORAGE; --4 min
alter table VARIABLE_ARCHIVE enable constraint VAR_ARC_FK;

truncate table TEMPLATES drop STORAGE --< 1 min

truncate table VARIABLE_DOCUMENTS drop STORAGE -- 1 min

truncate table VARIABLE_DOCUMENTS_INT3 drop STORAGE --< 1 min

alter table VARIABLE_DOCUMENTS disable constraint VAR_DOC_FK;
alter table VARIABLE_DOCUMENTS_INT3 disable constraint TMP$$_VAR_DOC_FK0;
alter table TEMPLATES disable constraint TEMPLATE_FK;
truncate table DOCUMENTS drop STORAGE;
alter table VARIABLE_DOCUMENTS enable constraint VAR_DOC_FK;
alter table VARIABLE_DOCUMENTS_INT3 enable constraint TMP$$_VAR_DOC_FK0;
alter table TEMPLATES enable constraint TEMPLATE_FK;

truncate table VARIABLE_CONTRACTS drop STORAGE --1 min

truncate table CONTRACTS_SALARY drop STORAGE --< 1 min

truncate table PERCENT_CONTRACTS drop STORAGE --< 1 min

truncate table TAXS_CONTRACTS drop STORAGE --< 1 min

truncate table COLLECTOR_PERCENT drop STORAGE --< 1 min

-- PACKAGE_CARDS
-- CONTRACT_PARAMS_HIST
--CONT_FIN_STATE
--CONTRACTS_IFRS9_FEE_AMORT
--CONTRACTS_IFRS9_EVENTS_AC
--CONTRACTS_EVENTS
--VARIABLE_TAX_CONTRACTS
--CONTRACTS_IFRS9_FEE_WORK

truncate table CONTRACTS_ASSIGNMENT drop STORAGE --< 1 min

truncate table CHANGE_COLLECTOR_CONTRACTS drop STORAGE --< 1 min

truncate table COLLECTOR_CONTRACTS drop STORAGE --< 1 min

truncate table REST_CONTRACTS drop STORAGE --< 1 min

truncate table TBL_RES_AUTHORIZED_ORGAN drop STORAGE --< 1 min

truncate table CONTRACTS_IFRS9_FEE_WORK drop STORAGE --< 1 min

truncate table CONTRACTS_IFRS9_EVENTS_CF drop STORAGE --< 1 min

truncate table CONTRACTS_IFRS9_EVENTS_CF drop STORAGE --< 1 min

truncate table CONTRACTS_MT940_RECEIVERS drop STORAGE --< 1 min

truncate table CARD_CORP_CFT_CHG_CASHBOX drop STORAGE --< 1 min

alter table VARIABLE_TAX_CONTRACTS disable constraint VAR_TAX_CONTRACTS_FK;
truncate table TAX_CONTRACTS drop STORAGE; --< 1 min
alter table VARIABLE_TAX_CONTRACTS enable constraint VAR_TAX_CONTRACTS_FK;

truncate table GARANT_FTS_INVOICE drop STORAGE --< 1 min

alter table GARANT_FTS_INVOICE disable constraint GARANT_FTS_INVOICE_FK;
truncate table GARANT_FTS drop STORAGE; --< 1 min
alter table GARANT_FTS_INVOICE enable constraint GARANT_FTS_INVOICE_FK;

truncate table JUDG_DOC_ASSOC drop STORAGE --< 1 min

alter table JUDG_DOC_ASSOC disable constraint CR_JUDG_DOC_ASSOC_JUDG;
truncate table JUDGMENT drop STORAGE; --< 1 min
alter table JUDG_DOC_ASSOC enable constraint CR_JUDG_DOC_ASSOC_JUDG;

truncate table CONTRACTS_IFRS9_CASHFLOW_CFT drop STORAGE --< 1 min

alter table CONTRACTS_IFRS9_CASHFLOW_CFT disable constraint CONTRACTS_IFRS9_CASHFLOW_CFTFK;
truncate table CONTRACTS_IFRS9_CASHFLOW drop STORAGE; --< 1 min
alter table CONTRACTS_IFRS9_CASHFLOW_CFT enable constraint CONTRACTS_IFRS9_CASHFLOW_CFTFK;

alter table CONTRACTS_IFRS9_FEE_WORK disable constraint CONTRACTS_IFRS9_FEE_WORK_FK3;
truncate table CONTRACTS_IFRS9_MODEL drop STORAGE; --< 1 min
alter table CONTRACTS_IFRS9_FEE_WORK enable constraint CONTRACTS_IFRS9_FEE_WORK_FK3;

truncate table CONTRACTS_IFRS9_EVENTS_OP drop STORAGE --< 1 min

alter table CONTRACTS_IFRS9_FEE_AMORT disable constraint CONTRACTS_IFRS9_FEE_AMORT_FK2;
alter table CONTRACTS_IFRS9_FEE_WORK disable constraint CONTRACTS_IFRS9_FEE_WORK_FK2;
alter table CONTRACTS_IFRS9_EVENTS_CF disable constraint CONTRACTS_IFRS9_EVENTS_CF_FK2;
alter table CONTRACTS_IFRS9_EVENTS disable constraint CONTRACTS_IFRS9_EVENTS_FK1;
alter table CONTRACTS_IFRS9_EVENTS_OP disable constraint CONTRACTS_IFRS9_EVENTS_OP_FK;
alter table CONTRACTS_IFRS9_MODEL disable constraint CONTRACTS_IFRS9_MODEL_FK2;
alter table CONTRACTS_IFRS9_CASHFLOW disable constraint CONTRACTS_IFRS9_CASHFLOW_FK2;
alter table CONTRACTS_IFRS9_EVENTS_AC disable constraint CONTRACTS_IFRS9_EVENTS_AC_FK2;
truncate table CONTRACTS_IFRS9_EVENTS drop STORAGE; --< 1 min
alter table CONTRACTS_IFRS9_FEE_AMORT enable constraint CONTRACTS_IFRS9_FEE_AMORT_FK2;
alter table CONTRACTS_IFRS9_FEE_WORK enable constraint CONTRACTS_IFRS9_FEE_WORK_FK2;
alter table CONTRACTS_IFRS9_EVENTS_CF enable constraint CONTRACTS_IFRS9_EVENTS_CF_FK2;
alter table CONTRACTS_IFRS9_EVENTS enable constraint CONTRACTS_IFRS9_EVENTS_FK1;
alter table CONTRACTS_IFRS9_EVENTS_OP enable constraint CONTRACTS_IFRS9_EVENTS_OP_FK;
alter table CONTRACTS_IFRS9_MODEL enable constraint CONTRACTS_IFRS9_MODEL_FK2;
alter table CONTRACTS_IFRS9_CASHFLOW enable constraint CONTRACTS_IFRS9_CASHFLOW_FK2;
alter table CONTRACTS_IFRS9_EVENTS_AC enable constraint CONTRACTS_IFRS9_EVENTS_AC_FK2;

alter table VARIABLE_CONTRACTS disable constraint VAR_CONTRACT_FK;
alter table CONTRACTS_SALARY disable constraint CONTRACTS_SALARY_ID_FK;
alter table PERCENT_CONTRACTS disable constraint PERCENT_CONTRACT_FK;
alter table TAXS_CONTRACTS disable constraint TAXS_CONTRACT_FK;
alter table COLLECTOR_PERCENT disable constraint COLLECTOR_PERCENT_FK;
alter table PACKAGE_CARDS disable constraint PACKAGE_CARDS_FK;
alter table TAX_CONTRACTS disable constraint TAX_CONTR_FK;
alter table CONTRACTS_ASSIGNMENT disable constraint CONTRACTS_ASSIGNMENT_FK;
alter table CHANGE_COLLECTOR_CONTRACTS disable constraint CHANGE_COLLECTOR_CONTRACT_FK;
alter table REST_CONTRACTS disable constraint REST_CONTRACT_FK;
alter table CONTRACT_PARAMS_HIST disable constraint CONTRACT_PARAMS_HIST_FK;
alter table COLLECTOR_CONTRACTS disable constraint COLLECTOR_CONTRACT_FK;
alter table GARANT_FTS disable constraint GARANT_FTS_FK;
alter table JUDGMENT disable constraint CR_JUDGMENT_CONTRACT;
alter table TBL_RES_AUTHORIZED_ORGAN disable constraint FK_RES_AUT_ORGAN$CONTR;
alter table CONT_FIN_STATE disable constraint CONT_FIN_STATE_FK;
alter table CONTRACTS_IFRS9_EVENTS disable constraint CONTRACTS_IFRS9_EVENTS_FK2;
alter table CONTRACTS_IFRS9_FEE_WORK disable constraint CONTRACTS_IFRS9_FEE_WORK_FK1;
alter table CONTRACTS_IFRS9_EVENTS_CF disable constraint CONTRACTS_IFRS9_EVENTS_CF_FK1;
alter table CONTRACTS_IFRS9_FEE_AMORT disable constraint CONTRACTS_IFRS9_FEE_AMORT_FK1;
alter table CONTRACTS_IFRS9_MODEL disable constraint CONTRACTS_IFRS9_MODEL_FK1;
alter table CONTRACTS_IFRS9_CASHFLOW disable constraint CONTRACTS_IFRS9_CASHFLOW_FK1;
alter table CONTRACTS_IFRS9_EVENTS_AC disable constraint CONTRACTS_IFRS9_EVENTS_AC_FK1;
alter table CONTRACTS_EVENTS disable constraint CONTRACTS_EVENTS_FK2;
alter table CONTRACTS_MT940_RECEIVERS disable constraint CONTRACTS_MT940_REC_FK;
alter table CARD_CORP_CFT_CHG_CASHBOX disable constraint CFT_CHG_CASHBOX_FK_CONTRACT;
alter table OPERATION_V_ACC disable constraint OPERATION_V_ACC_FK1;
truncate table CONTRACTS drop STORAGE; --2 min
alter table VARIABLE_CONTRACTS enable constraint VAR_CONTRACT_FK;
alter table CONTRACTS_SALARY enable constraint CONTRACTS_SALARY_ID_FK;
alter table PERCENT_CONTRACTS enable constraint PERCENT_CONTRACT_FK;
alter table TAXS_CONTRACTS enable constraint TAXS_CONTRACT_FK;
alter table COLLECTOR_PERCENT enable constraint COLLECTOR_PERCENT_FK;
alter table PACKAGE_CARDS enable constraint PACKAGE_CARDS_FK;
alter table TAX_CONTRACTS enable constraint TAX_CONTR_FK;
alter table CONTRACTS_ASSIGNMENT enable constraint CONTRACTS_ASSIGNMENT_FK;
alter table CHANGE_COLLECTOR_CONTRACTS enable constraint CHANGE_COLLECTOR_CONTRACT_FK;
alter table REST_CONTRACTS enable constraint REST_CONTRACT_FK;
alter table CONTRACT_PARAMS_HIST enable constraint CONTRACT_PARAMS_HIST_FK;
alter table COLLECTOR_CONTRACTS enable constraint COLLECTOR_CONTRACT_FK;
alter table GARANT_FTS enable constraint GARANT_FTS_FK;
alter table JUDGMENT enable constraint CR_JUDGMENT_CONTRACT;
alter table TBL_RES_AUTHORIZED_ORGAN enable constraint FK_RES_AUT_ORGAN$CONTR;
alter table CONT_FIN_STATE enable constraint CONT_FIN_STATE_FK;
alter table CONTRACTS_IFRS9_EVENTS enable constraint CONTRACTS_IFRS9_EVENTS_FK2;
alter table CONTRACTS_IFRS9_FEE_WORK enable constraint CONTRACTS_IFRS9_FEE_WORK_FK1;
alter table CONTRACTS_IFRS9_EVENTS_CF enable constraint CONTRACTS_IFRS9_EVENTS_CF_FK1;
alter table CONTRACTS_IFRS9_FEE_AMORT enable constraint CONTRACTS_IFRS9_FEE_AMORT_FK1;
alter table CONTRACTS_IFRS9_MODEL enable constraint CONTRACTS_IFRS9_MODEL_FK1;
alter table CONTRACTS_IFRS9_CASHFLOW enable constraint CONTRACTS_IFRS9_CASHFLOW_FK1;
alter table CONTRACTS_IFRS9_EVENTS_AC enable constraint CONTRACTS_IFRS9_EVENTS_AC_FK1;
alter table CONTRACTS_EVENTS enable constraint CONTRACTS_EVENTS_FK2;
alter table CONTRACTS_MT940_RECEIVERS enable constraint CONTRACTS_MT940_REC_FK;
alter table CARD_CORP_CFT_CHG_CASHBOX enable constraint CFT_CHG_CASHBOX_FK_CONTRACT;
alter table OPERATION_V_ACC enable constraint OPERATION_V_ACC_FK1;

select * from CONTRACTS

truncate table ENT_OBJ_ACNT drop STORAGE --������ �� ������� 

truncate table TBL_SCHEDULE_EVENT drop STORAGE --������� �������� �� ���������

truncate table TBL_CONNECT_EVENT drop STORAGE -- ?

truncate table TBL_PLAN_EVENT drop STORAGE --������� �� ���������

truncate table TBL_PLAN_EV_TO_REG_TRANS drop STORAGE --������ � ������������

alter table TBL_PLAN_EV_TO_REG_TRANS disable constraint FK_RASPR_TO_REG_TR$RASPR;
truncate table TBL_LINK_PLAN_EVENT_TO_RASPR drop STORAGE; --TBL_LINK_PLAN_EVENT_TO_RASPR
alter table TBL_PLAN_EV_TO_REG_TRANS enable constraint FK_RASPR_TO_REG_TR$RASPR;

alter table TBL_CONNECT_EVENT disable constraint FK_CONNECT_EVENT$PLAN;
alter table TBL_LINK_PLAN_EVENT_TO_RASPR disable constraint FK_PLAN_EV_TO_RASPR$EV;
truncate table TBL_PLAN_EVENT drop STORAGE;  --< 1
alter table TBL_CONNECT_EVENT enable constraint FK_CONNECT_EVENT$PLAN;
alter table TBL_LINK_PLAN_EVENT_TO_RASPR enable constraint FK_PLAN_EV_TO_RASPR$EV;

select * from
--delete 
TBL_REG_TRANSACTION where EOBJ_ID in 
(select EOBJ_ID from TBL_ENTITY_OBJECT where ARCHETYPE_KEY = 'CONTRACT')

truncate table bank_balance

select * from TBL_PLAN_EV_TO_REG_TRANS --������ �� ������� 

--select * from 
 