select * from contracts where type_doc = 12457 and date_open > sysdate-5 

subdepartment = 405007
/

select rowid,t.* from documents t where reference in (5051935, 5051934) 

select rowid,t.* from archive t where related = 5051934

5051935

select rowid,t.* from variable_documents t where reference in (5059319) 

select variable_doc_id.nextval from dual

COMPDOC_STATUS
30913249
30913250
/

5059319
/

declare
n number;
v1 varchar2(4000);
v2 varchar2(4000);
usr number;
begin
 for dd in (
  --select * from documents where reference in (5065838,5065839,5068438)
  select * from archive where reference in (5066918)  
  )
 
 loop
  -- mbank.ptools2.short_init_user (dd.owner);
   mbank.ptools2.short_init_user (1403);
   n := 0; v1 := null; v2 := null;     
   dbms_output.put_line('dd > '||start_process.WORKING(1, 11, dd.branch, dd.reference, null, n)); --11 �������
  -- dbms_output.put_line('dd > '||start_process.WORKING(1, 10112, dd.branch, dd.reference, null, n)); --���������� � ���������
   --dbms_output.put_line(DOCALGO.execdoc(191346 , 2257520376, 956763649, n, v1, v2));
 end loop; 
end;
/

select rowid,c.* from config c where name like 'CORP_OVERDRAFT_NEW_OPER'

select global_parameters.get_param(user_id,'���������_44��',sysdate), u.* from users u where user_id = 2025037473

select rowid, u.* from users u where user_id = 1403
/

selecT * from documents where type_doc = 226 and status = 35 and date_work > sysdate-3 and owner not in (1403,2025037473)


selecT * from documents_all where reference in (5066918)

docalgo

select rowid,v.* from variable_documents v where reference in (5059319,5054114)

select rowid,v.* from variable_documents v where reference = 5059316 EXEC2FREE

select * from parameters where name = 'OCR_2'

select * from contracts where reference = 558911

select rowid,v.* from variable_contracts v where reference in (558911,555661)

select * from documents where status = 16

select * from account where code = '40702810250000002135'