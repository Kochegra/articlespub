
select * from guides where type_doc = 13826

--insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,STR1,DATE1,CODE1)
select * from ( select 191,0, 13826 TYPE_DOC,978042 owner, '01jan1990' DATE_WORK, to_char(s.id) CODE, s.id STR1, trunc(sysdate) DATE1
,coalesce(global_parameters.get_param('�����_���24_���������',id),global_parameters.var_subdepartments(id,'BUSQUIT_ID'),' ')
 from subdepartments s where date_close is null and parent = 191 and global_parameters.get_param('�����_���24',id) = '1') g
where not exists (select null from  guides where type_doc = g.type_doc and code = g.code) -- and code1 = code and str3 = g.str3) 

insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,STR1,DATE1,CODE1)
select * from (select BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,'405011' code,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1 from guides where 
type_doc = 10036 and code = '405000' and str4 in (1,13,14,16,21,23,31,35,43,44,46,5,51)) g
where not exists (select null from  guides@vtbmain where type_doc = g.type_doc and code = g.code and str4 = g.str4 and str3 = g.str3) 
/

   select fwa.doc17_filialid as filialid,
          fwa.doc17_reference, fwa.doc17_branch,
          fwa.cont94_reference, fwa.cont94_branch,
          fwa.cont94_account,
          fwa.id
     from tbl_firm_wizard_accnt fwa
    where fwa.eobj_id=i_eobj_id
      and fwa.doc4607_reference is null
      
      select rowid,t.* from tbl_firm_wizard_accnt t where eobj_id = 105042592
      
      select * from tbl_firm_wizard where doc_number = 390612 
      
      select rowid,d.* from documents d where reference =  4276819102
      
      
   select * from (
select --(select count(*) from users where subdepartment = z.num4 and job not in (31445))
0 cnt 
,(select count(*) from account where close_date is null and header in ('A','B','C','D','X') 
 and subdepartment = z.num4 and branch <> z.num1 and open_date < z.dt1
 and bal not in (60309,70601,70606,55555,47422,47426)) cnt_a
,z.* from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 780
--and dt1 > sysdate-1
) t
where cnt + cnt_a > 0
--and (select count(*) from users where subdepartment = z.num4 and job not in (31445)) > 0
/

select * from users u where subdepartment = 780421
and exists (select null from all_users where username = u.user_) 

select * from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
and tbl = 'USERS' and obj_id = 63313
/


update contracts set subdepartment = 275504  
where (branch,reference) in (select branch_contract,contract from account where subdepartment = 275405)  


select * from account
where subdepartment = 780449 and branch <> 780
 and close_date is null and open_date < '11jul2020'
 and bal not in (60309,70601,70606,55555,47422,47426)


              select universe.namedepart(ar13.Migr_SubId(psubdepartment.Get_Subd_Boss(subd,subd_type),780)) subd,t.* from (
              select 'BISQUIT_ID' subd_type, substr(depart,3) subd, otv, code, header, subdepartment from bis_account a where filial_code = '06'
              union all
              select 'SAP_ID' subd_type,to_char(depart) subd, to_char(otv) ovt, code, header, subdepartment from cft_account a where filial_code = lpad('06',3,'0')
              ) t
              where code = '45408810006100000209'
              
select * from cft_depart where code_org = '605709'  
              
select * from account where branch = 0              

/

select * from all_tables@cft where owner = 'IBS'

select universe.namedepart(ar13.Migr_SubId(psubdepartment.Get_Subd_Boss(subdepartment,'SAP_ID'),780)), c.* from contracts_cft_kmb c where account like '45408810_13260027305' 

select * from contracts_cft_kmb where branch = 6
/

    select * from account where branch = 780 
             -- and  nvl(owner,1403) in (1403,0)
              and nvl(subdepartment,0) not in (select num4 from zyx_store z where oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 in (780)) 
              /
              
--����� ������ ���������/ ������
select * from contracts
--update contracts c set subdepartment = (select subdepartment from users where user_id = c.owner) 
--update contracts c set subdepartment = 191000 
where 1=1 and status < 1000
--and subdepartment is null
--and subdepartment not in (select id from subdepartments start with id = 191 connect by prior id = parent)
and subdepartment in 191 and status = 50 and date_open > '01jan2020' and type_doc <> 935

/

select * from contracts where reference = 17774809
/

select * from account
--update contracts c set subdepartment = (select subdepartment from users where user_id = c.owner) 
--update contracts c set subdepartment = 191000 
where 1=1 and close_date is null
--and subdepartment is null
and subdepartment not in (select id from subdepartments start with id = 191 connect by prior id = parent)
--and subdepartment in 191 and status = 50 and date_open > '01jan2020' and type_doc <> 935