select PTOOLS5.AS_DATE(global_parameters.get_param_cfg('FILIAL_CLOSE_DATE')) from dual;


  for cc in (select to_date(value,'dd.mm.yyyy') dt from config where name='FILIAL_CLOSE_DATE' and value like '__.__.____')
  loop
    for dd in (select to_date(value,'dd.mm.yyyy') dt from config where name='ARCHIVE_CLOSE_DATE' and value like '__.__.____')
      loop
        if cc.dt = dd.dt+1 then
          raise_application_error( -20936,'�������� ��������� '||to_char(sysdate,'dd.mm.yyyy')||' - �������� ������� '||to_char(cc.dt,'dd.mm.yyyy') );
        end if;  
      Return;
    end loop;
  end loop;
/



��������
� ���� 12900 ��� ��������
3744
4347
14620
13001
12633
/

select * from variable_types where name = 'UNBLOCK'

--insert into variable_types
select * from (select 'UNBLOCK' name,type_id,0 rownumber,'1' value from types where type_id in (21,8225,4215,28,199)) t
where not exists (select null from variable_types where name = t.name and type = t.type_id)

select UNIVERSE.VAR_TYPE(type_id,'UNBLOCK'),t.* from types t where type_id in (21,8225,4215,28,199)

select * from documents where status > 0 and status < 1000 and type_doc in (21,8225,4215) 
and date_work > sysdate-3
 
    
 --DISABLE        
DECLARE
-- %Author  : ALESHIN_RL
-- %Created : 29.10.2021
-- %usage ���������� �������� ��� ��������/�������� ������� 
BEGIN  
  for cc in (select to_date(value,'dd.mm.yyyy') dt from config where name='FILIAL_CLOSE_DATE' and value like '__.__.____')
  loop
    if :new.date_work >= cc.dt then
      raise_application_error( -20500,'�������� ��������� '||to_char(:new.date_work,'dd.mm.yyyy')||' - �������� ������� '||to_char(cc.dt,'dd.mm.yyyy') );
      Return;
    end if;
  end loop;   
END;
/

select * from account where code like '40702810_20200000059'

    bs#86.process_all;
    
    
    select * from bs#66_log_zft 
    
    PTOOLS_EID_BLACK_LIST.get_BlackLit_for_send_vtb24
    
    PKG_METRO_SALES.SEND_SALES_REG
    
    PKG_METRO_SALES.RUN_IMPORT_RPC;
   

PKG_METRO_SALES.SEND_PAMENT_ERROR;


SELECT max(DATE_CREATE)
              FROM PRC_LOADER.TBL_WALLET_PAYMENT T
              WHERE T.DATE_CREATE >= TRUNC(SYSDATE)-100
              /
              
               pck_log_operation2.add_doc
               
               eid.eid_monitoring_notify.RunNotifyRobot
               /
               
               EID.Pkg_Monitoring_Sheds.auto_create_fkr_k2_arest
               
               select *
               from opay.out_payment op
              where op.create_date >= trunc(sysdate)-10 
                and op.payment_type = 'ELECTION'
                
                PSCHED_921.runjob;
                
                SET_PERCENT_CONT_STREAM
                
                P_OPERDAY.START_STAGE(0, 999)
                
                   mbank.RISK_LEVEL_EID_PRODUCT.RECALCULATION_FL
                   
                   select *
               from opay.out_payment op
              where op.create_date >= trunc(sysdate - 100)
                and op.payment_type = 'RAPIDA'
                and opay.p_out_payment.check_journal_existance(op.payment_id) = 1
                and op.status_code = 'CHECKED_DOC'
                
               select * from  eid.stockholders