declare
v_cl_rec eid.p_eid_tools_firma.cl_record;
sRes varchar2(2000) := null;
nFilialReal number;
sDopParam varchar2(2000) := null;
v_eid number;
r varchar2(4000);
begin
  for x in (select distinct  t.* from firma_Post_of_Russia@pro8.world t where t.status = 0)
  loop
    for x1 in (select distinct f.eid,f.subdepartment,f.reference,f.branch from eid.eid_firma f 
                 where f.eid = x.eid and f.inn = x.inn_old and f.reference is not null )
    loop
      
      v_cl_rec := eid.p_eid_tools_firma.get_cl_record(nEID => x1.eid);
      
      v_cl_rec.cl_SUBD_MODIFY := 191;
      v_cl_rec.cl_OWNER_MODIFY := 'Admin';
      
      v_cl_rec.cl_INN := nvl(x.inn_new,v_cl_rec.cl_INN);
      v_cl_rec.cl_OGRN_REG := nvl(to_date(x.ogrn_date_reg_new,'dd.mm.yyyy'),v_cl_rec.cl_OGRN_REG);
      v_cl_rec.cl_OGRN_NUMBER := nvl(x.ogrn_num_new,v_cl_rec.cl_OGRN_NUMBER);
      v_cl_rec.cl_OGRN_DATE := nvl(to_date(x.ogrn_date_new,'dd.mm.yyyy'),v_cl_rec.cl_OGRN_DATE);
      v_cl_rec.cl_CLIENT_NAME := nvl(x.client_name_new,v_cl_rec.cl_CLIENT_NAME);
      v_cl_rec.cl_FULL_NAME := nvl(x.full_client_name_new,v_cl_rec.cl_FULL_NAME);
      
      v_eid := eid.p_eid_tools_firma.LoadClient(cl_rec => v_cl_rec ,nRealEdit => 1,nCommit => 0);
                                                
      eid.p_eid_tools_firma.LoadVariable(nEID => v_eid, dDATE_MODIFY => sysdate,
                                                sOWNER_MODIFY => 'Admin',  nSUBD_MODIFY => 191, sTABN_MODIFY => null,
                                                nSTATUS => 1, nPRIORITY => 1,
                                                sType => 'ANKETA_NOTPLANUPDATE', sVALUE => '01.10.2019', nMultiLine => 1);
      
      update firma_Post_of_Russia@pro8.world t set status = 1 where t.inn_old = x.inn_old and t.eid = x.eid;
       
      nFilialReal := eid.p_eid_tools2.get_filial_id(x1.subdepartment);
      
      for x_acc in (select distinct  t.* from firma_acc_Post_of_Russia@pro8.world t where t.status = 0 and t.eid = x1.eid )
      loop
      
        if nFilialReal <> mbgoid
        then
          r := ptools_by_utl.call_web_func_str(nFilialReal, 'MBANK.UPD_ACC_POSTR', 6, x1.reference
                                                                                    , x1.branch
                                                                                    , x_acc.ref_acc
                                                                                    , x_acc.br_acc
                                                                                    , x_acc.code_acc
                                                                                    , x_acc.name_new);
         else
            r := UPD_ACC_POSTR(nReference => x1.reference,nBranch => x1.branch ,ref_acc => x_acc.ref_acc,ref_br => x_acc.br_acc,code_acc => x_acc.code_acc,name_new => x_acc.name_new);
         end if;
      
        if r is not null
        then
          raise_application_error (-20001,'������ ��������� ������:'||x1.eid||' '||r);
        else
          update firma_acc_Post_of_Russia@pro8.world t set status = 1 where t.ref_acc = x_acc.ref_acc and t.br_acc = x_acc.br_acc ;
        end if;
        
      end loop;
      
      sDopParam:= NULL;
      mbank.ptools5.set_param(sDopParam, 'ref1', x1.reference);
      mbank.ptools5.set_param(sDopParam, 'br1', x1.branch);
      mbank.ptools5.set_param(sDopParam, 'cikl', 1);
      
      sRes := mbank.ptools_eid_to_filial.EXEC_EXPORT_RECORD(RecID => -1, TblName => 'EID.EID_FIRMA', nTekFilial => nFilialReal,
                                                            ch_refer => x1.eid, ch_branch => 0, ch_owner_modify => 'Admin',
                                                            ch_owner_modify_id => 1403,
                                                            ch_subd_modify => mbgoid,
                                                            ch_dop_param => sDopParam);
     
    if sRes is not null
    then
      raise_application_error (-20001,'������ ������������� ��:'||x1.eid||' '||sRes);
    end if;
      
    end loop;
    update firma_Post_of_Russia@pro8.world t set status = 2 where t.inn_old = x.inn_old and t.eid = x.eid;
    commit; 
  end loop;
end;
/



select EID,reference,branch,code,name from eid.eid_firma_account where code in
(select CODE_ACC from firma_acc_Post_of_Russia@pro8.world t)-- where t.status = 0 and t.eid = x1.eid)


select EID,INN,TAX_CODE KPP,TAX_REG,OGRN_SERIA,OGRN_NUMBER,OGRN_DATE,CLIENT_NAME,FULL_NAME 
from eid.eid_firma f where eid in (select eid from firma_Post_of_Russia@pro8.world)
and exists (select null from eid.eid_firma_products where eid = f.eid and status = 50)

/




--insert into firma_acc_Post_of_Russia@pro8.world(EID,REF_ACC,BR_ACC,CODE_ACC,NAME_OLD,NAME_NEW,STATUS)
--delete  firma_acc_Post_of_Russia@pro8.world where (ref_acc,br_acc) in
--(select REFERENCE,BRANCH  
select EID,REFERENCE,BRANCH,CODE,NAME,null NAME_NEW,0 STATUS 
from eid.eid_firma_account where eid in 
(137087,307823,106477,3339107,3344012,304988) and close_date is null
--)

select * from eid.eid_firma where inn = '7724261610' eid = 3344012


--insert into firma_Post_of_Russia@pro8.world(EID,STATUS,INN_OLD,INN_NEW,KPP_OLD,OGRN_DATE_REG_OLD,OGRN_DATE_REG_NEW,OGRN_NUM_NEW,OGRN_NUM_OLD,OGRN_DATE_OLD,OGRN_DATE_NEW,CLIENT_NAME_OLD
	,CLIENT_NAME_NEW,FULL_CLIENT_NAME_OLD,FULL_CLIENT_NAME_NEW)
select EID,0 status,INN,'7724490000' INN_NEW,TAX_CODE KPP,OGRN_DATE,'01.10.2019' OGRN_DATE_REG_NEW,'1197746000000' OGRN_NUM_NEW,OGRN_NUMBER,OGRN_DATE,'01.10.2019' OGRN_DATE_NEW  
,CLIENT_NAME, null CLIENT_NAME_NEW, FULL_NAME, null FULL_CLIENT_NAME_NEW 
from eid.eid_firma f where inn = '7724261610'
and exists (select null from eid.eid_firma_products where eid = f.eid and status = 50)
and not exists (select null from firma_Post_of_Russia@pro8.world where eid = f.eid) 


select * from firma_Post_of_Russia@pro8.world where eid = 3344012 


137087
307823
106477
3339107
3344012
304988

select * from eid.eid_firma_account where eid in (137087,307823,106477,3339107,3344012,304988)
/

select rowid,a.* from account a where
close_date is null and name like '%����%' and upper(name) like '%�����%'
 
code in 
('47422810400000000840'
,'60323810200000000045'
,'91803810000760000058'
,'91803810600761000059'
,'40502810300010000022'
,'40504810400010000001'
,'40504810700010000002'
,'47426810300013000001'
,'47426810600013000002'
,'47426810900010000022'
,'90902810400010000022')
