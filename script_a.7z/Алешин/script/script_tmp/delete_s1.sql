select rowid,t.* from documents t where reference = 6136520192

select rowid,t.* from variable_documents t where reference = 6136520192 and branch = 191

select t.* from archive t where type_doc = 7872 and date_work > sysdate-150 and date_work < sysdate-50
 
select * from UNIPAY_REQUEST  --����� ���� ������, �� �� ��������  CRIRICAL_ERROR
where date_start > sysdate-1  --�������� ����� http://bifit.com/online/corporate/client CBS_IBANK

select * from UNIPAY_TREE where dat > sysdate-1 --����� ���� ������, �������� ����� FINSTREAM

select * from HYPO_FORMS
 where --eid = 12474953
date_modify > sysdate-200

AXIOMA_FOBO_DEPOSIT_DATA
AXIOMA_FOBO_SHED_DEPOSIT
TEST_DEBUG

sco_anketa.tbl_scoring_request_attr
SCORING_FORMS

select * from CDCS.CDC_LOG$EID_CROSSALES
CDCS.CDC_LOG$TBL_SCORING_REQUEST_AT

TREPORT_664_HIST_LOG
TREPORT_664_SUB

SAS_TAB

RTK_PAYMENTS_EXT
UNIPAY_TREE --���� ������, �� ��� �����������
UNIPAY_SERVICE_GROUP
UNIPAY_SERVICE
UNIPAY_RESOURCE_INVENTORY_HIST
UNIPAY_RESOURCE_INVENTORY
UNIPAY_REQUEST
UNIPAY_PAY
UNIPAY_PARAM_VAR
UNIPAY_PARAM_TAX
UNIPAY_PARAM_SET
UNIPAY_PARAM_KEY
UNIPAY_PARAM_EVENT
UNIPAY_PARAM
UNIPAY_ORG_PARAM
UNIPAY_ORG
UNIPAY_OP_ACCESS
UNIPAY_OPERATOR
UNIPAY_GROUP
UNIPAY_DOC_SAVE
UNIPAY_DOC
UNIPAY_CHECK
UNIPAY_APP_STAFF
UNIPAY_APP_LOG
UNIPAY_APP

select max(DATE_MODIFY),min(DATE_MODIFY),count(*) from CLIENTS_ANKETA
--select min(date_create) from AXIOMA_FOBO_SHED
--where pk not in (5417230387251753)

select trunc(trans_date,'mm'), count(*) from prc_loader.kiosk_transactions
where trans_date > to_date('01.01.2020','dd.mm.yyyy')
group by trunc(trans_date,'mm')
--6325195

select * from mbank_audit.log_ddl where object_name = 'SKHOD_UNLOAD' 
order by ddl_date desc 
--and owner = dd.owner and orauser = 'SYS' and DDL_TYPE = 'CREATE') 

select * from DBA_DEPENDENCIES where referenced_name like 'PJOURNAL_31122014'

select * from DBA_DEPENDENCIES where referenced_type = 'TABLE' and name like 'CBS_QUERIES' 

select * from DBA_OBJECTS where object_name like '%TERROR_TBL%'

select * from DBA_TABLES where table_name like '%TERROR_TBL%'

select * from PersonalDesktop where id = 5053

select * from personal_object_usage where obj_id = 5053

--����� ������� ��������� �� 
select uu.*, 'alter table '||table_name||' disable constraint '||CONSTRAINT_NAME||';','alter table '||table_name||' drop constraint '||CONSTRAINT_NAME||';' from dba_constraints uu 
where r_constraint_name in 
--(select constraint_name from user_constraints where constraint_type in ('P','U') and table_name = 'ACCOUNT')
(select constraint_name from dba_constraints where table_name = 'VARIABLE_DOCUMENTS_INT3')
/
--alter session set ddl_lock_timeout = 13;

/

--�� ����� ������� ���������
select * from dba_constraints where constraint_name in
(select r_constraint_name from dba_constraints where constraint_type = 'R' and owner = 'MBANK'
and table_name = 'TAX'


--alter table FSSP_QUERY_NLS drop constraint TMP$$_FSSP_QUERY_NLS_FSSP_Q0;
--alter table FSSP_QUERY_CLI drop constraint TMP$$_FSSP_QUERY_CLI_FSSP_Q0;

--drop trigger TMP$$_FSSP_QUERY_INSERT0
--drop table FSSP_QUERY_INT purge
--truncate table DATA_PACKAGE_IN_HIST
--truncate table DATA_PACKAGE_INFO_HIST_HYPO
--truncate table DATA_PACKAGE_IN_HIST_HYPO
--truncate table DATA_PACKAGE_OUT_HIST_HYPO
--truncate table DATA_PACKAGE_IN
--truncate table DATA_PACKAGE_INFO
--truncate table DATA_PACKAGE_INFO_HIST
--truncate table DATA_PACKAGE_OUT
--truncate table DATA_PACKAGE_OUT_HIST
--truncate table MB_LOG

--drop table CONTRACT_EKONOM_INSURE purge 

select 'drop table '||t.table_name|| ' purge;',t.* from (
select substr(table_name,1,length(table_name)-4), (select count(*) from DBA_DEPENDENCIES where referenced_name = dd.table_name and referenced_owner = dd.owner) depen_cnt,
(select count(*) from dba_constraints uu,  dba_constraints tt where uu.r_constraint_name = tt.constraint_name and tt.table_name = dd.table_name and tt.owner = dd.owner) cont_cnt,
 dd.* from dba_tables dd where table_name like '%INT' 
and exists (select null from dba_tables where owner = dd.owner and table_name = substr(dd.table_name,1,length(dd.table_name)-4))
and exists (select null from mbank_audit.log_ddl where object_name = dd.table_name and owner = dd.owner and orauser = 'SYS' and DDL_TYPE = 'CREATE')
and not exists (select null from DBA_DEPENDENCIES where referenced_name = dd.table_name and referenced_owner = dd.owner and type not in ('TRIGGER'))  
--and owner = 'EID'
) t 
--where cont_cnt = 0 



select uu.*, 'alter table '||table_name||' drop constraint '||CONSTRAINT_NAME||';' 
from dba_constraints uu where r_constraint_name like 'TMP$$%' and status = 'DISABLED'
and owner = 'PFP_DATA'

(select constraint_name from dba_constraints where table_name = 'TBL_ENTITY_ATTR_INT')

select 'truncate table '||z.str3||'.'||z.str1||';',z.* from ZYX_STORE z where OPER = 'AR_INFO' and tbl = 'TABLE' and num3 = 0 and status = 1 and num6 = 1 
and str5 like '%truncate%' and nvl(num2,1) > 0 and str5 not like '%�������� redifination%'
and str3 not in 'MIS'
--and str1 not like 'SAS%'
/


select rowid,s.* from subo_movements s

select rowid,s.* from subo_archive_close_date s

select rowid,s.* from s_files_ovp s where line_no = 209 and reference = 5920688693

--���-�� �� ����������
EID.IBK_CONTROL
SCORING.SAS_OPERDAY_CARD