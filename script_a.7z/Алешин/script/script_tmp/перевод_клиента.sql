select * from zyx_cont_cb
where c like '��/1820-01608%'

select * from contracts c where 
--c.doc_number = '13/18'
related = 27154129

select c.doc_number,count(*) from contracts c where c.doc_number in (select c from zyx_cont_cb)
group by doc_number order by count(*) desc
/

--insert into zyx_store(OPER,TBL,USR,STATUS,DT_MOD,NUM1,NUM2,NUM3,NUM4,NUM5,NUM6,STR1,DT1,str6,num8)
 --     values('OBJ_MOVE','CONTRACTS',who,0,sysdate,aa.reference,aa.branch,nvl(aa.subdepartment,-1),sub_to,nvl(aa.owner,-1),own_id,aa.account,dt_sys,'IC',cnt);
select 'OBJ_MOVE','CONTRACTS',-1379,0,sysdate,reference,branch,nvl(subdepartment,-1),ff,nvl(owner,-1),0,account,sysdate,'IC',1 from (
select c.*,cl.inn,z.a,z.b,z.c,z.d,z.e,z.f,z.g
,universe.namedepart(c.subdepartment),PSUBDEPARTMENT.Get_Subd_First(z.d,'BISQUIT_ID') dd,PSUBDEPARTMENT.Get_Subd_First(z.f,'BISQUIT_ID') ff
 from contracts c, (select distinct * from zyx_cont_cb) z, clients cl where c.doc_number = z.c
and cl.reference = c.refer_client and cl.branch = c.branch_client and cl.inn = z.b
--and c.type_doc not in (2127,11240,30171,30173,7702,7703,7422,7632,2395,2397,6423,8665,715,714,6067,3490) 
and c.child = 0
--and  c.type_doc in (7225)
--and cl.inn= '7802749982'
)-- where ff = subdepartment

select distinct c from zyx_cont_cb

select distinct * from zyx_cont_cb

select c,b,count(*) from zyx_cont_cb
group by c,b
order by count(*) desc

--������� ������� ��������
 select rowid,zz.* from zyx_store zz

select
(select count(*) from v_user_subdep_groups g, subdepartments s, variable_subdepartments vs 
where g.id = s.id and vs.name = 'BOSS_ID' and vs.depart_id = s.id and g.group_id = t.z3
and vs.value = t.val) cc
,t.* from (
 select (select group_id from v_user_subdep_groups where id = zz.num4) z4,
(select group_id from v_user_subdep_groups where id = zz.num3) z3
,global_parameters.var_subdepartments(zz.num4,'BOSS_ID') VAL
,zz.* from zyx_store zz
 --delete zyx_store zz
 --update zyx_store zz set status = 10--,num2 = num5,num5 = num2 
 where oper = 'OBJ_MOVE'
 ) t
 where num3 = 365446 
 /

select coalesce(global_parameters.var_subdepartments(s.id,'BODEPART_ID'),global_parameters.var_subdepartments(id,'BISQUIT_ID')) BIS_ID
,(select group_id from v_user_subdep_groups where id = s.id) g
,id,name from subdepartments s where id in (365428,365472)


--��������������� �������
declare
  r_usr users%rowtype;
  r_usr_id number;
  r_subd number;
  r_cnt number := 0;
begin
  for rr in (
           --/* �������������
             select 785152 subd_to, null own_to, cl.* from clients cl 
             where cl.subdepartment = 785150 and cl.type_doc = 4  
           --*/  
            )
  loop
    begin   
      r_subd := rr.subd_to; --��������� �������������
      --��������� ������������
      r_usr := puser.Get_User(nvl(rr.own_to,rr.owner));
      r_usr_id := puser.Get_UserID(r_usr.params,r_subd);
      if r_usr_id = 0 then
        r_usr_id := coalesce(global_parameters.get_param('���_�����_��',r_subd),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;
      --��������������
      update clients cl set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr_id,owner)
        where reference = rr.reference and branch = rr.branch;          
      r_cnt := r_cnt + sql%rowcount;  
      if  sql%rowcount > 0 then
        execute immediate 'update eid.eid_firma set subdepartment = '||to_char(r_subd)||' where reference = '||to_char(rr.reference)||' and branch = '||to_char(rr.branch)||' and subdepartment = '||to_char(rr.subdepartment);                  
      end if;
      commit;
    exception when OTHERS then
      dbms_output.put_line('client = '||rr.reference||' branch_client = '||rr.branch||'  err ='||sqlerrm);
      rollback;
    end;
  end loop;   
  dbms_output.put_line('client r_cnt = '||r_cnt);
end;
/

--��������������� ��������
declare
  r_subd number;
  r_users users%rowtype;
  r_usr number;
  r_cnt number := 0;
  r_cnt_a number := 0;
  
begin
  for rr in (
  --/* ��������������
select 191 subd_to, null own_to, c.* from contracts c where 1=1 and status = 50
and subdepartment not in (select id from subdepartments start with id = 191 connect by prior id = parent)
and type_doc not in (7437) and child = 0 and related = 0 and refer_from = 0 
--and reference = 31947929
and type_doc in (6776)
             )
  loop
      r_subd := rr.subd_to; --��������� �������������
      --��������� ������������
      r_users := puser.Get_User(nvl(rr.own_to,rr.owner));
      r_usr := puser.Get_UserID(r_users.params,r_subd);
      if r_usr = 0 then
        r_usr := coalesce(global_parameters.get_param('���_�����_��',r_subd),global_parameters.get_param_cfg('���_�����_�������'),1403);
      end if;
      begin    
        update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner)
        where reference = rr.reference and branch = rr.branch      
          and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
        r_cnt := r_cnt + sql%rowcount;
        update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner) where contract = rr.reference and branch_contract = rr.branch 
        and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13)); 
        r_cnt_a := r_cnt_a + sql%rowcount; 
       -- update zyx_store set status = 30, dt_mod = sysdate where rowid = rr.rowid;
        commit;    
      exception when OTHERS then
        rollback;
        dbms_output.put_line('ref = '||rr.reference ||' br = '||rr.branch ||'  err ='||sqlerrm);
     --   update zyx_store set status = -10, dt_mod = sysdate where rowid = rr.rowid;
        commit;
      end;  
      --�������������� �����������
      for cc in ( select * from contracts c where status < 1001 
                 and refer_from = rr.reference and branch_from = rr.branch 
                )
      loop
        begin
          update contracts set subdepartment = rr.subdepartment, owner = rr.owner where reference = cc.reference and branch = cc.branch;
          r_cnt := r_cnt + sql%rowcount;
          update account set subdepartment = rr.subdepartment, owner = rr.owner where contract = cc.reference and branch_contract = cc.branch;   
          r_cnt_a := r_cnt_a + sql%rowcount; 
          commit;
        exception when OTHERS then
           rollback;
          dbms_output.put_line('contracts r_cnt = '||cc.reference||' err = '||sqlerrm);
        end;  
     end loop;  
  end loop; 
  commit;
  dbms_output.put_line('contracts r_cnt = '||r_cnt||'  r_cnt_a = '||r_cnt_a);
end;
/


--��������������� ��������
declare
  r_subd number;
  r_users users%rowtype;
  r_usr number;
  r_cnt number := 0;
  r_cnt_a number := 0;
begin
  for rr in (
  --/* ��������������
select c.* from contracts c where 1=1 and status = 50
and subdepartment not in (select id from subdepartments start with id = 191 connect by prior id = parent)
and type_doc not in (7437) and refer_from > 0 --and related > 0 
--and reference = 31947929
--and type_doc in (935)
             )
  loop
   -- select subdepartment,owner into  r_subd,r_usr from contracts where reference = rr.related and branch = rr.branch_related;
    select subdepartment,owner into  r_subd,r_usr from contracts where reference = rr.refer_from and branch = rr.branch_from;
      begin    
        update contracts set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner)
        where reference = rr.reference and branch = rr.branch      
          and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13));
        r_cnt := r_cnt + sql%rowcount;
        update account set subdepartment = nvl(r_subd,subdepartment), owner = nvl(r_usr,owner) where contract = rr.reference and branch_contract = rr.branch 
        and (nvl(owner,-13) <> nvl(r_usr,-13) or nvl(subdepartment,-13) <> nvl(r_subd,-13)); 
        r_cnt_a := r_cnt_a + sql%rowcount; 
       -- update zyx_store set status = 30, dt_mod = sysdate where rowid = rr.rowid;
        commit;    
      exception when OTHERS then
        rollback;
        dbms_output.put_line('ref = '||rr.reference ||' br = '||rr.branch ||'  err ='||sqlerrm);
     --   update zyx_store set status = -10, dt_mod = sysdate where rowid = rr.rowid;
        commit;
      end;  
  end loop; 
  commit;
  dbms_output.put_line('contracts r_cnt = '||r_cnt||'  r_cnt_a = '||r_cnt_a);
end;
/
