with t as (select * from cota.mb_contracts@cota cc where 
--updated = (select min(updated) from cota.mb_contracts@cota where reference = cc.reference and branch = cc.branch)
 pk_id = (select max(pk_id) from cota.mb_contracts@cota where reference = cc.reference and branch = cc.branch and div_code = cc.div_code) 
)
select * from contracts c, t  where c.subdepartment = 191590
and t.reference = c.reference and t.branch = c.branch
--and c.branch = 104007 and c.reference = 23010
and rownum < 10
/


--with t as (select * from cota.mb_contracts@cota cc where updated = (select min(updated) from cota.mb_contracts@cota where reference = cc.reference and branch = cc.branch) )
select * from contracts c where c.subdepartment = 191590 and status = 50
--and reference = 23010 
and rownum < 10
/

select * from contracts c where c.subdepartment in
(select num4 from zyx_store z where OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 192) 
--and status = 60
and not exists (select null from variable_contracts where reference = c.reference and branch = c.branch and name = '���_����������_�����')
and nvl(date_close,sysdate) > '31dec2018'  
/

select * from variable_contracts where reference = 89859 and branch = 138 
/

select * from zyx_cont_cb where b='104048' 
/

select * from cota.mb_contracts@cota cc where 1=1 
--and pk_id = (select min(pk_id) from cota.mb_contracts@cota where reference = cc.reference and branch = cc.branch and div_code = cc.div_code)
and branch = 104048 and reference = 1098265
/

declare
  dept number;
  okato varchar2(100);
  f_res varchar2(4000);
  
  function get_dept_cota(ref number, br number) return number
  is
    res number;
  begin
    for rr in (select * from cota.mb_contracts@cota cc where reference = ref and branch = br and 
                pk_id = (select min(pk_id) from cota.mb_contracts@cota where reference = cc.reference and branch = cc.branch and div_code = cc.div_code)
              order by pk_id desc 
              )
    loop
      res := rr.SUBDEPARTMENT;
      exit;
    end loop;   
    return res;         
  end; 

  function get_dept_okato(br number) return varchar2
  is
    res varchar2(100);
  begin
    for rr in (select * from zyx_cont_cb cc where b = to_char(br))
    loop
      res := rr.c;
    end loop;   
    return res;         
  end; 

  function set_okato(ref number, br number, okato varchar2) return varchar2
  is
  begin
    insert into variable_contracts(NAME,REFERENCE,BRANCH,VALUE)
    select '���_����������_�����', ref,br,okato from dual t 
      where trim(okato) is not null and not exists (select null from variable_contracts where reference = ref and branch = br and name = '���_����������_�����');
    return null;            
  exception when others then
    return  sqlerrm;
  end;

begin
  for rr in (select * from contracts c where c.subdepartment in
                (select num4 from zyx_store z where OPER = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS' and num1 = 49) 
                --= 191590 and status = 60 
               and not exists (select null from variable_contracts where reference = c.reference and branch = c.branch and name = '���_����������_�����')
               and nvl(date_close,sysdate) > '31dec2018'                    
             --and rownum < 10 
             )
  loop
  --  dept := get_dept_cota(rr.reference, rr.branch);
    okato := get_dept_okato(rr.branch);
    if okato is null then
      okato := get_dept_okato(get_dept_cota(rr.reference, rr.branch));
    end if;
    f_res := set_okato(rr.reference, rr.branch, okato);
    if f_res is not null then
      dbms_output.put_line(' f = '||f_res );
    end if;       
    --dbms_output.put_line('dept = '||dept||' | okato ='||okato||' | rr.reference = '||rr.reference||' | rr.branch = '||rr.branch ||' f = '||f_res );
    commit;
  end loop;           
end;