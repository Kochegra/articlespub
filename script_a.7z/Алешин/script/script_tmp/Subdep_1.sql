select coalesce(EID.P_EID_TOOLS_SUBDEP.getparam (s.id, 'BODEPART_ID'),EID.P_EID_TOOLS_SUBDEP.getparam (s.id, 'BISQUIT_ID')) bis_code
 ,s.* from eid.eid_subdepartments s  where type in (400,301)


select coalesce(lpad(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(id,'BODEPART_ID'),4,'0'),lpad(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(id,'BISQUIT_ID'),4,'0')) bis_id
 ,s.* from subdepartments s  where type in (400,301)

select * from dba_tables where owner = 'TMP_TABLES' 

--������ � ���/��
select * from TMP_TABLES.AR13_SUBD

--��������� ��� ����� � ������� ��� https://intranet.vtb.com/podrazdeleniya/rb/dars/Pages/region.aspx
select * from TMP_TABLES.ZYX_AR13_XLS 
where z = '4323'

select C name,Z bis_id,substr(AC,2) bis_bg,AF ref_id from TMP_TABLES.ZYX_AR13_XLS TP 

select 1 x ,s.* from eid.v_subdep_all s where nvl(s.boss_id,0) > 0 
and BIS_CODE in (0851,0651)
/

select * from guides where type_doc = 13884
/

with emp as (select /*+ MATERIALIZE*/  count(*) cnt, dept_id from  boss_emp_all where d_out > sysdate group by dept_id)
select (select sum(cnt) from emp where dept_id in (select id from boss_subdepartments start with ref_code = t.af connect by prior id = dept_id) ) bb_cnt
, t.*
--delete 
--select *
from TMP_TABLES.ZYX_AR13_XLS t 
where 1=1
--ab is null
--ab in ('5229')
--and af = '774046'


--grant select on zyx_cont_cb to tmp_tables  
/

--��������������
with subd as (select coalesce(lpad(EID.P_EID_TOOLS_SUBDEP.getparam (s.id, 'BODEPART_ID'),4,'0')
                             ,lpad(EID.P_EID_TOOLS_SUBDEP.getparam (s.id, 'BISQUIT_ID'),4,'0')) bis_code
             ,s.* from eid.eid_subdepartments s  where type in (400,301) )
select * from TMP_TABLES.ZYX_AR13_XLS z where 
--not exists (select null from eid.v_subdep_all s where s.status = 50 and parent = 191 and lpad(s.BIS_CODE,4,'0') = z.z)
not exists (select null from subd s where nvl(deleted,0) = 0 and parent = 191 and s.BIS_CODE = z.z)
and not exists (select null from subdepartments where date_close > '31may2021' 
                  and z.z in (lpad(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(id,'BISQUIT_ID'),4,'0'),lpad(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(id,'BODEPART_ID'),4,'0')))
and nvl(af,'1') not in ('768000','775000','776000','778000','773000','772000','771000','779000','725000'
              ,'702000','724000','973300','709000','703000','728000','730000','976900','761000'
              ,'��� ���','422445','776555','773023','774025','776553','774000'
) 
and instr(R,'��') > 0
/

--�� ��������
select (select count(*) from boss_emp_all where 1=1 and d_out > sysdate and dept_id in (select id from boss_subdepartments start with id in (s.boss_id) connect by prior id = dept_id)) usr
,s.* from v_subdep s where lpad(bis_id,4,'0') not in
(select ae from TMP_TABLES.ZYX_AR13_XLS z )
and date_close is null
--and id not in (631317)
and not exists (select null from eid.v_subdep_all e, TMP_TABLES.ZYX_AR13_XLS z where e.id = s.id and e.ref_code = z.ak )
--and not exists (select null from boss_subdepartments where id = s.boss_id and d_to > sysdate)
and lpad(bis_id,4,'0') in (
'0329','3011','4836','5329','3746','5547','2721','4101','4501','4901','5201','5301','5701','1904','2104','2304','2704','3004','3104','3204','3904','4204','5304','3190','3958','4001','4401','4104','4704','2004','2958','2163','2463','4066','4466'
)
--'821619'
/

'0329','3011','4836','5329','3746','5547','2721','4101','4501','4901','5201','5301','5701','1904','2104','2304','2704','3004','3104','3204','3904','4204','5304','3190','3958','4001','4401','4104','4704','2004','2958','2163','2463','4066','4466'
/

select 
(select count(*) from account where subdepartment = s.id) acc_cnt
,(select count(*) from account where subdepartment = s.id and close_date is null) acc_cnt_50
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 4) con_ur_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 4) cl_ur_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 5) con_fl_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 5) cl_fl_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50) con_50_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50 and type_client = 4) con_50_cnt_ur
,(select count(*)||'/'||sum((select count(*) from all_users where username = u.user_)) from users u where subdepartment = s.id) usr_cnt
,s.* from subdepartments s 
where 1=1
 --and id in (770230,780306,770237,770199,770216,544459,235322,770194,770200,770204,770211,770239,770253)  
and id in 
(select s.id from v_subdep s where lpad(bis_id,4,'0') not in (select ae from TMP_TABLES.ZYX_AR13_XLS z) and date_close is null
and not exists (select null from eid.v_subdep_all e, TMP_TABLES.ZYX_AR13_XLS z where e.id = s.id and e.ref_code = z.ak )
--and not exists (select null from boss_subdepartments where id = s.boss_id and d_to > sysdate)
and lpad(bis_id,4,'0') in (
'1162','5436','0990','0730','1329','3329','4260','2800','3655','5557','2990','4462','3658','2568','4262','2128','3129','3903','3701','0812','2722','3002','821627','3021','5519','5487','1850','0228','2609','2009','5704','3009','4504','3107'
))
--and not exists (select null from zyx_store z where tbl = 'SUBDEPARTMENTS' and oper = 'FIL_MIGR' and num2 = s.id)
--and date_close < sysdate-100 and type = 301
start with id = mbfilid connect by prior id = parent
order by id

/


select * from eid.v_subdep_all s where ref_code   in
(select ak from TMP_TABLES.ZYX_AR13_XLS z )
and id not in (631317)
/



select * from eid.v_subdep_all s, TMP_TABLES.ZYX_AR13_XLS z where 1=1 
--and z.ah = s.ref_code
and s.status = 60 --and parent = 191
--and nvl(bis_code,'-1') = '-1'
and lpad(s.BIS_CODE,4,0) = z.ae
and ref_code not in (768000,775000,776000,778000,773000,772000,771000,779000,422445)
and id not in (152)
--and instr(T,'��') = 0 and nvl(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'SERVICE_FIRMA'),0) = 1
--and O = '���' and nvl(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(s.id,'DEPART_OUT'),'0') <> '6'


begin
  for ss in (
        select * from eid.v_subdep_all s, zyx_cont_cb z where 
z.ah = s.ref_code
and s.status = 50 and parent = 191
--and nvl(bis_code,'-1') = '-1'
and lpad(s.BIS_CODE,4,0) = z.ab
and ref_code not in (768000,775000,776000,778000,773000,772000,771000,779000,422445)
and id not in (152)
--and instr(T,'��') = 0 and nvl(EID.P_EID_TOOLS_SUBDEP.getparam(s.id,'SERVICE_FIRMA'),0) = 1
and O = '���-��' and nvl(GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(s.id,'DEPART_OUT'),'0') <> '3'
)
  loop
    admin.set_subdep_variable(ss.id,'DEPART_OUT', '3');
  end loop;
end;

--insert into variable_subdepartments
select * from (
select 'BISQUIT_ID' name, s.id depart_id, 0 rownumber, to_number(z.ab) value  from eid.v_subdep_all s, zyx_cont_cb z where
z.ah = s.ref_code
and s.status = 50 and parent = 191
and nvl(bis_code,'-1') = '-1'and ref_code not in (768000,775000,776000,778000,773000,772000,771000,779000,422445)
and id not in (152)
--(360010,635509,665505,245501,245506,360019)
)t
where not exists (select * from variable_subdepartments where name = t.name and depart_id = t.depart_id);   
/

--������ ��������� �����������
select PSUBDEPARTMENT.GET_GROUPS_NAME(subdepartment) "����"
      ,universe.namedepart(subdepartment) "��"
      ,global_parameters.var_subdepartments(subdepartment,'BISQUIT_ID') "������� ���"
      ,subdepartment "����� ���" 
      ,User_name "���"     
      --,u.* 
      from users u where job = 31451
      and params in (select tab_n from boss_emp_all where d_out > sysdate)
      and exists (select null from all_users where username = u.user_)
      order by subdepartment
/

--���

select * from zyx_cont_cb z where substr(ae,2) in ('1044')


select * from eid.v_subdep_all s, zyx_cont_cb z where 1=1 
and s.status = 50 and parent = 191
and substr(z.ae,2) in ('1044')
and lpad(s.BIS_CODE,4,0) = z.ab
/

select * from tmp_tables.zyx_ar13_xls where ab in ('3310','2325','2006') --bisquit

select * from tmp_tables.zyx_ar13_xls where substr(ae,2) = '2325' --������

select * from users where subdepartment = 785061 and job = 31451

select * from account 45408810713260027305

--������ �������������
select * from users u where subdepartment = 631303 
and exists (select null from all_users where username = u.user_)