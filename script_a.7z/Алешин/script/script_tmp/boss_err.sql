select rowid,t.* from account t where code like '40702810619110000251'
/

select * from variable_account where reference = 243275231



 select tab_n,count(*) from boss_emp_all 
 group by tab_n order by count(*) desc
 /
 tab_n <> 208586,232650,445254 
/

select * from B2_HR.bmv_mbank_emp@BOSS bmv where 1=1
--tab_n > 3412054 and tab_n <= 5412054
--tab_n = 445254
and tab_n in (208586,232650,247498,249713,302450,334360,335188,336891,340220,340874
                 ,344697,346365,346838,349736,350460,355984,356016,356880,357068,361101
                 ,362412,366788,368451,370649,372349,372949,374445,383480,386140,396937
                 ,403841,403960,428009,428108,430271,430832,432140,437184,445254,451384
                 ,455910,457564,458054)
order by tab_n
/

select * from B2_HR.bmv_mbank_emp@BOSS where tab_n = 445254

select max(to_number(tab_n)), count(*) from boss_emp_all where tab_n > 5412054
/

--����������
declare

  PriznakExists 		number;
  PriznakEditHuman 		number;
  FilialId 				number;
  sSearchName 			varchar2(2000);
  sSearchDoc 			varchar2(2000);
  Res 					varchar2(2000);
  rec_boss 				boss_emp_all%rowtype;
  rec_boss_temp 		boss_emp_all%rowtype;
  num number := 0;


FUNCTION GET_FILIAL(FilStr in varchar2) RETURN NUMBER IS
  FilialId number;
BEGIN
   BEGIN
    SELECT min(u.filial_id) INTO FilialId FROM users_all u WHERE u.tab_n = FilStr;
  EXCEPTION WHEN NO_DATA_FOUND THEN 
    FilialId :=  NULL;
  END;
  return FilialId;
END;


BEGIN

  	--delete from boss_emp_all where tab_n in (select tab_n from boss_emp_all where tab_n > 0 minus select tab_n from B2_HR.bmv_mbank_emp@BOSS) and tab_n > 0;
  --commit;
  for rec1 in (select bmv.*, substr(trim(to_char(bmv.tab_n)), 1, 2000) as tab_str from B2_HR.bmv_mbank_emp@BOSS bmv 
  where   tab_n not in (208586,232650,247498,249713,302450,334360,335188,336891,340220,340874
                 ,344697,346365,346838,349736,350460,355984,356016,356880,357068,361101
                 ,362412,366788,368451,370649,372349,372949,374445,383480,386140,396937
                 ,403841,403960,428009,428108,430271,430832,432140,437184,445254,451384
                 ,455910,457564,458054)
    order by tab_n, d_out) loop
    BEGIN
      num := num + 1;
      insert into zyx_cont_cb (a,b) values(num,rec1.tab_n);
      commit;
		begin
		  rec_boss.tab_n := null;
		  rec_boss := rec_boss_temp;
		  for rr in (select * from boss_emp_all where tab_n = rec1.tab_n)
		  loop 
		    rec_boss := rr;
		  end loop;
		exception when others then 
		  dbms_output.put_line('rec1.TAB_N = '||rec1.TAB_N||' 1 ' || sqlerrm);
		  rec_boss.tab_n := null;
		end;
		if (rec_boss.tab_n is not null) then -- ����� ������ �� ������� ���������� � ������� - ���������

		  PriznakExists := 0;
		  PriznakEditHuman := 0;

		  if  nvl(rec_boss.L_NAME, '-') <> nvl(rec1.L_NAME, '-') or  -- ����� ������ ���������� (��)
			  nvl(rec_boss.F_NAME, '-') <> nvl(rec1.F_NAME, '-') or
			  nvl(rec_boss.M_NAME, '-') <> nvl(rec1.M_NAME, '-') or
			  nvl(rec_boss.D_IN, to_date('01.01.1900', 'dd.mm.yyyy')) <> nvl(rec1.D_IN, to_date('01.01.1900', 'dd.mm.yyyy')) or
			  nvl(rec_boss.D_OUT, to_date('01.01.1900', 'dd.mm.yyyy')) <> nvl(rec1.D_OUT, to_date('01.01.1900', 'dd.mm.yyyy')) or
			  nvl(rec_boss.EMAIL, '-') <> nvl(rec1.EMAIL, '-') or
			  nvl(rec_boss.DEPT_NAME_1, '-') <> nvl(rec1.DEPT_NAME_1, '-') or
			  nvl(rec_boss.DEPT_NAME_2, '-') <> nvl(rec1.DEPT_NAME_2, '-') or
			  nvl(rec_boss.DEPT_NAME_3, '-') <> nvl(rec1.DEPT_NAME_3, '-') or
			  nvl(rec_boss.DEPT_NAME_4, '-') <> nvl(rec1.DEPT_NAME_4, '-') or
			  nvl(rec_boss.APPOINT_NAME, '-') <> nvl(rec1.APPOINT_NAME, '-') or
			  nvl(rec_boss.SEX, '-') <> nvl(rec1.SEX, '-') or
			  nvl(rec_boss.emp_id, -1) <> nvl(rec1.emp_id, -1) or   -- ��� ��
			  nvl(rec_boss.NUM_PRIKAZ, '-') <> nvl(rec1.NUM, '-') or
			  nvl(rec_boss.DSIGN, to_date('01.01.1900', 'dd.mm.yyyy')) <> nvl(rec1.DSIGN, to_date('01.01.1900', 'dd.mm.yyyy')) or
			  nvl(rec_boss.E_NAME, '-') <> nvl(rec1.E_NAME, '-') or
			  nvl(rec_boss.passp_hash, -1) <> nvl(rec1.passp_hash, -1) or
			  nvl(rec_boss.entry_id, -1) <> nvl(rec1.entry_id, -1) or
			  nvl(rec_boss.TABN24, '-') <> nvl(to_char(rec1.TABN24), '-') or
        nvl(rec_boss.snn,'-') <> nvl(rec1.SNN, '-')
			  then
			PriznakExists := 1;
		  end if;

		  if (PriznakExists > 0) then  -- ���� ���-�� ���������� � ������ ���������
			FilialId := coalesce(rec_boss.filial, GET_FILIAL(rec_boss.tab_n));
			sSearchName := eid.p_eid_tools.Normalized(rec1.l_name) || ' ' || eid.p_eid_tools.Normalized(nvl(rec1.f_name,'')) || ' ' || eid.p_eid_tools.Normalized(nvl(rec1.m_name,''));

			rec_boss.TAB_N := rec1.TAB_N;
			rec_boss.EMP_ID := rec1.EMP_ID;
			rec_boss.L_NAME := rec1.L_NAME;
			rec_boss.F_NAME := rec1.F_NAME;
			rec_boss.M_NAME := rec1.M_NAME;
			rec_boss.D_IN := rec1.D_IN;
			rec_boss.D_OUT := rec1.D_OUT;
			rec_boss.D_UPLOAD := null;
			rec_boss.FILIAL := FilialId;
			rec_boss.D_MODIFY := sysdate;
			rec_boss.NUM_PRIKAZ := rec1.NUM;
			rec_boss.DSIGN := rec1.DSIGN;
			rec_boss.E_NAME := rec1.E_NAME;
			rec_boss.EMAIL := rec1.EMAIL;
			rec_boss.DEPT_NAME_1 := rec1.DEPT_NAME_1;
			rec_boss.DEPT_NAME_2 := rec1.DEPT_NAME_2;
			rec_boss.DEPT_NAME_3 := rec1.DEPT_NAME_3;
			rec_boss.DEPT_NAME_4 := rec1.DEPT_NAME_4;
			rec_boss.SEARCH_NAME := sSearchName;
			rec_boss.APPOINT_NAME := rec1.APPOINT_NAME;
			rec_boss.DEPT_ID := rec1.DEPT_ID;
			rec_boss.SEX := rec1.SEX;
			rec_boss.TABN24 := rec1.TABN24;
      rec_boss.snn := rec1.SNN;

			if (nvl(rec_boss.flag_edit_human, -1) <> nvl(rec1.passp_hash, -1)) then
			  rec_boss.eid := null;
			end if;

			rec_boss.FLAG_EDIT_HUMAN := 0;
			rec_boss.passp_hash := rec1.passp_hash;
			rec_boss.entry_id := rec1.entry_id;
             begin
               update boss_emp_all set row = rec_boss where TAB_N = rec_boss.TAB_N;
             exception when OTHERS then
                dbms_output.put_line('rec_boss.TAB_N = '||rec_boss.TAB_N||' ������ ��� ��������� ' || sqlerrm);
             end;			
			commit;

		--	if (rec_boss.eid is null) then
		--	  Res := FILL_BOSS_REESTR_EID(rec_boss.tab_n);
		--	end if;

		  end if;
		else -- �� ����� ������ �� ������� ���������� � ������� - ��������� ����� �������
		  FilialId := GET_FILIAL(rec1.tab_n);
		  sSearchName := eid.p_eid_tools.Normalized(rec1.l_name) || ' ' || eid.p_eid_tools.Normalized(nvl(rec1.f_name,'')) || ' ' || eid.p_eid_tools.Normalized(nvl(rec1.m_name,''));

		  rec_boss.TAB_N := rec1.TAB_N;
		  rec_boss.EMP_ID := rec1.EMP_ID;
		  rec_boss.L_NAME := rec1.L_NAME;
		  rec_boss.F_NAME := rec1.F_NAME;
		  rec_boss.M_NAME := rec1.M_NAME;
		  rec_boss.D_IN := rec1.D_IN;
		  rec_boss.D_OUT := rec1.D_OUT;
		  rec_boss.D_UPLOAD := null;
		  rec_boss.FILIAL := FilialId;
		  rec_boss.D_MODIFY := sysdate;
		  rec_boss.NUM_PRIKAZ := rec1.NUM;
		  rec_boss.DSIGN := rec1.DSIGN;
		  rec_boss.E_NAME := rec1.E_NAME;
		  rec_boss.EMAIL := rec1.EMAIL;
		  rec_boss.DEPT_NAME_1 := rec1.DEPT_NAME_1;
		  rec_boss.DEPT_NAME_2 := rec1.DEPT_NAME_2;
		  rec_boss.DEPT_NAME_3 := rec1.DEPT_NAME_3;
		  rec_boss.DEPT_NAME_4 := rec1.DEPT_NAME_4;
		  rec_boss.SEARCH_NAME := sSearchName;
		  rec_boss.APPOINT_NAME := rec1.APPOINT_NAME;
		  rec_boss.DEPT_ID := rec1.DEPT_ID;
		  rec_boss.SEX := rec1.SEX;
		  rec_boss.eid := null;
		  rec_boss.FLAG_EDIT_HUMAN := 0;
		  rec_boss.passp_hash := rec1.passp_hash;
		  rec_boss.entry_id := rec1.entry_id;
		  rec_boss.TABN24 := rec1.TABN24;
      rec_boss.snn := rec1.snn;

		  insert into boss_emp_all values rec_boss;
		  commit;

		--  if (rec_boss.eid is null) then
		--	Res := FILL_BOSS_REESTR_EID(rec_boss.tab_n);
		--  end if;

		end if;
	EXCEPTION WHEN OTHERS THEN 
	  dbms_output.put_line('rec1.TAB_N = '||rec1.TAB_N||' ������ ��� ��������� ' || sqlerrm);
	  CONTINUE;
	END;
  end loop;
  Commit;
  --return Res;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    dbms_output.put_line('������ ��� ��������� ' || sqlerrm);
  --  return Res;
END UPDATE_BOSS_REESTR_HASH;

end;