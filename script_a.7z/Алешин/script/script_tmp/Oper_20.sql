DECLARE
xMemo varchar2(2000):='���������';
xRET VARCHAR2(2000);
xSTAGE NUMBER := 20;
xOD_ID NUMBER;
xDate DATE;
xBranch NUMBER;
BEGIN
  xBranch := mbFilID;
  xDate := global_parameters.DAT_SUBDEPARTMENTS(xBranch, 'SYSTEMDATE');
  xRET := MB_LOCKS.L_TRY('OD.MBANK.'||xBranch||'#'||xSTAGE );
  xOD_ID := P_OPERDAY.ADD_LOG(xDate , xBranch, xSTAGE, xMemo );
  P_AUDIT.SAVE('CLOSE_OD', P_OPERDAY.DAY_ID(xDate), -101, xMemo, xStage);   COMMIT;
--===============
  P_OPERDAY.MOVEDOCUMENTS(xDate -1,  xDate, xBranch);
--===============
  P_OPERDAY.SET_LOG(xOD_ID , 2, xMemo||' SUCCESS!' );  COMMIT;
  xRET := MB_LOCKS.L_FREE('OD.MBANK.'||xBranch||'#'||xSTAGE );
EXCEPTION
  WHEN OTHERS THEN
    xMemo := xMemo||'. '||SqlErrm;
    P_OPERDAY.SET_LOG(xOD_ID , -1, xMemo );
    COMMIT;
END;