  SQL_SELECT('SELECT U.SUBDEPARTMENT, S.SERVER_ADDRESS, S.TYPE FROM USERS U, SUBDEPARTMENTS S WHERE ' +
  ' UPPER(USER_) = USER AND S.ID = U.SUBDEPARTMENT');

  _Branch := SQL_FIELDBYNAME('SUBDEPARTMENT');
  _UserNameServer := SQL_FIELDBYNAME('SERVER_ADDRESS');

  with CREATEQUERY('SELECT ID FROM SUBDEPARTMENTS START WITH ID = (' +
        ' SELECT ID FROM ( SELECT *  FROM SUBDEPARTMENTS START WITH ID = :nBranch'  +
        ' CONNECT BY PRIOR PARENT = ID) WHERE TYPE IN (301, 401)) CONNECT BY PRIOR ID = PARENT', False) do begin
    DeclareAndSet('nBranch', otFloat, _Branch);
    Execute;
    while not EOF do begin
      if _cSelectSubdep = '' then
        _cSelectSubdep :=  FieldAsString('ID')
      else _cSelectSubdep := _cSelectSubdep + ',' + FieldAsString('ID');
      Next;
    end;
    Free;
  end;
/

  _cSelectSubdepN := FloatToStr(_Branch);
  _fSubdepIndivid := false;

  cStr := GetParameter('������_���������');
  if (cStr <> '') then
    begin
      _cSelectSubdepN := _cSelectSubdepN + ',' + cStr;
      _fSubdepIndivid := true;
    end;

  cStr := GetParameter('������_��');
  if (cStr <> '') then
    begin
      cStr := OraPac('PEID_TOOLS2', 'get_subdep_group', ['sIDGroup', cStr, 'sTypeGroup', 'BG'], 0);
      if (cStr <> '') then
        begin
          _cSelectSubdepN := _cSelectSubdepN + ',' + cStr;
          _fSubdepIndivid := true;
        end;
    end;

  cStr := GetParameter('������_���');
  if (cStr <> '') then
    begin
      cStr := OraPac('PEID_TOOLS2', 'get_subdep_group', ['sIDGroup', cStr, 'sTypeGroup', 'ROO'], 0);
      if (cStr <> '') then
        begin
          _cSelectSubdepN := _cSelectSubdepN + ',' + cStr;
          _fSubdepIndivid := true;
        end;
    end;   
/

    if ((GetListParams.GETPARAMETER('������_������') = '') and (_Branch <> _BranchFilial)) or (_fSubdepIndivid) then
      begin
        case Self.nTYPEOBJ of
          nLISTDOC:
            begin
              cSubdepartSelect := ' AND (nvl(T1.XSUBDEPARTMENT, T1.BRANCH) IN (' + _cSelectSubdepN + ') or nvl(T1.DEPART_PAYERS, T1.BRANCH) IN (' + _cSelectSubdepN + ') ' +
                                  ' or (nvl(T1.XSUBDEPARTMENT, T1.BRANCH) IN (mbfilid) and universe.var_type(T1.TYPE_DOC, ''ACCESS_FILIAL'') = ''1'') ' +
                                  ' or (nvl(T1.DEPART_PAYERS, T1.BRANCH) IN (mbfilid) and universe.var_type(T1.TYPE_DOC, ''ACCESS_FILIAL'') = ''1''))'
            end
          else
            cSubdepartSelect := ' AND T1.SUBDEPARTMENT IN (' + _cSelectSubdepN + ')';
        end;
      end;


function CheckRights1(TypeObj: double; User: Double; BitNumber: integer): Boolean;
var
  r: PRights;
  i, j: integer;
//  ncode: integer;
  storage: pSubUsers;
//  group: PRights;
  lFound: Boolean;
begin
  result := True;
  if sub = nil then
    EXIT;
  result := False;
  lFound := False;
  for i := 0 to sub.Count - 1 do
  begin
    storage := sub.items[i];
    if (storage^.ID = User) then
    begin
      lFound := True;
      break;
    end;
  end;
  if not lFound then
    exit;
  j := RightsList.Count;
  for i := 0 to j - 1 do
  begin
    r := RightsList.Items[i];
    if (r^.Id = TypeObj) then
    begin
//      nCode := r^.Code;
      if (storage^.GroupID = 0) then
      begin
        result := ISBIT(r^.Rights, BitNumber);
        exit;
      end else begin
///13.08.2009        result := False;
        j := CheckGroupsRights(User, trunc(TypeObj));
        result := isbit(j, BitNumber) and ISBIT(r^.Rights, BitNumber);
        exit;
      end;
    end;
  end;
end;

function CheckGroupsRights(nOwnerId: Double; nType: Integer): Integer;
begin
  result := 0;
  GroupsRights.Session := GetSession;
///13.08.2009  GroupsRights.SetVariable('USERID', UserId);
  GroupsRights.SetVariable('USERID', _UserId);
  GroupsRights.SetVariable('OWNER', nOwnerId);
  GroupsRights.SetVariable('TYPE', nType);
  GroupsRights.Open;
  while not GroupsRights.EOF do
  begin
    Result := result or GroupsRights.fieldbyname('RIGHTS').asinteger;
    GroupsRights.Next;
  end;
  GroupsRights.Close;
end;

  GroupsRights := CreateOracleDataSet(Application);
  //     GroupsRights.QueryAllRecords := True;
  GroupsRights.SQL.text := 'select rights from groups_rights where GROUP_ID in '
    +
    '( select GROUP_ID  from groups_rights where object_id=:OWNER and code=-1 ' +
    'intersect select GROUP_ID from group_membership where user_id=:USERID )' +
    ' and code = ( select code from types where type_id=:TYPE )';

  GroupsRights.DeclareVariable('USERID', otInteger);
  GroupsRights.DeclareVariable('OWNER', otInteger);
  GroupsRights.DeclareVariable('TYPE', otInteger);

------------
function getSubUsers: TList;
var
  qTmp: TOraDataset;
  storage: pSubUsers;
begin
  if sub = nil then
    sub := TList.Create
  else begin
    result := sub;
    exit;
  end;
  qTmp := CreateOracleDataSet(Application);
  try
    qTmp.QueryAllRecords := True;
    qTmp.ReadBuffer := 4096;
    qTmp.SQL.Text :=
      ' SELECT 0, 1 subd, user_id, subdepartment, user_name, job, params '+
      '   FROM users u WHERE user_id = '+FloatToStr(_UserId)+ ' union all'+
      ' SELECT 1, globals.check_subdepartments(subdepartment) subd, user_id, subdepartment, user_name, job, params '+
      '   FROM users u WHERE exists (select null from dual where globals.check_subuser(user_id) = 1) AND user_id <> '+FloatToStr(_UserId)+
      ' ORDER BY 1, subd DESC, user_name';
    qTmp.open;
    while not qTmp.eof do
    begin
      new(storage);
      storage^.Name := qTmp.fieldbyname('USER_NAME').asstring;
      storage^.ID := qTmp.fieldbyname('USER_ID').asfloat;
      storage^.SUBDEPARTMENT := qTmp.fieldbyname('SUBDEPARTMENT').asinteger;
      storage^.GroupID := Ord(qTmp.fieldbyname('SUBD').asinteger=0); //1=������� ������
      storage^.job := qTmp.fieldbyname('job').asinteger;
      storage^.TabNo := qTmp.fieldbyname('params').asstring;
      sub.Add(storage);
      qTmp.next;
    end;
  finally
    qTmp.Free;
  end;
  result := sub;
end;

----

globals.check_subuser(user_id) = 1