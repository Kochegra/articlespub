grant select on zyx_store to MB_ALESHIN_RL


grant ST_MBANK to MB_ALESHIN_RL


create table aa(n number);

alter table aa add (n1 number);

drop table aa

alter package AR13_TST compile;

truncate table doc1
/

select * from mbank_audit.mb_audit