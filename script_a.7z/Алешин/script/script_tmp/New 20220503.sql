select (select active from shed_tasks where task_name = j.task_name) tsk, (select count(*)||'/'||sum(decode(disabled,null,1,0)) from shed_JOBS where task_name = j.task_name) cnt
, j.* from shed_JOBS j
where disabled is null and task_name in (select task_name from shed_tasks where active = 1)
order by task_name, job_name



select * from config where name='DISABLE_DEILT_EXCHANGE' and value='1'


select code,eid.get_data_firma.getparam(EID.P_EID_TOOLS_FIRMA.search_new_eid(eid),'UIK_MDM') MDM_ID, eid.p_eid_paramvalues.Get_Param('���_�������',200) BIK
--, a.* 
from eid.eid_firma_account a 
where close_date is null and header = 'A' and code like '40_0%'
and subdepartment in (select id from eid.eid_subdepartments where parent = 200 or id = 200)


select * from user_param_values
--delete user_param_values  
where activated > sysdate-2
and id in (select id from user_parameters where name = '������')
and user_id in (select user_id from users where params in (select tab_n from boss_emp_all where d_modify > sysdate-2 and d_out > sysdate))