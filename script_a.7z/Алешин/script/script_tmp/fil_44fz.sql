select * from boss_emp_all where l_name = '��������'
/


select * from shed_hist where job_name = 'ProcessFinOperCard'


select * from shed_log where job_name = 'ProcessFinOperCard'
and time_stamp > sysdate-2

select (SELECT decode(puser.Get_UserID(u.tab_n),0,71912,puser.Get_UserID(u.tab_n)) from users_all u where filial_id = 405 and user_id = c.owner) usr
,c.* from contracts c 

--update contracts c set owner = 
(nvl((
with tt as (
select u.user_id,cl.reference,cl.branch from users_all u, users_all u0, contracts@vtbmain cl 
where u0.filial_id = 405 and u0.user_id = cl.owner and u.filial_id = 191
and u0.tab_n = u.tab_n 
order by (select count(*) from all_users where username = u.user_ ) desc
)
select user_id from tt where reference = c.reference and branch = c.branch and rownum = 1),71912)
) 
where subdepartment = 191007
-- not exists (select null from users where user_id = c.owner )

select * from account a
--update account a set owner =  (select owner from contracts c where reference = a.contract and branch = a.branch_contract )
where (contract,branch_contract) in 
 (select reference  , branch from contracts c where subdepartment = 191007)
-- and mod(substr(code,9,1),2) = 1
 and not exists (select null from users where user_id = a.owner )

SELECT puser.Get_UserID(u.tab_n), u.* from users_all u where filial_id = 405 and user_id = c.owner)


with tt as (
select u.user_id,cl.reference,cl.branch from users_all u, users_all u0, clients@vtbmain cl 
where u0.filial_id = 405 and u0.user_id = cl.owner and u.filial_id = 191
and u0.tab_n = u.tab_n 
--and cl.reference = 227367 and cl.branch = 405
order by (select count(*) from all_users where username = u.user_ ) desc
) 
select nvl((select user_id from tt where reference = c.reference and branch = c.branch and rownum = 1),71912) usr,c.* from clients c
where c.reference = 262911 and c.branch = 405
/

update clients c set owner = (nvl((
with tt as (
select u.user_id,cl.reference,cl.branch from users_all u, users_all u0, clients@vtbmain cl 
where u0.filial_id = 405 and u0.user_id = cl.owner and u.filial_id = 191
and u0.tab_n = u.tab_n 
--and cl.reference = 227367 and cl.branch = 405
order by (select count(*) from all_users where username = u.user_ ) desc
)
select user_id from tt where reference = c.reference and branch = c.branch and rownum = 1),71912)
)
where subdepartment = 191007
-- and not exists (select null from users where user_id = c.owner )
--and c.reference = 262911 and c.branch = 405


select * from users_all u, users_all u0, clients@vtbmain cl 
where u0.filial_id = 405 and u0.user_id = cl.owner and u.filial_id = 191
and u0.tab_n = u.tab_n 
and cl.reference = 262911 and cl.branch = 405
order by (select count(*) from all_users where username = u.user_ ) desc 

and (cl.reference,cl.branch) in 
(select reference,branch from clients c where subdepartment = 191007)






0 in ()