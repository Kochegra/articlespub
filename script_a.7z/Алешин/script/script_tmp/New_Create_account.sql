declare
cAcc varchar2(2000);

FUNCTION CREATE_ACCOUNT_V2( cHeader IN VARCHAR2,cBal IN VARCHAR2,cCurrency IN VARCHAR2,dDate IN Date,nOwner IN NUMBER,
                                 nClient IN NUMBER := 0, nBranchClient IN NUMBER := 0, cName IN VARCHAR2 := '', cCFU IN VARCHAR2 := null)
        RETURN VARCHAR2
        IS              
                cAccount account.code%TYPE;
                cCurr    account.currency%TYPE;
                nLsNum   NUMBER;
                nBranch  NUMBER := 0;
                cBranch  VARCHAR2(4);
                cFilCFU VARCHAR2(4);
                cServerAddress VARCHAR2(2000);
                cMinUr   VARCHAR2(2000);
                cMaxUr   VARCHAR2(2000);
                cMinFiz   VARCHAR2(2000);
                cMaxFiz   VARCHAR2(2000);
                cResult   VARCHAR2(2000);
                nLsMin number := 0;
                nLsMax number := 9999999;
                nRetryCnt number := 3; --���-�� �������� ����� �� �������� ��������                 

        BEGIN
PACCOUNT.Error_Message := '';
        cMinFiz  := GLOBAL_PARAMETERS.GET_PARAM(nOwner,'MIN_FIZ',dDate);
        cMaxFiz  := GLOBAL_PARAMETERS.GET_PARAM(nOwner,'MAX_FIZ',dDate);
        cMinUr  := GLOBAL_PARAMETERS.GET_PARAM(nOwner,'MIN_UR',dDate);
        cMaxUr  := GLOBAL_PARAMETERS.GET_PARAM(nOwner,'MAX_UR',dDate);

        IF  cCurrency IS NULL THEN
PACCOUNT.Error_Message := 'CREATE_ACCOUNT:'||chr(10)||'�� ������� ������ �����';
          RETURN('');
        END IF;

        cFilCFU := substr(global_parameters.get_param ('���_�������', mbfilid), 1, 4);
        IF  cFilCFU IS NULL THEN
          PACCOUNT.Error_Message := 'CREATE_ACCOUNT:'||chr(10)||'�� �������� �������� "���_�������" ';
          RETURN('');
        END IF;
  
        cFilCFU := lpad(cFilCFU, 4, '0');
        cCurr := cCurrency;
        IF cCurr = '098' THEN cCurr := 'A98'; END IF;

        cBranch := cFilCFU;
        BEGIN
          cServerAddress := Globals.GlobalName;
          for recAddress in (select SERVER_ADDRESS from subdepartments
                              where id in (select subdepartment from users where user_id = nOwner))
          loop
            cServerAddress := recAddress.SERVER_ADDRESS;
          end loop;
          IF  cServerAddress <> Globals.cMasterServer AND Globals.IsMaster AND cHeader = 'X'
          THEN
            nBranch := to_number(
                                  NVL(LTRIM(RTRIM(GLOBAL_PARAMETERS.GET_PARAM(nOwner,'���_������',dDate))),'0') ||
                                  LPAD(NVL(LTRIM(RTRIM(GLOBAL_PARAMETERS.GET_PARAM(nOwner,'���',dDate))),cFilCFU),3,'0' ));
          ELSIF cServerAddress <> Globals.GlobalName AND cHeader = 'X'
          THEN
            nBranch := to_number(
                                  NVL(LTRIM(RTRIM(GLOBAL_PARAMETERS.GET_PARAM(nOwner,'���_������_���',dDate))),'0') ||
                                  LPAD(NVL(LTRIM(RTRIM(GLOBAL_PARAMETERS.GET_PARAM(nOwner,'���',dDate))), cFilCFU),3,'0' ));
          ELSE
            nBranch := to_number( NVL(GLOBAL_PARAMETERS.GET_PARAM(nOwner,'���',dDate), cFilCFU ) );
          END IF;
        EXCEPTION
          WHEN OTHERS THEN   nBranch := ptools5.as_Num(cFilCFU);
        END;
        IF   cCFU is Null Then
           cBranch := LPAD(LTRIM(RTRIM(TO_CHAR(nBranch))),4,'0');
        else
           cBranch := LPAD( cCFU,4,'0');
        end if;
--����� ���������� ���������� ����� � ������ �����������        
  if cBal in ('47425','50408','47427','47423') then
    nLsMin := ptools.to_num_err(nvl(cMinUr,'1'),1);
    nLsMax := ptools.to_num_err(nvl(cMaxUr,'999999'),999999);
  elsif substr(cBal,1,3) in ('406','407') then
    nLsMax := 99999;
  elsif cHeader = '�' then
    nLsMin := ptools.to_num_err(nvl(cMinFiz,'10000'),10000);
    nLsMax := ptools.to_num_err(nvl(cMaxFiz,'300000'),30000);     
  end if;       
  nLsNum := nLsMin;
  for rr in 1..nRetryCnt
  loop   
    for aa in (select /*+ INDEX(account account_pk) */ * from account a 
                        where header = cHeader and currency = cCurrency
                              and  code like cBal || cCurrency || '_' || cBranch || '%' 
                              and to_number(substr(code,14)) between nLsMin and nLsMax                               
                        order by to_number(substr(code,14))        
             )
    loop
      if to_number(substr(aa.code,14)) > nLsNum then
        exit;
      else
        nLsNum := to_number(substr(aa.code,14)) + 1;        
      end if;
    end loop;   
    if nLsNum > nLsMax then
      PACCOUNT.Error_Message := 'CREATE_ACCOUNT:'||chr(10)||'�������� ���������� �������� �����';
      RETURN('');           
    else 
      cAccount := cBal || LPAD(cCurr,3,'0') || '0' || cBranch ||LPAD(LTRIM(RTRIM(TO_CHAR(nLsNum))),7,'0');
      cResult := PACCOUNT.ADD_ACCOUNT(cHeader,cAccount,LPAD(cCurrency,3,'0'),dDate,nOwner,nClient,nBranchClient,cName);
      exit when cResult is not null;            
    end if;
  end loop;
PACCOUNT.Error_Message := 'CREATE_ACCOUNT>>' || PACCOUNT.Error_Message;
        RETURN(cResult);
        EXCEPTION 
                WHEN OTHERS THEN
PACCOUNT.Error_Message := 'CREATE_ACCOUNT:'||chr(10)||sqlerrm(sqlcode);
                        call_back.sn('CREATE_ACCOUNT>>'||sqlerrm(sqlcode));
                        RETURN('');
        END;
        
begin 
  dbms_output.put_line(CREATE_ACCOUNT_V2(cHeader => 'A',cBal => '47423', cCurrency => '810', dDate => trunc(sysdate)
                                        , nOwner => 1403,cName => '�����������', cCFU => '0000'));
                                        
  dbms_output.put_line(PACCOUNT.Error_Message);                                          
-- dbms_output.put_line(Paccount.CREATE_ACCOUNT(cHeader => 'A',cBal => '47423', cCurrency => '810', dDate => trunc(sysdate)
 --                                       , nOwner => 1403,cName => '�����������', cCFU => '0001'));                                                                                                                                                                         
 --IF cAccount IS NULL or cAccount = '' THEN
--   RETURN('������ ��� �������� �����. ���.���� '||cBal|| ' ��� '||cCurrency);
--- END IF; 
end;  