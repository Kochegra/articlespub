select rowid,u.* from users u where user_id = 495000833 


select * from DBA_SYS_PRIVS where grantee = 'MBANK_ADMIN_ROLE'

select * from DBA_SYS_PRIVS where grantee = 'MBANK_READ_ROLE'

select * from DBA_TAB_PRIVS where table_name like '%PROFILER%'

grant SELECT,UPDATE,DELETE,INSERT on PLSQL_PROFILER_DATA to MBANK_READ_ROLE
grant SELECT,UPDATE,DELETE,INSERT on PLSQL_PROFILER_RUNS to MBANK_READ_ROLE
grant SELECT,UPDATE,DELETE,INSERT on PLSQL_PROFILER_RUNS to MBANK_READ_ROLE

PLSQL_PROFILER_DATA
PLSQL_PROFILER_RUNS
PLSQL_PROFILER_RUNS

 tee = 'MBANK_READ_ROLE'

alter user MB_1  QUOTA 1000M on bank_medium
/

select * from DBA_SYS_PRIVS where grantee = 'MBANK_ADMIN_ROLE'

grant CREATE ANY INDEX to MBANK_ADMIN_ROLE

grant CREATE ANY INDEX to MBANK_ADMIN_ROLE WITH ADMIN OPTION;
/

select * from dba_tables where table_name like '%PROFILE%'
/

collateral_CFT_KMB

CREATE INDEX MBANK.collateral_CFT_KMB_IDX ON MBANK.collateral_CFT_KMB
(branch,reference)
LOGGING
TABLESPACE IDX_MEDIUM
PCTFREE    0
INITRANS   20
MAXTRANS   255
STORAGE    (
            INITIAL          40M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        37
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
/

CREATE INDEX MBANK.collateral_CFT_KMB_CNV_IDX ON MBANK.collateral_CFT_KMB
(convert_bra,convert_ref)
LOGGING
TABLESPACE IDX_MEDIUM
PCTFREE    0
INITRANS   20
MAXTRANS   255
STORAGE    (
            INITIAL          40M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        37
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
           
tmp_cft_report_do           

DROP INDEX IDX_TMP_CFT_REPORT_DO

CREATE INDEX MBANK.TMP_CFT_REPORT_DO_IDX ON MBANK.TMP_CFT_REPORT_DO
(filial_id, USER#, FILE_NAME)
LOGGING
TABLESPACE BANK_MEDIUM
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );
/

begin
  dbms_stats.gather_table_stats('MBANK','TMP_CFT_REPORT_DO');
  dbms_stats.gather_table_stats('MBANK','COLLATERAL_CFT_KMB');
end;

