select * from mb_od_log where start_time > trunc(sysdate)
/

select * from documents where reference = 3693310146


select * from zyx_jstat
/

select work_date,count(*)/2 from journal where header = 'A' and work_date = '10dec2019'
--and nvl(operation,'ar') <> '519002'
and related > 7284 and related < 7284.13 
group by work_date  


select to_date('11.12.2019 10','dd.mm.yyyy hh24')-to_date('01.01.2000','dd.mm.yyyy') from dual 
/

select count(*) from account where substr(code,1,5) in ('40106','40202','40203','40302','40501','40502','40503','40504','40602','40603','40701','40702','40703','40802','40804','40807')
and close_date is null
/

select work_date,count(*) from journal where header = 'A' and work_date = '10dec2019'
and substr(code,1,5) in ('40106','40202','40203','40302','40501','40502','40503','40504','40602','40603','40701','40702','40703','40802','40804','40807')
group by work_date 

/

select currency,sum(bad),count(*) from (
select 
currency
,nvl((select min(1) from variable_contracts v where name in ('ACCOUNT_NOSROK','ACCOUNT_NOSROK_474')
and reference = c.reference and branch = c.branch 
and COALESCE((select wrest from ledger l WHERE header = 'A' and code = v.value and currency = substr(v.value,6,3) and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) <> 0
 ),0) bad 
from contracts c where type_doc in (30171,30172,7422,7731)
and status = 50
)
group by currency
/

select * from contracts where type_doc in (--6774
6776,6777
)
 and status = 50
 /
 --��������
 select currency,count(*) from contracts where (refer_from,branch_from) in 
 (select reference,branch from contracts where type_doc in (6776,6777) and status = 50)
 and status = 50
 group by currency

 /
 --��� ��������
 select currency,count(*) from contracts where type_doc in (select type from variable_types where name = 'PRODUCT' and value = 'DEPOSIT')
 and type_client = 5 and status = 50
 group by currency
 /
 
 --��� �������
 select currency,count(*) from contracts where type_doc in (select type from variable_types where name = 'PRODUCT' and value = 'CREDIT')
 and type_client = 5 and status = 50
 group by currency
 
  select * from contracts where type_doc in (select type from variable_types where name = 'PRODUCT' and value = 'CREDIT' and type not in (976))
 and type_client = 5 and status = 50 and child = 0
/

select * from variable_types where type = 3926