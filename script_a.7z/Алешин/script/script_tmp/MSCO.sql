--MSCO

select * from guides where type_doc=9999 and code = '45586' --date3 > sysdate -10
/

--������
select * from msco.v_installation where install_id = 41563

--������
select * from msco.tbl_installation where install_id = 39764

--������
select * from msco.tbl_installation_hist where install_id = 45586

select * from msco.tbl_installation_exec where install_id = 45586

--�����
select * from msco.tbl_patch_hist where install_id = 45586

select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = 41563

--�����
select * from msco.tbl_patch_file_his where 1=1 
--patch_id = 106958
and file_name like '%PHOTOSPASSPORTS%'

--�����
select * from (select distinct file_name, install_id from msco.tbl_patch_hist pp, msco.tbl_patch_file_his pf where pf.patch_id = pp.patch_id ) where install_id = 41059 


--���� ������
select * from msco.tbl_install_db_hist where install_id = 41563

select * from msco.newver_info where set_id = 45586

--��� ������ �� �������������
select * from msco.tbl_installation_hist tt where date_create > sysdate-100
and date_change = (select max(date_change) from msco.tbl_installation_hist where install_id = tt.install_id)
and status not in ('COMPLETED','CANCEL')
and exists (select null from msco.tbl_install_db_hist where install_id = tt.install_id and db_name in ('TRAIN','DSS'))
/

--��� ������ �� ������������� (�����)
select (select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_installation_hist) where install_id = tt.install_id) all_memo
,(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = tt.install_id) all_memo_p
,(select sys_xmlagg(xmlelement(file_name,file_name||chr(13))).extract('/ROWSET/FILE_NAME/text()') from (select distinct file_name, install_id from msco.tbl_patch pp, msco.tbl_patch_file pf where pf.patch_id = pp.patch_id ) where install_id = tt.install_id) all_files
,(select sys_xmlagg(xmlelement(db_name,db_name||chr(13))).extract('/ROWSET/DB_NAME/text()') from (select distinct db_name, install_id from msco.tbl_install_db) where install_id = tt.install_id) all_DB
,(select sys_xmlagg(xmlelement(set_base,set_base||chr(13))).extract('/ROWSET/SET_BASE/text()') from (select distinct set_base, set_id from msco.newver_info) where set_id = tt.install_id) newver
,(select user_fio from msco.tbl_employee where user_id = tt.owner) own_name
,Install_name||' ('||install_id||')', status, date_create 
from msco.tbl_installation tt--, msco.tbl_install_db_hist dd--, msco.tbl_patch_hist pp,
where tt.date_create > sysdate-20
--and tt.date_change = (select max(date_change) from msco.tbl_installation_hist where install_id = tt.install_id)
--and tt.id = (select max(id) from msco.tbl_installation_hist where install_id = tt.install_id)
and tt.status not in ('CANCEL','DENIED','CREATE')
--and tt.status <> 'COMPLETED'
and not exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('TRAIN'))--,'DSS','CHIN','MBK3'))
and exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('DSS','CHIN','MBK3'))--,'DSS','CHIN','MBK3'))
--and nvl(date_install,sysdate) > sysdate-3
and date_install is null
--and tt.install_id in (42056,42054,42053,42052,42051)
order by tt.date_create desc
/


--��� ������ � ���������
select (select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_installation_hist) where install_id = tt.install_id) all_memo
,(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = tt.install_id) all_memo_p
,(select sys_xmlagg(xmlelement(file_name,file_name||chr(13))).extract('/ROWSET/FILE_NAME/text()') from (select distinct file_name, install_id from msco.tbl_patch pp, msco.tbl_patch_file pf where pf.patch_id = pp.patch_id ) where install_id = tt.install_id) all_files
,(select sys_xmlagg(xmlelement(db_name,db_name||chr(13))).extract('/ROWSET/DB_NAME/text()') from (select distinct db_name, install_id from msco.tbl_install_db) where install_id = tt.install_id) all_DB
,(select sys_xmlagg(xmlelement(set_base,set_base||chr(13))).extract('/ROWSET/SET_BASE/text()') from (select distinct set_base, set_id from msco.newver_info) where set_id = tt.install_id) newver
,(select user_fio from msco.tbl_employee where user_id = tt.owner) own_name
,Install_name||' ('||install_id||')', status, date_create 
from msco.tbl_installation tt--, msco.tbl_install_db_hist dd--, msco.tbl_patch_hist pp,
where tt.date_create > sysdate-160
--and tt.date_change = (select max(date_change) from msco.tbl_installation_hist where install_id = tt.install_id)
--and tt.id = (select max(id) from msco.tbl_installation_hist where install_id = tt.install_id)
and tt.status not in ('CANCEL','DENIED','CREATE','TRAINING')
--and tt.status <> 'COMPLETED'
--and not exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('TRAIN'))--,'DSS','CHIN','MBK3'))
and exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('TRAIN'))--,'DSS','CHIN','MBK3'))
--and nvl(date_install,sysdate) > sysdate-3
and date_install is null
--and tt.install_id in (42056,42054,42053,42052,42051)
order by tt.date_create desc
/

--��� ������ ��� ������������� (�����������)
select (select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_installation_hist) where install_id = tt.install_id) all_memo
,(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = tt.install_id) all_memo_p
,(select sys_xmlagg(xmlelement(file_name,file_name||chr(13))).extract('/ROWSET/FILE_NAME/text()') from (select distinct file_name, install_id from msco.tbl_patch_hist pp, msco.tbl_patch_file_his pf where pf.patch_id = pp.patch_id ) where install_id = tt.install_id) all_files
,(select sys_xmlagg(xmlelement(db_name,db_name||chr(13))).extract('/ROWSET/DB_NAME/text()') from (select distinct db_name, install_id from msco.tbl_install_db_hist) where install_id = tt.install_id) all_DB
,universe.nameowner(owner) Own_name
,Install_name||' ('||install_id||')', status, date_create, date_install 
--,tt.*
 from msco.tbl_installation_hist tt
where tt.date_INSTALL > sysdate-6
and tt.id = (select max(id) from msco.tbl_installation_hist where install_id = tt.install_id)
and tt.status = 'COMPLETED' and exists (select null from msco.tbl_install_db_hist where install_id = tt.install_id and db_name in ('TRAIN'))
order by tt.date_create desc
/

select * from (
select (select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_installation_hist) where install_id = tt.install_id) all_memo
,(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = tt.install_id) all_memo_p
,(select sys_xmlagg(xmlelement(file_name,file_name||chr(13))).extract('/ROWSET/FILE_NAME/text()') from (select distinct file_name, install_id from msco.tbl_patch pp, msco.tbl_patch_file pf where pf.patch_id = pp.patch_id ) where install_id = tt.install_id) all_files
,(select sys_xmlagg(xmlelement(db_name,db_name||chr(13))).extract('/ROWSET/DB_NAME/text()') from (select distinct db_name, install_id from msco.tbl_install_db) where install_id = tt.install_id) all_DB
,(select sys_xmlagg(xmlelement(set_base,set_base||chr(13))).extract('/ROWSET/SET_BASE/text()') from (select distinct set_base, set_id from msco.newver_info) where set_id = tt.install_id) newver
,(select user_fio from msco.tbl_employee where user_id = tt.owner) own_name
,Install_name||' ('||install_id||')', status, date_create
,tt.install_id 
--,tt.*
from msco.tbl_installation tt--, msco.tbl_install_db_hist dd--, msco.tbl_patch_hist pp,
where tt.date_create > sysdate-300 --2000
) t where 1=1 
--and not exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('TRAIN'))--,'DSS','CHIN','MBK3'))
--and exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('DSS','CHIN','MBK3','TRAIN'))--,'DSS','CHIN','MBK3'))
and t.install_id in ( 47880      )
--and t.newver like '%DEPKIB-1070%'
--order by t.date_create desc
/

select --(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_installation_hist) where install_id = tt.install_id) all_memo
--,(select sys_xmlagg(xmlelement(memo,memo||chr(13))).extract('/ROWSET/MEMO/text()') from (select distinct to_char(memo) memo,install_id from msco.tbl_patch_hist) where install_id = tt.install_id) all_memo_p
--,(select sys_xmlagg(xmlelement(file_name,file_name||chr(13))).extract('/ROWSET/FILE_NAME/text()') from (select distinct file_name, install_id from msco.tbl_patch pp, msco.tbl_patch_file pf where pf.patch_id = pp.patch_id ) where install_id = tt.install_id) all_files
--,(select sys_xmlagg(xmlelement(db_name,db_name||chr(13))).extract('/ROWSET/DB_NAME/text()') from (select distinct db_name, install_id from msco.tbl_install_db) where install_id = tt.install_id) all_DB
(select sys_xmlagg(xmlelement(set_base,set_base||chr(13))).extract('/ROWSET/SET_BASE/text()') from (select distinct set_base, set_id from msco.newver_info) where set_id = tt.install_id) newver
,(select user_fio from msco.tbl_employee where user_id = tt.owner) own_name
,Install_name||' ('||install_id||')', status, date_create
,tt.install_id 
--,tt.*
from msco.tbl_installation tt--, msco.tbl_install_db_hist dd--, msco.tbl_patch_hist pp,
where tt.date_create > sysdate-300 --2000
) t where 1=1 
--and not exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('TRAIN'))--,'DSS','CHIN','MBK3'))
--and exists (select null from msco.tbl_install_db where install_id = tt.install_id and db_name in ('DSS','CHIN','MBK3','TRAIN'))--,'DSS','CHIN','MBK3'))
--and t.install_id in ( 47600     )
--and t.newver like '%DEPKIB-1070%'


select * from msco.newver_info where set_base like '%UPRLIKV-403%' 



          