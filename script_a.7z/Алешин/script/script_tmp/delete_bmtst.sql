begin
 insert into IMAGES_PARENT_bmtst@mainb
select * from IMAGES_PARENT i
where operation = '3' and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj )
and i.branch_obj <> 108000;
commit;
  dbms_session.close_database_link('MAINB'); 
end;
/


begin
  for rr in (
    select rowid rid from IMAGES_DOC
   where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT i
   where operation = '3' and exists (select null from mbank.scoring_forms where reference = i.refer_obj and branch = i.branch_obj )
   and i.branch_obj <> 108000 and i.branch_obj < 1000
   and mod(refer_Obj,10) = nvl('&1',mod(refer_obj,10))
   ))
  loop  
   insert into IMAGES_DOC_bmtst@mainb select * from IMAGES_DOC where rowid = rr.rid;
   commit;
  end loop; 
  dbms_session.close_database_link('MAINB'); 
end;
/


    select rowid rid from IMAGES_DOC
   where (reference,branch,image_type) in (select refer_image,branch_image,p_type from IMAGES_PARENT i
   where operation = '3' and exists (select /*+ INDEX (sf SCORING_FORMS_PK)*/ null from mbank.scoring_forms sf where reference = i.refer_obj and branch = i.branch_obj )
   and i.branch_obj <> 108000 --and i.branch_obj > 50 and i.branch_obj < 1000
   and branch >= 1000 and branch < 100000  
   and mod(refer_Obj,10) = nvl('&1',mod(refer_obj,10))
   )
   
  /
   
       select COUNT(*) from IMAGES_DOC d, IMAGES_PARENT i
   where d.reference = i.refer_image and d.branch = i.branch_image and d.image_type = i.p_type 
   and i.operation = '3'
    and (i.branch_obj,i.refer_obj) in
     (select /*+ INDEX (sf SCORING_FORMS_PK)*/ branch,reference from mbank.scoring_forms sf where branch <> 108000 
     --and branch > 50 and branch < 1000
     and branch >= 1000 and branch < 100000  
    -- and mod(reference,10) = nvl(&1,mod(reference,10))
   )
 /    
 
   

   begin
for ii in (select rowid rid from IMAGES_DOC1_BMTST d where 1=1 
           and not exists (select null from IMAGES_DOC_BMTST where REFERENCE = d.REFERENCE and branch = d.branch and IMAGE_TYPE = d.IMAGE_TYPE)
          )
loop
  insert into IMAGES_DOC_BMTST select * from IMAGES_DOC1_BMTST where rowid = ii.rid;
  commit;
end loop;           
end;
/

 begin
 for ss in (
            select * from v$session where 1=1 --username = 'CT_GUIDES' --����
            and sid in (11566,11519)
 )
 loop
     BEGIN
        SYSTEM.Kill_Session(p_sid => ss.sid, p_serial => ss.serial#);
      EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.Put_Line(SQLERRM);
      END;  
 end loop;  
end;