select * from boss_emp_all where search_name like upper('����� �����_ ���������')

/

select tab_n tabn, 191 subd, 31125 job, email, b.* from boss_emp_all b where tab_n in (404665,322230,391058)
/

--������� ������������� �� ������
declare
  r_usr users%rowtype;
begin 
  for uu in ( 
              select tab_n tabn, 405018 subd, 31247 job, 'AUDIT_IB' lgn, email from boss_emp_all b where tab_n in ('251672','250319')
                          )
  loop
    r_usr := mbank_admin.adm_tools.Set_User(uu.tabn,uu.subd,uu.job,uu.lgn);     
    dbms_output.put_line('tabn = '||r_usr.params||' user_id = '||r_usr.user_id||' job - '||r_usr.job||' subdepartment - '||r_usr.subdepartment);
    if r_usr.user_id > 0 then
      --dbms_output.put_line(' create - '||mbank_admin.adm_tools.mb_user_create(usr => r_usr.user_id, pswd => null, lvl => 1, email => 'r.aleshin@vtb.ru'));
      dbms_output.put_line(' create - ');
    end if;         
  end loop;           
  --dbms_output.put_line('���������� = ');
end;
--*/
/

select rowid,u.* from users u 
/
--����������
select * from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
and au.tbl = 'USERS'
and au.dt > sysdate-1/24
order by au.dt desc
/

select rowid,
--select (select count(*) from v$session where username = u.user_) act, (select count(*) from all_users where username = u.user_) ext,
set_mb_user.decryptpassn_login(decode(length(translate(PASSWORD,'#0123456789ABCDEF','#')),null,user_),'PASSWORD') psw,
set_mb_user.decryptpassn_login(decode(length(translate(RIGHTS,'#0123456789ABCDEF','#')),null,user_),'RIGHTS') psw,   
--update users u set password = substr(password,3)
u.* from users u
where 1=1 
--and user_name = ������� �.�. 
and user_id = 978042
--and params in ('381087', '429319')
/

select * from group_membership where user_id = 208004829
/

select * from object_rights where id = 208000
/
select rowid,t.* from variable_subdepartments t
--update variable_subdepartments t set value = '09.11.2019' 
where name = 'SYSTEMDATE' and value = '08.11.2019' --depart_id = 76001 
/
 
--������ ������
select rowid,u.* from users u
--update users u set password = 'ar'||password
where job not in (1,31445,30995,95,471,336,31160,613,2455492,31306,31305,31377,31335,30950,235)
and exists (select null from all_users where username = u.user_)
and substr(password,1,2) <> 'ar'
and subdepartment in (select num4 from zyx_store where num1 = 544 and oper = 'FIL_MIGR' and tbl = 'SUBDEPARTMENTS')
/


--������� ������������� �� ������
declare
  r_usr users%rowtype;
  
begin 
  for uu in ( 
         --    select params tabn, 191 subd, 31247 job, null email from users z
           --   where params in ('245542','396558','220224')
           select tab_n tabn, 405018 subd, 9 job, null email from boss_emp_all b where tab_n in ('251672','250319') 
            )
  loop
    r_usr := mbank_admin.adm_tools.Set_User(uu.tabn,uu.subd,uu.job);     
    dbms_output.put_line('tabn = '||r_usr.params||' user_id = '||r_usr.user_id||' job - '||r_usr.job||' subdepartment - '||r_usr.subdepartment);
    if r_usr.user_id > 0 then
      dbms_output.put_line(' create - '||mbank_admin.adm_tools.mb_user_create(usr => r_usr.user_id, pswd => null, lvl => 0, email => 'r.aleshin@vtb.ru'));
    end if;         
  end loop;           
  --dbms_output.put_line('���������� = ');
end;
/

begin
  dbms_stats.gather_table_stats('MBANK','PARAMETERS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','PARAMVALUES',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','PARAMGROUPMEMBERSHIP',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','GROUPS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','GROUP_MEMBERSHIP',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','GROUPS_RIGHTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','SUBDEPARTMENTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','VARIABLE_SUBDEPARTMENTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade); 
  dbms_stats.gather_table_stats('MBANK','TYPES',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','VARIABLE_TYPES',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','USERS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','USER_PARAM_VALUES',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','USERS_RIGHTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','JOBS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade);
  dbms_stats.gather_table_stats('MBANK','JOB_PARAM_VALUES',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','JOBS_RIGHTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','OBJECT_RIGHTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','BOSS_EMP_ALL',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','BOSS_SUBDEPARTMENTS',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','USERS_ALL',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
  dbms_stats.gather_table_stats('MBANK','USER_PARAMETERS_ALL',ESTIMATE_PERCENT => 100,CASCADE => dbms_stats.auto_cascade,DEGREE => 6);
end;
/

-- ~30 ��� �� ���� ��������  (���� ��� ���������� ����� ������������� ����������, � � ����� ���������� �� ����������)
begin
  dbms_stats.gather_table_stats('MBANK_AUDIT','AUDIT_TABLE',partname => 'SYS_P5686117',granularity => 'APPROX_GLOBAL AND PARTITION'); 
end;

select * from all_tab_partitions where table_name = 'AUDIT_TABLE'

DBA_UTILS

ALTER TABLE MBANK.GROUP_MEMBERSHIP drop CONSTRAINT GROUP_MEMBERSHIP_FK ;

Drop INDEX MBANK.GROUP_MEMBERSHIP_INDEX 
/

/* Formatted on 19.06.2020 7:51:33 (QP5 v5.300) */
SELECT GROUP_ID
  FROM MBANK.GROUPS G
 WHERE --substr(group_,1,1) = 'D' and 
 EXISTS
           (SELECT NULL FROM MBANK.SUBDEPARTMENTS S  WHERE  MBANK.PUSER.GET_RIGHT_SUBDEP (:B1, S.ID) < 0
                   AND G.GROUP_ LIKE 'D' || S.ID || ' %')
/

SELECT GROUP_ID  FROM MBANK.GROUPS G, MBANK.SUBDEPARTMENTS S 
 WHERE G.GROUP_ LIKE 'D' || S.ID || ' %' and MBANK.PUSER.GET_RIGHT_SUBDEP (:B1, S.ID) < 0
                   

/
DELETE MBANK.GROUP_MEMBERSHIP
 WHERE     GROUP_ID IN
               (SELECT GROUP_ID
                  FROM MBANK.GROUPS G
                 WHERE --    SUBSTR (G.GROUP_, 1, 1) = 'D'
                       EXISTS (SELECT NULL FROM MBANK.SUBDEPARTMENTS S
                                 WHERE     MBANK.PUSER.GET_RIGHT_SUBDEP (
                                               :B1,
                                               S.ID) = 0
                                       AND G.GROUP_ LIKE 'D' || S.ID || ' %'))
       AND USER_ID = :B1
/

DELETE MBANK.GROUP_MEMBERSHIP
 WHERE     GROUP_ID IN (SELECT GROUP_ID  FROM MBANK.GROUPS G, MBANK.SUBDEPARTMENTS S 
                           WHERE G.GROUP_ LIKE 'D' || S.ID || ' %' and MBANK.PUSER.GET_RIGHT_SUBDEP (:B1, S.ID) = 0)
/
begin --���������
 
 /*for tt in (select rowid, str1 u_tabn, num3 u_job, num2 u_subdep, str2 u_name from zyx_store where oper = 'TEST' and tbl = 'USERS' and nvl(status,0) = 0)
  loop
    
  end loop;
  for uu in (
   select user_id usr_id, user_ usr_lgn,'Tt123456' usr_pwd from users u, zyx_store z
  where params = str1 and oper = 'TEST' and tbl = 'USERS'
 --and job = 613
and exists (select null from all_users where username = u.user_) 
)
  loop

 */
  --usr_id := 978042;  
  --dbms_output.put_line('Del_User_GroupM - '||Del_User_GroupM(usr_id,127));
  --dbms_output.put_line('Set_User_GroupM - '||Set_User_GroupM(usr_id,127));   
  --dbms_output.put_line('Del_User_GroupR - '||Del_User_GroupR(usr_id,127)); 
  --dbms_output.put_line('Set_User_GroupR - '||Set_User_GroupR(usr_id,127));  
  --dbms_output.put_line('Get_Kod_Kassir - '||Get_Kod_Kassir(56));
 -- dbms_output.put_line('Del_User_Param - '||Del_User_Param(usr_id,'���')); 
 -- dbms_output.put_line('Set_User_Param - '||Set_User_Param(usr_id,'���','������ ����� ���'));
 --  dbms_output.put_line('Get_User_id - '||Get_User_id(9823,191,f_lgn => 'KHRICHENKOVA'));       
 --  dbms_output.put_line('Ins_User - '||Ins_User(9823,191,null));
 -- dbms_output.put_line('Upd_User_Groups - '||Upd_User_Groups(957904817));
 --  dbms_output.put_line('Get_Who - '||Get_Who);
--    dbms_output.put_line(' Get_Subd_F - '|| Get_Subd_F(f_val => '146056'));
 --   dbms_output.put_line(' Get_Subd_Boss - '|| Get_Subd_Boss(f_id => 602261, f_par => 'SAP_ID'));
 --   dbms_output.put_line(' Upd_User_Subd - '|| Upd_User_Subd(978042,191));  
--   dbms_output.put_line(' Get_User_Param - '|| Get_User_Param(978042,'LAST_LOGOUT','')); 
  -- dbms_output.put_line(' Set_User_Params_Pers - '|| Set_User_Params_Pers(978042,135));
   dbms_output.put_line(' Get_Right_Type - '|| pUSER.Get_Right_Type(978042,1,4));
  commit;
end;
/

--������� �����������
LOG_ERRORS
LOG_ACTIONS
/

select * from mbank_audit.mb_audit au, mbank_audit.mb_audit_values auv where au.ref = auv.ref(+) and au.br = auv.br(+)
and tbl = 'GROUPS_RIGHTS' and dt > sysdate-1/24 
/

select * from users where
user_id = 978042
 params = '9823'

select * from USER_PARAM_VALUES where user_id = 978042 and id in (select id from user_parameters where name = '���')

select * from group_membership where user_id = 957904817   

select * from GROUPS_RIGHTS where object_id = 957904817   

select * from object_RIGHTS where object_id = 957904817   

select * from config
/

declare
  emp globals.UserIdList;
begin
  puser.init(978042);
  --puser.init(497150);
   --puser.init(1403);
  --globals.subdepartmentslist := emp;
  --globals.userlist := emp;
end;
/


select count(*) from (
select (select count(*) from v$session where username = u.user_) act
,z.num4 subd_new 
,u.*,z.* from users u, zyx_store z where subdepartment = z.num2 and job not in (31445)
and z.oper = 'FIL_MIGR' and z.tbl = 'SUBDEPARTMENTS' and z.num1 = 191
and exists (select null from zyx_store where num1 = 544 and num4 = z.num4 and oper = z.oper and tbl = z.tbl)
) 
--where act > 0


