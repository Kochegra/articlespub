select header,substr(code,1,5),count(*)
,(select name from plan_account where header = a.header and bal=  substr(a.code,1,5)) nm from account a where close_date is null
group by header,substr(code,1,5)
/


select * from (
select 
COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) sld
,(select count(*) from journal where header = a.header and code = a.code and currency = a.currency and work_date > sysdate-40) cnt
,a.* from account a where close_date is null
and code in ('70601810100002720151','70606810600434111804','70606810500434111904','70606810700434112004')
) where 1=1 --sld <> 0

/

update account a set close_date = trunc(sysdate) where 1=1
and code in ('70601810100002720151','70606810600434111804','70606810500434111904','70606810700434112004')

select * from (
select 
COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) sld
,(select count(*) from journal where header = a.header and code = a.code and currency = a.currency and work_date > sysdate-40) cnt
,a.* from account a where close_date is null
) where sld <> 0 and substr(code,1,5) in ('40820','40823') and header = 'X'


select header,code,currency,status_id,count(*) from status_account 
group by header,code,currency,status_id
order by count(*) desc
/



select * from journal where work_date >= to_date('07.01.2022','dd.mm.yyyy')
and '40504810' not in (substr(code,1,8),substr(assist,1,8))

--alter trigger journal_block enable

select * from documents where date_work >= to_date('07.01.2022','dd.mm.yyyy') and date_create > trunc(sysdate)
and type_doc not in (1614,6271,4560,6285,6270,8225,13002,161,5508,10956,19999) and sub_type not in (200)
and not substr(nvl(refer_office,'-'),1,2) = 'I_'
--and date_work > trunc(sysdate)
order by date_create desc

select universe.variable_doc(branch,reference,'DBO_TYPE'), d.* from documents d where (date_work > to_date('30.12.2021','dd.mm.yyyy') or DATE_WORK IS NULL)
 and date_create > trunc(sysdate)-5
--and type_doc not in (1614,6271,4560,6285,6270,8225,13002,161,5508) 
and substr(refer_office,1,2) = 'I_' 
--and (status < 30 or status = 90) 
order by date_create desc
/


select * from variable_documents where reference = 7074209060 and branch = 191
/

select * from types where type_id in (1614,6271,4560,6285,6270,8225,13002,161,5508,10956,19999) 
/


select UNIVERSE.NAMETYPE(type_doc),d.* from documents d where 1=1 and date_create > trunc(sysdate)-1
and type_doc not in (1614,6271,4560,6285,6270,8225,13002,161,5508,10956,19999,4215,7176,13641,4125,4120,12883,100,11419,7175,13201,12623,14736,14735,14386,12916,14739,12664
,14577,13359,13360,14738,13361,13295,7182,10957,12036,10553,13822,13436,12758,10961,4171,14218,10422,14570,11606,14737,10886,14768,7177,10887,1786,13490,14732,10885,14776,13346,3369
,13496,1173,12153,3081)
and type_doc not in (1,152,107,28,5087,270,203,198,233,6576,6564,4665,8628,252,199,2806,11422,9035,5098,95,226,5099,8066,8934,5859,4132,4851,6722,153,4124,3753,1432,4131,7071,3296
,4497,561,4790,505,5559,13000,1982,2208,159,7581,5991,7386,7440)
and type_doc not in (2,6,1161,4814)
 and sub_type not in (200)
 and branch not in (200)
and not substr(nvl(refer_office,'-'),1,2) = 'I_'
and status < 1000
and type_doc not in (select type from variable_types where name = 'UNBLOCK' and value = '0') 
order by date_create desc
/

select * from types where type_id in 
(select type from variable_types where name = 'UNBLOCK' and value = '0') 

select rowid,v.* from variable_types v where name = 'UNBLOCK' and value = '0'
order by type 

--insert into variable_types
select * from (select 'UNBLOCK' name,type_id type,0,'0' value from types where type_id in (3445,990,1990,270,6087,4434,3829,7205,4827,17,8058,3363,5384,14664,13797,3476,12871
,9770,13886,7990,4998,6245,4966,7754,7683,4607,4208,12716,12154,12169,12170,13337,12153,12155,4690 
)) t
where not exists (select null from variable_types where type = t.type and name = t.name)

select rowid,d.* from documents d where reference = 7074360409 

select rowid,d.* from archive d where type_doc = 4572 and date_work >= to_date('21.12.2021','dd.mm.yyyy')

select d.* from documents d where type_doc = 6 and date_work >=  to_date('11.01.2022','dd.mm.yyyy')

select d.* from documents d where type_doc = 1173 and date_create > sysdate-2

--insert into variable_types
select * from (select 'UNBLOCK' name,type_id type,0,'1' value from types where type_id in (12457,12488,590,5142,7437,6385)) t
where not exists (select null from variable_types where type = t.type and name = t.name)
/
select * from contracts where reference = 10004679

select * from types where type_id in 
(select type from variable_types where name = 'UNBLOCK' and value = '1') 

/
select * from documents where type_doc = 1161 and date_create > sysdate-1
order by date_create desc


select * from archive where type_doc = 1161 and date_work = to_date('30.12.2021','dd.mm.yyyy')
and xsubdepartment = 200

--alter trigger documents_block disable
--alter trigger documents_block enable


select GLOBAL_PARAMETERS.VAR_SUBDEPARTMENTS(id,'UNBLOCK') uu, s.* from subdepartments s where id = 200010


--insert into variable_subdepartments
select * from (select 'UNBLOCK' name,id depart_id,0,'1' value from subdepartments where parent = 200--id in (200,405)
) t
where not exists (select null from variable_subdepartments where depart_id = t.depart_id and name = t.name)


select rowid,v.* from variable_subdepartments v where bisquit

select rowid,v.* from eid.eid_subdep_variable v where TYPE like 'BISQUIT_ID' and value in ('690')


select * from eid.eid_subdepartments where id in (780469,785370,780465,785030,780466,785020)



