select * from EDK_DOC_VERSION where id_version > 21682682-1000

/

select rowid,e.* from eid.EID_CARD_COLLECTOR e where pk = '1'

select t.* from CF_COLLECTOR t where work_date > sysdate-1and docnum = 7163910390

select * from EDK_FILES_RECEIVED where id > 29287554-10000


select * from TBL_ENTITY_OBJECT_ATTR_LOG where id > 2602022591-10000

select * from TBL_SWIFT_STATUS_HIST where id > 2818181846-10

select * from SCD_DOCUMENTS_HIST where id > 1029305609-10

select * from eid.EID_FIRMA_MANAGER_HISTORY where id_record > 172758446-1000

select * from eid.EID_FIRMA_VARIABLE where id > 1197996347-100000

select * from TBL_ENT_OBJ_ON_ROUT where  id > 501476995-10000

select * from TBL_ENT_OBJ_ON_ROUT_HIST where  id > 501474279-10000

select * from FSSP_HISTORY WHERE timestart > sysdate-1

select * from PBS_BF_DOCUMENT where id > 209508284-10

select * from EID.EID_PRODUCTS_VARIABLE where id > 457537507-100

select * from EID_ACTIVITY_LOG where date_work > sysdate-2000 and task_id = 1

select * from EID.EID_SERVICE_OBJ_LIST where reference_obj > 7165421406-1000

select * from RESERVE_MSFO_POS_HIST where work_date > sysdate-30


select * from RESERVE_MSFO_POS_HIST where work_date > sysdate-80

select * from SYNERGY_QUERIES_REESTR where VTB_TRAN_ID = 'SP.3275976'

select * from SYNERGY_QUERIES where VTB_TRAN_ID = 'SP.3275976'

select * from PRC_LOADER.UKM_PCARD_HISTORY where rep_point > sysdate-10

select * from MBANK.WORK_LOG_ARCHIVE where date_message > sysdate-100

select * from MBANK.SWMESSAGES where id > 260751835-10

select * from PRC_LOADER.PCARD_RESERV where rep_point > sysdate-30

select * from EID.FAST_PAYMENT where date_create > sysdate-1

select * from EID.FAST_PAYMENT_KVIT where date_kvit > sysdate-3

select * from MBANK.BO_CONTENTOUTPUT where message > 870439918-10

select * from MBANK.VARIABLE_CLIENTS where branch = 191 and reference > 118214255-100

select * from MBANK.SVK_TASK_BLOB where create_date > sysdate-60

select * from CR_DOCS.TBL_EL_DOC_CERTIFICATE where id > 45640170-10

select * from EID.EID_ANKETA_115FZ where id_anketa > 180356941-10

select * from MBANK.TBL_PLAN_EVENT where reference > 8780827570-100

select * from SCORING.SAS_OPERDAY_CARD where on_date > sysdate-200

select * from MBANK.U4936_DATA where id > 558789561-10

select * from MBANK.K2_LOGS where id > 273051669-10

select * from MBANK.BO_TITLEOUTPUT where initdate > sysdate-80

select * from MBANK.MQ_EVENTS where date_create >  sysdate-3

select * from MBANK.JOURNAL_DELETE where work_date > sysdate-80

select * from MBANK.FNS_MESSAGE_ARC where mes_date > sysdate-10

select * from EID.EID_FIRMA_MDM_UPLOAD where id_rec > 406386902-100000000

select id,status,date_start,date_finish from MBANK.UNIPAY_REQUEST where id > 4605383-10000

select max(doc_date) from MBANK.PBS_DOCUMENT_MAP