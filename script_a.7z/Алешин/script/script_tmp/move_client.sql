declare
  cnt number := 0;
  cnt_v number := 0; 
  own_id number := 1403;
  subdep number := 405007;
  sub_def number := 405007;
  fil number := mbfilid@vtbmain;
  
begin
  for t in (
              select * from clients cl where subdepartment = 405007 
             )
  loop     
   insert into clients@vtbmain(BRANCH,REFERENCE,REFER_FROM,RELATED,FOLDER,TYPE_DOC,SUB_TYPE,STATUS,CODE,SHORT_NAME,FULL_NAME,L_NAME,FULL_L_NAME,DOC_SERIA,DOC_NUMBER,REG_ATTR,DATE_REG,DATE_OPEN,INN,COUNTRY,REGION,POSTING,ADRES,PHONE,FAX,DATE_CREATE,DATE_END,DATE_MODIFY,OWNER,DATE_WORK,CHILD,BRANCH_RELATED,BRANCH_FROM,SUBDEPARTMENT,ADDRESS_REAL) 
        values (t.BRANCH,t.REFERENCE,t.REFER_FROM,t.RELATED,t.FOLDER,t.TYPE_DOC,t.SUB_TYPE,t.STATUS,t.CODE,t.SHORT_NAME,t.FULL_NAME,t.L_NAME,t.FULL_L_NAME,t.DOC_SERIA,t.DOC_NUMBER,t.REG_ATTR,t.DATE_REG,t.DATE_OPEN,t.INN,t.COUNTRY,t.REGION,t.POSTING,t.ADRES,t.PHONE,t.FAX,t.DATE_CREATE,t.DATE_END,t.DATE_MODIFY,t.OWNER,t.DATE_WORK,t.CHILD,t.BRANCH_RELATED,t.BRANCH_FROM,t.SUBDEPARTMENT,t.ADDRESS_REAL);      
cnt := cnt + sql%rowcount;

  for tt in (select * from variable_clients cl where reference = t.reference and branch = t.branch)
  loop
     insert into variable_clients@vtbmain(name,BRANCH,REFERENCE,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD) 
        values (tt.name,tt.BRANCH,tt.REFERENCE,tt.SUBNUMBER,tt.ROWNUMBER,tt.COLNUMBER,tt.VALUE,tt.SUBFIELD);                
cnt_v := cnt_v + sql%rowcount;
  end loop;
  update clients@vtbmain set owner = 2025037473 where reference = t.reference and branch = t.branch;
    commit;                   
  end loop;
      dbms_output.put_line('cnt = '||cnt||' cnt_v = '||cnt_v);             
end;