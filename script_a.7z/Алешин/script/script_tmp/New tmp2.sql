--��������������� �������
declare      
  r_tbl varchar2(30) := 'TBL_QUEUE_PAYFIND_CABS_MB_MQ';
  r_own varchar2(30) := 'MBANK';
  r_suf varchar2(6) := '$R';
  r_num pls_integer;
  cnt_invalid number := 0;
  cnt_trg number := 0;
  cnt_cns number := 0;
begin
  execute immediate 'select count(*) from all_constraints where owner = '''||r_own||''' and table_name = '''||r_tbl||'''' into cnt_cns;  
  execute immediate 'select count(*) from all_triggers where table_owner = '''||r_own||''' and table_name = '''||r_tbl||'''' into cnt_trg;
  dbms_output.put_line('start -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss')||' r_tbl -> '||r_tbl||' cnt_cns -> '||cnt_cns||' cnt_trg -> '||cnt_trg);
  --dbms_metadata.set_transform_param(dbms_metadata.session_transform,'CONSTRAINTS_AS_ALTER',TRUE);
   --dbms_metadata.set_transform_param(dbms_metadata.session_transform,'REF_CONSTRAINTS',FALSE);
  dbms_metadata.set_transform_param(dbms_metadata.session_transform,'CONSTRAINTS',FALSE);
  dbms_metadata.set_transform_param(dbms_metadata.session_transform,'STORAGE',FALSE);
  -- dbms_output.put_line(replace(dbms_metadata.get_ddl('TABLE',r_tbl,r_own),r_own||'"."'||r_tbl,r_own||'"."'||r_tbl||r_suf));
  execute immediate replace(dbms_metadata.get_ddl('TABLE',r_tbl,r_own),r_own||'"."'||r_tbl,r_own||'"."'||r_tbl||r_suf);
  --execute immediate 'create table '||r_tbl||r_suf||' as select * from '||r_tbl||' where 0=1';
  --�������� �����������  
  --dbms_redefinition.can_redef_table(uname => r_own, tname => r_tbl, options_flag => dbms_redefinition.cons_use_pk);
  dbms_redefinition.can_redef_table(uname => r_own, tname => r_tbl, options_flag => dbms_redefinition.cons_use_rowid);
  --������ ��������������� �������
  dbms_output.put_line(' start_redef_table '||r_tbl||' -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  --dbms_redefinition.start_redef_table(uname => r_own, orig_table => r_tbl, int_table => r_tbl||r_suf, options_flag => dbms_redefinition.cons_use_pk);
  dbms_redefinition.start_redef_table(uname => r_own, orig_table => r_tbl, int_table => r_tbl||r_suf, options_flag => dbms_redefinition.cons_use_rowid);
 --����������� ��������� �������� �������
  dbms_output.put_line('copy_table_dependents '||r_tbl||' -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));  
  dbms_redefinition.copy_table_dependents(uname => r_own, orig_table => r_tbl, int_table => r_tbl||r_suf, num_errors => r_num, ignore_errors => TRUE); 
  --���������� ��������������� �������, int_table ������� �������
  dbms_output.put_line('finish_redef_table '||r_tbl||' -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss')||' r_num -> '||r_num);
  dbms_redefinition.finish_redef_table(uname => r_own, orig_table => r_tbl, int_table => r_tbl||r_suf);
  select count(*) into cnt_invalid from dba_objects where status = 'INVALID' and owner in ('MBANK','EID') and object_name not in ('ACCOUNT_SVOD','MV_KBK','MV_ORG','PLAN_TMP_BAL_V');
  execute immediate 'select count(*) from all_constraints where owner = '''||r_own||''' and table_name = '''||r_tbl||'''' into cnt_cns;
  execute immediate 'select count(*) from all_triggers where table_owner = '''||r_own||''' and table_name = '''||r_tbl||'''' into cnt_trg;  
  dbms_output.put_line('finish -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss')||' r_num -> '||r_num||' cnt_invalid ->'||cnt_invalid||' cnt_cns -> '||cnt_cns||' cnt_trg -> '||cnt_trg);
end;
/

--alter table TBL_QUEUE_GIS_MQ_MB modify id null
--alter table TBL_QUEUE_EFR_MB_MQ modify id not null

-- TBL_QUEUE_BPMSMEV_MB_MQ $RD
 
--drop table TBL_QUEUE_PAYFIND_CABS_MB_MQ$RDF purge
/

begin
  dbms_output.put_line('TBL_QUEUE_FNS_MQ_MB start -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  dbms_redefinition.abort_redef_table(uname => 'MBANK', orig_table => 'MESSAGES', int_table => 'MESSAGES$RD');
  --dbms_redefinition.start_redef_table(uname => 'MBANK', orig_table => 'BIP_LOAD$FL_LOG', int_table => 'TBL_QUEUE_FNS_MQ_MBRDF', options_flag => dbms_redefinition.cons_use_rowid);
  dbms_output.put_line('TBL_QUEUE_SOI_GETACC_MB_MQ finish -> '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss')); 
end;
/

alter table text_files modify DIRECTORY      DEFAULT ''

DIRECTORY     VARCHAR2(2000 BYTE)             DEFAULT ''
/

select count(*) from dba_objects where status = 'INVALID' and owner in ('MBANK','EID')
 and object_name not in ('ACCOUNT_SVOD','MV_KBK','MV_ORG','PLAN_TMP_BAL_V') 
 
 select count(*) over(), sum(num2) over(), (dt2-dt3)*24*60*60, z.* from zyx_store z where oper = 'INFO' and tbl = 'DB_CLEAR' and str2 = 'TBL_QUEUE_BO_PUBLISHACC_MB_MQ' order by dt2 desc
select count(*) over(), sum(num2) over(), (dt2-dt3)*24*60*60, z.* from zyx_store z where oper = 'INFO' and tbl = 'DB_CLEAR' and str2 = 'TBL_QUEUE_PKB_LEADSTATUS_MQ_MB' order by dt2 desc
