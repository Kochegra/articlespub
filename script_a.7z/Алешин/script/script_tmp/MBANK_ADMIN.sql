--MBANK
grant execute on set_mb_user to MBANK_ADMIN;
grant execute on global_parameters to MBANK_ADMIN;
grant execute on p_email to MBANK_ADMIN; 
grant select,update,delete on subdepartments to MBANK_ADMIN;
grant select,update,delete on users to MBANK_ADMIN;
grant select,update,delete on user_parameters to MBANK_ADMIN;
grant select,update,delete on user_param_values to MBANK_ADMIN;
grant select,update,delete on info to MBANK_ADMIN;
grant st_mbank to MBANK_ADMIN with admin option;
grant execute on set_mb_user to MBANK_READ_ROLE;

--MBANK_ADMIN
grant execute on adm_tools to MBANK_READ_ROLE;

--MBANK_ADMIN_ROLE
grant st_adm_mbank to MBANK_ADMIN with admin option;

--SYS
grant execute on SYSTEM.KILL_SESSION to MBANK_ADMIN; 
grant create session to MBANK_ADMIN;
grant alter user to MBANK_ADMIN;
grant create user to MBANK_ADMIN;
grant drop user to MBANK_ADMIN; 
grant alter session to MBANK_ADMIN;
grant CREATE PROCEDURE to MBANK_ADMIN;
grant CREATE JOB to MBANK_ADMIN;
grant CREATE TYPE to MBANK_ADMIN;
grant CREATE VIEW to MBANK_ADMIN;
grant CREATE TABLE to MBANK_ADMIN;
grant CREATE SYNONYM to MBANK_ADMIN;
grant CREATE TRIGGER to MBANK_ADMIN;
grant CREATE SEQUENCE to MBANK_ADMIN;
grant CREATE MATERIALIZED VIEW to MBANK_ADMIN;
grant DEBUG CONNECT SESSION to MBANK_ADMIN;
grant QUERY REWRITE to MBANK_ADMIN;
grant FORCE TRANSACTION to MBANK_ADMIN;
grant CREATE RULE to MBANK_ADMIN;
grant CREATE RULE SET to MBANK_ADMIN;
/
--revoke execute on set_mb_user from MBANK_ADMIN;
--grant MBANK_ADMIN_ROLE to MBANK_ADMIN; 

--with grant option

select * from config where name = 'ADDITIONAL_SERVER_INFO'
/

select * from info
/

select * from DBA_TAB_PRIVS where 1=1 and grantee = 'MBANK_ADMIN_ROLE'
and owner = 'SYSTEM'