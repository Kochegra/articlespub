select * from DBA_ROLE_PRIVS where grantee like 'MB_OB%'
/

select * from DBA_TAB_PRIVS where grantee in ('MBANK_SUPPORT_ROLE','MBANK_READ_ROLE')
and table_name like 'GARANTY_2%'
/

select 'grant '||pp.priv||' on '||tt.owner||'.'||tt.object_name||' to MBANK_SUPPORT_ROLE;', tt.* from dba_objects tt, (select 'SELECT,UPDATE,INSERT,DELETE' priv from dual) pp
where owner in ('MBANK','EID','REPORT_SRV') 
and object_name in 'TBL_CFT_CLIENT_ACC'
and not exists (select null from DBA_TAB_PRIVS where grantee = 'MBANK_SUPPORT_ROLE' and owner = tt.OWNER and table_name = tt.object_name and instr(pp.priv,privilege) > 0)
/

select 'grant '||pp.priv||' on '||tt.owner||'.'||tt.object_name||' to MBANK_SUPPORT_ROLE;', tt.* from dba_objects tt, (select 'EXECUTE' priv from dual) pp
where owner in ('MBANK','EID','REPORT_SRV') 
and object_type in ('PACKAGE','FUNCTION')
--and object_name in ('P_BSS','PKG_REPORT_SRV','PKG_REPORT')
and object_name like 'SYNERGY%' 
and not exists (select null from DBA_TAB_PRIVS where grantee = 'MBANK_SUPPORT_ROLE' and owner = tt.OWNER and table_name = tt.object_name and instr(pp.priv,privilege) > 0)
/

select 'grant '||pp.priv||' on '||tt.owner||'.'||tt.object_name||' to MBANK_READ_ROLE;', tt.* from dba_objects tt, (select 'SELECT' priv from dual) pp
where owner in --('MBANK','EID','POOL')
('SMS_LOG') 
and object_type in ('TABLE')
and not exists (select null from DBA_TAB_PRIVS where grantee = 'MBANK_READ_ROLE' and owner = tt.OWNER and table_name = tt.object_name and instr(pp.priv,privilege) > 0)
--and object_name like 'CM%'
--and object_name in 'EVENT_ABS_FAST_PAYMENT'
/



GRANT SELECT ON POOL.CM_* TO MBANK_READ_ROLE; 

    insert ,update report_srv.tbl_task_result 


select * from dba_jobs where
next_date < sysdate-1/24 and broken = 'N' and schema_user = 'MBANK'
/


select * from v$parameter where name like '%job%'

select * from dba_jobs_runners where 


select * from account a 
--update account a set close_date = trunc(sysdate)
where code like '7060_810%' and close_date is null
and not exists (select null from ledger where code = a.code and header = a.header and currency = a.currency)
and rownum < 80001


select rowid, e.* from eid.eid_subdep_variable e where subd_id = 191 and status = 1
order by type


select * from guides where type_doc = 2165

select * from audit_table where table_name = 'GUIDES' and branch = 2165 and reference = -2 and time > sysdate-3
/

select sysdate,mb.* from mb_od_log mb where start_time >= trunc(sysdate)-2 and start_time < trunc(sysdate)-1
order by start_TIME
/


select * from documents where type_doc = 12692

INSERT INTO object_rights_user (USER_ID,OBJ_TYPE,OBJ_ID) select 1403,-3,ID From subdepartments s Where s.type in (400,301);