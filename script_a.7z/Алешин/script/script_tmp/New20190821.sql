select rowid,t.* from documents t where reference = 3510360588


select rowid,t.* from documents t where payers_account like '60323%' and receivers_account like '30305%'

select * from journal where docnum = 3510360588

select rowid,t.* from archive t where payers_account like '60323%' and receivers_account like '30305%'
and type_doc = 1 and date_work = '21aug2019'


select rowid,t.* from documents t where payers_account like '60323%' and receivers_account like '30305%'
/


declare
  dt_new date := trunc(sysdate);
begin
  for dd in (select rowid,d.* from documents d where reference in (42007879))
  loop
    insert into journal_zp select * from journal where docnum = dd.reference and branch = dd.branch and work_date <> dt_new;
    update journal_zp set work_date = dt_new, value_date = dt_new where docnum = dd.reference and branch = dd.branch and work_date <> dt_new;
    delete journal where docnum = dd.reference and branch = dd.branch and work_date <> dt_new;
    insert into journal select * from journal_zp where docnum = dd.reference and branch = dd.branch;
    update documents set date_work = dt_new, date_value = dt_new, date_document = dt_new where reference = dd.reference and branch = dd.branch and date_work <> dt_new;   
  end loop;
end;    
/


--select * from documents_delete

select parent,count(*) from subdepartments where id like '180%' and date_close is null
group by parent

select * from subdepartments where id like '180%' and date_close is null

select rowid,t.* from documents_delete t where reference = 3509651011

select rowid,t.* from archive t where reference = 3509651011

select code,name from account where owner in (957271,1576079,968733) and close_date is null

select * from users t where user_name like '����������%' 
/

EID.P_EID_TOOLS.JOINCLIENTS

select * from mb_links

select p.* from eid.eid_products p where account='5417152505855648'

select h.* from eid.eid_human h where eid in 
(31889220)

select h.* from eid.eid_join h where eid in 31889220


select * from documents where type_doc = 13337

select * from plan_account where bal in ('91203','91202','91207','99999') 
/

select * from eid.eid_products p where account in (select pk from cards_s@pro8)
and eid in (32020170,32020173,32020169)
 
/
select * from zyx_cont_cb
/

select * from eid.eid_human where eid = 31891405 
/

select eid,count(*) from eid.eid_products p where account in (select a from zyx_cont_cb)
group by eid
order by count(*) desc 
/
 

declare 
 eid_good number;
i number;
msg varchar2(4000);
begin
--for cc in(select * from cards_s@pro8 where pk='4652061926655833') loop
   for pp in (select eid,count(*) from eid.eid_products p where account in (select a from zyx_cont_cb) --and eid = 31889014  
              group by eid) 
   loop
     for hh in(select h.* from eid.eid_human h where eid=pp.eid order by date_modify desc) loop
       if substr(hh.search_doc,1,1) = 'S' then
         eid_good := null;
         for hh2 in(select distinct eid from eid.eid_human h where search_doc = substr(hh.search_doc,2) 
           and search_name = hh.search_name and length(search_doc) = 10 and eid <> hh.eid) loop -- ���� �������� �������
           if eid_good is null then
             eid_good := hh2.eid;
           else
             eid_good := -1;
           end if;
         end loop;
         if eid_good is null then
           --dbms_output.put_line(hh.eid||' �� ������ ������');
           msg := hh.eid||' �� ������ ������';
         elsif eid_good = -1 then  
           --dbms_output.put_line(hh.eid||' ����� ������ �������');
           msg := hh.eid||' ����� ������ �������';
         else  -- ������ ���� ������� ���
         --  i := 0; -- �������� �� ������ �� ���
        --   for hh3 in(select * from eid.eid_human h where eid = eid_good and search_name = hh.search_name) loop
        --     i := 1;   
        --   end loop;
        --   if i = 0 then
        --     msg := hh.eid||' �� ������� ���';
             --dbms_output.put_line(hh.eid||' �� ������� ���');
        --   else 
             EID.P_EID_TOOLS.JOINCLIENTS(hh.eid, eid_good, 1); -- old, new
             --dbms_output.put_line(hh.eid || ' -> '|| eid_good);
             msg := hh.eid||' -> '||eid_good;             
          -- end if;
         end if;
         insert into zyx_excel(a,b,c,d) values('SSS',hh.eid,msg,to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
         commit;  
       end if;
       exit;
     end loop;
   end loop;
--end loop;
end;
/

(select eid,count(*) from eid.eid_products p where account in (select a from zyx_cont_cb) and eid = 31889483
              group by eid) 
/

select * from eid.eid_products where eid in (31889483,9396333)

select * from eid.eid_human where eid = 31889483 order by date_modify desc

select * from eid.eid_human where search_doc = '4010244082' order by date_modify desc

select * from eid.eid_join where feature_eid = 9396333

select * from documents where reference = 3510514102

select rowid,t.* from audit_table t where reference = 3510514102 
/

select rowid,t.* from guides t where type_doc = 12059 
/

select * from zyx_excel where A = 'SSS'
/

declare 
  eid_good number;
  i number;
  msg varchar2(4000);
begin
  for hh in (select h.* from eid.eid_human h where substr(search_doc,1,1) = 'S' and length(search_doc) = 11
              and date_modify > '20aug2019'
              and date_modify = (select max(date_modify) from eid.eid_human where eid = h.eid)  
              and rownum < 100
              --and eid = 32020173
              )
 loop
   eid_good := null;
   for hh2 in(select distinct eid from eid.eid_human h where search_doc = substr(hh.search_doc,2) 
     and search_name = hh.search_name and length(search_doc) = 10 and eid <> hh.eid) 
   loop -- ���� �������� �������
     dbms_output.put_line(hh.eid||' ����');
     if eid_good is null then
       eid_good := hh2.eid;
     else
       eid_good := -1;
     end if;
   end loop;
   if eid_good is null then
     --dbms_output.put_line(hh.eid||' �� ������ ������');
     msg := hh.eid||' �� ������ ������';
   elsif eid_good = -1 then  
    --dbms_output.put_line(hh.eid||' ����� ������ �������');
     msg := hh.eid||' ����� ������ �������';
   else  -- ������ ���� ������� ���
     EID.P_EID_TOOLS.JOINCLIENTS(hh.eid, eid_good, 1); -- old, new
     msg := hh.eid||' -> '||eid_good;             
   end if;
   insert into zyx_excel(a,b,c,d) values('SSS',hh.eid,msg,to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
   commit;  
  -- exit;
  end loop;
end;
/


32020173 -> 18136754
32020169 -> 17106522
32020170 -> 17239905

