--������ AR 1.03
with tt as (select s.*,u.*,nvl(j.name,j.job) job_name, j.parent
            ,universe.namedepart(u.subdepartment) name, a.CREATED
            ,(select name from (select name from subdepartments where id <> 0 and type = 400 start with id = u.subdepartment connect by prior parent = id and rownum < 2 order by level)
              where rownum < 2) fil_name
            ,(select nvl(name,job) from jobs where job_id = j.parent) job_task
            ,b.* 
            from users u, jobs j, v$session s, all_users a, boss_emp_all b
            where u.user_ = s.username(+) and u.job = j.job_id(+) and u.user_ = a.username(+) and u.params = b.tab_n(+) ) 
select  user_name "���", null, name "�������������", tt.subdepartment "���", logon_time "���� �����"
,user_ "�����",
tt.user_id,job,params "���_N"
,created 
,job_name "����"
,job_task "������"
,decode(:pswd,1,set_mb_user.decryptpassn_login(decode(length(translate(PASSWORD,'#0123456789ABCDEF','#')),null,user_),'PASSWORD'),null) �����
,fil_name
,sid,serial#,machine,program,client_info,status
,email
,tabn24
,d_out
,d_in
,appoint_name
,DEPT_NAME_2
,DEPT_NAME_3
,DEPT_NAME_4
,l_name||' '||f_name||' '||m_name FIO
,dept_id
--,tt.*
from tt
where  
(trim(:VAR1) is null or instr(upper(user_name),upper(:VAR1))<>0 or :VAR1 = to_char(tt.user_id)
        or instr(upper(user_),upper(:VAR1))<>0 or :VAR1 = params   
        or :VAR1 = to_char(tt.subdepartment) or instr(upper(tt.name),upper(:VAR1))<>0
        )          
and (:var2 is null or :var2 = tt.name) 
and (:var5 is null or :var5 = tt.job)
and (nvl(:usr_work,0) = 0 or :usr_work = 1 and logon_time is not null)
and (nvl(:var3,0) = 0 
     and tt.subdepartment in (select id from subdepartments where type not in (1788) start with id = mbfilid connect by prior id = parent)
     and tt.job not in (30809,31210)
     or :var3 = 1)
and rownum < 481
order by user_name 
/

PCL_BANK

/
select * from parameters where name like '��������%'
/

select GLOBAL_PARAMETERS.GET_PARAM('���������_����_���_�����',s.id),s.* from subdepartments s
where GLOBAL_PARAMETERS.GET_PARAM('���������_����_���_�����',s.id) is not null 


select * from eid.eid_subdepartments where boss_subdep_id = 146256
/


select 
(select count(*) from account where subdepartment = s.id) acc_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 4) con_ur_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 4) cl_ur_cnt
,(select count(*) from contracts where subdepartment = s.id and status < 1000 and status > 40 and type_client = 5) con_fl_cnt
,(select count(*) from clients where subdepartment = s.id and status < 1000 and status >= 310 and type_doc = 5) cl_fl_cnt
,(select count(*) from contracts where subdepartment = s.id and status = 50) con_50_cnt
,(select count(*)||'/'||sum((select count(*) from all_users where username = u.user_)) from users u where subdepartment = s.id) usr_cnt
,s.* from subdepartments s where id in (354109,354110,354112,354113,354116)
/


select * from contracts where subdepartment = 354100
/

select * from subdepartments where substr(id,1,3) = '240'
order by id desc
/
354109

354110
354112
354113
