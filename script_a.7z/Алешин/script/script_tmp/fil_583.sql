--����� �������� ������ ����� subdepartments
select rowid,s.* from subdepartments s where id in (200,785)

--�������
select * from guides where type_doc = 1362
and name like '�����%'
/

--���������
select s0.*, s.id id_old from subdepartments s, subdepartments s0
where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 
and s0.id <> s.id and s0.type = s.type

--��������� ���������
--insert into variable_subdepartments(NAME,DEPART_ID,ROWNUMBER,VALUE) 
with ss as (select s0.*, s.id id_old from subdepartments s, subdepartments s0
             where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type)
select distinct vs.NAME,ss.id,vs.ROWNUMBER,value             
--select ss.id,ss.id_old, vs.* 
from ss, variable_subdepartments vs
where vs.depart_id = ss.id_old and substr(vs.name,1,1) <> '#' and vs.name not in ('DEPART_OUT','UNBLOCK')
and not exists (select null from variable_subdepartments where depart_id = ss.id and name = vs.name) 

--���������
--insert into variable_subdepartments(NAME,DEPART_ID,ROWNUMBER,VALUE) 
select * from (select 'DEPART_OUT' name,s.id,0,'7' from subdepartments s where s.date_open = '21jan2022') vs
where not exists (select null from variable_subdepartments where depart_id = vs.id and name = vs.name) 

--������ ����������
--insert into paramgroupmembership
with ss as (select s0.*, s.id id_old from subdepartments s, subdepartments s0
             where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type)
--select * 
select pm.GROUP_ID, ss.id
from ss, paramgroupmembership pm where pm.DEPART_ID = ss.id_old 
and not exists (select null from paramgroupmembership where depart_id = ss.id and group_id = pm.group_id)  
/

--� ��� ���������
--insert into eid.eid_subdepartments
with ss as (select s0.*, s.id id_old from subdepartments s, subdepartments s0
             where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type)
select ss.ID,e.NAME||' (���2)',e.APPSERVER_ADDRESS,e.PARENT,e.TYPE,e.TIME_ZONE,e.TC_ADDRESS,e.ID_SELS
,e.PARENT_R,1 DELETED,e.BOSS_SUBDEP_ID,e.BOSS_SUBDEP_NAME  
from eid.eid_subdepartments e, ss
where e.id = ss.id_old
and not exists (select null from  eid.eid_subdepartments where id = ss.id)

select rowid,s.* from eid.eid_subdep_variable s where subd_id in (772) 
--and type in ('FILIAL_CODE','DEPART_OUT','FILIAL_PROCESSING')
--and status = 1
order by type,subd_id
/

select * from config where name like 'IS%'
/

with ss as (select s.*, s0.id id_old from subdepartments s, subdepartments s0
             where s.date_open = '14nov2021' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type)           
              select ss.id,ss.id_old,sv.* from ss, eid.eid_subdep_variable sv
              where sv.subd_id = ss.id_old and sv.status = 1
                and not exists (select null from eid.eid_subdep_variable where subd_id = ss.id and status = sv.status and type = sv.type and value not in ('-1'))   

/

--��������� ��
declare
  r_cnt number := 0;
  r_str varchar2(2000);
begin
  for rec in (
             with ss as (select s0.*, s.id id_old from subdepartments s, subdepartments s0
             where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type)          
              select ss.id,ss.id_old,sv.* from ss, eid.eid_subdep_variable sv
              where sv.subd_id = ss.id_old and sv.status = 1
                and not exists (select null from eid.eid_subdep_variable where subd_id = ss.id and status = sv.status and type = sv.type and value not in ('-1'))   
             )
  loop
    r_str := rec.value;
    if rec.type = 'DEPART_OUT' then
      r_str := '7';
    elsif rec.type = 'FILIAL_PROCESSING' then
      r_str := '-1';  
    end if;      
    EID.P_EID_TOOLS_SUBDEP.LoadVariable(rec.id,sysdate,'������ �.�.',mbfilid,1,0,rec.type,r_str,to_date('21.01.2022','dd.mm.yyyy'));
    r_cnt := r_cnt + 1;
    commit;
  end loop;  
  dbms_output.put_line('eid_subdepartments r_cnt = '||r_cnt); 
end;
/

--��������� ���������
begin
globals.INIT_USER_EXT('GRUZ');
insert into PARAMVALUES 
 with ss as (select s0.*, s.id id_old from subdepartments s, subdepartments s0
             where s0.date_open = '21jan2022' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type
             and s0.id in (785))        
              select paramid,PARAMGROUPID,ss.id,value,trunc(sysdate)-1 from ss, paramvalues pv
where pv.departid = ss.id_old and pv.activated = (select max(activated) from paramvalues where paramid = PV.PARAMID and paramgroupid = PV.PARAMGROUPID and departid =PV.DEPARTID)
and not exists (select null from paramvalues where paramid = Pv.paramid and paramgroupid = Pv.paramgroupid and departid = ss.id)
 ;
 dbms_output.put_line('param rowcount = '||sql%rowcount); 
end;
/

--�� ���������
--��� ���2 ��������� ���_������� � SWIFT_FILIAL
select rowid,t.* from eid.eid_paramvalues t
where departid in (191,772)  
/

select rowid,t.* from paramvalues t
where departid in (191,772) and paramid in (5171,427,431,10629)   
/

select * from parameters where name like '%����%'
/

begin
insert into eid.eid_paramvalues 
 with ss as (select s.*, s0.id id_old from subdepartments s, subdepartments s0
             where s.date_open = '14nov2021' and s0.type = 400 and instr(s0.depart_name,s.depart_name) > 0 and s0.id <> s.id and s0.type = s.type
             and s.id in (771))        
              select PARAM_NAME,PARAMGROUPID,ss.id,value,trunc(sysdate)+1 from ss, eid.eid_paramvalues pv
where pv.departid = ss.id_old and pv.activated = (select max(activated) from eid.eid_paramvalues where PARAM_NAME = PV.PARAM_NAME and paramgroupid = PV.PARAMGROUPID and departid =PV.DEPARTID)
and not exists (select null from eid.eid_paramvalues  where PARAM_NAME = Pv.PARAM_NAME and paramgroupid = Pv.paramgroupid and departid = ss.id)
 ;
 dbms_output.put_line('param rowcount = '||sql%rowcount); 
end;
/

044525411
VTBRRUM2MS2 
/

--� ���� �������� ������� ��������� � ������� ������ + �������� 13211
select * from subdepartments s where id in 771--(242,272,662,540,270,665)

select rowid,s.* from eid.eid_subdepartments s where id in (200,785,785005)--(242,272,662,540,270,665)

--13211
select decode(num1,540,242,270,272,662),gg.* from guides gg
where type_doc = 13211 and  num1 in (785)
and exists (select null from eid.eid_subdepartments where id = gg.code and nvl(deleted,0) <> 1) 
/

select rowid,gg.* from guides gg
where type_doc = 13211 and  num1 in (200)
and exists (select null from eid.eid_subdepartments where id = gg.code and nvl(deleted,0) <> 1) 
/
--1

update subdepartments set date_close = null where id in (785);
update subdepartments set date_close = to_date('21.01.2022','dd.mm.yyyy') where id in (200);
update eid.eid_subdepartments set deleted = 0 where id in (785);
update eid.eid_subdepartments set deleted = 1 where id in (200);
update guides gg set num1 = decode(num1,245,612) 
where type_doc = 13211 and  num1 in (245)
and exists (select null from eid.eid_subdepartments where id = gg.code and nvl(deleted,0) <> 1); 
/

--2
begin
--��������� ���������
globals.INIT_USER_EXT('GRUZ');
insert into PARAMVALUES  
select p.id,p.group_id,s.id,decode(p.name,'SWIFT_FILIAL','VTBRRUM2MS2','044525411'),to_date('12.06.2021','dd.mm.yyyy')
 from parameters p, subdepartments s, paramgroupmembership pg 
 where 1=1 and pg.depart_id = s.id and pg.group_id = p.group_id 
 and s.id in (775) 
 and not exists (select null from paramvalues where  paramid = P.ID and paramgroupid = p.group_id and departid = s.id
  and value = decode(p.name,'SWIFT_FILIAL','VTBRRUM2MS2','044525411')   
)
and p.name in ('SWIFT_FILIAL','���_�������')
;
dbms_output.put_line('��������� ������� = '||sql%rowcount);
end;

--3 
commit;
/

select * from parameters where id in (39299,964508) 

--��������� ����� ������ �� ����������
select rowid,t.* from paramvalues t where paramid in (39299,964508) 
and departid in (select to_number(code) from guides where type_doc = 13211 and num1 = 771)

select rowid,t.* from variable_subdepartments t where depart_id in (208101,208100)

select rowid,s.* from eid.eid_subdep_variable s where subd_id in (785) and status = 1
order by type,subd_id
