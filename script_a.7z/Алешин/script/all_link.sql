--������ ��� ������������� ���� �� �����
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
 err varchar2(4000);
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            and code1 = '200'
            )
 loop
   begin 
     sq := 'insert into zyx_cont_cb(a,b,c,d) 
              select ''FZ214'',reference,branch,to_char(date_work,''dd.mm.yyyy'') from archive@'||i.value||' d where type_doc = 2 and status = 30 
                and not exists (select null from journal@'||i.value||' where docnum = d.reference and branch = d.branch )
                and date_work > ''19nov2018''';
     execute immediate sq;

     dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;      
 end loop;
end;
/

insert into zyx_cont_cb(a,b,c,d) 
              select 'FZ214',reference,branch,to_char(date_work,'dd.mm.yyyy') from archive@lnk_209 d where type_doc = 2 and status = 30 
                and not exists (select null from journal@lnk_209 where docnum = d.reference and branch = d.branch )
                and date_work > '19nov2018'
                
insert into zyx_cont_cb(a,b,c,d)
select 'FZ214',reference,branch,to_char(date_work,'dd.mm.yyyy') from archive d where type_doc = 2 and status = 30 
and not exists (select null from journal where docnum = d.reference and branch = d.branch )
and date_work > '19nov2018'

select value from config where name ='����_����'

select to_date(nvl(global_parameters.get_param_cfg('����_����'),'03.11.2018'),'dd.mm.yyyy') from dual

truncate table zyx_cont_cb

select * from zyx_cont_cb
/

--������ ��� ������������� ������������� � ��������
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
 err varchar2(4000);
begin
  for i in  (select vg.value,s.name,s.id from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            and code1 = '200' and g.num1 <> 208 
            )
 loop
   begin 
     sq := 'insert into zyx_users select * from (select '||i.id||' fil_id, user_,user_name,user_id 
, set_mb_user.decryptpassn_login@'||i.value||'(user_,''PASSWORD'') password
   ,job,params, set_mb_user.decryptpassn_login@'||i.value||'(user_,''RIGHTS'') rights, subdepartment, null new_id from users@'||i.value||') t
   where not exists (select null from zyx_users where fil_id = t.fil_id and user_id = t.user_id)';
     execute immediate sq;

   sq := 'insert into zyx_users_rights select * from (select '||i.id||' fil_id,u.* from users_rights@'||i.value||' u) t
   where not exists (select null from zyx_users_rights where fil_id = t.fil_id and user_id = t.user_id
     and object_id = t.object_id and code=t.code)';
      execute immediate sq;
   
   sq := 'insert into zyx_user_parameters select * from (select '||i.id||' fil_id,u.* from user_parameters@'||i.value||' u) t
   where not exists (select null from zyx_user_parameters where fil_id = t.fil_id and id = t.id 
   and depart_id = t.depart_id and name=t.name)';
   execute immediate sq;
   
   sq := 'insert into zyx_user_param_values select * from (select '||i.id||' fil_id,u.* from user_param_values@'||i.value||' u) t
   where not exists (select null from zyx_user_param_values where fil_id = t.fil_id and id = t.id 
   and depart_id = t.depart_id and user_id=t.user_id)';
      execute immediate sq;
   commit;  
   
   sq := 'insert into zyx_groups select * from (select '||i.id||' fil_id,u.* from groups@'||i.value||' u) t
   where not exists (select null from zyx_groups where fil_id = t.fil_id and group_id = t.group_id)';
      execute immediate sq;          
   
   sq := 'insert into zyx_groups_rights select * from (select '||i.id||' fil_id,u.* from groups_rights@'||i.value||' u) t
   where not exists (select null from zyx_groups_rights where fil_id = t.fil_id and group_id = t.group_id and object_id = t.object_id)';
          execute immediate sq;  

   sq := 'insert into zyx_group_membership select * from (select '||i.id||' fil_id,u.* from group_membership@'||i.value||' u) t
   where not exists (select null from zyx_group_membership where fil_id = t.fil_id and group_id = t.group_id and user_id = t.user_id)';
          execute immediate sq;  
          
   commit;  

        dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
       rollback;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;      
 end loop;
end;
/


--������ ��� ������������� ������������� � ��������
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
 err varchar2(4000);
begin
  for i in  (select vg.value,s.name,s.id from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            and code1 = '200' and g.num1 <> 208 
            )
 loop
   begin 
     sq := 'insert into zyx_users1 select * from (select '||i.id||' fil_id, user_,user_name,user_id 
, set_mb_user.decryptpassn_login@'||i.value||'(user_,''PASSWORD'') password
   ,job,params, set_mb_user.decryptpassn_login@'||i.value||'(user_,''RIGHTS'') rights, subdepartment, null new_id from users@'||i.value||') t
   where not exists (select null from zyx_users1 where fil_id = t.fil_id and user_id = t.user_id)';
     execute immediate sq;
          
   commit;  

        dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
       rollback;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;      
 end loop;
end;
/



select * from variable_guides where name not in ('TAGS','FORM','UPD_9999','GRID','ORDERING','GRID2','ORDERING2')

create table zyx_guides as select mbfilid fil_id, u.*  from guides u where rownum < 100

create table zyx_variable_guides as select mbfilid fil_id, u.*  from variable_guides u where rownum < 100

truncate table zyx_guides 

truncate table zyx_variable_guides 

 select * from all_constraints where table_name = 'ZYX_VARIABLE_GUIDES'
  
  alter table ZYX_VARIABLE_GUIDES drop constraint SYS_C00285667

select universe.nametype(type_doc), type_doc,count(*) from guides
 group by type_doc
order by count(*) desc

select universe.nametype(type_doc), type_doc,count(*) from guides g where 
not exists (select null from hash_config where name = 'GUIDE' and instr(text,''''||g.type_doc||'''') > 0)
and type_doc not in (1365,1364,2372,7396,587,586,9936,3772,10036,5183,11295,1363,2097,588,1495,2772,1970,365)
and nvl(owner,0) not in (0,1403)  
group by type_doc
order by count(*) desc
/

select * from guides g
/

--������ ��� ������������� ������������� � ��������
declare 
 n varchar2(4000);
 sq varchar2(4000); 
 err varchar2(4000);
 g_list varchar2(4000);
begin
  g_list := '2135,2761,521,10729,8947,985,5450,1873,1035,4744' ; 
  for i in  (select vg.value,s.name,s.id from subdepartments s, zyx_variable_guides vg, zyx_guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            and code1 = '200' and g.num1 <> 208 
            )
 loop
   begin 
     sq := 'insert into zyx_variable_guides select * from (select '||i.id||' fil_id, u.* from variable_guides@'||i.value||' u
              where (reference,branch) in (select reference,branch from guides@'||i.value||' where code <> ''FORM_STORAGE'' and type_doc in ('||g_list||')  )) t
            where not exists (select null from zyx_variable_guides where fil_id = t.fil_id and reference = t.reference and branch = t.branch)';
     execute immediate sq;

     sq := 'insert into zyx_guides select * from (select '||i.id||' fil_id, u.* from guides@'||i.value||' u
              where code <> ''FORM_STORAGE'' and type_doc in ('||g_list||') ) t
            where not exists (select null from zyx_guides where fil_id = t.fil_id and reference = t.reference and branch = t.branch)';
     execute immediate sq;
         
   commit;  

        dbms_output.put_line('4 '||sq);
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
       rollback;
   end;   
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;      
 end loop;
end;
/

/