declare
 i number;
 cnt number;
 t number;
begin
cnt := 0;
for rec in (                                                 
            select rowid,g.* from guides g where reference > 106346773 and branch = 0 
            --and not exists (select null from variable_guides where reference = g.reference and branch = g.branch)
            --and type_doc = 3454
            and exists (select null from variable_guides where reference = g.reference and branch = g.branch)
            )
loop
  if cnt > 5000 then
    commit;
    cnt := 0;        
  else
    --dbms_output.put_line('re = '||rec.reference);    
    i := guides_reference.nextval;
    cnt := cnt + 1;
    t := 0;
    for g in (select * from guides where branch = 0 and reference = i)
    loop
     t := 1;
    end loop;
    if t = 0 then
      --update guides set reference = i where rowid = rec.rowid;
      update variable_guides set reference = i where reference = rec.reference and branch = rec.branch;  
    end if;
  end if;  
end loop; 
end;

/
select guides_reference.nextval from dual

1002255583
106346782