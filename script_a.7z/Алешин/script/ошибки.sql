--����� ��������� �������� ������� K+210107 � GRAPH_PERCENT
select c.reference,c.branch,sum(decode(rc.name,'GRAPH_PERCENT',rc.rest,0))-sum(decode(rc.name,'K+210107',rc.rest,0))
from contracts c, rest_contracts rc 
where c.reference = rc.reference and c.branch = rc.branch and c.type_doc = 5142 and c.status = 50
 and UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'MA') <> 3 
 and nvl(lpad(UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'PAY_DAY'),2,'0'),to_char(c.date_open,'dd')) <= to_char(sysdate,'dd')
 and c.date_open > trunc(sysdate)-100 
 and rc.name in ('GRAPH_PERCENT','K+210107') and rc.work_date = (select max(work_date) from rest_contracts where work_date <= sysdate and name = rc.name and reference = rc.reference and branch = rc.branch)
 group by c.reference,c.branch
 having sum(decode(rc.name,'GRAPH_PERCENT',rc.rest,0))-sum(decode(rc.name,'K+210107',rc.rest,0)) <> 0
/


/*
select TEXT from all_source@pro8 where name = 'P_RETAIL_RIGHTS' --upper(text) like upper('%block_account%') --/ unblock_account

select * from all_source where upper(text) like upper('%makeOracleUser%') --/ unblock_account

select count(*),count(message),count(message)/count(*) from scoring_egrul_request@nnovg where request_date > sysdate-1/4

select * from scoring_egrul_request where inn = '6607000556'  order by request_date desc anketa_reference =  4455798


select * from bill_params where gid = '28_2A5E4AF997A90018E0530AC944AC0E23'

select * from sforms where type_id = 6508
*/
/
--������� ������ �� ��������� �������/��������
select Universe.NameClient(c.branch_client,c.refer_client) "�.�.�.",c.doc_number "� ��������",Universe.NameType(c.type_doc) "��� ���-��",c.ACCOUNT "����" ,c.date_open "���� ��������", c.date_work "���� ���������",c.summa "����� ���-��",Universe.NameDepart(c.subdepartment) "���������"
--select insum-outsum,Round(Ptools_credit.CALC_YEAR(c.summa-UNIVERSE.SALDO_COLLECTOR(rc.branch,rc.reference,'GRAPH_LOAN',rc.currency,rc.work_date-1),UNIVERSE.VARIABLE_CONTRACT(rc.branch,rc.reference,'PERCENT_FORMULE')
--                                        ,(select max(work_date) from rest_contracts where reference = rc.reference and branch = rc.branch and name = 'GRAPH_PERCENT' and insum-outsum <> 0 and work_date < rc.work_date),rc.work_date,'NAN'),2) perc
--,c.summa-UNIVERSE.SALDO_COLLECTOR(rc.branch,rc.reference,'GRAPH_LOAN',rc.currency,rc.work_date-1) sld,(select max(work_date) from rest_contracts where reference = rc.reference and branch = rc.branch and name = 'GRAPH_PERCENT' and insum-outsum <> 0 and work_date < rc.work_date) dt
--,c.*                                                 
 from contracts c,rest_contracts rc where status = 50 and type_doc not in (1880,1881,3280,7293,3800,7284,3881) and (c.reference,c.branch) in ( 
select distinct reference,branch from taxs_contracts tc
where (reference,branch,work_date) in (select reference,branch,work_date from taxs_contracts where OPERATION = '21010107' group by reference,branch,worK_date having count(*) > 1)
and operation = '21010107' 
and not exists (select null from taxs_contracts where reference = tc.reference and branch = tc.branch and operation = tc.operation and work_date > tc.work_date)  
and exists (select null from taxs_contracts where reference = tc.reference and branch = tc.branch and operation = tc.operation and work_date = tc.work_date and percent <> tc.percent and summa = tc.summa)
) 
    --������ ��������� � ��������� ���� �������
and c.reference = rc.reference and c.branch = rc.branch and rc.name = 'GRAPH_PERCENT' and rc.work_date = 
(select max(work_date) from rest_contracts where reference = rc.reference and branch = rc.branch and name = rc.name and insum-outsum <> 0)
and (rc.insum-rc.outsum-Round(Ptools_credit.CALC_YEAR(c.summa-UNIVERSE.SALDO_COLLECTOR(rc.branch,rc.reference,'GRAPH_LOAN',rc.currency,rc.work_date-1)
                                                ,UNIVERSE.VARIABLE_CONTRACT(rc.branch,rc.reference,'PERCENT_FORMULE')
                                                ,(select max(work_date) from rest_contracts where reference = rc.reference and branch = rc.branch and name = 'GRAPH_PERCENT' and insum-outsum <> 0 and work_date < rc.work_date)
                                                ,rc.work_date,'NAN'),2)) <> 0
/

--����������� �� ���� ��������� (���� ������ ������������)
select sum(RSUM) from journal where work_date = '08oct2018' and substr(code,1,5) = '96901' and flag_debit = '-'
group by substr(code,1,5)
/

select sum(RSUM) from journal where work_date = '17-jun-2017' and substr(assist,1,5) = '60324' and flag_debit = '-'
group by substr(assist,1,5)
/

select rowid,j.* from journal j where docnum = 3223273562 work_date >= '09oct2018' and substr(code,1,5) = '96901'
/
96901978900761010601

select * from journal_delete where work_date >= '08oct2018'  and substr(code,1,5) = '96901'
/
select * from journal_delay
/
select * from journal_defer
/
--������������
select * from journal j1 where j1.work_date = '11jan2018' --and header in ('A','C')
 --and header = 'C' and substr(j1.code,1,5) = '99999' and flag_debit = '+'
 and header||'' = 'A' --and substr(j1.code,1,5) in ('20202')
  --and flag_debit = '+'
  and rsum = 300
and not exists (select null from journal where docnum = j1.docnum and branch = j1.branch and assist = j1.code and flag_debit <> j1.flag_debit)   
/

select rowid,d.* from config d where name = 'ARCHIVE_CLOSE_DATE'
/

--insert into journal_zp
select * from journal
--delete journal
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3225721662))
/ 

update journal_zp 
set work_date = '11jan2019', value_date = '11jan2019'
--set rsum = 8200, vsum = 8200
 where  (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3225721662))
/
--insert into journal
select j.* from journal_zp j
--select rowid,j.* from journal_zp j
--update journal_zp zp set work_date = '01-jun-2018', value_date = '01-jun-2018'
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (3225721662))
--and flag_debit = '-'
--and journal_id in (1571523049,1571523050)
/
select * from documents 
--update documents set date_work = '11jan2019', date_value = '11jan2019'
where reference in (3225721662)
/
    select PLEDGER.WCOURSE(currency,work_date) crs,header,BAL,WORK_DATE,currency,
          sum(rdebit) rdebit ,round(sum(debit)*PLEDGER.WCOURSE(currency,work_date),2) calc_debit
          ,sum(rcredit) rcredit
           --,round(sum(credit)*PLEDGER.WCOURSE(currency,work_date),2) calc_credit --���������� vsum = 
          ,sum(debit) debit,sum(credit) credit,
           sum(saldo+debit-credit) saldo,sum(rsaldo+rdebit-rcredit) rsaldo
      from (      
        select header, substr(code,1,5) bal,currency,work_date,
               sum(decode(flag_debit,'+',vsum,0)) debit,
               sum(decode(flag_debit,'+',rsum,0)) rdebit,
               sum(decode(flag_debit,'-',vsum,0)) credit,
               sum(decode(flag_debit,'-',rsum,0)) rcredit,
               0 saldo,0 rsaldo
                       from journal where work_date = '18dec2018'
                          and header||''='A' and substr(code,1,5) = '30305'
        group by header,substr(code,1,5),currency,work_date
)
  group by header,BAL,WORK_DATE,currency;
/
    select PLEDGER.WCOURSE(currency,work_date) crs,header,BAL,WORK_DATE,currency,
          sum(rdebit) rdebit ,round(sum(debit)*PLEDGER.WCOURSE(currency,work_date),2) calc_debit
          ,sum(rcredit) rcredit
           --,round(sum(credit)*PLEDGER.WCOURSE(currency,work_date),2) calc_credit --���������� vsum = 
          ,sum(debit) debit,sum(credit) credit,
           sum(saldo+debit-credit) saldo,sum(rsaldo+rdebit-rcredit) rsaldo
      from (      
        select header, code bal,currency,work_date,
               sum(decode(flag_debit,'+',vsum,0)) debit,
               sum(decode(flag_debit,'+',rsum,0)) rdebit,
               sum(decode(flag_debit,'-',vsum,0)) credit,
               sum(decode(flag_debit,'-',rsum,0)) rcredit,
               0 saldo,0 rsaldo
                       from journal where work_date = '07feb2019'
                          and header||''='A' and code like '20309A99%'
        group by header,code,currency,work_date
)
  group by header,BAL,WORK_DATE,currency;
/
select rowid, a.* from documents a where type_doc = 21 and  owner = 
/

select * from bank_balance where bal = 20309 and work_date > '06feb2019' and currency = 'A99'
/
--����������
select rowid, a.* from journal a where 1=1 --and docnum in (3201823333)
and code like '20309A99%'
--and code like '20202____00000000001'
and work_date = '07feb2019' 
--and journal_id in (1584678694,1584681777,1584678699,1584681781) 
--(1584375954,1584464263,1584678555,1584375748,1584375864,1584678556,1584376005) --(1584678525,1584678526) --(1584024184,1584024189) 1584019965,1584000132)
--and currency in ('840','978','826','392','756') --and operation = '519002'
and currency in ('A99') --and operation = '519002'
--and ASSIST like '7060_810_0000%'
/

select * from journal where docnum in (3218645363,3218645363,3218186943) and JOURNAL_ID in (1589007062,1589007064,1588968736)
/

--������� � �������� ��������
select round(vsum*PLEDGER.WCOURSE(currency,work_date),2) ss, a.* from journal a where -- docnum in (2750822298)
header = 'A' and code like '20309A99%' and currency in ('A99') and work_date = '07feb2019'
and rsum <> round(vsum*PLEDGER.WCOURSE(currency,work_date),2) --and flag_debit = '+'
/

--������� � �������� ��������
select pledger.saldo(header,code,currency,work_date) vs, pledger.rsaldo(header,code,currency,work_date) rs
,round(pledger.saldo(header,code,currency,work_date)*PLEDGER.WCOURSE(currency,work_date),2) vs
,round(vsum*PLEDGER.WCOURSE(currency,work_date),2) ss, a.* from journal a where -- docnum in (2750822298)
header = 'A' and code like '20309A99%' and currency in ('A99') and work_date = '07feb2019'
and rsum <> round(vsum*PLEDGER.WCOURSE(currency,work_date),2) --and flag_debit = '+'
/

select * from bank_balance where bal = 20309 and work_date = '07feb2019' and currency = 'A99'

select sum(pledger.saldo(header,code,currency,work_date)) vs, sum(pledger.rsaldo(header,code,currency,work_date)) rs
,sum(round(pledger.saldo(header,code,currency,work_date)*PLEDGER.WCOURSE(currency,work_date),2)) vs from journal a where -- docnum in (2750822298)
header = 'A' and code like '20309A99%' and currency in ('A99') and work_date = '07feb2019'
and rsum <> round(vsum*PLEDGER.WCOURSE(currency,work_date),2) --and flag_debit = '+'
/

select rowid, a.* from journal_defer a where docnum in (2750822298)
/
select rowid, a.* from journal_delete a where docnum in (2750822298)
/
insert into journal a 
select * from journal_delete where docnum in (2527622477) and journal_id = 1379080948 and header in ('A','C')

select * from audit_table where reference = 2750822298

select * from documents_delete where reference in (2685152630,2684339606)

select * from documents where reference in (3109349146)

select * from archive where reference in (3106192309)

select * from CDCS.CDC_LOG$DOCUMENTS where reference in (2684339606)

select universe.nameowner(owner),d.* from documents d where num_group = 903
/

--��� ������ ����.��������
select * from journal where work_date > '01-dec-2017'  and substr(ASSIST_currency,1,1) = 'A'  
/
--�������� ����� 91604 �� ������� (�� ����������� ��� ����� ���������)
--������� ��������� select * from contracts where reference = 14272585 and branch = 191
declare
  opAccRec ACCOUNT%rowtype;
  opAccount account.code%type;
begin
    for c in (select * from contracts where reference = :c_ref and branch = :c_br) loop
      opAccount := ptools_credit.acc_value(c.Branch, c.Reference, 'ACCOUNT_NOSROK_91604', trunc(sysdate));
      --dbms_output.put_line( '���� ' || opAccount);    
      if not universe.GET_ACCOUNT_REC('C', opAccount, null, opAccRec) then
        dbms_output.put_line( '�� ������ ���� ' || opAccount);
      else 
        universe.input_var_contr(c.branch, c.reference, 'ACCOUNT_NOSROK_91604', opAccount);
        dbms_output.put_line( '�������� ���� ' || opAccount);    
      end if;
    end loop;
    commit;      
end;  
/
--delete account where code = '91604810302280002116'



PBALANCE

/
--����������������� 
declare
        dDate1  DATE;
        cHeader VARCHAR2(100);
begin
        dDate1 := to_date('11.01.2019','dd.mm.yyyy');
 while dDate1 <= to_date('12.01.2019','dd.mm.yyyy') loop
        cHeader := 'A';

delete from bank_balance where header=cHeader and WORK_DATE = dDate1;
insert into bank_balance(HEADER,BAL,CURRENCY,WORK_DATE,
                         DEBIT,RDEBIT,CREDIT,RCREDIT,SALDO,RSALDO)
    select header,BAL,CURRENCY,WORK_DATE,
           sum(debit) debit,sum(rdebit) rdebit,sum(credit) credit,sum(rcredit) rcredit,
           sum(saldo+debit-credit) saldo,sum(rsaldo+rdebit-rcredit) rsaldo
      from (
        select header, substr(code,1,5) bal,currency,dDate1 work_date,
               sum(decode(flag_debit,'+',vsum,0)) debit,
               sum(decode(flag_debit,'+',rsum,0)) rdebit,
               sum(decode(flag_debit,'-',vsum,0)) credit,
               sum(decode(flag_debit,'-',rsum,0)) rcredit,
               0 saldo,0 rsaldo
        from journal where work_date = dDate1
                          and header||''=cHeader
--and ysubdepartment <> 191253
        group by header,substr(code,1,5),currency
        union all
        select HEADER,BAL,CURRENCY,dDate1 work_date,
               0 debit, 0 rdebit, 0 credit,0 rcredit,
               saldo, rsaldo
        from bank_balance
        where work_date = (dDate1-1) and header=cHeader
       )
       group by header,BAL,CURRENCY,WORK_DATE;
 commit;

 dDate1 :=  dDate1 + 1;
 end loop;
end;
/

--����� 4918 ������� �� ��������� � ������
select rowid,a.* from account a where bal = '96901' and currency = '978'  and code = '96901978800760810601'
/

select * from ledger where code like '96901%' and work_date > '08oct2018'
/
--����� ���������� �� 47411 
select * from journal j where code = '47411810500004230103' and work_date = '06-jun-2018'
and not exists (select null from collector_contracts where docnum = j.docnum and zbranch_docnum = j.branch) 


select rowid,j.* from journal_delete j where
--docnum = 3109349146 
code = '96901978900761010601' and work_date >= '08oct2018'

insert into  journal
select j.* from journal_delete j where
docnum = 3109349146 

select * from journal where docnum = 3109349146 

select * from journal where work_date >= '08oct2018' and substr(code,1,5) in ('96901','99996') 

select rowid,d.* from documents d where reference in (3109349146)

--����� 101
select * from bank_balance where work_date = '23nov2018' and bal = 20309   

select sum(debit),sum(credit) from bank_balance where work_date = '13-jul-2018' and currency = '810'

select * from account where code =  
header = 'D' and open_date >= '09oct2018'

/

--������� ������
select sign(wrest),(select max(decode(type_bal,'P',-1,'A',1)) from plan_account where bal = substr(l.code,1,5) and header = l.header) plan,
l.* from ledger l WHERE work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date >= l.work_date and work_date < sysdate) 
and wrest <> 0 and work_date > sysdate-20 
and (header,substr(l.code,1,5)) in (select header,bal from plan_account where type_bal in ('A','P') and header in ('A','C'))
and sign(wrest) <> (select max(decode(type_bal,'P',-1,'A',1)) from plan_account where bal = substr(l.code,1,5) and header = l.header) 
/

select decode(type_bal,'P',-1,1),p.* from plan_account p where bal in ('42301','47427','55555')

select type_bal,count(*) from plan_account p group by type_bal
/

select
lg.wrest,nvl(UNIVERSE.VARIABLE_CONTRACT(branch_contract,contract,'OVERDRAFT'),UNIVERSE.VARIABLE_CONTRACT(branch_contract,contract,'OVERDRAFT_EXIT')) OVERDRAFT
,a.code "����", open_date "���� ��������", close_date "���� ��������"
from account a, (select decode(type_bal,'P',-1,'A',1) sgn, bal, header from plan_account) pa,  
(select * from ledger l WHERE rest_id = 0 and work_date = (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date >= l.work_date and work_date < sysdate)) lg
where a.header in ('A','C') and nvl(close_date,sysdate) > '10jan2019'
and pa.bal = substr(a.code,1,5) and pa.header = a.header
and lg.header = a.header and lg.code = a.code and lg.currency = a.currency
and lg.wrest <> 0 and lg.work_date > sysdate-8 and lg.work_date < sysdate-1
and sign(lg.wrest) <> pa.sgn  
/

select * from variable_contracts where reference = 9166861
/