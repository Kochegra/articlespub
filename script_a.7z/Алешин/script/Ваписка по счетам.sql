/* Formatted on 11.09.2018 13:54:27 (QP5 v5.227.12220.39724) */
DECLARE
 mail_blob blob;
   DDATE1           DATE;
   DDATE2           DATE;
   ACC_TEMPL        VARCHAR2 (32767);
   CURR             VARCHAR2 (32767);
   TURN_ONLY        NUMBER;
   CHECK_OUT        NUMBER;
   DAY_NEW_PAGE     NUMBER;
   WITH_MEMO        NUMBER;
   PRIL             NUMBER;
   CLIENT_BANK      NUMBER;
   ORDERING         NUMBER;
   LAST_ACC         VARCHAR2 (32767);
   UR_ONLY          NUMBER;
   P_HEADER         VARCHAR2 (32767);
   MEMO_ONLY        NUMBER;
   OWN_ONLY         NUMBER;
   REVAL            NUMBER;
   P_CL_REL         NUMBER;
   DEP_FIN          NUMBER;
   OD_ORDERING      NUMBER;
   SPEC_MODE        NUMBER;
      nncount        NUMBER;
   IS_MASK          NUMBER;
   CORRESP          NUMBER;
   CL_INT_CLIENTS   NUMBER;
   IZVESCH          NUMBER;
   INN              NUMBER;
      I              NUMBER;
      filial1 VARCHAR2 (1000);
      BIK1 VARCHAR2 (500);
      INN1 VARCHAR2 (500);
      KPP1 VARCHAR2 (500);
      name2 VARCHAR2 (500); inn2 VARCHAR2 (500);inn3 VARCHAR2 (500); kpp2 VARCHAR2 (500);account2 VARCHAR2 (500); cur2 VARCHAR2 (500);
      REST_BEGIN VARCHAR2 (500);DEBIT  VARCHAR2 (500);CREDIT VARCHAR2 (500);  REST_END  VARCHAR2 (500);title1 VARCHAR2 (500);
      ---
      src_account9 VARCHAR2 (500);
   NationalCurrency varchar2(10) := nvl(global_parameters.get_param('������������������'),'810');
   r_BIK      varchar2(100)      := nvl(global_parameters.get_param('���_�������'),'-');
   r_CorrAcc  varchar2(100)      := nvl(global_parameters.get_param('�������_�������'),'-');
   r_BankName varchar2(1000)     := nvl(global_parameters.get_param('������������_�����_��'),'-');
   r_currency varchar2(10);
            OPER_KIND9 VARCHAR2 (500);
                  date_work9 VARCHAR2 (500);
                        doc_number9 VARCHAR2 (500);
                        date_documents9 VARCHAR2 (500);
                        corr_acc9 VARCHAR2 (500);
                        bank_name9 VARCHAR2 (500);
                        BIK9 VARCHAR2 (500);
                        FIO9 VARCHAR2 (500);
                        INN9 VARCHAR2 (500);
                        INNENTER VARCHAR2 (15);
                        KPP9 VARCHAR2 (500);
                        ACCOUNT9 VARCHAR2 (500);
                        DEBIT9 VARCHAR2 (500);
                        CREDIT9 VARCHAR2 (500);
                        MEMO9 VARCHAR2 (500);
                        DATE_DOCUMENT9 VARCHAR2 (500);
                        
                        
      ---

   AUTO_RUN         NUMBER;
   NO_RIGHTS        NUMBER;
   IS_GTMP          NUMBER;
   OLD_FIL          NUMBER;
   P1513LIST        VARCHAR2 (32767);
   PWEBUSER         NUMBER;
BEGIN
INNENTER:='';
   ptools2.short_init_user (1403);
   GLOBALS.BRANCHID := mbfilid;
   DDATE1 := TO_DATE ('15.11.2018', 'dd.mm.yyyy');
   DDATE2 := TO_DATE ('19.03.2019', 'dd.mm.yyyy');
   ACC_TEMPL := '';
   CURR := '';
   TURN_ONLY := 1; --����� �������� ���������
   CHECK_OUT := NULL;
   DAY_NEW_PAGE := NULL;
   WITH_MEMO := NULL;
   PRIL := NULL;
   CLIENT_BANK := 0;
   ORDERING := 0;
   LAST_ACC := NULL;
   UR_ONLY :=0;
   P_HEADER := '';
   MEMO_ONLY := 0;
   OWN_ONLY := 0;
   REVAL := 1;
   P_CL_REL := 0;
   DEP_FIN := 0;
   OD_ORDERING := 0;
   SPEC_MODE := 0;
   IS_MASK := 0;
   CORRESP := 0;
   CL_INT_CLIENTS := 1;
   IZVESCH := 0;
   INN := 0;
   AUTO_RUN := 1;
   NO_RIGHTS := 1;
   IS_GTMP := 1;
   OLD_FIL := 1; --��� ������ ��������� � ���������������� �������
   P1513LIST := NULL;
   PWEBUSER := NULL;
   
---inn kpp bik �������
select  global_parameters.get_param('������')  into filial1 from dual;
 
select   
':         '||substr(INN0,1, 1)||'                    '||substr(INN0,2, 1)||'                    '||substr(INN0,3, 1)||'                    '||substr(INN0,4, 1)||'                    '||substr(INN0,5, 1)||'                    '||substr(INN0,6, 1)||'                    '||substr(INN0,7, 1)||
'                    '||substr(INN0,8, 1)||'                    '||substr(INN0,9, 1)||'                    '||substr(INN0,10, 1) into inn1
from (select global_parameters.get_param('���_�������') as INN0  from DUAL);

select     
'         '||substr(KPP0,1,1)||'                    '||substr(KPP0,2,1)||'                    '||substr(KPP0,3,1)||'                    '|| 
substr(KPP0,4,1)||'                    '||substr(KPP0,5,1)||'                    '||substr(KPP0,6,1)||'                    '||substr(KPP0,7,1)||'                    '||
substr(KPP0,8,1)||'                    '||substr(KPP0,9,1) into kpp1
from (  select  global_parameters.get_param('���_�������') KPP0  from DUAL);

select 
'         '||substr(BIK0,1,1)||'                    '||substr(BIK0,2,1)||'                    '||substr(BIK0,3,1)||'                    '|| 
substr(BIK0,4,1)||'                    '||substr(BIK0,5,1)||'                    '||substr(BIK0,6,1)||'                    '||substr(BIK0,7,1)||'                    '||
substr(BIK0,8,1)||'                    '||substr(BIK0,9,1) into bik1 
 from (select global_parameters.get_param('���_�������') BIK0  from DUAL );
 
PTOOLS_XLSX.new_document;  ---create xlsx

--nncount
for kk in (
---start cursor kk
select code,header,currency from account a where 
code in ('40825810239000000001'              
,'40506810415000000380'
,'40706810415000001105'
,'40506810315000000309'
,'40706810615000000414'
,'40706810215010000749'
,'40706810415010000251'
,'40706810515010000782'
,'40706810315010001004'
,'40706810715010000595'
,'40706810615010001241'
,'40706810815010001041'
,'40706810715010001251'
,'40706810515000002059'
,'40706810384070000160'
,'40706810084070000143'
,'40706810284070000150'
,'40706810384070000157'
,'40706810684070000161'
,'40706810584070000148'
,'40706810384070000092'
,'40706810984070000159'
,'40706810484070000183'
,'40706810368030000540'
,'40706810674000000604'
,'40706810015000000755')

)  --������ ����� 
loop
dbms_output.put_line (innenter);
ACC_TEMPL :=kk.code;
curr :=kk.currency;
P_HEADER:=kk.header;

   EXECUTE IMMEDIATE 'truncate table report_gtmp3';
   
   MBANK.PREPORT2.REPORT_URLIST (DDATE1, DDATE2, ACC_TEMPL, CURR,TURN_ONLY, CHECK_OUT, DAY_NEW_PAGE,
                                 WITH_MEMO, PRIL,CLIENT_BANK, ORDERING,LAST_ACC, UR_ONLY,P_HEADER,MEMO_ONLY,OWN_ONLY,
                                 REVAL, P_CL_REL,DEP_FIN, OD_ORDERING,SPEC_MODE,IS_MASK,CORRESP,
                                 CL_INT_CLIENTS, IZVESCH,INN, AUTO_RUN, NO_RIGHTS, IS_GTMP, OLD_FIL,
                                 P1513LIST, PWEBUSER);
                                 
   INSERT INTO report_gtmp3 SELECT * FROM report_gtmp;
   COMMIT;
   EXECUTE IMMEDIATE 'truncate table report_gtmp';
 ---��������
 --���/��� �������� �� �����
select NAME,INN,
':         '||substr(INN,1, 1)||'                    '||substr(INN,2, 1)||'                    '||substr(INN,3, 1)
||'                    '||substr(INN,4, 1)
||'                    '||substr(INN,5, 1)
||'                    '||substr(INN,6, 1)
||'                    '||substr(INN,7, 1)
||'                    '||substr(INN,8, 1)
||'                    '||substr(INN,9, 1)
||'                    '||substr(INN,10, 1)
||'                    '||substr(INN,11, 1)
||'                    '||substr(INN,12, 1), 
'         '||substr(KPP,1, 1)
||'                    '||substr(KPP,2, 1)
||'                    '||substr(KPP,3, 1)
||'                    '||substr(KPP,4, 1)
||'                    '||substr(KPP,5, 1)
||'                    '||substr(KPP,6, 1)
||'                    '||substr(KPP,7, 1)
||'                    '||substr(KPP,8, 1)
||'                    '||substr(KPP,9, 1) , 
':         '||substr(ACC_TEMPL,1, 1)
||'                    '||substr(ACC_TEMPL,2, 1)
||'                    '||substr(ACC_TEMPL,3, 1)
||'                    '||substr(ACC_TEMPL,4, 1)
||'                    '||substr(ACC_TEMPL,5, 1)
||'                    '||substr(ACC_TEMPL,6, 1)
||'                    '||substr(ACC_TEMPL,7, 1)
||'                    '||substr(ACC_TEMPL,8, 1)
||'                    '||substr(ACC_TEMPL,9, 1)
||'                    '||substr(ACC_TEMPL,10, 1)
||'                    '||substr(ACC_TEMPL,11, 1)
||'                    '||substr(ACC_TEMPL,12, 1)
||'                    '||substr(ACC_TEMPL,13, 1)
||'                    '||substr(ACC_TEMPL,14, 1)
||'                    '||substr(ACC_TEMPL,15, 1)
||'                    '||substr(ACC_TEMPL,16, 1)
||'                    '||substr(ACC_TEMPL,17, 1)
||'                    '||substr(ACC_TEMPL,18, 1)
||'                    '||substr(ACC_TEMPL,19, 1)
||'                    '||substr(ACC_TEMPL,20, 1),
':         '||substr(ACC_TEMPL,6, 1)
||'                    '||substr(ACC_TEMPL,7, 1)
||'                    '||substr(ACC_TEMPL,8, 1)
 into name2,inn3, inn2, kpp2,account2, cur2
 from
 (
 select
 FULL_NAME NAME,
 INN,
 universe.variable_client(BRANCH,REFERENCE,'TAXCODE') KPP,
 ACC_TEMPL 
 from CLIENTS
 where (REFERENCE, BRANCH) in (select CLIENT, BRANCH_CLIENT from ACCOUNT where HEADER = 'A' and CODE = ACC_TEMPL) and TYPE_DOC = 4 and STATUS between 310 and 999 and ROWNUM < 2
 )
;

PTOOLS_XLSX.create_sheet(to_char(ACC_TEMPL)); --������ ����
---������ �������
PTOOLS_XLSX.xls_column_width('A', 11);
PTOOLS_XLSX.xls_column_width('B', 11);
PTOOLS_XLSX.xls_column_width('C', 11);
PTOOLS_XLSX.xls_column_width('D', 11);
PTOOLS_XLSX.xls_column_width('E', 11);
PTOOLS_XLSX.xls_column_width('F', 22);
PTOOLS_XLSX.xls_column_width('G', 22);
PTOOLS_XLSX.xls_column_width('H', 11);
PTOOLS_XLSX.xls_column_width('I', 22);
PTOOLS_XLSX.xls_column_width('J', 11);
PTOOLS_XLSX.xls_column_width('K', 11);
PTOOLS_XLSX.xls_column_width('L', 22);
PTOOLS_XLSX.xls_column_width('M', 11);
PTOOLS_XLSX.xls_column_width('N', 11);
PTOOLS_XLSX.xls_column_width('O', 22);
PTOOLS_XLSX.xls_column_width('P', 11);
PTOOLS_XLSX.xls_column_width('Q', 11);
PTOOLS_XLSX.xls_column_width('R', 11);
PTOOLS_XLSX.xls_column_width('S', 11);
PTOOLS_XLSX.xls_column_width('T', 11);
PTOOLS_XLSX.xls_column_width('U', 11);
PTOOLS_XLSX.xls_column_width('V', 11);
PTOOLS_XLSX.xls_column_width('W', 11);
PTOOLS_XLSX.xls_default_font( 'Arial', 8 );
PTOOLS_XLSX.create_row;
    PTOOLS_XLSX.xls_row_height(15); 
        PTOOLS_XLSX.xls_cell_value('A', '������� �� ��������� �� ����� ����������� (��������������� ���������������, ���������, ������������� ������� ���������, ��������, ����������� ����������� �������)');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A'); 
PTOOLS_XLSX.create_row;
    PTOOLS_XLSX.xls_row_height(15); 
        PTOOLS_XLSX.xls_cell_value('A', '����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
                PTOOLS_XLSX.xls_cell_value('B', filial1);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('B');
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
        PTOOLS_XLSX.xls_cell_value('B', inn1);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('B');
        PTOOLS_XLSX.xls_cell_value('J', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');
         PTOOLS_XLSX.xls_cell_value('K', kpp1);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT('K');
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
       PTOOLS_XLSX.xls_cell_value('B', bik1);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('B');
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '� ������������ � �������� ���������� ������  ��  30 ������� 1899 �.   � ');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
PTOOLS_XLSX.create_row;    
        PTOOLS_XLSX.xls_cell_value('A', '� ���������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
PTOOLS_XLSX.create_row;    
        PTOOLS_XLSX.xls_cell_value('A', name2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '���/���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A'); 
        PTOOLS_XLSX.xls_cell_value('B', inn2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('B'); 
           --**--
        PTOOLS_XLSX.xls_cell_value('J', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('J'); 
        PTOOLS_XLSX.xls_cell_value('K', kpp2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('K'); 
        --***--
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '������������ ������� �� �����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');   
PTOOLS_XLSX.create_row;
        PTOOLS_XLSX.xls_cell_value('A', '�');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A'); 
        PTOOLS_XLSX.xls_cell_value('B', account2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('B'); 
PTOOLS_XLSX.create_row; 
        PTOOLS_XLSX.xls_cell_value('A', '��� ������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
        PTOOLS_XLSX.xls_cell_value('C', cur2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('C');
PTOOLS_XLSX.create_row; 
        PTOOLS_XLSX.xls_cell_value('A', '�� ������ c');
        PTOOLS_XLSX.XLS_CELL_ALIGN_LEFT ('A');
        PTOOLS_XLSX.xls_cell_value('B', DDATE1);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('B');
        PTOOLS_XLSX.xls_cell_value('C', '��');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
        PTOOLS_XLSX.xls_cell_value('D', DDATE2);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
PTOOLS_XLSX.create_row; 
    PTOOLS_XLSX.xls_row_height(35);
      PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('A');
      PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('A');
      PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('B');
      PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('B');
      PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('C');
      PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('C');
            PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('F');
            PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('F');
                  PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('I');
                  PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('I');
                        PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('M');
                        PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('M');
                        PTOOLS_XLSX.XLS_CELL_VERT_ALIGN_TOP('O');
                        PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('O');
                                PTOOLS_XLSX.xls_cell_value('A', '� �/�');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
        PTOOLS_XLSX.xls_cell_value('B', '���� ���������� ��������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('B');
        PTOOLS_XLSX.xls_cell_value('C', '��������� ���������, �� ��������� �������� ���� ��������� �������� �� �����');
        PTOOLS_XLSX.MERGE_CELLS('C','E');        
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
        PTOOLS_XLSX.xls_cell_value('F', '��������� ����� �����������\���������� �������� �������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('F');
                        PTOOLS_XLSX.MERGE_CELLS('F','H');   
                PTOOLS_XLSX.MERGE_CELLS('I','L');
        PTOOLS_XLSX.xls_cell_value('I', '��������� �����������\���������� �������� �������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('I');
        PTOOLS_XLSX.xls_cell_value('M', '����� �������� �� �����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('M');
                PTOOLS_XLSX.MERGE_CELLS('M','N');
        PTOOLS_XLSX.xls_cell_value('O', '���������� �������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('O');
      ---*-**-*-*
PTOOLS_XLSX.create_row; 
    PTOOLS_XLSX.xls_row_height(25); 
        PTOOLS_XLSX.xls_cell_value('C', '��� (����)');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('�');
        PTOOLS_XLSX.xls_cell_value('D', '�����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('�');
        PTOOLS_XLSX.xls_cell_value('E', '����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('E');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('�');
        PTOOLS_XLSX.xls_cell_value('F', '����� ���������- ��������� �����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('F');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('F');
        PTOOLS_XLSX.xls_cell_value('G', '������������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('G');
        PTOOLS_XLSX.xls_cell_value('H', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('H');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('H');
        PTOOLS_XLSX.xls_cell_value('I', '������������/ �.�.� ');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('I');  
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('I');
        PTOOLS_XLSX.xls_cell_value('J', '���/���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J'); 
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('J'); 
        PTOOLS_XLSX.xls_cell_value('K', '���');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('K'); 
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('K'); 
        PTOOLS_XLSX.xls_cell_value('L', '����� �����');
        PTOOLS_XLSX.XLS_CELL_ALIGN_RIGHT ('L');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('L');
         PTOOLS_XLSX.xls_cell_value('M', '�� ������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('M');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('M');
        PTOOLS_XLSX.xls_cell_value('N', '�� �������');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('N');
              PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('N');
    --  -*-*-*-*-*-*-
 PTOOLS_XLSX.create_row; 
        PTOOLS_XLSX.xls_cell_value('A', '1');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
        PTOOLS_XLSX.xls_cell_value('B', '2');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('B');
        PTOOLS_XLSX.xls_cell_value('C', '3');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
        PTOOLS_XLSX.xls_cell_value('D', '4');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
        PTOOLS_XLSX.xls_cell_value('E', '5');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('E');
        PTOOLS_XLSX.xls_cell_value('F', '6');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('F');
        PTOOLS_XLSX.xls_cell_value('G', '7');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
        PTOOLS_XLSX.xls_cell_value('H', '8');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('H');
        PTOOLS_XLSX.xls_cell_value('I', '9');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('I');  
        PTOOLS_XLSX.xls_cell_value('J', '10');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');  
        PTOOLS_XLSX.xls_cell_value('K', '11');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('K');  
        PTOOLS_XLSX.xls_cell_value('L', '12');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('L');
         PTOOLS_XLSX.xls_cell_value('M', '13');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('M');
        PTOOLS_XLSX.xls_cell_value('N', '14');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('N');
        PTOOLS_XLSX.xls_cell_value('O', '15');
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('O');
        -----������� ������
        i:=0;
        for vv in (select
                 COUNT_OUT, WORK_DATE, DEBIT, CREDIT, CURRENCY,
                 to_number(ltrim(substr(TEXT,14,20))) REFERENCE,
                 to_number(ltrim(substr(TEXT,34,10))) BRANCH,
                 rtrim(ltrim(substr(BAL,16,25)))  ACCOUNT,          -- ����������������� ����
                 rtrim(ltrim(substr(BAL,6,10)))   BIK,
                 rtrim(ltrim(substr(TEXT,50,12))) INN,
                 rtrim(ltrim(substr(BAL,1,5)))    OPER_KIND,
                 rtrim(ltrim(substr(BAL,51,10)))  DOC_NUMBER,
                 PARENCY MEMO
              from report_gtmp3
              where ID = 'REPORT_URLIST' and USERS = 1403
                and OPERATION = '1'
                and (DEBIT <> 0 or CREDIT <> 0))
                
        loop
      src_account9 := ACC_TEMPL;
      DATE_WORK9     := to_char(vv.WORK_DATE,'DD.MM.YYYY');
      OPER_KIND9     := vv.OPER_KIND;
      DOC_NUMBER9    := vv.DOC_NUMBER;
      r_currency := substr(ACC_TEMPL,6,3);
      BIK9 := vv.BIK;
      if BIK9 is NULL and r_currency = NationalCurrency and vv.ACCOUNT not like '2%' then
         BIK9 := r_BIK;
      end if;
      INN9     := ltrim(rtrim(vv.INN));
      ACCOUNT9 := ltrim(rtrim(vv.ACCOUNT));
      DEBIT9   := replace(to_char(vv.DEBIT, '99999999999999999990.00'),'.','-');
      CREDIT9  := replace(to_char(vv.CREDIT,'99999999999999999990.00'),'.','-');
      MEMO9    := vv.MEMO;
      -- ������ ���������
      for rec_doc in (select TYPE_DOC, DATE_DOCUMENT,
                             PAYERS,    PAYERS_BANK,    PAYERS_CORACC,
                             RECEIVERS, RECEIVERS_BANK, RECEIVERS_CORACC
                      from ARCHIVE
                      where REFERENCE = vv.REFERENCE and BRANCH = vv.BRANCH
                      union all
                      select TYPE_DOC, DATE_DOCUMENT,
                             PAYERS,    PAYERS_BANK,    PAYERS_CORACC,
                             RECEIVERS, RECEIVERS_BANK, RECEIVERS_CORACC
                      from DOCUMENTS
                      where REFERENCE = vv.REFERENCE and BRANCH = vv.BRANCH
                      union all
                      select TYPE_DOC, DATE_DOCUMENT,
                             PAYERS,    PAYERS_BANK,    PAYERS_CORACC,
                             RECEIVERS, RECEIVERS_BANK, RECEIVERS_CORACC
                      from GLOBAL_ARCHIVE
                      where REFERENCE = vv.REFERENCE and BRANCH = vv.BRANCH
                     )
         loop
         DATE_DOCUMENT9 := nvl(to_char(rec_doc.DATE_DOCUMENT,'DD.MM.YYYY'),'-');
         if vv.DEBIT = 0 then
            CORR_ACC9  := rtrim(ltrim(rec_doc.PAYERS_CORACC));
            BANK_NAME9 := rtrim(ltrim(rec_doc.PAYERS_BANK));
            FIO9       := rtrim(ltrim(rec_doc.PAYERS));
            KPP9       := rtrim(ltrim(universe.variable_part(vv.REFERENCE,vv.BRANCH,'PAYERS_KPP')));
         else
            CORR_ACC9  := rtrim(ltrim(rec_doc.RECEIVERS_CORACC));
            BANK_NAME9 := rtrim(ltrim(rec_doc.RECEIVERS_BANK));
            FIO9       := rtrim(ltrim(rec_doc.RECEIVERS));
            KPP9       := rtrim(ltrim(universe.variable_part(vv.REFERENCE,vv.BRANCH,'RECEIVERS_KPP')));
         end if;
         if CORR_ACC9 is NULL and r_currency = NationalCurrency and BIK9 = r_BIK and vv.ACCOUNT not like '2%' then
            CORR_ACC9 := r_CorrAcc;
         end if;
         if BANK_NAME9 is NULL and r_currency = NationalCurrency and BIK9 = r_BIK and vv.ACCOUNT not like '2%' then
            BANK_NAME9 := r_BankName;
         end if;
         exit;
      end loop;
        ----
        i:=i+1;
        
         PTOOLS_XLSX.create_row;  
            PTOOLS_XLSX.xls_row_height(35);
        PTOOLS_XLSX.xls_cell_value('A', i);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
        PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('A');
        PTOOLS_XLSX.xls_cell_value('B', date_work9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('B');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('B');
        PTOOLS_XLSX.xls_cell_value('C', oper_kind9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('C');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('C');
        PTOOLS_XLSX.xls_cell_value('D', doc_number9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('D');
        PTOOLS_XLSX.xls_cell_value('E', date_document9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('E');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('E');
        PTOOLS_XLSX.xls_cell_value('F', corr_acc9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('F');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('F');
        PTOOLS_XLSX.xls_cell_value('G', bank_name9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
             PTOOLS_XLSX.XLS_CELL_FONT('G','Arial',6);
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('G');
        PTOOLS_XLSX.xls_cell_value('H', BIK9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('H');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('H');
        PTOOLS_XLSX.xls_cell_value('I', FIO9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('I'); 
        PTOOLS_XLSX.XLS_CELL_FONT('I','Arial',6);
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('I');
        PTOOLS_XLSX.xls_cell_value('J', INN9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');  
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('J');
        PTOOLS_XLSX.xls_cell_value('K', KPP9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('K');  
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('K');
        PTOOLS_XLSX.xls_cell_value('L', ACCOUNT9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('L');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('L');
         PTOOLS_XLSX.xls_cell_value('M', DEBIT9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('M');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('M');
        PTOOLS_XLSX.xls_cell_value('N', credit9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('N');
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('N');
        PTOOLS_XLSX.xls_cell_value('O', memo9);
        PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER('O');     
                PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('O');
                        PTOOLS_XLSX.XLS_CELL_FONT('O','Arial',6);  
       end loop;                 
                    ----�������
select
 replace(to_char(REST_BEGIN1,'99999999999999999990.00'),'.','-') ,
 replace(to_char(DEBIT1,     '99999999999999999990.00'),'.','-') ,
 replace(to_char(CREDIT1,    '99999999999999999990.00'),'.','-') ,
 replace(to_char(REST_END1,  '99999999999999999990.00'),'.','-') 
 into REST_BEGIN,DEBIT ,CREDIT  ,REST_END 
 from
 (
 select
 abs(pledger.saldo(HEADER, CODE, CURRENCY, DDATE1-1)) REST_BEGIN1,
 pledger.debit(HEADER, CODE, CURRENCY, DDATE1, DDATE2) DEBIT1,
 pledger.credit(HEADER, CODE, CURRENCY, DDATE1, DDATE2) CREDIT1,
 abs(pledger.saldo(HEADER, CODE, CURRENCY, DDATE2)) REST_END1 
 from ACCOUNT
 where HEADER = 'A' and CODE = ACC_TEMPL
   and CURRENCY = substr(
   ACC_TEMPL,6,3)
 );   
  PTOOLS_XLSX.create_row;
         PTOOLS_XLSX.xls_cell_value('A', ' ');
          PTOOLS_XLSX.create_row;
         PTOOLS_XLSX.xls_cell_value('A', ' ');
 PTOOLS_XLSX.create_row;
         PTOOLS_XLSX.xls_cell_value('A', '������� �� ����� �� ������ �������');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('A');
         PTOOLS_XLSX.MERGE_CELLS('A','C'); 
         
         PTOOLS_XLSX.xls_cell_value('D', '����� �� ������ ����� �� ������');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('D');
         PTOOLS_XLSX.MERGE_CELLS('D','F');
         
         PTOOLS_XLSX.xls_cell_value('G', '����� �� ������� ����� �� ������');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('G');
         PTOOLS_XLSX.MERGE_CELLS('G','I');      
         
         PTOOLS_XLSX.xls_cell_value('J', '������� �� ����� �� ����� �������');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('J');
         PTOOLS_XLSX.MERGE_CELLS('J','L');  
         
 PTOOLS_XLSX.create_row;
         PTOOLS_XLSX.xls_cell_value('A', '1');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('A');
         PTOOLS_XLSX.MERGE_CELLS('A','C'); 
         
         PTOOLS_XLSX.xls_cell_value('D', '2');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('D');
         PTOOLS_XLSX.MERGE_CELLS('D','F');
         
         PTOOLS_XLSX.xls_cell_value('G', '3');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('G');
         PTOOLS_XLSX.MERGE_CELLS('G','I');      
         
         PTOOLS_XLSX.xls_cell_value('J', '4');
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('J');
         PTOOLS_XLSX.MERGE_CELLS('J','L');  
         
          PTOOLS_XLSX.create_row;
         PTOOLS_XLSX.xls_cell_value('A', REST_BEGIN);
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('A');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('A');
         PTOOLS_XLSX.MERGE_CELLS('A','C'); 
         
         PTOOLS_XLSX.xls_cell_value('D', DEBIT);
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('D');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('D');
         PTOOLS_XLSX.MERGE_CELLS('D','F');
         
         PTOOLS_XLSX.xls_cell_value('G', CREDIT);
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('G');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('G');
         PTOOLS_XLSX.MERGE_CELLS('G','I');      
         
         PTOOLS_XLSX.xls_cell_value('J', REST_END);
         PTOOLS_XLSX.XLS_CELL_ALIGN_CENTER ('J');
         PTOOLS_XLSX.XLS_CELL_WRAP_TEXT('J');
         PTOOLS_XLSX.MERGE_CELLS('J','L');  
 end loop;
 ----end cursor kk   
         title1 :=to_char(inn3)||sysdate||'.xlsx';
      ----       
PTOOLS_XLSX.save_to_blob(mail_blob);
  P_EMAIL.SEND_MAIL_FROM_JOB_NORMAL(RECIEVER  => 'r.aleshin@vtb.ru',
        SUBJECT   => '��� �������',
        MAIL_TEXT => name2,
        MAIL_BLOB => mail_blob,
        FILE_NAME => title1);
        


        commit;
        end; 