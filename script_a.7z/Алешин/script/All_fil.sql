insert into jobs_rights@ekburg 
select 1,type_id,code,0,null,null,null from types@nnovg t where type_id in (11289,11391,11469)
and not exists (select null from jobs_rights@nnovg where job_id = 1 and object_id = t.type_id)
/

--DISABLE_SUCC
declare 
 n varchar2(4000);
 n1 varchar2(4000);
 -- ref number := 54897535;
-- br number := 104008;
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
             --union all select server_address value,s.name from subdepartments s where S.ID = 191
            )
  loop
     n := '';
    n1 := '';  
    begin
      execute immediate 'select min(value),min(p.name) from parameters@'||i.value||' p, paramvalues@'||i.value||' pv  where p.name = ''APP_SERVER_EI'' --not in (''MAIL_SERVER'', ''CKKI_EX _SERVER'',''SMTP_SERVER'')  
      and p.id = pv.paramid and p.group_id = pv.paramgroupid
          and pv.activated = (select max(activated) from paramvalues@'||i.value||' where paramid = pv.paramid and paramgroupid = pv.paramgroupid)' into n,n1;

      --     execute immediate 'select directory from cbs_dirs@'||i.fil||' where instr(upper(directory),upper('''||n||''')) > 0' into n1;
    exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ����');
    end;  
    dbms_output.put_line(i.value||'>>'||n1||'>>'||n); --||'; �������� � RS_EXP >> '||n1||'');
  commit;
  rollback;
  commit;
  dbms_session.close_database_link(i.value);
  end loop;
end;
/

/
select * from cbs_dirs@nsibirsk

\\OSO.MMBANK.RU\ROBOTS\IBANK.FIL\NVSIB\

select id from subdepartments@nsibirsk where type = 400 and parent = 0 and server_address = (select GLOBAL_NAME from global_name@nsibirsk)   
select * from global_name@nsibirsk

select * from parameters where name like '%DEMAND%'--= '����������_�����_���'
/
insert into paramvalues
select id,group_id,(select id from subdepartments where type = 400 and parent = 0 and server_address = (select GLOBAL_NAME from global_name)),'500000',trunc(sysdate)-1 from parameters where name like '%LSO%' and rownum < 2 
/
begin
  dbms_output.put_line('mbGoID - '||mbGoID@rostov);
  insert into paramvalues@rostov
  select id,group_id,(select id from subdepartments@rostov where type = 400 and parent = 0 and server_address = (select GLOBAL_NAME from global_name@rostov)),'200000',trunc(sysdate)-1 from parameters@rostov where name like '%LSO%' and rownum < 2;
end; 
/

select pv.paramid,pv.rowid,pv.value,pv.activated from parameters@spburg p, paramvalues@nsibirsk pv  where p.name = '����_�����_LSO'  and p.id = pv.paramid and p.group_id = pv.paramgroupid
   and pv.activated = (select max(activated) from paramvalues@spburg where paramid = pv.paramid and paramgroupid = pv.paramgroupid)  
/   

--DISABLE_SUCC
declare 
 n varchar2(4000);
 err varchar2(4000);
 -- ref number := 54897535;
-- br number := 104008;
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
               --union all select server_address value,s.name from subdepartments s where S.ID = 191            
            )
loop
   n := null;
   err := null;
   begin
     execute immediate
    -- 'select count(*) from smtp_messages@'||i.value||' where done = 1 and sys_date > trunc(sysdate)-1 ' into n;
   -- 'select count(*) from jobs_rights@'||i.value||'  where code = 13 and object_id = 969' into n; 
    --    'select count(*) from documents@'||i.value||'  where type_doc in (1982) and date_work >= ''29-mar-2017'' and status = 10' into n; 
        --select count(*) from archive@'||i.value||'  where type_doc in (1982) and date_work >= '29-mar-2017' and status = 30
    --'select count(*) from shed_jobs@'||i.value||' where job_name = ''OD_1001_PORTFOLIO_1'' and  task_name = ''OPERDAY''' into n;
     --and smtp_server = ''mbankrgate.main.mmbank.ru''
   --  'select count(*) from tax t where work_date = ''28-feb-2017'' and
   --   not exists (select null from tax@'||i.value||' where work_date = t.work_date and operation = t.operation and type_contract = t.type_contract and type_client = t.type_client and subtype_client = t.subtype_client and currency = t.currency)'  into n;  
   --'select count(*) from account@'||i.value||' c where code like ''91316810439040000002''' into n;
   -- 'select count(*) from contracts@'||i.fil||' c where status = 50 and type_doc in (select type from variable_types@'||i.fil||' where name = ''LOAN_HUMAN'') and date_work between ''01-jan-2016'' and ''10-jan-2016'' 
   --and date_penalty is null and exists (select null from rest_contracts@'||i.fil||' where reference = c.reference and branch = c.branch and name in (''GRAPH_PERCENT'',''GRAPH_LOAN'') and insum-outsum <> 0 and work_date = c.date_work)'    
   --'select /*+index(collector_contracts_pk)*/ count(*) from contracts@'||i.fil||' c, collector_contracts@'||i.fil||'  cc where status = 50 and type_doc in (select type from variable_types@'||i.fil||'  where name = ''LOAN_HUMAN'')
   --and cc.reference = c.reference and cc.branch = c.branch and cc.name = ''GRAPH_HOLIDAY'' and cc.work_date >= ''01-dec-2015''
   --and exists (select /*+index(rest_contracts_pk)*/  * from rest_contracts@'||i.fil||'  where reference = c.reference and branch = c.branch and name in (''GRAPH_LOAN'',''GRAPH_PERCENT'') and work_date =cc.work_date and insum-outsum > 0) 
   --and exists (select /*+index(rest_contracts_pk)*/  * from rest_contracts@'||i.fil||'  where reference = c.reference and branch = c.branch and name in (''GRAPH_HOLIDAY'') and work_date =cc.work_date and insum-outsum > 0)'
   --'select count(*) from account where header = ''V'''
   'select count(*) from clients@'||i.value||' where inn = ''7701330105''' into n;
   
   -- 'INSERT INTO guides@'||i.value||' ( BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK ,CODE,NAME,STR1,CODE1) select  BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,DATE_WORK ,CODE,NAME,STR1,CODE1 from guides g where type_DOC = 3467 AND CODE = ''DEMAND_INFO''
   --and not exists (select null from guides@'||i.value||'  where type_doc = g.type_doc and code = g.code and upper(code1) = upper(g.code1))';
   -- 'DELETE guides@'||i.fil||' where type_DOC = 3467 AND CODE = ''DEMAND_INFO'' AND STR1 = ''79055870643''';
    --'select count(*) from guides@'||i.fil||' where type_DOC = 3467 AND CODE = ''DEMAND_INFO'' AND STR1 = ''79055870643''' 
     --'INSERT INTO tax@'||i.value||' 
    -- 'select count(*) from journal@'||i.value||' where work_date > ''01-dec-2017''  and substr(currency,1,1) = ''A'' ' into n;
     
   exception when NO_DATA_FOUND then       
       err := i.value||' �� ������';
       n := null;
   end;   
  commit;
  rollback;
   if err is not null then
     dbms_output.put_line(err);
   else
     dbms_output.put_line(i.value||'>> ���-�� >> '||n);
     begin
       dbms_session.close_database_link(i.value);
     exception when OTHERS then
       dbms_output.put_line(i.value||'��� �����');
     end;    
   end if;       
end loop;
end;
/

select * from guides g where type_DOC = 3467 AND CODE = 'DEMAND_INFO' AND STR1 = '79036396961'
/
--������ ������� �� �������� ����������
select   
Universe.NameClient(c.branch_client,c.refer_client) "�.�.�.",c.doc_number "� ��������",Universe.NameType(c.type_doc) "��� ���-��"
,c.date_open "���� ��������", c.date_next "���� ���.���������"
,decode(Period,0,null,to_char(DECODE(universe.DATE_COLLECTOR(c.branch,c.reference,'PROLONGATION',c.CURRENCY,:dt),NULL,c.date_open,universe.DATE_COLLECTOR(c.branch,c.reference,'PROLONGATION',c.CURRENCY,:dt))+PERIOD,'dd.mm.yyyy')) "���� ��������"
,c.ACCOUNT "����"
,ABS(round(Pledger.SALDO('A',c.ACCOUNT,c.CURRENCY,sysdate)*pledger.WCOURSE(c.CURRENCY,sysdate),2)) "������� ���"
,universe.nameowner(c.owner) "���������"
,Universe.NameDepart(c.subdepartment) "���������"
--select * 
from contracts c  where c.date_procent  <= trunc(sysdate) and c.status in (50,70) and c.type_client = 5 and c.type_doc != 6905
            and c.TYPE_DOC IN (select v.type from variable_types v where v.name='PRODUCT' and v.value  in ('DEPOSIT','CURRENT')) 
            AND c.subdepartment in (SELECT s.id FROM subdepartments s WHERE s.id IN (SELECT id FROM subdepartments s2   START WITH s2.id = TO_NUMBER(NVL(Global_parameters.Get_param_cfg('FILIAL_BRANCH'),'0')) CONNECT BY PRIOR s2.id = s2.parent)
                AND s.type NOT IN (57,3301,1788) AND SUBSTR(s.name,1,3) IN ('OO_','��_', '��_', '��_'))
/

--������ �������� �������������
declare 
 n varchar2(4000);
 sq varchar2(4000);
begin
  for i in (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            )
 loop
   n := '0';
   sq := --'select count(*) from user_parameters'||i.value||' where depart_id = 31306'; 
    --'select count(*) from users@'||i.value||' u where user_name like ''���������� �%''';--user_id = 5697';
    --'update config@'||i.value||' c set value = ''10140;''||value where name in (''LOAN.REPAY'',''LOAN.CARDS'') and instr(value,''10140'') = 0';
    --'insert into zyx_excel@'||i.value||' select * from zyx_excel' ;
  -- execute immediate 'select count(*) from collector_contracts@'||i.value||' cc where name = ''GRAPH_ANNUAL'' and work_date > ''01-oct-2016'' and exists (select null from collector_contracts@'||i.value||'  where reference = cc.reference and branch = cc.branch and name = cc.name and work_date = cc.work_date and summa <> cc.summa)' into n;
  -- execute immediate 'select count(*) from journal@'||i.value||'  j where J.DOCNUM > 2224858607000' into n;
  -- execute immediate 'insert into zyx_select_skripka select (select name from subdepartments@'||i.value||' where id = (select parent from subdepartments@'||i.value||'  where id = a.xsubdepartment)) "������", universe.namedepart@'||i.value||' (xsubdepartment) "�������������", universe.nametype@'||i.value||'(type_doc) "��� ��������", decode(type_doc,18,payers_currency,receivers_currency) "��� ������", summa "�����" 
--,payers "��� �������", UNIVERSE.VARIABLE_ARCH@'||i.value||'(branch,reference,''NUMBER'')||'', ''||UNIVERSE.VARIABLE_ARCH@'||i.value||'(branch,reference,''OUTPUTING'')||'', ''||UNIVERSE.VARIABLE_ARCH@'||i.value||'(branch,reference,''DATEWHEN'') "���������� ������"
--, xsummacredit "����� ���", date_work "���� ��������" 
--from archive@'||i.value||' a where date_work >= ''01-sep-2016'' and date_work <= ''30-sep-2016'' and type_doc in (18,19)';
   -- 'insert into zyx_doc_complance select d.reference,d.branch,d.date_work,d.payers_bik,d.payers_bank,d.payers,d.payers_inn,d.payers_account,eid.p_eid_tools2.get_filial_name(xsubdepartment) filial
         --    ,universe.namedepart@'||i.value||'(xsubdepartment) depart,z.b,z.c,d.summa,d.memo from zyx_cont_cb z, archive@'||i.value||' d where d.type_doc = 2 and d.date_work > ''01-jan-2015'' and instr(replace(d.memo,'' ''),z.c) > 0';
   -- sq := --'select count(*) from clients@'||i.value||' where inn = ''7735580336''';
   --          'select count(*) from jobs@'||i.value||'  j,users@'||i.value||'  u,boss_emp_all b where u.params=b.tab_n(+) and u.job = j.job_id and job_id not in (30809,31280,774) --����� ������,���,����
   --            and instr(upper(u.user_name),''������'') = 0 and u.user_ not in (''MT_MBANK'',''IT_AUDIT'',''REP_SRVR'') --����������� ������
   --            and nvl(global_parameters.get_param(u.user_id,''������'',trunc(sysdate)),''0'') = ''0'' --��� �������� ������
   --            and nvl(global_parameters.get_param(u.user_id,''������_������_��_MAIN'',trunc(sysdate)),''0'') = ''0''
   --           and params <> ''0000'' and sysdate < b.d_out(+)';
  'update shed_tasks@'||i.value||' sh set active = 0 where task_name in (''���'') and nvl(active,0) = 1'; 
   -- 'select active from shed_tasks@'||i.value||' sh where task_name in (''���'') and nvl(active,0) = 1';            
  --execute immediate sq;-- into n;
   begin
    --execute immediate sq into n;
    dbms_output.put_line(i.value||sq);
    exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  --dbms_output.put_line(sq); 
   commit;
  rollback;
  commit;
  dbms_session.close_database_link(i.value);
    dbms_output.put_line(i.name||';'||n);
  end loop;
end;                
/

--������ �������������
select (select name from eid.eid_subdepartments where id = e.parent) "������",substr(NAME,1,instr(name,' ')-1) "��� �������������",count(*) "���-��" from eid.eid_subdepartments e where deleted is null and type = 301 and parent_r is not null
--and id = 191304
group by parent,substr(NAME,1,instr(name,' ')-1)
order by parent
/

--������� �������
--drop table zyx_userparam
--create table zyx_userparam as
/*
select eid.p_eid_tools2.get_filial_name(mbfilid) fil,up.name,upv.value,upv.activated,u.USER_NAME,b.l_name||' '||b.f_name ||' '||b.m_name BNAME,u.USER_ID,B.APPOINT_NAME,j.JOB,j.JOB_ID,B.FILIAL
,b.DEPT_NAME_1,B.DEPT_NAME_2,B.DEPT_NAME_3,b.tab_n,u.user_  
from jobs j, users u, user_parameters up, user_param_values upv, boss_emp_all b 
where upv.depart_id = up.depart_id and upv.id = up.id and upv.user_id = u.user_id and upv.depart_id = u.job and b.d_out > sysdate and u.params = b.tab_n and U.JOB = J.JOB_ID and u.job not in (1)
      and up.name = '������_��_VIP' and upv.activated = (select max(activated) from user_param_values where depart_id = upv.depart_id and id = upv.id and user_id = upv.user_id) and upv.value <> '0' ;
*/      

--������ ��������  
SELECT (select s.name from subdepartments s where S.ID = 191) mb, (select related from clients where reference = c.refer_client and branch = c.branch_client) eid
,Universe.NameClient(c.branch_client,c.refer_client) fio,c.doc_number,Universe.NameType(c.type_doc) nametype
,c.date_open ,c.period ,c.summa ,to_char(c.CURRENCY) curr,to_char(c.ACCOUNT) acc,c.date_close, a.code 
FROM CONTRACTS c, account a
WHERE c.type_doc in (select type from variable_types where name = 'LOAN_HUMAN')
AND c.status IN (50,70,60) --and (c.date_close is null or c.date_close < trunc(sysdate)) --�������� �� ���� dt
and type_client = 5 
and substr(a.code,1,3) in ('918','917') and a.contract = c.reference and a.branch_contract = c.branch and a.close_date is null
--and c.reference = 1561506           
/

--�������� �� ��������
declare 
 n varchar2(4000);
 sq varchar2(4000);
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            )
 loop
   n := '';
   begin
/*   
   sq :=  'insert into zyx_userparam select '''||i.name||''',up.name,upv.value,upv.activated,u.USER_NAME,b.l_name||'' ''||b.f_name ||'' ''||b.m_name,u.USER_ID,B.APPOINT_NAME,j.JOB,j.JOB_ID,B.FILIAL
   ,B.DEPT_NAME_1,B.DEPT_NAME_2,B.DEPT_NAME_3 ,b.tab_n,u.user_   
                 from jobs@'||i.value||' j, users@'||i.value||' u, user_parameters@'||i.value||' up, user_param_values@'||i.value||' upv, boss_emp_all b
   where upv.depart_id = up.depart_id and upv.id = up.id and upv.user_id = u.user_id and upv.depart_id = u.job and b.d_out > sysdate and u.params = b.tab_n and U.JOB = J.JOB_ID and u.job not in (1)
      and up.name =  ''������_��_VIP'' and upv.activated = (select max(activated) from user_param_values@'||i.value||' where depart_id = upv.depart_id and id = upv.id and user_id = upv.user_id) and upv.value <> ''0''';
     --*/ 
/*
sq := 'insert into zyx_log select mbfilid@'||i.value||' ,t.* from (
                  select ''������ ���������'' "��������",a1.start_time "������",a1.end_time "�����",0 "���-��" from demand_x_log@'||i.value||'  a1 where filial = mbfilid@'||i.value||'  and stage = 0 and trunc(start_time) = ''15-jun-2017'' 
        union all
           select ''�������� � ��'' "��������",min(a1.date_create) "������",max(a2.date_create) "�����",count(*) "���-��" from archive@'||i.value||'  a1, archive@'||i.value||'  a2 where a1.type_doc=1432 and a1.date_work=''15-jun-2017'' and a1.payers_operation=''21000220'' and a1.num_group = 9389
and A2.REFER_FROM = a1.reference and a2.branch_from = a1.branch
group by a1.date_work  
union all
select ''��������� ��������'' "��������",min(a1.date_create) "������",max(a2.date_create) "�����",count(*) "���-��" from archive@'||i.value||'  a1, archive@'||i.value||'  a2 where a1.type_doc = 990 and a1.date_work = ''15-jun-2017'' and a1.num_group = 9389 and substr(a1.payers_operation,1,6) = ''210006''
and a1.summa = 0 and A2.REFER_FROM = a1.reference and a2.branch_from = a1.branch
group by a1.date_work
) t
order by 1,3';  
--*/
--/*
sq := 'insert into zyx_userparam SELECT '''||i.name||''', (select related from clients@'||i.value||'  where reference = c.refer_client and branch = c.branch_client) eid
,Universe.NameClient@'||i.value||' (c.branch_client,c.refer_client) fio,c.doc_number,Universe.NameType@'||i.value||' (c.type_doc) nametype
,c.date_open ,c.period ,c.summa  ,to_char(c.CURRENCY) curr,to_char(c.ACCOUNT) acc,c.date_close, a.code 
FROM CONTRACTS@'||i.value||'  c, account@'||i.value||'  a
WHERE c.type_doc in (select type from variable_types@'||i.value||'  where name = ''LOAN_HUMAN'')
AND c.status IN (50,70,60) 
and type_client = 5 and substr(a.code,1,3) in (''918'',''917'') and a.contract = c.reference and a.branch_contract = c.branch and a.close_date is null';
--*/      
    execute immediate sq;-- into n;
   exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  dbms_output.put_line(i.value||'>> ���-�� >> '||n);
  end loop;
end;
/
--������� ����������
select decode(tab_n,-9999, fil,dept_name_1) "�������������_1",
decode(tab_n,-9999,user_name,bname) "���",tab_n "� ���������", appoint_name "���������" , dept_name_2 "�������������_2"
,dept_name_3 "�������������_3" ,user_ "�����", job "����", value "������ VIP", activated "���� ���������"
--* 
from zyx_userparam where value <> 0
order by dept_name_1,dept_name_2,dept_name_3,2
/

--select * from zyx_userparam 
order by mb,fio,doc_number,date_open,summa
--�������� �� �������� ���-�� �������������
/

declare 
 n varchar2(4000);
 sq varchar2(4000);
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            )
 loop
   n := '';
   begin
--   sq := 
/*
    'select count(*) from jobs@'||i.value||' j,users@'||i.value||' u,boss_emp_all b where u.params=b.tab_n(+) and u.job = j.job_id and job_id not in (30809,31280,774) --����� ������,���,����
and instr(upper(u.user_name),''������'') = 0 and u.user_ not in (''MT_MBANK'',''IT_AUDIT'',''REP_SRVR'') --����������� ������
and nvl(global_parameters.get_param@'||i.value||'(u.user_id,''������'',trunc(sysdate)),''0'') = ''0'' --��� �������� ������
and nvl(global_parameters.get_param@'||i.value||'(u.user_id,''������_������_��_MAIN'',trunc(sysdate)),''0'') = ''0''
and params <> ''0000'' and sysdate < b.d_out(+)' 
;
*/
--sq := 'select count(*) from documents@'||i.value||'  a where type_doc in (1,2,226,225) and date_work = ''08-dec-2017'' and summa <> 0 and status > 24 and status <= 50   
--and not exists (select null from journal@'||i.value||' where docnum = a.reference and branch = a.branch)
--and not exists (select null from variable_documents@'||i.value||' where reference = a.reference and branch = a.branch and name = ''ROLLBACKTOEMITENT'' and value = ''1'')';

--sq := 'select count(*) from subdepartments@'||i.value||' where upper(name) like ''%���24%''';   
--sq := 'select count(*) from jobs@'||i.value||' where upper(job) = upper(''��������� �/�'')';
--sq := 'select job from jobs@'||i.value||' where upper(job) = upper(''��������� �/�'')';
sq := 'select job from jobs@'||i.value||' where job_id = 30809';
-- sq := 'delete zyx_excel@'||i.value||' z where substr(z.A,1,6) in (''DELETE'',''INSERT'')';
    execute immediate sq into n;
   exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  dbms_output.put_line(i.value||'>> ���-�� >> '||n);
  commit;
  rollback;
  dbms_session.close_database_link(i.value);
  end loop;
end;
/

select z.* from zyx_log z
--create table zyx_log as
select mbfilid,t.* from (
select '������ ���������' a_oper,a1.start_time a_begin,a1.end_time a_end,0 a_count from demand_x_log a1 where filial = mbfilid and stage = 0 and trunc(start_time) >= '26-jun-2017' 
union all
select '�������� � ��' a_oper,min(a1.date_create) a_begin,max(a2.date_create) a_end,count(*) a_count from archive a1, archive a2 where a1.type_doc=1432 and a1.date_work>='26-jun-2017' and a1.payers_operation='21000220' and a1.num_group = 9389
and A2.REFER_FROM = a1.reference and a2.branch_from = a1.branch
group by a1.date_work  
union all
select '��������� ��������' a_oper,min(a1.date_create) a_begin,max(a2.date_create) a_end,count(*) a_count from archive a1, archive a2 where a1.type_doc = 990 and a1.date_work >= '26-jun-2017' and a1.num_group = 9389 and substr(a1.payers_operation,1,6) = '210006'
and a1.summa = 0 and A2.REFER_FROM = a1.reference and a2.branch_from = a1.branch
group by a1.date_work
) t
order by 1,3  
/
--�������� �� ��������� -������ �����
select  d.local_date,
(select count(*) from contracts c where status in (50,60) and (date_close is null or date_close > d.local_date)
 and  type_doc in (select type from variable_types where name = 'LOAN_HUMAN')
and date_work >= d.local_date and date_open < d.local_date
and (select sum(summa) from collector_contracts where reference = c.reference and branch = c.branch and name in ('GRAPH_LOAN','GRAPH_PERCENT') and work_date = d.local_date) <> 0
) gr_loan
,(select count(*) from contracts c where status in (50,60) and (date_close is null or date_close > d.local_date)
 and  type_doc in (select type from variable_types where name = 'LOAN_HUMAN')
and date_work >= d.local_date and date_open < d.local_date
and exists (select null from collector_contracts where reference = c.reference and branch = c.branch and name in ('210108','K+210008') and work_date = d.local_date)) bad_loan
 from dates d where (local_date =  '26-jun-2017')-- and local_date < '03-jul-2017' or local_date = '15-jun-2017')

/


--������ ��� ������������� ���� �� �����
declare 
 n varchar2(4000);
 sq varchar2(4000);
 jb varchar2(1000);
begin
  for i in  (select vg.value,s.name from subdepartments s, variable_guides vg, guides g where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
            -- union all select server_address value,s.name from subdepartments s where S.ID = 191
            and g.num1 = 47
            )
 loop
   jb := ' 35,31391'; --������ id ����� �� main 
   n := '';
   begin
  --������ ������ ������ 
   sq := 'delete zyx_excel@'||i.value||' z where substr(z.A,1,6) in (''DELETE'',''INSERT'')'; 
   execute immediate sq;
   commit;
   --��������� ������ �� �������� ������ ���� 
   sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''DELETE JOBS_RIGHTS'',''delete jobs_rights where job_id = ''||jr.job_id||'' and object_id = ''||jr.object_id||'' and code = ''||jr.code||'' and operation = ''||jr.operation||'' and nvl(rights,-1379) = ''||nvl(jr.rights,-1379)
 from jobs_rights@'||i.value||' jr where job_id in (select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and J.JOB_ID in ('||jb||'))   
and not exists (select null from jobs_rights where job_id = (select j.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and jf.JOB_ID = jr.job_id)
 and object_id = jr.object_id and code = jr.code and operation = jr.operation and nvl(rights,-1379) = nvl(jr.rights,-1379))';
   --execute immediate sq;
   commit;
   dbms_output.put_line('1 '||sq);
--��������� ������ �� ���������� ���� 
 sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''INSERT JOBS_RIGHTS'',''insert into jobs_rights(job_id,object_id,code,operation,rights) values(''||(select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and j.JOB_ID = jr.job_id)||'',''||jr.object_id||'',''||jr.code||'',''||jr.operation||'',''||nvl(to_char(jr.rights),''NULL'')||'')''
 from jobs_rights jr where job_id in ('||jb||') and not exists (select null from jobs_rights@'||i.value||' where job_id in (select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and j.JOB_ID = jr.job_id)
 and object_id = jr.object_id and code = jr.code and operation = jr.operation and nvl(rights,-1379) = nvl(jr.rights,-1379))';
  --execute immediate sq;
   commit;
 --dbms_output.put_line('2 '||sq);
sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''DELETE USER_PARAMETERS'',''delete user_parameters where depart_id = ''||up.depart_id||'' and name = ''''''||up.name||''''''''
 from user_parameters@'||i.value||' up where depart_id in (select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and J.JOB_ID in ('||jb||'))   
and not exists (select null from user_parameters where depart_id = (select j.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and jf.JOB_ID = up.depart_id) and name = up.name)';
  -- execute immediate sq;   
   commit;
   --dbms_output.put_line('3 '||sq);
sq := 'insert into zyx_excel@'||i.value||'(a,b) select ''INSERT USER_PARAMETERS'',''insert into user_parameters(depart_id,name) values(''||(select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and j.JOB_ID = up.depart_id)||'',''''''||up.name||'''''')''
 from user_parameters up where depart_id in ('||jb||') and not exists (select null from user_parameters@'||i.value||' where depart_id = (select jf.job_id from jobs@'||i.value||' jf, jobs j where upper(jf.job) = upper(j.job) and j.JOB_ID = up.depart_id) and name = up.name)';
  --execute immediate sq;
   commit;
 --dbms_output.put_line('4 '||sq);
   
   exception when NO_DATA_FOUND then
       dbms_output.put_line(i.value||'�� ������ ');
   end;   
  dbms_output.put_line(i.value||'>> ���-�� >> '||n);
  commit;
  rollback;
  dbms_session.close_database_link(i.value);
  end loop;
end;
/



select vg.value from guides g, variable_guides vg where vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M'
and g.num1 = rec.fil
/


  --insert into jobs
select 'NEW JOBS','insert into jobs(JOB,JOB_ID,PARENT) values('''||j.JOB||''','||j.JOB_ID||','||j.PARENT||')' 
,j.* from jobs j where job_id = 35 and not exists (select null from jobs@nsibirsk where job_id = j.job_id)   


select 'NEW JOBS_RIGHTS','insert into jobs_rights(job_id,object_id,code,operation,rights) values('||jr.job_id||','||jr.object_id||','||jr.code||','||jr.operation||','||nvl(to_char(jr.rights),'NULL')||')'
 from jobs_rights jr where job_id = 35

select 'NEW USER_PARAMETERS','insert into user_parameters(depart_id,name) values('||up.depart_id||','''||up.name||''')'
 from user_parameters up where depart_id = 35

/

--������������� ����
begin
--������� ������ �����
  for rec in (select * from zyx_excel where a = 'DELETE JOBS_RIGHTS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--��������� ����������� �����
  for rec in (select * from zyx_excel where a = 'INSERT JOBS_RIGHTS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;   
  end loop;
  commit;
--������� ������ ���������
  for rec in (select * from zyx_excel where a = 'DELETE USER_PARAMETERS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
--��������� ����������� ��������
  for rec in (select * from zyx_excel where a = 'INSERT USER_PARAMETERS') 
  loop
     execute immediate rec.B;
     update zyx_excel set A= '#'||A where A= rec.A and B = rec.B;     
  end loop;
  commit;
   dbms_output.put_line('FINISH ');
end;
/

select * from zyx_excel where b =  
'354' '192' '49' '47' '104' '48' '76'

insert into zyx_excel(a,b,c,d,e)
select a,b,'07.06.2018',d,sum(to_number(e)) from zyx_excel@rostov where a in ('20180606_0')
group by a,b,d


select b "������",d "���",sum(to_number(e)) "���-�� ��������" from zyx_excel where a in ('20180606_0') --,'20180606_0')
group by a,b,d

select b "������",sum(to_number(e)) "���-�� ��������" from zyx_excel where a in ('20180606_0') --,'20180606_0')
group by b