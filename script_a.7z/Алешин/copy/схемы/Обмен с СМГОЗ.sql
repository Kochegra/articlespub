--����� �� ������� ������
--40706810815000002089
--40706810015000003024 

--�����
select rowid,t.* from mbank.tbl_queue_SMGOZ_MB_MQ t where state in (0,3) and mod_dt > sysdate-2 and instr(message,'40706810015000003024') > 0

select rowid,t.* from mbank.tbl_queue_SMGOZ_MQ_MB t where state = 3 and mod_dt > sysdate-1 and instr(message,'40706810015000003024') > 0

select * from mbank.goz_message_log where date_create > sysdate-2
and related_ref = 257298124
--and msg_id = 3815748346--3785580189  --11160783
--and status = -1
--and id = 11160785

-- 28873310000200
select ''''||'MB_SMGOZ'||q.ID||''',',rowid,q.* from MBANK.GOZ_MESSAGE_LOG q where 
trunc(Q.DATE_CREATE) > sysdate -1
--and q.RELATED_BR = 200
--Q.RELATED_REF in (2887331 )
and q.MTYPE = 'OT_CABS_ACCSTAT_GOZ_REQ'
--and instr(message,'6552774')>0
--q.MSG_ID = 2619559487 
order by Q.DATE_CREATE desc
/
--����� ������
SMGOZ_EXCHANGE
/


--�� ���������� �������� � �������� ��������� ��������
--��� ������ ���� �������� �������� ( ������ ��� ��������� ������� "&" � MEMO)
declare
  v_XMLmsg         number;
  o_error         varchar2(4000);
begin
PTOOLS2.SHORT_INIT_USER (1403);
  o_error := null;
  --��������� XML-���������
  v_XMLmsg := SMGOZ_EXCHANGE_LOCAL.SEND_DOCUMENT_REQUEST_LOCAL( 256457565,200,'ToControl',mbfilID,o_error);
  dbms_output.put_line('v_XMLmsg = '||v_XMLmsg);
  dbms_output.put_line('o_error = '||o_error);
end;

/

-- ��������� �� ������� �� ������ ����������
declare
  v_XMLmsg         number;
  o_error         varchar2(100);
begin
PTOOLS2.SHORT_INIT_USER (1403);
for dd in (select * from documents where reference in (select num1 from zyx_store where oper = 'SMGOZ' and tbl = 'TMP')
and folder =5000 and status = 20 and reference <> 257298125)
loop
  o_error := null;
  --��������� XML-���������
  v_XMLmsg := SMGOZ_EXCHANGE_LOCAL.SEND_DOCUMENT_REQUEST_LOCAL( dd.reference,dd.branch,'ToControl',mbfilID,o_error);
  if v_XMLmsg is not null then
    dbms_output.put_line('ref='||dd.reference||' '||v_XMLmsg);
  end if;
  if o_error is not null then
    dbms_output.put_line('ref='||dd.reference||' '||o_error);
  end if;    
end loop;  
end;
/
--������ �� ������� ������ � ������� OT_CABS_ACCSTAT_GOZ_REQ
--�������� ����� �� ������ (������� �� ���� �����)
  select 
  smgoz_exchange_accs_local.get_info_for_accstat(
  xmlelement("root",
            xmlelement("multi", 0),
            xmlelement("filial", 200),
            xmlelement("name", 'mbank.smgoz_exchange_accs_local.get_info_for_accstat'),
            xmlelement("params",
            xmlelement("DINFODATE", '2019-10-14'),
            xmlelement("SACC_NUMBER", '40706810815000002089'))
             ).getclobval()
)
  from dual;
  
/


--�������� �����, ������� ������� ��������� � ����
declare

    v_last_send_msg  mbank.goz_message_log%rowtype;
    v_goz_log_domain varchar2(30) := mbank.SMGOZ_EXCHANGE_LOG.SEND_SMGOZ_ACCOUNT_REQUEST;
    v_error          varchar2(2000);
    v_XMLmsg         CLOB;
    v_HASH           varchar2(32);
    v_URL            varchar2(2000);
    v_qid            varchar2(50);
    v_qname          varchar2(30);
    v_qmsgid         number;
    v_qmsgerr        varchar2(4000);
    
    v_xml xmltype;
  v_AnswStat xmltype;
p_ret clob;
p_err varchar2(2000);
p_req clob ;



  SMGOZ_SERVICE_NAME constant varchar2(5) := 'SMGOZ';
  SMGOZ_QUEUE_NAME   constant varchar2(20) := 'SMGOZ_MB_MQ';

  stat_goz       constant number        := 5000;
  v_qname_out    constant varchar2(128) := 'SMGOZ_MB_MQ'; -- ��������� �������
  v_qname_in     constant varchar2(128) := 'SMGOZ_MQ_MB'; -- �������� �������
  v_sub_type_cli constant varchar2(100) := 'EID';
  v_sub_type_acc constant varchar2(100) := 'ACCOUNT';
  C_SERVICE_TAG_NAME constant varchar2(2000) := 'C_SERVICE_TAG_NAME' ; -- ������������ ������������ ����

  -- ���������� ���. ��������� ��������� ������ (��� ����������, ������������� �� ���� ��������� ���������)
  v_guides       constant number := 12399;

  TYPE T_FILID IS TABLE OF number; -- ��� �������� ID ��������


function EXTRACT_XML(v_xml in xmltype, v_tag in varchar2) return varchar2 is
  rez varchar2(2000) := null;
begin
  if v_xml.EXISTSNODE('//' || v_tag) = 1 then
    if v_xml.EXTRACT('//' || v_tag || '/text()') is null then
      rez := null;
    else
      rez := v_xml.EXTRACT('//' || v_tag ||'/text()').GETSTRINGVAL();
    end if;
  end if;

  return rez;
end EXTRACT_XML;

function GET_ACCSTAT_RESPONSE(p_id in number, p_req in clob, p_error out varchar2)
  return clob
is
  c_my_name constant varchar2(30) := '[GET_ACCSTAT_RESPONSE]:' ;
  v_xml xmltype;

  v_SCORRELATIONID varchar2(200);
  v_NACC_ID varchar2(30);
  v_SACC_NUMBER varchar2(25);
  v_DINFODATE varchar2(20);

  v_ReqForWeb clob;
  v_AnswStat xmltype;
  v_Answ clob;
  v_SERROR varchar2(4000);
  v_SERROR_xml xmltype;
  v_filid number;
  v_Ret number;
  v_RespID clob; --id �������
  p_TryCnt number := 60; --���-�� ���������� ��������� ������
  p_NoRes number := 1;
begin
  -- ��������� ������
  v_xml  := xmltype(p_req);
  v_SCORRELATIONID := extract_xml(v_xml, 'SMESSAGEID');
  v_NACC_ID := extract_xml(v_xml, 'NACC_ID');
  v_DINFODATE := extract_xml(v_xml, 'DINFODATE'); -- !!!�� ��������������� ��� WEB
  v_DINFODATE := substr(v_DINFODATE,1,10); -- ��������� ������ ����
  v_SACC_NUMBER := extract_xml(v_xml, 'SACC_NUMBER');

  -- ��������� ������ �����
  v_filid := eid.p_eid_tools_account.get_firma_account_filial(v_SACC_NUMBER);
--  v_filid := 200;

  -- ��������� ��������� �������, ��� ���������� ������ ����� ����� ������
  select xmlelement("root",
            xmlelement("multi", 0),
            xmlelement("filial", v_filid),
            xmlelement("name", 'mbank.smgoz_exchange_accs_local.get_info_for_accstat'),
            xmlelement("params",
            xmlelement("DINFODATE", v_DINFODATE),
            xmlelement("SACC_NUMBER", v_SACC_NUMBER))
             ).getclobval()
    into v_ReqForWeb
  from dual;

  -- �������� ���� ������, ���� ������
  v_Ret := 1;

v_Answ := '
<C_SERVICE_TAG_NAME><RECDEPOSITS>
 <OT_DEPOSIT_INFOGOZ>
  <NDEAL_ID>13813300200150</NDEAL_ID>
  <DTOPENDATE>2019-09-23</DTOPENDATE>
  <DTCLOSEDATE>2019-09-30</DTCLOSEDATE>
  <NSUM>8270000000</NSUM>
  <NSUMRETURNED>8270000000</NSUMRETURNED>
  <SRATEDESCRIPTION>4.35</SRATEDESCRIPTION>
  <NRATE>4.35</NRATE>
  <NPROFIT>6899219</NPROFIT>
  <NPROFITVALUE>6899219</NPROFITVALUE>
  <DTLASTMODIFIED>2019-09-30</DTLASTMODIFIED>
  <SOPS>
   <C_SERVICE_TAG_NAME>
  <OT_SOP>
    <NSOP>2546875750000200</NSOP>
  </OT_SOP>
</C_SERVICE_TAG_NAME>
  </SOPS>
 </OT_DEPOSIT_INFOGOZ>
 <OT_DEPOSIT_INFOGOZ>
  <NDEAL_ID>13858320200150</NDEAL_ID>
  <DTOPENDATE>2019-09-30</DTOPENDATE>
  <DTCLOSEDATE>2019-10-07</DTCLOSEDATE>
  <NSUM>8000000000</NSUM>
  <NSUMRETURNED>8000000000</NSUMRETURNED>
  <SRATEDESCRIPTION>4.5</SRATEDESCRIPTION>
  <NRATE>4.5</NRATE>
  <NPROFIT>6904110</NPROFIT>
  <NPROFITVALUE>6904110</NPROFITVALUE>
  <DTLASTMODIFIED>2019-10-07</DTLASTMODIFIED>
  <SOPS>
   <C_SERVICE_TAG_NAME>
  <OT_SOP>
    <NSOP>2554489850000200</NSOP>
  </OT_SOP>
</C_SERVICE_TAG_NAME>
  </SOPS>
 </OT_DEPOSIT_INFOGOZ>
 <OT_DEPOSIT_INFOGOZ>
  <NDEAL_ID>13903040200150</NDEAL_ID>
  <DTOPENDATE>2019-10-07</DTOPENDATE>
  <DTCLOSEDATE>2019-10-10</DTCLOSEDATE>
  <NSUM>8100000000</NSUM>
  <NSUMRETURNED>8100000000</NSUMRETURNED>
  <SRATEDESCRIPTION>4.42</SRATEDESCRIPTION>
  <NRATE>4.42</NRATE>
  <NPROFIT>2942630</NPROFIT>
  <NPROFITVALUE>2942630</NPROFITVALUE>
  <DTLASTMODIFIED>2019-10-10</DTLASTMODIFIED>
  <SOPS>
   <C_SERVICE_TAG_NAME>
  <OT_SOP>
    <NSOP>2561386510000200</NSOP>
  </OT_SOP>
</C_SERVICE_TAG_NAME>
  </SOPS>
 </OT_DEPOSIT_INFOGOZ>
 <OT_DEPOSIT_INFOGOZ>
  <NDEAL_ID>13925610200150</NDEAL_ID>
  <DTOPENDATE>2019-10-10</DTOPENDATE>
  <DTCLOSEDATE>2019-10-14</DTCLOSEDATE>
  <NSUM>7630000000</NSUM>
  <NSUMRETURNED>7630000000</NSUMRETURNED>
  <SRATEDESCRIPTION>4.29</SRATEDESCRIPTION>
  <NRATE>4.29</NRATE>
  <NPROFIT>3587145</NPROFIT>
  <NPROFITVALUE>3587145</NPROFITVALUE>
  <DTLASTMODIFIED>2019-10-14</DTLASTMODIFIED>
  <SOPS>
   <C_SERVICE_TAG_NAME>
  <OT_SOP>
    <NSOP>2565329310000200</NSOP>
  </OT_SOP>
</C_SERVICE_TAG_NAME>
  </SOPS>
 </OT_DEPOSIT_INFOGOZ>
</RECDEPOSITS>
<RECLOANS>
 <OT_LOAN_INFOGOZ>
  <NDEAL_ID>11641580000200</NDEAL_ID>
  <DTOPENDATE>2018-05-25</DTOPENDATE>
  <DTCLOSEDATE>2020-05-24</DTCLOSEDATE>
  <SNUM>24/18</SNUM>
  <NSUM>12500000000</NSUM>
  <SRATEDESCRIPTION>0</SRATEDESCRIPTION>
  <PAYMENTS_DETAILS>
   <C_SERVICE_TAG_NAME>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>26290400</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1456422720200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>29172662</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1285885990200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>658052372</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1195158370200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>123912152</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1158411260200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>27889789</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1192022790200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>9512387</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1189447340200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>55654861</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1155265310200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>24782268</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1188468460200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>234758802</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1232565560200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>18360000</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-09-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2112217360200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>19417202</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1153053500200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>158557124</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1184876050200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>38677800</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-09-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2108084960200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>5393493</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1150341480200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>105916921</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1183729980200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>516173219</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1224875280200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>197043134</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1226042600200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>44649897</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1149019510200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>33723435</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1182443530200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>7964607</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1181395120200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>10924900</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1222045870200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>20220400</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2104068940200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>66586260</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1146933610200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>175916306</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1145419020200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>26445636</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1104322440200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>9248279</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1219256780200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>64740567</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1142662070200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>13631145</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1144080920200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>8140300</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2100776320200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>6510000</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2101787420200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>45034244</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-22</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1216975300200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>448949544</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1141261900200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>33980550</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1138666680200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>65710400</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1179840170200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>2863068</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-01</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1213431030200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>26883400</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1211472710200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>71385269</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1136014610200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>14493591</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2096629730200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>12170000</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2093029250200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>1974086</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1210186750200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>41965197</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1177465470200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>5062300</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1176131520200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>12.3</NRATE>
    <NRECEIVED>93343366</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1208715650200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>25656157</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1174984130200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>307602010</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2091358990200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>12.3</NRATE>
    <NRECEIVED>79666619</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1204976050200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>29282079</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1172035880200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>153568000</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1170709900200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>19579058</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1167956510200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>7185732</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2086268900200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>463346352</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-05-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1165836490200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>77200726</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1201139040200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>26297466</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1202256040200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>24627527</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1162750780200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>48699600</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-07-31</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1923861420200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>8543322</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-08-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2083610760200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>284289036</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1196537260200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>77439700</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-06-30</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>1198092650200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>20817226</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-09-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2169392190200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
  <OT_PAYMENT_DETAILSGOZ>
    <NRATE>11.5</NRATE>
    <NRECEIVED>249000831</NRECEIVED>
    <NRETURNED>0</NRETURNED>
    <NTOLL>0</NTOLL>
    <NTOLLVALUE>0</NTOLLVALUE>
    <DTLASTMODIFIED>2019-09-20</DTLASTMODIFIED>
    <SOPS>
      <C_SERVICE_TAG_NAME>
        <OT_SOP>
          <NSOP>2380037240200150</NSOP>
        </OT_SOP>
      </C_SERVICE_TAG_NAME>
    </SOPS>
  </OT_PAYMENT_DETAILSGOZ>
</C_SERVICE_TAG_NAME>
  </PAYMENTS_DETAILS>
  <DTLASTMODIFIED>2019-10-14</DTLASTMODIFIED>
 </OT_LOAN_INFOGOZ>
</RECLOANS>
</C_SERVICE_TAG_NAME>
';




  begin
    v_AnswStat := XMLType(v_Answ);
    if v_Ret = 1 then
      v_SERROR := extract_xml(v_AnswStat, 'error');
    else
      v_SERROR := extract_xml(v_AnswStat, 'ERROR');
    end if;
    if (v_SERROR is NOT NULL) then
      v_AnswStat := NULL;
      v_SERROR :=  '������: '||v_filid||', ������ ������:'||v_SERROR;
    end if;
    exception when others then
        v_SERROR := c_my_name||'������ XML �������������� ��� ������������ ������.';
  end;


  -- ��������� �������� �������� ���������
  v_SERROR_xml := xmltype('<SERROR_MSG>'||v_SERROR||'</SERROR_MSG>');

  select
      xmlelement("OT_CABS_ACCSTAT_GOZ_RES",
      case when v_SERROR is not null then
         v_SERROR_xml
      end,
      xmlelement("SMESSAGEID",to_char(p_id)), -- id �������
      xmlelement("NACC_ID", v_NACC_ID), -- ��������� ����� �� �������
      xmlelement("SCORRELATIONID", v_SCORRELATIONID), -- id ��������� ���������
      xmlelement("SACC_NUMBER", v_SACC_NUMBER), -- ����� �����
      xmlelement("DINFODATE", (v_DINFODATE||'T23:59:00')), -- ���� �� ������� + �����
      deletexml(v_AnswStat,'//*[not(text())][not(*)]') ) -- ������� ������ ����
  into v_xml from dual;


  -- ������� quote � �.�.
  v_Answ := dbms_xmlgen.convert(v_xml.getclobval(), dbms_xmlgen.ENTITY_DECODE);

  -- ������ ���. ����, ������� ������������� ��� ��������� �����������
  v_Answ := replace(v_Answ, '<' ||C_SERVICE_TAG_NAME||'>', '');
  v_Answ := replace(v_Answ, '</'||C_SERVICE_TAG_NAME||'>', '');
  v_Answ := replace(v_Answ, '<' ||C_SERVICE_TAG_NAME||'/>', '');

  -- ������� ������ ������ � ������ ��������
  select
    xmlserialize(
                     CONTENT XMLType(v_Answ)
                     INDENT SIZE=2
                 )
  into v_Answ from dual;

  return v_Answ;

exception when others then
  p_error := c_my_name || SQLERRM ;
  return null;
end GET_ACCSTAT_RESPONSE;

begin
  p_req  := '
<OT_CABS_ACCSTAT_GOZ_REQ>
  <SSUBSYSTEM>SMGOZ</SSUBSYSTEM>
  <NDEPARTMENT>80</NDEPARTMENT>
  <RATRANSPROPS>
    <T_PROPERTY>
      <SNAME>SOURCE_SYSTEM</SNAME>
      <SVALUE>MBANK</SVALUE>
    </T_PROPERTY>
  </RATRANSPROPS>
  <SMESSAGEID>5d88bb9bb46741cf813ec37aec84ac96</SMESSAGEID>
  <NACC_ID>34927460000200</NACC_ID>
  <SACC_NUMBER>40706810015000003024</SACC_NUMBER>
  <DINFODATE>2019-10-14</DINFODATE>
</OT_CABS_ACCSTAT_GOZ_REQ>
';

p_ret := GET_ACCSTAT_RESPONSE(11299020, p_req , p_err); --����� ������ �� id select * from mbank.goz_message_log 


--dbms_output.put_line(p_ret);

          v_qname := mbank.PKG_INTGR_QUEUE.get_service_queue(SMGOZ_SERVICE_NAME);
          v_URL   := mbank.PKG_INTGR_QUEUE.get_service_url(SMGOZ_SERVICE_NAME);
          v_qid   := 'MB_' || SMGOZ_SERVICE_NAME || to_char(11299020);
          mbank.PKG_INTGR_QUEUE.put_message(p_queue    => v_qname,
                                      p_qid      => v_qid,
                                      p_msg_body => p_ret,
                                      p_url      => v_URL,
                                      p_ask_id   => null,
                                      p_eobj_id  => null,
                                      p_queue_id => v_qmsgid,
                                      p_err      => v_qmsgerr);
dbms_output.put_line(v_qmsgerr);

end;
 