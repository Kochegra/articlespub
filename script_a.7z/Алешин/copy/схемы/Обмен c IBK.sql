--�������� ������� ���������� �� ��� (����� ���� IBK_DEF - def_<x> )
--���� ���-�� ������ ���� ������������� ������ OraScktSrv (�/� ������� ����� ��� �������� ����� ����)
--��� �� ��� ������ mbas2n.oso.mmbank.ru, ���� �� RDP, ��� �������� mbas-f<x>.oso.mmbank.ru, ���� ����� RAdmin
--������ � �������� ���� � ������ �.�., ������� �.�., ������� �.�. �������� �.�., ��������� ����� �� 
select count(*) from doc_state1 ds
                    where state_date > sysdate - 0.5 and nvl(not_loaded,0) = 1
                      -- ������� �� �/� �������
and not exists (select null from in_query1 where field_name = 'DOC_TYPE' and upper(value) = 'SALARY_ACCOUNTING_REGISTER' and query_id = ds.query_id)        
      
/                 
select rowid,c.* from config c where name like '%���%'

/
--���������� ������ 
select rowid,ds.* from doc_state1 ds 
                    where 
                    state_date > sysdate - 1/2 and nvl(not_loaded,0) = 1                   
    --                  and nvl(not_loaded,0) = 1
      --                and substr(to_char(query_id),-1) = '7'
                      -- ������� �� �/� �������
and not exists (select null from in_query1 where field_name = 'DOC_TYPE' and upper(value) = 'SALARY_ACCOUNTING_REGISTER' and query_id = ds.query_id)        
--and date_ins < sysdate-9
order by date_ins  
/

select * from in_query1 where 
--value = ('AE50FA3D1A7D4E96B59FC40DB31B2C40')
query_id = 20593278199880
order by query_id,field_name
/
--������ ���� 
------------------------------------------------------------------------------------
select * from documents ds
--update documents d set status = 1000
 where refer_office is not null and type_doc in (167,4215,7077) and trunc(date_create) = '30-dec-2015' and date_create <  to_date('30.12.2015 10:00:00','dd.mm.yyyy hh24:mi:ss') and status = 1000 
--and not exists (select null from journal where docnum > 0 and docnum in (d.reference,d.refer_from,d.related))
--and exists (select /*+INDEX(DISTRIB_FEATURES_PK)*/ null from eid.distrib_features df where value = to_char(d.reference))     
and not exists (select null from doc_state1 where reference = d.reference and branch = d.branch and state = 35)

--1652213612,1652281409  20593231382537

abselect * from users where user_id = 1574065aselect * from documents_ where summa = 282.06 and trunc(date_create) = '22-dec-2015' and status = 1000 and refer_office is not nullvselect * from doc_state1 ds where reference in (2933635512)riselect * from documents where type_doc = 10957 and date_create > sysdate-2

select * from documents
update documents set status = 1000 
where (refer_from,branch_from) in
(select reference,branch from documents_delete where type_doc = 167 and trunc(date_create) = '22-dec-2015')   

select * from doc_state1 ds where
reference = 3768774077
 
doc_id = 9804468394104


update doc_state1 set state_date = sysdate+3/(24*60) 
where  (reference,branch) in 
(select reference,branch from documents_delete where type_doc in (167,4215,7077) and refer_office is not null and trunc(date_create) = '30-dec-2015' and date_create <  to_date('30.12.2015 10:00:00','dd.mm.yyyy hh24:mi:ss') and status = 1000 ) 

--select count(*) from documents_delete where type_doc in (167,4215,7077) and trunc(date_create) = '22-dec-2015' and status = 1000 and refer_office is not null

select * from ibank.doc_state1 ds where reference in (2941017389) and not_loaded is not null
  
20593179355127
     
     select universe.nametype(type_doc),d.* from documents d
 --update documents d set status = 1000     
     where status = 20 and date_work = '30-dec-2015' and type_doc in (7077,167,4215) and date_create < to_date('30.12.2015 10:00:00','dd.mm.yyyy hh24:mi:ss')
and not exists (select null from journal where docnum > 0 and docnum in (d.reference,d.refer_from,d.related))
and not exists (select /*+INDEX(DISTRIB_FEATURES_PK)*/ null from eid.distrib_features df where value = to_char(d.reference))    

    
select d.* from documents_delete d where reference in (1652248139,1652232877) group by status

select d.* from variable_documents d where reference in (2933635512) 

    
select status,count(*) from documents where type_doc = 4355 group by status
     
select * from archive where type_doc = 4355 and date_work > sysdate - 100
/

--���������� �������
select * from in_query1 where --field_name = 'CNN_INN' and upper(value) = 'SALARY_ACCOUNTING_REGISTER' and date_ins >= sysdate-1/2
--instr(value,'Z_0000151280_20180608_') > 0
--and date_ins >= to_date('07.06.2018','dd.mm.yyyy')
/

select * from in_query1 where --field_name = 'DOC_TYPE' and upper(value) = 'SALARY_ACCOUNTING_REGISTER' and date_ins >= sysdate-1/2
instr(value,'20593272044826') > 0
and date_ins >= to_date('12.08.2019','dd.mm.yyyy')
/

select * from in_query1 where query_id in (9804493809227)
order by query_id,field_name
--20593211957780
/
20593263683521
20593263683523
20593263683524
20593263683525
20593263683526
/

select rowid,d.* from doc_state1 d where doc_id in 
(9804368555120) 
/
select * from doc_state1 d where 
query_id in  
(20593229967723
,20593229910692
,20593229993622
,20593229977732
,20593229967722
,20593229964882
,20593229967716
,20593229967724
,20593229892949
,20593229892989
,20593229986039
,20593229977729
,20593229967719
,20593230014439
,20593229977731
,20593229967721
,20593229977730
,20593229967720
,20593229954570
,20593229967718
,20593229967717
,20593229989285
,20593230007556
,20593230055574
)
and exists (select null from in_query1 where query_id = d.query_id)  
/

select rowid,d.* from doc_state1 d
--update doc_state1 set not_loaded = 3
where query_id in
--(select query_id from in_query1 where field_name = 'DOC_TYPE' and upper(value) = 'SALARY_ACCOUNTING_REGISTER' and date_ins < sysdate-1)
(
20593233709284
)
and nvl(not_loaded,0) = 1
order by state_date
/

select * from unloaded_attachments where pars_status > 1
order by id desc

select * from unloaded_attachments where doc_id = 9804354691351--9804355002152

select * from all_tables where table_name like upper( 'unload%')


Doc_state1_func (Reference, Branch)


select * from cbs_errors 
order by msg_date desc 
/

--����� ����������
47422810200002000077 --��� ��������� ����� 
30232810300002000077 --�� ��

select * from documents where doc_number = '���'



select * from audit_table@NSIBIRSK where reference = 179579553

select * from archive where reference = 2952532401

select * from variable_archive where reference = 2952532657

select * from archive where type_doc in (1,2) and date_work >= '07-jun-2018' 
--and instr(memo,'50012406.RE') > 0
and instr(memo,'D18311E6.RE') > 0

--select * from documents where type_doc = 2 and date_work >= '07-jun-2018' and instr(memo,'50012406.RE') > 0

SELECT * FROM eid.eid_firma_products p WHERE p.account = '30232810600520340566'

SELECT * FROM eid.eid_firma_variable fv WHERE fv.eid in (1030,106912,1031) AND fv.type LIKE 'SZP%'

SELECT * FROM eid.eid_firma fv WHERE inn = '2434000335'


SELECT p.eid FROM eid.eid_firma_products p WHERE p.account = '30232810700600011344' AND p.type_doc = 3601 AND p.status != 60 AND rownum = 1



select * from SALARY_REESTR where reference = 4550896