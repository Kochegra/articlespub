--�� ������������ ������
select * from mbank.trade_44fz_msg where date_out in (to_date('01.01.1900','dd.mm.yyyy'),to_date('01.01.2000','dd.mm.yyyy'))


select count(*),min(date_create),max(date_create) from mbank.trade_44fz_msg where date_out in (to_date('01.01.1900','dd.mm.yyyy'),to_date('01.01.2000','dd.mm.yyyy'))


select to_char(date_create,'dd.mm.yyyy hh24:mi'),count(*),min(date_create),max(date_create) from trade_44fz_msg where date_out in (to_date('01.01.1900','dd.mm.yyyy'),to_date('01.01.2000','dd.mm.yyyy'))
group by to_char(date_create,'dd.mm.yyyy hh24:mi')
--group by  MSGID_OUT
--order by count(*) desc


select * from trade_44fz_req where 
--reference = 6949880
msgid = '15183b04a6604381b77162bbb6328b55' 

select * from clob_bill_params where gid = '09_FF3E511158A147449A002FE1ED0268AB'

select * from mbank.trade_44fz_msg where reference = 25336943
/
select * from eid.eid_firma where eid = 18096005
/
select * from eid.eid_account where code = '40817810802160106726'
/

--������� ������
select mbank.ptools5.as_num(mbank.pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'AMOUNT')) amount,
       mbank.pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'ROLLBACK_ACTION') rollback_action,
       rq.date_in, rq.date_in_done, ms.err_msg,
       rq.*, ms.*, 
       '(' || rq.reference || ',' || rq.branch || '),',
       vt.value BUSINESS_ACK_ID, rq.rowid
  from mbank.trade_44fz_req rq
    left join mbank.trade_44fz_msg ms on ms.reference = rq.reference and ms.branch = rq.branch
    left join mbank.variable_trade_44fz_req vt on vt.reference = rq.reference and vt.branch = rq.branch and vt.name = 'BUSINESS_ACK_ID' --and vt.value is not null
where 1=1
--and rq.date_work >= to_date('09.01.2019', 'dd.mm.yyyy') 
--and rq.entity_key like '44FZ_UNLO%'
--and rq.entity_key not in ('_44FZ_NOT_ACC_OPEN_SBER', '_44FZ_NOT_ACC_OPEN_SBER_ANS', '_44FZ_RESPONSE_SBER','_44FZ_OPEN_ACCOUNT','44FZ_ERROR_SERVICE_SBER')
--and rq.entity_key in ('44FZ_REC_FEES_SBER', '44FZ_PAY_BUDG_SBER') --and ms.err_code > 1
--and rq.entity_key in ('_44FZ_REQ_ACCES_SBER', '_44FZ_CLIENT_STATUS_SBER', '44FZ_LOCK_AMOUNT_SBER', '44FZ_UNLOCK_AMOUNT_SBER') --and ms.err_code >= 1
--and ptools5.as_num(pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'AMOUNT')) = 58175.42
--and rq.entity_key in ('44FZ_RESPONSE_SBER') and rq.err_code = 999
--and pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'ROLLBACK_ACTION') = '1'
--and rq.reference in (729107)
--and rq.eobj_id = 77327223
--and vt.value is null
and (rq.reference, rq.branch) in (
  select ms.reference, ms.branch
    from mbank.trade_44fz_msg ms
   where ms.date_out in (to_date('01.01.1900', 'dd.mm.yyyy'), to_date('01.01.2000', 'dd.mm.yyyy'))   
)
--and rq.payers_eid = '3558727'
--and rq.msgid_search in (upper('89C3010393FC5AB200D5A9B505619024'), upper(''), upper(''),upper(''), upper(''))
--and rq.payers_acc = '40602810750000000106' -- 40802810350000000034 40702810750000001898
--and rq.payers_inn = '7705242611' --504508242579 7727555833
--and rq.status = 80
--and rq.date_in >= trunc(sysdate)
--and rq.trade_id not in ('ETP_GPB', 'ETP_ASTGOZ', 'ETP_AVK', 'ETP_TEKTORG')
--and rq.trade_id in ('ETP_GPB')
--and rq.trade_id in ('ETP_ASTGOZ')
--and rq.trade_id in ('ETP_AVK')
--and rq.trade_id in ('ETP_TEKTORG')
--and rq.trade_id in ('ETP_EETP')
--and rq.trade_id in ('ETP_ASTGOZ')
--and rq.trade_id in ('ETP_SBAST')
--and rq.trade_id in ('ETP_RTS')
--and rq.trade_id in ('ETP_RAD')
--and rq.tranid = '000-55370015'
--and rq.trade_id in ('EETP_OPEN_ACCOUNT')
--and rq.status != 50 and rq.entity_key not in ('44FZ_OPEN_ACCOUNT', '44FZ_UNKNOWN', '44FZ_ERROR_SERVICE_SBER')
--and ms.err_code = 1
--and ms.msgid_out = upper('AB1C6BE436E14B16A20D816BB54C769B')
--and ms.date_out in (to_date('01.01.1900', 'dd.mm.yyyy'), to_date('01.01.2000', 'dd.mm.yyyy'))
--and ms.send_msg is not null
--and ms.err_msg is not null
--and ms.err_code >= 1
--and pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'ROLLBACK_ACTION') = '1'
--and ptools5.as_num(pkg_entity_object_attr.GET_STR_ATTR_VALUE(rq.branch, rq.reference, rq.entity_key, 'AMOUNT')) = 16084.10
order by rq.reference desc, ms.date_out desc

/


select * from collector_contracts where reference = 563504 and branch = 405

select * from rest_contracts where reference = 563504 and branch = 405