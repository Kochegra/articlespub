--����� � ���

--1 �������� �� MAIN ��� �������� �� ������
--create table zyx_upp as
select mbfilid fil
,to_char(substr(message,instr(message,'<MessageId>')+11
                      ,instr(message,'</MessageId>')-instr(message,'<MessageId>')-11)) mes
, -1 id
--,t.*
 from tbl_queue_deiltp_mb_mq t where 
mod_dt >= to_date('31.07.2019 13','dd.mm.yyyy hh24') and mod_dt <= to_date('31.07.2019 17','dd.mm.yyyy hh24')
and state = 3
/

--2 �������� �� �� ������ FIL1
--create table zyx_upp as 
select * from zyx_upp@etalon
/

--3  �������� �� �������� ��� �������� �� ������
--create table zyx_upp as
--insert into zyx_upp
select mbfilid fil
,to_char(substr(messagerequest,instr(messagerequest,'<MessageId>')+11
                      ,instr(messagerequest,'</MessageId>')-instr(messagerequest,'<MessageId>')-11)) mes
 ,id                    
--,t.* 
from TBL_DEILT_MESSAGE t where createmsgdate >= to_date('31.07.2019 15:30','dd.mm.yyyy hh24:mi') 
and createmsgdate <= to_date('31.07.2019 18:30','dd.mm.yyyy hh24:mi')
--and DOCREFERENCE = 85484329 
--85484714

/
select * from zyx_upp

--drop table zyx_upp
/

select * from zyx_upp where mes not in (select mes from zyx_upp@etalon)
and id in (2208583,2208610,2208974)
/

       DECLARE
          vInsReq CLOB := '<root><name>mbank.DEILT_EXCHANGE.Send_DEILTP_REQ_WEB</name><filial>'||to_char(MBgoID) ||'</filial></root>';
          r number; -- 0 - ������, 1 - ������
          vbXML BLOB;
       BEGIN
          for rr in (select * from TBL_DEILT_MESSAGE where id in (2130995) )
          loop 
            begin
              dbms_lob.createtemporary(vbXML,true);
              vbXML := clob_to_blob(rr.messagerequest);
              
              r := p_webxml_client.SendBLOBRequest(BLOBRequest => vbXML, Clobresponse => vInsReq);
              --r:= p_webxml_client.SendXMLRequest(CLOBRequest => rr.messagerequest, Clobresponse => vInsReq);
              dbms_lob.freetemporary(vbXML);
              dbms_output.put_line('id = '||rr.id||' r = '||r||' vInsReq = '||vInsReq);                          
            exception when OTHERS then
              dbms_output.put_line('id = '||rr.id||' sql = '||SQLERRM);
              dbms_lob.freetemporary(vbXML);
            end;    
          end loop;  
        END;
/
      

--��������� �� MAIN
--create table zyx_upp as
select mbfilid fil
,to_char(substr(message,instr(message,'<MessageId>')+11
                      ,instr(message,'</MessageId>')-instr(message,'<MessageId>')-11)) mes
, -1 id
,t.*
 from tbl_queue_deiltp_mb_mq t where 1=1 
--mod_dt >= to_date('31.07.2019 13','dd.mm.yyyy hh24') and mod_dt <= to_date('31.07.2019 17','dd.mm.yyyy hh24') and state = 3
--instr(message,'8EFAAD6F-B5FD-00C4-E053-0AD00419E9AC') > 0
and mod_dt > sysdate-1/48-- and state = 3
/

--create table zyx_upp as
select mbfilid fil
,to_char(substr(message,instr(message,'<MessageId>')+11
                      ,instr(message,'</MessageId>')-instr(message,'<MessageId>')-11)) mes
, -1 id
,t.*
 from tbl_queue_deiltp_mq_mb t where 1=1 
--mod_dt >= to_date('31.07.2019 13','dd.mm.yyyy hh24') and mod_dt <= to_date('31.07.2019 17','dd.mm.yyyy hh24') and state = 3
--instr(message,'8EFAAD6F-B5FD-00C4-E053-0AD00419E9AC') > 0
and mod_dt > sysdate-1-- and state = 3

/  
deilt_exchange   
     
     select * from archive where reference= 85484329
        
          select * from documents where reference= 85484329
        