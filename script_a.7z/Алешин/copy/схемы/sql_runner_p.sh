#!/bin/bash
# PARAMETERS
# -s --- ORACLE_SID
# -f --- Flag for job_start (1,2,3,4) Default 1
# -m --- max processes default 100
# -t --- time interval in seconds default 15
declare -rx     SCRIPT=${0##*/}
declare         gf_syslib_module
declare         gf_admin_module=/var/opt/oracle/admin.cfg
declare         gf_profile_module
declare -rx     OPTSTRING=":s:f:m:t:l:"
declare         gc_flag=1
declare         LOG_FILE_NAME=$SCRIPT".log"
declare  	gc_proc_number=100
declare		gc_last_start
declare 	gc_interval=15
declare		gc_shed_task
declare         LOCK_FILE=/tmp/${SCRIPT}_${gc_flag}".lock"
declare		gc_os=$(uname)
declare		gf_syslib_module=/usr/local/sbin/syslib.lib
declare		LOG_FILE_NAME=${SCRIPT}.log


if [ ! -f $gf_syslib_module ]; then
        echo "$(basename $gf_syslib_module) is not found"
        exit $SYS_INTERRUPT_CODE
fi

if [ ! -f $gf_admin_module ]; then
        echo "$(basename $gf_admin_module) is not found"
        exit $SYS_INTERRUPT_CODE
fi



source $gf_syslib_module
source $gf_admin_module

while getopts  $OPTSTRING opt 
do
        case $opt in 
	s) export gc_sid=$OPTARG ;;
	f) gc_flag=$OPTARG ;;
	m) gc_proc_number=$OPTARG ;;
	t) gc_interval=$OPTARG ;;
	l) LOCK_FILE=$OPTARG ;;
	esac
done

declare 	gc_spool_file=/tmp/_sqr_${gc_flag}_${gc_sid}_$(date +%m%d%H%M%S).spool
declare         LOG_FILE_NAME=${SCRIPT}_${gc_sid}.log

get_lock2 $LOCK_FILE 
case $? in
        1)
                write_to_log "The another instance with flag ${gc_flag}  is in working state right now."
                trap - INT TERM EXIT
                exit $SYS_INTERRUPT_CODE
                ;;
        2)
                write_to_log "An error occured. The lock file wasnt created due to some errors."
                exit $SYS_INTERRUPT_CODE
                ;;
esac

set_oraenv $gc_sid
source $gf_admin_module
gc_last_start=$(date '+%s')
gc_shed_flag=$((gc_flag-1))
gc_mbank_passwd=$(eval "echo \${$(echo ${gc_sid}_MBANK_PASSWD})")
gc_mbank_passwd=${gc_mbank_passwd:-$(echo $MBANK_PASSWD)} 
while true
do
	sqlplus <<EOF > /dev/null 2>&1 
	$gc_mbank_passwd
	set feed 1
	set serveroutput on
	spool $gc_spool_file
	declare
	nflag number;
	nproc number;
	shed_str varchar2(10);
	begin
		nproc:=0;
		LOOP 
		  	select count(*) into nproc from v\$session 
			where client_info in ('MBANK-0Shed_LONG P_SHED','MBANK-0Shed_OPER P_SHED') 
		    	;
		  	if (nproc >=$gc_proc_number ) then
				dbms_lock.sleep(1);
		  	else
		  		exit ;
			end if;
		end LOOP;
		shed_str:='TASK_'||'${gc_shed_flag}' ;
		select flag into nFlag from shed_flags where TASK_ID = shed_str;
		If (nFlag = 1) then
			update shed_flags set flag = 0 where TASK_ID = shed_str;
			COMMIT;
			dbms_output.put_line('FLAG_UP');
		else
			dbms_output.put_line('FLAG_DOWN');
		end if;
	end;
/
spool off
EOF
	if (cat $gc_spool_file |grep "ORA-" >/dev/null 2>&1)
	then
		write_to_log "PS/SQL Error. Check $gc_spool_file"
		write_to_log "exit"
		mail_to_adm "sql_runner error. Daemon is down"
		if [ "$gc_os" == "AIX" ]
		then
			send_to_sms "sql_runner error. Daemon is down"
		fi
		exit
	fi
	if (cat $gc_spool_file |awk '{print $1}'|grep FLAG_UP >/dev/null 2>&1) || [ $(($(date '+%s')-$gc_last_start)) -ge $gc_interval ]
	then
		shed_flag=$((gc_flag-1))
		sqlplus <<EOF  >/dev/null 2>&1 &
		$gc_mbank_passwd
		exec p_shed.dispatch($gc_shed_flag) ;
EOF
		gc_last_start=$(date '+%s')
	fi
	if (cat $gc_spool_file |awk '{print $1}'|grep FLAG_UP >/dev/null 2>&1)
	then
		sleep 1
	else
		sleep 	$gc_interval	
	fi
done







