select rowid,e.* from eid.eid_human e where eid = 32671989 --26935380
order by date_modify desc

select rowid,e.* from eid.eid_human_modify e where eid = 29335834
order by date_modify desc

select rowid,e.* from eid.eid_contacts e where eid = 32671989 --26935380
order by date_modify desc


32671989

--�������� 
select rowid,h.* from EID.EID_DOCUMLIST h where eid = :cl_eid --and search_doc = :cl_doc 

--eid.p_eid_tools.LoadClient --��������� ����� ������ �� �������


26935380, 30087520, 30607026


select *
                  from eid.eid_human_obj_variable ehov
                 where ehov.type = 'FIELDS_2_CHANGE'
                   and ehov.eid = 26935380
                   and ehov.status = 1
                   and not exists (select *
                                     from eid.eid_human
                                    where eid = 26935380
                                      and date_modify > ehov.date_modify)
                                      /

select rowid,h.* from EID.EID_JOIN h where FEATURE_EID = :cl_eid 

select rowid,h.* from EID.EID_JOIN h where FEATURE_EID = :cl_eid

Select * from eid.eid_trusts
/

