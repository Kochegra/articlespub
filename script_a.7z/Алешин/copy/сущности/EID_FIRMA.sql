select * from eid.eid_firma_prospectus s where 1=1 
and eid = 2475078

select rowid,s.* from eid.eid_firma s where 1=1
--and length(okato) > 12 and OKATO = OGRN_NUMBER 
--and eid = 5620655
--and OWNER_MODIFY = '(MDM_VTB-24)'
--and eid in (240343619 )
and inn = '4205296405'


select rowid,s.* from eid.eid_firma_history s where 1=1
--and length(okato) > 12 and OKATO = OGRN_NUMBER 
--and eid = 5620655
--and OWNER_MODIFY = '(MDM_VTB-24)'
and eid in (6191985)

select * from eid.EID_FIRMA_MODIFY s where 1=1 
and eid = 6196055

--and inn = '4401132410'

select * from eid.eid_firma_relation s where 1=1 
and eid in (select eid from eid.eid_firma_prospectus where 1=1)
and date_modify > sysdate-300
and type_col = 'PROSPECTUS_TO_CLIENT' 

--�����������
select * from eid.EID_FIRMA_RELATION s where 1=1 and eid_to = 6196055


select type_col,count(*) from eid.eid_firma_relation s where 1=1 
and eid in (select eid from eid.EID_FIRMA_PROSPECTUS where 1=1)
and date_modify < sysdate-10
--and date_modify < sysdate-15
group by type_col


select rowid,s.* from eid.eid_firma_variable s where eid = 157008 
--and type in ('SUB_BUSSINES','CATEGORY','CLASSIF_PROFIT')
and type like 'SUB_BUSSINES'-- and status =1
order by date_modify


--pkg_CRMVTB_Shed.ImportData; --�������� ��������� �� ���
select * from BALANCE b where b.users = 1403 and b.id = 'LoadFromCRM'
and item = 3619953

SELECT /*+ DRIVING_SITE(c) */ c.* FROM sysdba.MV_BM_CLIENT@CRMEDUVTB c  WHERE c.inn = '7841312071'
 
--��.��.����.��������� �������
SELECT * from guides g WHERE g.type_doc = 6054; 
--��.��.����.������-����
SELECT * FROM guides g WHERE g.type_doc = 6740;
/

--���������� �� �������
select eid,date_modify,type,count(*) from eid.eid_firma_variable where status = 1 and type in 'CATEGORY'--('CLASSIF_PROFIT')--('OKVED','SUB_BUSSINES','CATEGORY')
and eid = 3704943
group by  eid,date_modify,type
having count(*) > 1
order by count(*) desc
/

--����� �������� ���
select INN
--(select min(value) from eid.eid_firma_variable fv where eid = f.eid and status = 1 and type in 'CATEGORY' and date_modify =
--(select max(date_modify) from eid.eid_firma_variable where eid = fv.eid and status = fv.status and type = fv.type)) val
,nvl(FULL_NAME,CLIENT_NAME) "�������� �������"
,'�������' "������� ���"
,'��� �-����' "��� ���"
,eid.p_eid_tools2.get_filial_name(subdepartment) "������"
,EID.p_eid_paramvalues.Get_Param('���_�������',eid.p_eid_tools2.get_filial_id(subdepartment))  "��� �������"
--,f.* 
from eid.eid_firma f where 1=1 and type_client = 1 --eid = 3561740
and (select min(value) from eid.eid_firma_variable fv where eid = f.eid and status = 1 and type in 'CATEGORY' and date_modify =
(select max(date_modify) from eid.eid_firma_variable where eid = fv.eid and status = fv.status and type = fv.type)) = '1'
and rownum < 10000
order by 6
--and exists select 

/

select * from eid.eid_firma_variable fv where eid = 3561740 and status = 1 and type in 'CATEGORY' and date_modify =
(select max(date_modify) from eid.eid_firma_variable where eid = fv.eid and status = fv.status and type = fv.type)

select rowid,e.* from eid.EID_FIRMA_ADDRESS e where status = 6

/

--���������� �����������
begin
 for tt in 
    ( 
    select distinct f.rowid, f.eid, p.refer_client, p.branch_client from eid.eid_firma f, eid.eid_firma_products p where f.eid = p.eid and f.reference <> p.refer_client
 and not exists (select null from eid.eid_firma where reference = p.refer_client and  branch = p.branch_client)
 )
 loop
    update eid.eid_firma set reference = tt.refer_client, branch = tt.branch_client where rowid = tt.rowid;
    commit;
 end loop;
end;
/

select * from  eid.eid_firma f
--update eid.eid_firma f set subdepartment = (select subdepartment from clients where reference = f.reference  and branch = f.branch)
where subdepartment <> (select subdepartment from clients where reference = f.reference  and branch = f.branch)
and subdepartment in (select id from subdepartments start with id = 191 connect by prior id = parent)


select rowid,s.* from eid.eid_firma s  
--update eid.eid_firma s set subdepartment = (select max(subdepartment) from eid.eid_firma_history where eid = s.eid and date_modify < s.date_modify and subdepartment <> s.subdepartment and reference = s.reference)
where 1=1
--and eid in (6191985)
and exists (select null from eid.eid_firma_history where eid = s.eid and date_modify < s.date_modify and subdepartment <> s.subdepartment and reference = s.reference)
and date_modify > sysdate-30 and subdepartment = 191
 
select s.* from eid.eid_firma_history s where 1=1
and eid in (6196055)
union all
select s.* from eid.eid_firma s where 1=1
and eid in (6194423)

--��������� ����, ������������
select rowid,e.* from
--delete 
EID.EID_FIRMA_MANAGER e where eid = 6194423
/

--insert into EID.EID_FIRMA_MANAGER
select EID,DATE_MODIFY,STATUS,OWNER_MODIFY,SUBD_MODIFY,OWNER_DELETE,SUBD_DELETE,DATE_DELETE,MANAGER_TYPE,MANAGER_EID,LAST_NAME,FIRST_NAME,SECOND_NAME,FIO,SEARCH_NAME,BIRTHDAY,PLACE_BIRTH,DOC_TYPE,DOC_SERIA,DOC_NUMBER,DOC_ATTR,DOC_DATE,SEARCH_DOC,PHONE,MANAGER_ORDER,ID_RECORD,DATE_GET_JOB,DATE_LEAVE,E_MAIL,CMNT,POSSIBLE_TO_EDIT,KEY_EMPLOYEE,MANAGER_TYPE_HAND,MANAGER_TYPE_NAME,DOP_EMPLOYEE,CONTACT_EMPLOYEE,BIRTHDAY_SHORT,STATUS_LPR,PHONE_PREFIX,PHONE_CODE,PHONE_VALUE,PHONE_NORMAL,UCHRED_EMPLOYEE,BENEFIT_EMPLOYEE,DELEGATE_EMPLOYEE,MANAGINGAUTH_EMPLOYEE,EID_TYPE,BENEFIT_PROCENT,PARAMS,PROFIT_EMPLOYEE,DELEGATE_CATEGORY,DELEGATE_RIGHT,DELEGATE_STATUS,MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT_TEXT,BENEFIT_REASON,PROFIT_REASON 
 from EID.EID_FIRMA_MANAGER_HISTORY  where eid = 6194423
 and rowid = 'AAYf3CAOyAAEZYWAAD'
/

select rowid, h.* from EID.EID_FIRMA_MANAGER_HISTORY h  where eid = 1531355
/

select rowid, h.* from EID.EID_FIRMA_MANAGER_MODIFY h  where eid = 6196055
/

select * from EID.EID_FIRMA_MANAGER _DSA h where date_modify > sysdate-1
/

select * from dba_tab_columns where table_name = 'EID_FIRMA_MANAGER_HISTORY'
--'EID_FIRMA_MANAGER'
/

--�������� � ������
declare
  sRes varchar2(2000) := null;
  nFilialReal number;
  sDopParam varchar2(2000) := null;
begin
  for x1 in (select distinct f.eid,f.subdepartment,f.reference,f.branch from eid.eid_firma f 
               where f.reference is not null and f.eid = :eid )
  loop
    nFilialReal := eid.p_eid_tools2.get_filial_id(x1.subdepartment);
    sDopParam:= NULL;
    mbank.ptools5.set_param(sDopParam, 'ref1', x1.reference);
    mbank.ptools5.set_param(sDopParam, 'br1', x1.branch);
    mbank.ptools5.set_param(sDopParam, 'cikl', 1);

    sRes := mbank.ptools_eid_to_filial.EXEC_EXPORT_RECORD(RecID => -1, TblName => 'EID.EID_FIRMA', nTekFilial => nFilialReal,
                                                            ch_refer => x1.eid, ch_branch => 0, ch_owner_modify => 'Admin',
                                                            ch_owner_modify_id => 1403,
                                                            ch_subd_modify => mbgoid,
                                                            ch_dop_param => sDopParam);
    if sRes is not null then
      raise_application_error (-20001,'������ ������������� ��:'||x1.eid||' '||sRes);
    end if;
    commit;
  end loop;
end;


--���������� ��������� �������� ��� ��������� ������
select (select value from (select * from eid.eid_firma_variable fv where fv.status = 1 and fv.date_exec < sysdate order by date_exec desc, priority desc, date_modify desc, fv.id desc) t
          where rownum = 1 and t.eid = a.eid and t.type = upper(a.type) ) val,
  a.* from EID.EID_FIRMA_VARIABLE A
--update EID.EID_FIRMA_VARIABLE A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
where 1=1
and eid in (3794977) --and type = 'PROBLEMS'
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_VARIABLE where eid = a.eid and type = a.type and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and value is not null
and not exists (select null from (
                   select * from eid.eid_firma_variable fv where fv.status = 1 and fv.date_exec < sysdate                   
                   order by date_exec desc, priority desc, date_modify desc, fv.id desc
                  ) t where rownum = 1 and t.eid = a.eid and t.type = upper(a.type) )
--and DATE_DELETE > sysdate-1 and rownum < 100                                     
/

select * from EID.EID_FIRMA_CONTACTS where eid = 97693
order by date_modify                  
/

--��������
select  
(select contact from (
                   select * from eid.EID_FIRMA_CONTACTS fv where fv.status = 1                   
                   order by priority desc, date_modify desc
                  ) t where rownum = 1 and t.eid = a.eid and t.type_contact = a.type_contact) val,
a.* from EID.EID_FIRMA_CONTACTS A
--update EID.EID_FIRMA_CONTACTS A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
where 1=1
and eid in (3794977) 
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_CONTACTS where eid = a.eid and type_contact = a.type_contact and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and CONTACT is not null
and not exists (select null from (select * from eid.EID_FIRMA_CONTACTS fv where fv.status = 1 order by priority desc, date_modify desc) t 
                  where rownum = 1 and t.eid = a.eid and t.type_contact = a.type_contact )
--and DATE_DELETE > sysdate-1 and rownum < 100                    
/

--������
select  
(select ADDRESS from (select * from eid.EID_FIRMA_ADDRESS fv where fv.status = 1                   
                       order by date_modify desc
                      ) t where rownum = 1 and t.eid = a.eid and t.type_address = a.type_address) val,
a.* from EID.EID_FIRMA_ADDRESS A
--update EID.EID_FIRMA_CONTACTS A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
where 1=1
and eid in (3794977) 
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_ADDRESS where eid = a.eid and type_address = a.type_address and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and ADDRESS is not null
and not exists (select null from (select * from eid.EID_FIRMA_ADDRESS fv where fv.status = 1 order by date_modify desc) t 
                  where rownum = 1 and t.eid = a.eid and  t.type_address = a.type_address )
--and DATE_DELETE > sysdate-1 and rownum < 100     
/

--������������
 select (select nvl(t.MANAGER_ORDER,MANAGER_ORDER)||','||KEY_EMPLOYEE||','||nvl(t.MANAGER_TYPE_NAME,MANAGER_TYPE_NAME)||','||nvl(t.MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT)||','||nvl(t.MANAGINGAUTH_INPUT_TEXT,MANAGINGAUTH_INPUT_TEXT)||','||nvl(t.PARAMS,PARAMS) from eid.eid_firma_manager_history tt where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1
                 and not exists (select null from EID.EID_FIRMA_MANAGER_HISTORY where eid = tt.eid and manager_eid = tt.manager_eid 
                                and date_modify > tt.date_modify and owner_modify not like '%(MDM_VTB-24)')
                                and key_employee = 1 and rownum = 1) val
 ,t.*
 from EID.EID_FIRMA_MANAGER t
 /* update EID.EID_FIRMA_MANAGER t set (MANAGER_ORDER,KEY_EMPLOYEE,MANAGER_TYPE_NAME,MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT_TEXT,PARAMS,BENEFIT_PROCENT,BENEFIT_REASON) = 
  (select nvl(t.MANAGER_ORDER,MANAGER_ORDER),KEY_EMPLOYEE,nvl(t.MANAGER_TYPE_NAME,MANAGER_TYPE_NAME),nvl(t.MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT),nvl(t.MANAGINGAUTH_INPUT_TEXT,MANAGINGAUTH_INPUT_TEXT)
         ,nvl(t.PARAMS,PARAMS),nvl(t.BENEFIT_PROCENT,BENEFIT_PROCENT),nvl(t.BENEFIT_REASON,BENEFIT_REASON)
           from eid.eid_firma_manager_history tt where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1
                 and not exists (select null from EID.EID_FIRMA_MANAGER_HISTORY where eid = tt.eid and manager_eid = tt.manager_eid and date_modify > tt.date_modify and owner_modify not like '%(MDM_VTB-24)')
                                and key_employee = 1 and rownum = 1)
--*/                                 
 where 1=1
 and eid = 3794977
 and owner_modify like '%(MDM_VTB-24)'
 and KEY_EMPLOYEE = 0 
 and exists (select null from eid.eid_firma_manager_history tt where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1 and date_modify < t.date_modify
                 and not exists (select null from EID.EID_FIRMA_MANAGER_HISTORY where eid = tt.eid and manager_eid = tt.manager_eid 
                                and date_modify > tt.date_modify and owner_modify not like '%(MDM_VTB-24)')
                                and key_employee = 1
            )     
 /
 
 --������ ���������� ������������� (~2 min)    
 select t.* from EID.eid_firma_manager_history t
 where 1=1
 --and eid = 6192071
 and owner_modify like '%(MDM_VTB-24)'
 and KEY_EMPLOYEE = 0
 and insert_date = (select max(insert_date) from eid.eid_firma_manager_history where eid = t.eid and manager_eid = t.manager_eid)  
 and exists (
             select null from eid.eid_firma_manager_history where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1 and owner_modify not like '%(MDM_VTB-24)'
                    and insert_date = (select max(insert_date) from eid.eid_firma_manager_history where eid = t.eid and manager_eid = t.manager_eid and date_modify < t.date_modify)  
            )
 and DATE_MODIFY >= sysdate-2               
 and rownum < 100
 /
 
--��������� ���������� ��� ��������� ������
select (select value from (select * from eid.eid_firma_variable fv where fv.status = 1 and fv.date_exec < sysdate order by date_exec desc, priority desc, date_modify desc, fv.id desc) t
          where rownum = 1 and t.eid = a.eid and t.type = upper(a.type) ) val,
  a.* from EID.EID_FIRMA_VARIABLE A
where 1=1
--and eid in (6194423) --and type = 'PROBLEMS'
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_VARIABLE where eid = a.eid and type = a.type and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and value is not null
and not exists (select null from (
                   select * from eid.eid_firma_variable fv where fv.status = 1 and fv.date_exec < sysdate                   
                   order by date_exec desc, priority desc, date_modify desc, fv.id desc
                  ) t where rownum = 1 and t.eid = a.eid and t.type = upper(a.type) )
and DATE_DELETE > sysdate-1                  
and rownum < 100                                    
/

--�������� ��������� ��� ��������� ������
select  
(select contact from (
                   select * from eid.EID_FIRMA_CONTACTS fv where fv.status = 1                   
                   order by priority desc, date_modify desc
                  ) t where rownum = 1 and t.eid = a.eid and t.type_contact = a.type_contact) val,
a.* from EID.EID_FIRMA_CONTACTS A
where 1=1
--and eid in (6194423) 
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_CONTACTS where eid = a.eid and type_contact = a.type_contact and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and CONTACT is not null
and not exists (select null from (select * from eid.EID_FIRMA_CONTACTS fv where fv.status = 1 order by priority desc, date_modify desc) t 
                  where rownum = 1 and t.eid = a.eid and t.type_contact = a.type_contact )
and DATE_DELETE > sysdate-1                  
and rownum < 100                    
/

--�������� ������ ��� ��������� �����
select  
(select ADDRESS from (select * from eid.EID_FIRMA_ADDRESS fv where fv.status = 1                   
                       order by date_modify desc
                      ) t where rownum = 1 and t.eid = a.eid and t.type_address = a.type_address) val,
a.* from EID.EID_FIRMA_ADDRESS A
where 1=1
--and eid in (6194423) 
and owner_delete like '%(MDM_VTB-24)'
and not exists (select null from EID.EID_FIRMA_ADDRESS where eid = a.eid and type_address = a.type_address and owner_modify = a.owner_delete and date_modify = a.date_delete)
and status = -1 and ADDRESS is not null
and not exists (select null from (select * from eid.EID_FIRMA_ADDRESS fv where fv.status = 1 order by date_modify desc) t 
                  where rownum = 1 and t.eid = a.eid and  t.type_address = a.type_address )
and DATE_DELETE > sysdate-1                  
and rownum < 100   
/

begin
  for rr in (select * from eid.eid_firma_variable where type = 'SEGMENT_RKO' and value in ('R125','R500','RGD') and status=1)
  loop 
     eid.p_eid_tools_firma.DeleteVariable(rr.eid,rr.type);
  end loop;
end; 

contracts