--���������� ������� ����� ���
declare
  sRes varchar2(2000) := null;
  nFilialReal number;
  sDopParam varchar2(2000) := null;
  --cl_eid number := :eid;
begin
  for x1 in ( 
               select distinct f.eid,f.subdepartment,f.reference,f.branch from eid.eid_firma f 
               where f.reference is not null 
               and subdepartment = 544308 
               --and f.eid = cl_eid
               )               
  loop
--���������� ��������� �������� ��� ��������� ������
  update EID.EID_FIRMA_VARIABLE A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
  where eid = x1.eid and owner_delete like '%(MDM_VTB-24)'
    and not exists (select null from EID.EID_FIRMA_VARIABLE where eid = a.eid and type = a.type and owner_modify = a.owner_delete and date_modify = a.date_delete)
    and status = -1 and value is not null
    and not exists (select null from (select * from eid.eid_firma_variable fv where fv.status = 1 and fv.date_exec < sysdate                   
                     order by date_exec desc, priority desc, date_modify desc, fv.id desc
                   ) t where rownum = 1 and t.eid = a.eid and t.type = upper(a.type) );
                   
--��������
  update EID.EID_FIRMA_CONTACTS A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
  where eid = x1.eid and owner_delete like '%(MDM_VTB-24)'
    and not exists (select null from EID.EID_FIRMA_CONTACTS where eid = a.eid and type_contact = a.type_contact and owner_modify = a.owner_delete and date_modify = a.date_delete)
    and status = -1 and CONTACT is not null
    and not exists (select null from (select * from eid.EID_FIRMA_CONTACTS fv where fv.status = 1 order by priority desc, date_modify desc) t 
                  where rownum = 1 and t.eid = a.eid and t.type_contact = a.type_contact );

--������
  update EID.EID_FIRMA_ADDRESS A set status = 1, OWNER_DELETE = null, subd_delete = null, DATE_DELETE = null
  where eid = x1.eid and owner_delete like '%(MDM_VTB-24)'
    and not exists (select null from EID.EID_FIRMA_ADDRESS where eid = a.eid and type_address = a.type_address and owner_modify = a.owner_delete and date_modify = a.date_delete)
    and status = -1 and ADDRESS is not null
    and not exists (select null from (select * from eid.EID_FIRMA_ADDRESS fv where fv.status = 1 order by date_modify desc) t 
                    where rownum = 1 and t.eid = a.eid and  t.type_address = a.type_address );

--������������
  update EID.EID_FIRMA_MANAGER t set (MANAGER_ORDER,KEY_EMPLOYEE,MANAGER_TYPE_NAME,MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT_TEXT,PARAMS,BENEFIT_PROCENT,BENEFIT_REASON) = 
  (select nvl(t.MANAGER_ORDER,MANAGER_ORDER),KEY_EMPLOYEE,nvl(t.MANAGER_TYPE_NAME,MANAGER_TYPE_NAME),nvl(t.MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT),nvl(t.MANAGINGAUTH_INPUT_TEXT,MANAGINGAUTH_INPUT_TEXT)
         ,nvl(t.PARAMS,PARAMS),nvl(t.BENEFIT_PROCENT,BENEFIT_PROCENT),nvl(t.BENEFIT_REASON,BENEFIT_REASON)
           from eid.eid_firma_manager_history tt where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1
                 and not exists (select null from EID.EID_FIRMA_MANAGER_HISTORY where eid = tt.eid and manager_eid = tt.manager_eid and date_modify > tt.date_modify and owner_modify not like '%(MDM_VTB-24)')
                                and key_employee = 1 and rownum = 1)
  where eid = x1.eid and owner_modify like '%(MDM_VTB-24)' and KEY_EMPLOYEE = 0 
  and exists (select null from eid.eid_firma_manager_history tt where eid = t.eid and manager_eid = t.manager_eid and KEY_EMPLOYEE = 1 and date_modify < t.date_modify
                 and not exists (select null from EID.EID_FIRMA_MANAGER_HISTORY where eid = tt.eid and manager_eid = tt.manager_eid 
                                and date_modify > tt.date_modify and owner_modify not like '%(MDM_VTB-24)')
                                and key_employee = 1  );   
                  
--�������� � ������ 
    nFilialReal := eid.p_eid_tools2.get_filial_id(x1.subdepartment);
    sDopParam:= NULL;
    mbank.ptools5.set_param(sDopParam, 'ref1', x1.reference);
    mbank.ptools5.set_param(sDopParam, 'br1', x1.branch);
    mbank.ptools5.set_param(sDopParam, 'cikl', 1);
    sRes := mbank.ptools_eid_to_filial.EXEC_EXPORT_RECORD(RecID => -1, TblName => 'EID.EID_FIRMA', nTekFilial => nFilialReal,
                                                            ch_refer => x1.eid, ch_branch => 0, ch_owner_modify => 'Admin',
                                                            ch_owner_modify_id => 1403,ch_subd_modify => mbgoid,
                                                            ch_dop_param => sDopParam);
    if sRes is not null then
      raise_application_error (-20001,'������ ������������� ��:'||x1.eid||' '||sRes);
    end if;
    commit;
  end loop;  
end;