--�������� �������
 select rowid,t.* from clients t where reference =  101245348
 
 select rowid,t.* from variable_clients t where reference =  101245348
 
  select rowid,t.* from collector_clients t where 1=1 
  --and reference =  101245348
  and work_date > sysdate-1000
  and name = 'ADD_PARAM_90' 
  
    select rowid,t.* from rest_clients t where reference =  101245348
    
    select * from guides where type_doc = 1323 --���.���������
    
--insert into collector_clients
select name,reference,currency,work_date
,nvl((select rest from collector_clients cc where reference = t.reference and branch = t.branch and name = t.name 
and work_date = (select max(work_date) from collector_clients where reference = cc.reference and branch = cc.branch and name = cc.name and work_date <= t.work_date)),0) + summa rest
,summa
,collector_clients_id.nextval
,docnum, users, branch, zbranch_docnum from (
select name,101245348 reference,currency,trunc(sysdate) work_date,1 summa,-1379 docnum, 1403 users,branch,to_char(sysdate,'yyyymmdd') zbranch_docnum
 from collector_clients where reference =  100688997 and name = 'ADD_PARAM_90') t 
    
