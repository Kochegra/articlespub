--�������� ������� ������ � contracts
 select rowid,t.* from contracts t where reference =  2871564
 
 select rowid,t.* from variable_contracts t where reference =  2871564
 
  select rowid,t.* from collector_contracts t where 1=1 
  --and reference =  101245348
  and work_date > sysdate-1000
  and name = 'ADD_PARAM_74'
  
    select rowid,t.* from rest_contracts t where reference = 2871564
    
    select * from guides where type_doc = 1155 --���.��������� 
    
--insert into collector_contracts
select name,reference,currency,work_date
,nvl((select rest from collector_contracts cc where reference = t.reference and branch = t.branch and name = t.name 
and work_date = (select max(work_date) from collector_contracts where reference = cc.reference and branch = cc.branch and name = cc.name and work_date <= t.work_date)),0) + summa rest
,summa
,collector_contracts_id.nextval
,docnum, users, branch, zbranch_docnum from (
select name,2871564 reference,currency,trunc(sysdate) work_date,1 summa,-1379 docnum, 1403 users,191 branch,to_char(sysdate,'yyyymmdd') zbranch_docnum
 from collector_contracts where reference =  12082511 and name = 'ADD_PARAM_74') t 
    

    
