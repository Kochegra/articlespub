begin
for rec in (select u.user_,set_mb_user.decryptpassn_login(u.user_,'RIGHTS') ora_pswd from users u, boss_emp_all b
                 where subdepartment = (select id from subdepartments e where instr(name,'���24') > 0 and substr(name,3,1) <> '_' and type = 301)
                 and b.tab_n = u.params and u.params <> '-9999' and b.d_out > sysdate and not exists (select null from all_users where username = u.user_)
                 and nvl(global_parameters.get_param(u.user_id,'������',trunc(sysdate)),'0') = '0'
                 and job not in (30809)
                 and length(set_mb_user.decryptpassn_login(u.user_,'PASSWORD')) < 16 and length(set_mb_user.decryptpassn_login(u.user_,'RIGHTS')) < 32
                 )
loop
  personal.makeOracleUser(rec.user_,rec.ora_pswd,mbfilid);
end loop;                   
end;
/
exit;
/