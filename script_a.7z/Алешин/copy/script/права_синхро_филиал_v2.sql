--create table support_chg_rights
(tbl varchar2(50)
,job_id number
,id number
,code number
,oper number
,rights number
,value varchar2(4000)
,dt date) 
/

select * from support_chg_rights
/

select * from  cbs_errors where msg_date > sysdate-1/48 order by msg_date desc

/

select rowid,s.* from SUPPORT_CHANGE_FIL s where status = 0
/

--������������� ����
declare
  procedure oper_exec(p_id varchar2) is
  begin
    for rec in (select rowid,s.* from support_change_fil s where status = 0 and oper_id = p_id) 
    loop
      begin
        execute immediate rec.oper;
        update support_change_fil set status = 1 where rowid = rec.rowid;
      exception when OTHERS then  
        update support_change_fil set status = 2 where rowid = rec.rowid;  
      end;     
    end loop;
    commit;       
  end;
begin
  for r in (select count(*) cnt from support_change_fil where status = 0 and substr(oper_id,1,12) = 'MODIFY JOBS ')
  loop
    if r.cnt > 0 then
      oper_exec('MODIFY JOBS JR_DEL');
      oper_exec('MODIFY JOBS JR_INS');
      oper_exec('MODIFY JOBS UP_DEL');
      oper_exec('MODIFY JOBS UP_INS');
      oper_exec('MODIFY JOBS JPV_DEL');
      oper_exec('MODIFY JOBS JPV_INS');
 --    dbms_output.put_line('FINISH ');
     --�������������� ����� ��� ����
      if mbfilid >= 200 and mbfilid < 210 then 
        update jobs_rights set rights = -1 
        where job_id in (175,9,761) and code = 4 and object_id = 17 and rights <> -1;
        update jobs_rights set rights = -8 
        where job_id in (613) and nvl(rights,0) <> -8 and (object_id,code) in (select type_id,code from types jr where code = 5 and upper(name) like '%�����%');
        delete jobs_rights a where code=9 and object_id=11905;
        insert into job_param_values  
          select * from (select t.type_id id,j.job_id,'1' value,trunc(sysdate) activated from types t, jobs j where  t.code = 14 
                  and j.job_id in (175,9,761) and t.name in ('���������_���������2','������_�_������')) tbl
          where not exists (select null from job_param_values pv where job_id = tbl.job_id and id=tbl.id and activated = tbl.activated)
            and not exists (select null from job_param_values pv where job_id = tbl.job_id and id=tbl.id and value = tbl.value 
                         and activated = (select max(activated) from job_param_values where job_id = pv.job_id and id=pv.id and activated <= tbl.activated));
        insert into job_param_values
          select * from (select t.type_id id,j.job_id,'1' value,trunc(sysdate) activated from types t, jobs j where  t.code = 14 
                   and j.job_id in (613) and t.name in ('���������_990')) tbl       
          where not exists (select null from job_param_values pv where job_id = tbl.job_id and id=tbl.id and activated = tbl.activated)
            and not exists (select null from job_param_values pv where job_id = tbl.job_id and id=tbl.id and value = tbl.value 
                         and activated = (select max(activated) from job_param_values where job_id = pv.job_id and id=pv.id and activated <= tbl.activated));
      end if;    
      commit;
    end if;    
  end loop;
end;
/

--������������� ����� � ���������
declare 
 flag number; --���� 1 - ������ ��������
begin   
    --������ ������ ������ 
    delete support_change_fil where status = 0 and substr(oper_id,1,12) = 'MODIFY JOBS '; 
    flag := 1; 
    
    delete support_chg_rights where tbl in ('JR','UP','JPV'); 
     
    insert into support_chg_rights(tbl,job_id,id,code,oper,rights)
    select 'JR',job_id,object_id,code,operation,rights from jobs_rights@etalon; 

    insert into support_chg_rights(tbl,job_id,id,value)
    select 'UP',depart_id,id,name from user_parameters@etalon;

    insert into support_chg_rights(tbl,job_id,id,value,dt)
    select 'JPV',job_id,id,value,activated from job_param_values@etalon;

    begin 
      commit; rollback;
      dbms_session.close_database_link('ETALON');
    exception when OTHERS then null;   
    end;       
    
    --����� ������ �����
    for job_from in (select * from jobs where name is not null)-- and job_id not in (31155,35,55))
    loop      
      if flag = 1 then      
        --��������� ������ �� �������� ���� ������������� � ���������� 
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS JR_DEL','delete jobs_rights where job_id ='||jr.job_id||' and object_id = '||jr.object_id||' and code = '||jr.code||' and operation = '||jr.operation||' and nvl(rights,-1379) = '||nvl(jr.rights,-1379)
          from jobs_rights jr where job_id = job_from.job_id 
               and not exists (select null from support_chg_rights where tbl = 'JR' and job_id = jr.job_id and id = jr.object_id and code = jr.code and oper = jr.operation and nvl(rights,-1379) = nvl(jr.rights,-1379));       
        --commit;
      --��������� ������ �� ���������� ���� 
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS JR_INS','insert into jobs_rights(job_id,object_id,code,operation,rights) values('||jr.job_id||','||jr.id||','||jr.code||','||jr.oper||','||nvl(to_char(jr.rights),'NULL')||')'
          from support_chg_rights jr where tbl = 'JR' and job_id = job_from.job_id 
               and not exists (select null from jobs_rights where job_id = jr.job_id and object_id = jr.id and code = jr.code and operation = jr.oper and nvl(rights,-1379) = nvl(jr.rights,-1379));
       -- commit;
        --��������� �������� ����������
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS UP_DEL','delete user_parameters where depart_id = '||up.depart_id||' and name = '''||up.name||''''
          from user_parameters up where depart_id = job_from.job_id   
              and not exists (select null from support_chg_rights where tbl = 'UP' and job_id = up.depart_id and value = up.name);
       -- commit;
        --��������� ���������� ����������
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS UP_INS','insert into user_parameters(depart_id,name) values('||up.job_id||','''||up.value||''')'
          from support_chg_rights up where tbl = 'UP' and job_id = job_from.job_id and not exists (select null from user_parameters where depart_id = up.job_id and name = up.value)
           and (exists (select null from types where name = up.value and code = 14) 
                 or up.value in ('���_�������','���_�������','���_1','���_2','���_������') );
       -- commit;
        --��������� �������� �������� ����������
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS JPV_DEL','delete job_param_values where job_id = '||jpv.job_id||' and id = '||jpv.id
                                         ||' and trunc(activated) = to_date('''||to_char(jpv.activated,'dd.mm.yyyy')||''',''dd.mm.yyyy'')'   
                                         from job_param_values jpv where job_id = job_from.job_id and not exists (select null from support_chg_rights where tbl = 'JPV' 
                                         and job_id = jpv.job_id and id = jpv.id and dt >= jpv.activated and jpv.value = decode(id,2904,decode(value,'5','3.1',value),value));                                          
        --commit;
        --��������� ���������� �������� ����������
        insert into SUPPORT_CHANGE_FIL(oper_id,oper) select 'MODIFY JOBS JPV_INS','insert into job_param_values(id,job_id,value,activated) values('||jpv.id||','||jpv.job_id
                    ||','''||decode(jpv.id,2904,decode(jpv.value,'5','3.1',jpv.value),jpv.value)||
                     ''',to_date('''||to_char(jpv.dt,'dd.mm.yyyy')||''',''dd.mm.yyyy''))' from support_chg_rights jpv where tbl = 'JPV' and job_id = job_from.job_id
                     and jpv.dt = (select max(dt) from support_chg_rights where tbl = jpv.tbl and job_id = jpv.job_id and id = jpv.id)
                     and not exists (select null from job_param_values where job_id = jpv.job_id and id = jpv.id and activated = jpv.dt
                                      and value = decode(jpv.id,2904,decode(jpv.value,'5','3.1',jpv.value),jpv.value));                      
        commit;    
      end if;
    end loop;   
end;
/

ALTER SESSION CLOSE DATABASE LINK ETALON;


SELECT * FROM USER_DB_LINKS;


