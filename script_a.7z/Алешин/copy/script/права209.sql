select * from clients where 

--�������������� ����� ��� ����
update jobs_rights
set rights = -1 
where job_id = 175 and code = 4 and object_id = 17 and rights <> -1


--��������
175

select * from types where type_id in (662,2833,10224)

rights = -4
select * from types where type_id in (1990)


rights = -1
select * from types where type_id in (3363,3445,4110)

rights = -8
select * from types where type_id in (30173,7535,2264)


31410,1
select * from types where type_id in (8187)

/
select * from archive where type_doc = 6315 and date_work > sysdate-100

select * from contracts where type_doc in (30173)

select * from clients where type_doc in (2264)

1961,2387,4110

select * from zyx_types_real@etalon where type_id = 3363