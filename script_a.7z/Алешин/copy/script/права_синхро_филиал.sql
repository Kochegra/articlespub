--������������� ������� ��������� c ��
declare
  dt_0 varchar2(256);
  dt_1 varchar2(256);
  dt varchar2(256);
  st varchar2(4000);
  jobs_t sys_refcursor;
  job_to jobs%rowtype;
  sql_text varchar2(4000);
  cnt number;
begin
    --������ ������ ������ 
   delete support_change_fil z where status = 0 and oper_id = 'MODIFY JOBS'; 
   for job_from in (select * from jobs@etalon)
   loop   
     st := null; 
     open jobs_t for select * from jobs where job_id = job_from.job_id;
     fetch jobs_t into job_to;
     if jobs_t%NOTFOUND then
     --���������� ����� �� �������
     --dbms_output.put_line(job_from.job_id||' ���� �� �������');
       if job_from.name is not null then           
         if job_from.date_start is null then
           dt_0 := 'null';
         else
           dt_0 := 'to_date('''||to_char(job_from.date_start,'dd.mm.yyyy')||''',''dd.mm.yyyy'')';
         end if;          
         if job_from.date_finish is null then
           dt_1 := 'null';
         else
           dt_1 := 'to_date('''||to_char(job_from.date_finish,'dd.mm.yyyy')||''',''dd.mm.yyyy'')';
         end if;                  
         dt := 'to_date('''||to_char(sysdate,'dd.mm.yyyy')||''',''dd.mm.yyyy'')';
         st := 'insert into jobs(job,job_id,parent,name,priority,date_start,date_finish,date_modify,doc_number,info_add) 
            values('''||job_from.job||''','||job_from.job_id||','||job_from.parent||','''||job_from.name||''','||job_from.priority||
            ','||dt_0||','||dt_1||','||dt||','''||job_from.doc_number||''','''||job_from.info_add||''')';
       end if;    
     else
     --���������� ������������ ����
     --  dbms_output.put_line(job_from.job_id||' ���� �������');
       if job_from.job <> job_to.job then st := ' job = '''||to_char(job_from.job)||''''; end if;
       if nvl(job_from.parent,-1379) <> nvl(job_to.parent,-1379) then st := st||', parent = '||nvl(job_from.parent,0); end if;
       if nvl(job_from.priority,-1379) <> nvl(job_to.priority,-1379) then st := st||', priority = '||nvl(job_from.priority,0); end if;       
       if nvl(job_from.name,'-1379') <> nvl(job_to.name,'-1379') then st := st||', name = '''||job_from.name||''''; end if;
       if nvl(job_from.doc_number,'-1379') <> nvl(job_to.doc_number,'-1379') then st := st||', doc_number = '''||job_from.doc_number||''''; end if;
       if nvl(job_from.info_add,'-1379') <> nvl(job_to.info_add,'-1379') then st := st||', info_add = '''||job_from.info_add||''''; end if;
       dt_0 := to_char(job_from.date_start,'dd.mm.yyyy');
       dt_1 := to_char(job_to.date_start,'dd.mm.yyyy'); 
       if nvl(dt_0,'-1379') <> nvl(dt_1,'-1379') then
         st := st||', date_start = ';  
         if dt_0 is null then st := st||'null'; else st := st||'to_date('''||dt_0||''',''dd.mm.yyyy'')'; end if;
       end if;  
       dt_0 := to_char(job_from.date_finish,'dd.mm.yyyy');
       dt_1 := to_char(job_to.date_finish,'dd.mm.yyyy');
       if nvl(dt_0,'-1379') <> nvl(dt_1,'-1379') then
         st := st||', date_finish = ';  
         if dt_0 is null then st := st||'null'; else st := st||'to_date('''||dt_0||''',''dd.mm.yyyy'')'; end if;
       end if;        
       if st is not null then
         st := 'update jobs set '||ltrim(st,', ')||' where job_id = '||job_to.job_id;
       end if;                   
     end if;
     --dbms_output.put_line( st );            
     close jobs_t;
     --�������� �� ����������� �������������
     cnt := 0;
     if job_from.job <> job_to.job then 
       select count(*) into cnt from all_users where username in (select user_ from users where job = job_from.job_id); 
     end if; 
     if st is not null and cnt = 0 then       
       insert into SUPPORT_CHANGE_FIL(oper_id,oper) values('MODIFY JOBS',st);
       --dbms_output.put_line(sql_text);       
       commit;
     end if;                 
    end loop;   
end;

/

--������������� �������
declare
  procedure oper_exec(p_id varchar2) is
  begin
    for rec in (select rowid,s.* from support_change_fil s where status = 0 and oper_id = p_id) 
    loop
      begin
        execute immediate rec.oper;
        update support_change_fil set status = 1 where rowid = rec.rowid;
      exception when OTHERS then  
        update support_change_fil set status = 2 where rowid = rec.rowid;  
      end;     
    end loop;
    commit;       
  end;
begin
--������� ���������
  oper_exec('MODIFY JOBS');
  dbms_output.put_line('FINISH ');
end;
/

select * from SUPPORT_CHANGE_FIL where status = 0
/
select * from jobs where job_id in (30880,471)

select * from v$parameter@etalon where name = 'spfile'
/
--������� ������� �� �����
select
(select count(*)||'/'||count(a.username) from users u, all_users a where u.job = j.job_id and u.USER_ = a.username(+)) usr 
,(select job from jobs@etalon where job_id = j.job_id) je
,j.* 
from jobs j where 
exists (select null from jobs@etalon where name is not null and job_id = j.job_id and job <> j.job)
/

select (select count(*)||'/'||count(a.username) from users u, all_users a where u.job = j.job_id and u.USER_ = a.username(+)) usr
,(select name from jobs where job_id = j.parent) "������" 
 ,j.* from jobs j where 1=1
 --and name is null
 --and parent in (31180)
and job_id in (31305,31160,175,761,31452,9) 
--and job like '%��������%'
 order by parent,name  