select * from documents d where refer_from = 9280089 and status = 35
 
select * from documents d where related in
(select reference from documents d where refer_from = 9280089 and status = 35)

select * from v$instance


select * from guides where type_doc = 11680 and code = 'EXCEPTION_SHED'


update shed_tasks set active = null where task_name = 'ADMINISTRATIVE';
commit;
/
exit;
/
drop table zyx_upv_20181103
/
create table zyx_upv_20181103 as 
select * from user_param_values as of timestamp (systimestamp - interval '160' minute) pv
where not exists (select null from user_param_values where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id and activated = pv.activated)
--and exists (select null from user_parameters where id = pv.id and depart_id = pv.depart_id)

create table zyx_up_20181103 as 
select * from user_parameters as of timestamp (systimestamp - interval '60' minute) pv


select * from zyx_upv_20181103 pv  where activated =
(select max(activated) from zyx_upv_20181103 where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id)

select * from zyx_up_20181103

--����������
--insert into user_param_values 
select * from (select
nvl((select id from user_parameters where depart_id = up.depart_id and name = up.name),0) id 
,pv.depart_id,user_id,value,activated from zyx_upv_20181103 pv, zyx_up_20181103 up  where activated =
(select max(activated) from zyx_upv_20181103 where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id)
and up.id = pv.id and up.depart_id = pv.depart_id) tbl
where id > 0
and not exists (select null from user_param_values where id = tbl.id and depart_id = tbl.depart_id and user_id = tbl.user_id)
 

select * from zyx_up_20181102

select * from user_param_values
select * from user_param_values as of timestamp (systimestamp - interval '60' minute) pv
where not exists (select null from user_param_values where id = pv.id and depart_id = pv.depart_id and user_id = pv.user_id and activated = pv.activated)
and exists (select null from user_parameters where id = pv.id and depart_id = pv.depart_id)
