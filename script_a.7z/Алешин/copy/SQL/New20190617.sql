select rowid,t.* from documents t where reference = 4984889 
/

--insert into guides
select rowid,g.*
from guides g where type_doc = 9936 --and str1 = 405008
and str4 like '70601810%2740402'
and code = '20132005'
/

select guides_reference.nextval from dual 
/

select * from account where code = '70601810550002740402' 
/

select * from documents where refer_from in 

select rowid,d.* from documents d where 
--reference in  
--(4985347,4985510,4985512,4985514,4985830,4985831,4985832,4985833,4985836)
--(4987853,4987854,4987855)
--(4988033,4988034,4988035,4988036)
--(4988150,4988151,4988152,4988153)
type_doc = 153 and status < 30
/

 select * from documents where (refer_from,branch_from) in (
select reference,branch from documents where (refer_from,branch_from) in
(select reference,branch from documents where reference in 
(4988150,4988151,4988152)
)
)
/

select * from journal 
--delete journal 
where docnum in (4988150,4988151,4988153)
/
select reference,date_work,payers_account,RECEIVERS_ACCOUNT,SUMMA,memo 
,m_filial_1.guess_operation_code(d.payers_account,
                                                               d.payers_currency,
                                                               d.receivers_account,
                                                               d.receivers_currency,
                                                               d.summa,
                                                               d.summa,
                                                               mbfilid,
                                                               mbfilid,
                                                               mbfilid)       operation_code
,m_filial_1.get_client_type_by_account(d.receivers_account) dd
,pckmfilialutil.IsVIPByAccount(d.payers_account) dc
,universe.variable_doc(d.branch, d.reference, 'TO_ALIEN')
,m_filial_1.calculate_payer_commission('20132005',mbfilid,d.summa,
                                                   '810',0,1,5) vv                                                              
from documents d
where reference in  
--(4985830,4985832,3420323324,3420347239,3421176778,4985834,4985837,4985835,4985838,4985835,4985838)
(4987853,4987854)


2200650483559999	42306810080930010214		10150
2200650483559999	40817810280930010181		580


