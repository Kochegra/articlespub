select * from guides@nnovg where type_doc = 11706 and  str2 = '0'

select * from guides@nnovg  where type_doc = 11712 

select * from guides@stavropol where type_doc = 11706 

select * from guides@stavropol where type_doc = 11712

select * from users@stavropol where user_id = '981658'


insert into guides(branch,folder,type_doc,status,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)
select g.branch,folder,type_doc,status,g.owner,to_date('10.02.2017','dd.mm.yyyy'),g.code,g.name,str1,str2,str3,z.f,str5,num1,num2,num3,num4,num5,date1,date2,date3,g.code||g.str1||g.str3  
from guides g, zyx_cont_cb z  where g.type_doc = 9936 and substr(g.code,1,3) = '100'
and g.str4 = trim(z.a) and substr(z.a,1,1) = '7' 
and code1 = g.code||g.str1||g.str3
/

--insert into guides@nnovg(branch,folder,type_doc,status,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)
select mbfilid@nnovg,folder,type_doc,status,1403,date_work,g.code,g.name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1  
--select * 
from guides@stavropol g where g.type_doc = 11712 and code <> 'FORM_STORAGE'

insert into guides@nnovg(branch,folder,type_doc,status,owner,date_work,code,name,str1,str2,str3,code1)
select 
 mbfilid@nnovg,0,11706,0,1403,to_date('01.01.1990','dd.mm.yyyy'),t.A,t.D,t.F,t.B,t.C,'NULL'||t.i
 --select *   
 --select *  
 from doc_3@nnovg t  where b  in ('0')--,'2') and '30' in (substr(e,1,2),substr(f,1,2))

select * from guides@stavropol where type_doc = 11706-- and str2 not in ('0','2')

select rowid,n.* from guides@nnovg n where type_doc = 11712

select global_parameters.get_param@nnovg('��_��������_�����_��_978',mbfilid@nnovg,sysdate) from dual  
--
/
--,'��_��������_�����_��_840','��_��������_�����_��_978','��_����������_��_810','��_����������_��_840','��_����������_��_978')

select name,value,count(*) from paramvalues@nnovg pv, parameters@nnovg p where p.name in ('��_��������_�����_��_810')
   and p.id = pv.paramid and p.group_id = pv.paramgroupid 
   and activated = (select max(activated) from paramvalues@nnovg where paramid = pv.paramid and paramgroupid = pv.paramgroupid and departid = pv.departid and activated <= trunc(sysdate))
group by name,value
/

select * from paramvalues@nnovg pv

select * from parameters@nnovg pv

select * from subdepartments@nnovg where id =  47049