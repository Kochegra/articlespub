UPDATE eid.eid_black_firma t SET  status = 1, date_modify = trunc(sysdate)


select count(*) from eid.eid_black_firma t
 WHERE not exists (SELECT null FROM t_list_dfkk u  WHERE u.did = '2016.06.21.11.44.30' and u.C02 = t.name_firma and NVL(u.C01,'*') = NVL(t.INN,'*') and u.C07 = t.source)
                     AND t.status = 0 and t.source = '������ ���' and t.code_text = '������ ����'
                     AND t.date_modify =  (SELECT max(d.date_modify) FROM eid.eid_black_firma d  WHERE d.name_firma = t.name_firma AND NVL(d.INN,'*') = NVL(t.INN,'*') AND d.source = t.source )
                     


SELECT count(*) FROM eid.eid_black_firma t WHERE t.status = 0 
AND t.date_modify = (SELECT max(d.date_modify) FROM eid.eid_black_firma d 
                         WHERE d.name_firma = t.name_firma AND NVL(d.INN,'*') = NVL(t.INN,'*') AND d.source = t.source AND d.code_text = t.code_text) 
                         AND (t.name_firma,NVL(t.INN,'*'),t.Source) NOT IN  (select C02,NVL(C01,'*'),C07 from t_list_DFKK where did = '2016.06.21.11.44.30' AND C07 = '������ ���' )
                         AND t.source = '������ ���' AND t.code_text = '������ ����'



                     
select count(*) FROM eid.eid_black_firma t WHERE t.status = 1
                          AND t.date_modify = (SELECT max(d.date_modify) FROM eid.eid_black_firma d WHERE d.name_firma = t.name_firma AND NVL(t.INN,'*') = NVL(d.INN,'*') AND d.source = t.source)
                          and exists (SELECT null FROM t_list_dfkk u  WHERE u.did = '2016.06.21.11.44.30' and u.C02 = t.name_firma and NVL(u.C01,'*') = NVL(t.INN,'*') and u.C07 = t.source)
                          and t.source = '������ ���'
                         --AND (t.name_firma, NVL(t.INN,'*'),t.Source) IN  (select C02,NVL(C01,'*'),C07 from t_list_DFKK WHERE did = '2016.06.21.11.44.30'
                         -- AND C07 = '������ ���')
                         

 SELECT * FROM t_list_dfkk u  WHERE d01 > trunc(sysdate) - 10 and u.did not in ('2016.06.21.11.44.30','2016.06.21.09.30.29','2016.06.16.06.12.44'
 ,'2016.06.16.06.41.52','2016.06.17.02.41.41','2016.06.16.06.01.44','2016.0.16.06.01.44')
 
 
 SELECT count(*) FROM t_list_dfkk u  WHERE d01 > trunc(sysdate) - 10 and u.did in ('2016.06.17.02.41.41')
 
  SELECT DT01,C13 FROM t_list_dfkk u  WHERE u.did in ('2016.06.16.06.01.44')


SELECT count(*) FROM eid.eid_black_human where (trunc(date_modify),source) in (SELECT D01,C13 FROM t_list_dfkk u  WHERE u.did in ('2016.06.16.06.01.44'))


SELECT * FROM t_list_dfkk u  WHERE u.did in ('2016.06.16.06.01.44') and  instr(upper(c04),'������')>0-- and birthday = '10-aug-1969'

SELECT * FROM eid.eid_black_human where --(trunc(date_modify),source) in (SELECT D01,C13 FROM t_list_dfkk u  WHERE u.did in ('2016.06.16.06.01.44'))
 instr(upper(search_name),'������ �������� ����')>0 and birthday = '10-aug-1969'


--���������� �������
--insert into  eid.eid_black_human(
REFER_FIRMA, BRANCH_FIRMA,STATUS,SEARCH_NAME,    SEARCH_DOC,    LAST_NAME,    FIRST_NAME,    SECOND_NAME,    BIRTHDAY,    DOC_NUMBER,    ADDRESS,    ADDRESS_REAL
,    SUBD_MODIFY    ,OWNER_MODIFY    ,MEMO    ,SOURCE    ,CODE    ,CODE_TEXT    ,SOURCE_CODE    ,POST_INDEX    ,REGION    ,AREA    ,CITY    ,PLACE    ,STREET
    ,HOUSE    ,BUILDING    ,FLAT    ,IS_HAND_ADDRESS    ,REAL_POST_INDEX    ,REAL_REGION    ,REAL_AREA    ,REAL_CITY    ,REAL_PLACE,   REAL_STREET,    REAL_HOUSE,    REAL_BUILDING
,    REAL_FLAT,    IS_HAND_REAL_ADDRESS,    NO_IN_BASE,    DOC_REFERENCE,    DOC_BRANCH,    U_LNAME,    U_FNAME,    U_SNAME,    INN,    ID,    PARENT) 
select 
REFER_FIRMA, BRANCH_FIRMA,1,SEARCH_NAME,    SEARCH_DOC,    LAST_NAME,    FIRST_NAME,    SECOND_NAME,    BIRTHDAY,    DOC_NUMBER,    ADDRESS,    ADDRESS_REAL
,SUBD_MODIFY    ,OWNER_MODIFY    ,MEMO    ,SOURCE    ,CODE    ,CODE_TEXT    ,SOURCE_CODE    ,POST_INDEX    ,REGION    ,AREA    ,CITY    ,PLACE    ,STREET
    ,HOUSE    ,BUILDING    ,FLAT    ,IS_HAND_ADDRESS    ,REAL_POST_INDEX    ,REAL_REGION    ,REAL_AREA    ,REAL_CITY    ,REAL_PLACE,   REAL_STREET,    REAL_HOUSE,    REAL_BUILDING
,    REAL_FLAT,    IS_HAND_REAL_ADDRESS,    NO_IN_BASE,    DOC_REFERENCE,    DOC_BRANCH,    U_LNAME,    U_FNAME,    U_SNAME,    INN,    ID,    PARENT
from eid.eid_black_human t  where 
search_name like '�������� ����� ��%' 
--search_name,BIRTHDAY,SEARCH_DOC in (select A,B,C from zyx_excel) 
and date_modify = (select max(date_modify) from eid.eid_black_human where search_name = t.search_name and search_doc = t.search_doc)

select * from zyx_excel 