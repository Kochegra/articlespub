select * from documents where date_work >= :dt and instr(memo,'18810177170717599874') > 0
select * from documents where summa = 772.50

select * from variable_documents where reference = 2564781390 and branch = 191 

select * from documents_delete where summa = 772.50

select * from archive where reference = 1452017352 date_work = :dt and summa = 772.50
/
select rowid,va.* from variable_archive va where reference in 1560606799  -- (1561824345,1452017352)
/
select * from archive where date_work = :dt and instr(memo,'18810177160211022084') > 0
--18810177160208110555
/
select rowid,va.* from variable_archive va where reference = 1634188614
and name in ('COMPDOC_STATUS','PAYERS_KPP','TAX_MEMO','OKATO','TAX_PERIOD','TAX_DOCNUMBER','TAX_DATEDOC','TAX_TYPEDOC','COM:PAYERIDENTIFIER','PI:SUPPLIERBILLID','BDI:STATUS')
/
select * from bill_params where GID = '18_2C07B62921FB062AE0530AC944AC6C06' -- and field = 'ChargeInfo'
/
select * from PRC_LOADER.KIOSK_TRANSACTIONS where contract_number = '5417150588249325'-- ret_ref_number = '528002864368'
/
--������� �� �������� � ��� �M�
select rowid,f.* from fk_send_info@ekburg f where reference in (53245593,61370914)  
/

select rowid,f.* from fk_send_info f where reference in (1560606799,1452017352,2508087944) --(1452017352)
sys_date >= sysdate-1 and error_message is not null and done <> 1
/ 
--��������� ��������
--1634188614,1627293780
--ekburg 53245593,61370914
/
select * from mbank.rtk_payments where --sys_date > sysdate -1
--rrn in ('533501229091','533501228499') 
ipshnum = '18810177160208110555'                   
/
select * from FK_ADD where reference = 1261084352
select * from all_tables where table_name like 'KIOSK%'
10314016010000006149


/
select rowid,g.* from eid.gibdd_penalty g where bill_id  =  '18810177160208110555'
bm_summa > 0 and bill_date > sysdate -10
/
select * from eid.gibdd_penalty_hist where account = '4652060577663344' --bill_id = '18810177141130086638'

select * from penalty_monitor where bill_id = '18810177160208110555'  msg is not null
--reference = 1112918764

 select * from eid.eid_products where reference = 343254 0000000000000047 
 
 select LPAD (REFERENCE, 16, '0') || LPAD (branch, 16, '0') from contracts@krasnodar c where reference = 343254
select * from all_links
/
----------------------------------------------
--������ � ������� �� ��������:
declare 
  i integer;                                     
  rec_doc archive%rowtype;
begin
ptools2.short_init_user(1403);
select * into rec_doc from archive where reference = 1560606799;
p_fk_info.register_fk_document(rec_doc,1);
commit;
end;
/
--��������� variable_archive
declare  
  type tVar_Doc is record (name varchar2(30), val varchar2(2000));
  type tVarDoc is table of tVar_Doc index by binary_integer;
  vd tVarDoc;
begin
   vd(1).name := 'COMPDOC_STATUS';  vd(1).val := '24'; 
   vd(2).name := 'PAYERS_KPP';  vd(2).val := global_parameters.get_param('���_�������',191); 
   vd(3).name := 'TAX_MEMO';  vd(3).val := '0';
   vd(4).name := 'OKATO';  vd(4).val := '0';
   vd(5).name := 'TAX_PERIOD';  vd(5).val := '0';
   vd(6).name := 'TAX_DOCNUMBER';  vd(6).val := '0';
   vd(7).name := 'TAX_DATEDOC';  vd(7).val := '0';
   for i in 1..vd.count loop
       insert into variable_archive   
       select vd(i).name,reference,branch,0,0,0,vd(i).val,null,variable_doc_id.nextval,date_work from archive a where reference in ( 1476746669,1476746672,1476746676)
       and not exists (select null from variable_archive where reference = a.reference and branch = a.branch and name = vd(i).name);
      dbms_output.put_line(vd(i).name); 
   end loop;
end;
/

gis_gmp_cb.unload_pays (1, 10, 1000); 