select * from collector_contracts cc where reference in
(select reference from contracts where type_doc = 4258 and status = 50)
and name = 'GRAPH_ANNUAL' and docnum > 0
and (select count(*) from collector_contracts where reference = cc.reference and name = 'GRAPH_LOAN' and work_date = cc.work_date-1) = 1

insert into collector_contracts
select 'EXECPERCENT',c.reference,c.currency,d.date_work,32883.01+d.summa, 
d.summa,COLLECTOR_CONTRACTS_ID.Nextval,d.reference,d.owner,c.branch,d.branch 
from contracts c, documents d where d.reference = 611016036 and c.reference = 6005625

select rowid,c.* from collector_contracts c where reference = 6005625