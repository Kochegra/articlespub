--������, ����, �� ���������� ����� ����������� ������.
--����� ����������� � ����� ������: ?
--1.    �������� ����� ���������.
--2.    ��������� ���������� ������� ����� �����, ���������, ��������������.
--3  ���������� ����� ������ ��������� � ������ �� ��������
declare
    l_next_Reference documents.reference%type;
    l_Date DATE := to_date('02.09.2019','dd.mm.yyyy');
    l_code journal.code%type;
    l_Saldo number;
    l_SaldoR number;
    v_ost_r number;
    v_ost number;
    j_id number;
    st_tmp varchar2(50);
begin
    for recs in (select r.rowid, r.* from archive r where date_work = l_Date
                            and real_payers like '303%' and receivers_account like '20202%' and (mbfilid = mbgoid and type_doc = 6 or mbfilid <> mbgoid and type_doc = 2) 
                            and exists (select null from journal where docnum = r.reference and branch = r.branch) 
                            --and reference = 2824516675  
                 union all
                 select r.rowid, r.* from archive r where date_work = l_Date
                        and payers_account like '303%' and receivers_account like '20202%' and type_doc in (610)
                        and exists (select null from journal where docnum = r.reference and branch = r.branch)   
                    )
    
    loop
       l_next_Reference := doc_reference.nextval();

         insert into archive (REFERENCE, BRANCH, type_doc, BRANCH_FROM, BRANCH_PAYERS, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, BRANCH_RECEIVERS, BRANCH_RELATED, CHILD, DATE_CREATE, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, ID, MEMO, NUM_GROUP, OWNER, PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK, PAYERS_CONTRACT, PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS, REAL_PAYERS_CONTRACT, REAL_RECEIVERS, REAL_RECEIVERS_CONTRACT, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CONTRACT, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE, RELATED, SHIFROPER, STATUS, SUB_TYPE, SUMMA, VERSION, XSUBDEPARTMENT, XSUMMACREDIT)
         select l_next_Reference, BRANCH, 8, branch, BRANCH_PAYERS, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, BRANCH_RECEIVERS, BRANCH_RELATED, CHILD, DATE_CREATE, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, ID, MEMO, NUM_GROUP, OWNER, PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK, PAYERS_CONTRACT, PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS, REAL_PAYERS_CONTRACT, REAL_RECEIVERS, REAL_RECEIVERS_CONTRACT, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CONTRACT, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, reference, REFER_OFFICE, RELATED, SHIFROPER, STATUS, SUB_TYPE, SUMMA, VERSION, XSUBDEPARTMENT, XSUMMACREDIT
              from archive where rowid = recs.rowid;

         insert into variable_archive (REFERENCE, BRANCH, COLNUMBER, ID, NAME, ROWNUMBER, SUBFIELD, SUBNUMBER, VALUE, XDATE)
         select l_next_Reference, BRANCH, COLNUMBER, ID, NAME, ROWNUMBER, SUBFIELD, SUBNUMBER, VALUE, XDATE
              from variable_archive where reference = recs.reference and branch = recs.branch;

         if recs.payers_currency = '810' then     
           INSERT INTO variable_archive (branch,reference,NAME,rownumber,colnumber,subfield,VALUE)
           VALUES (recs.branch,l_next_Reference, 'CASHSYMBOL', 1, 0,'SYMBOL','72');
         else  
           INSERT INTO variable_archive (branch,reference,NAME,rownumber,colnumber,subfield,VALUE)
           VALUES (recs.branch,l_next_Reference, 'CASHSYMBOL', 1, 0,'SYMBOL','00');
         end if;
           
         INSERT INTO variable_archive (branch,reference,NAME,rownumber,colnumber,subfield,VALUE)
         VALUES (recs.branch,l_next_Reference, 'CASHSYMBOL', 1, 1,'SUMMA',TO_CHAR(recs.summa,'99999999999999.99'));
         INSERT INTO variable_archive (branch,reference,NAME,rownumber,colnumber,subfield,VALUE)
         VALUES (recs.branch,l_next_Reference, 'CASHSYMBOL', 1, 2,'ACCOUNT',recs.Receivers_account);

         update journal 
                set docnum = l_next_Reference, branch = recs.branch, operation = case when recs.payers_currency = '810' then  '110072' else '120000' end
                where docnum = recs.reference and branch = recs.branch;
         
         if recs.payers_currency = '810' then 
           if recs.date_document is null then
             update archive set status = 30, date_document = date_work
                    where reference = l_next_Reference and branch = recs.branch;
           else
             update archive set status = 30
                    where reference = l_next_Reference and branch = recs.branch;
           end if;
         else
           if recs.date_document is null then
             update archive set date_document = date_work
                    where reference = l_next_Reference and branch = recs.branch;
           end if;         
         end if;
         
         p_audit.save('DOCUMENTS',recs.branch,l_next_Reference,'�������� ��������� ������ �� ��������� ������� '||recs.reference,recs.reference);
         
         /* ���������*/
         for jr in (select * from journal where docnum = l_next_Reference and flag_debit = '-' )
         loop
           for rec in (select rowid,a.* from account a where code = jr.code||'00007')-- and close_date is null) 
           loop
             l_Saldo := pledger.saldo(rec.header, rec.code, rec.currency, l_Date);
             if l_Saldo > 0 then
               select value into st_tmp from config where NAME like 'ARCHIVE_CLOSE_DATE'; 
               update config set value = to_char(l_Date-1,'dd.mm.yyyy') where NAME like 'ARCHIVE_CLOSE_DATE';
               l_SaldoR := pledger.Rsaldo(rec.header, rec.code, rec.currency, l_Date);
               j_id := journal_id.nextval;
               insert into journal (WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,BRANCH,RELATED,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT,HEADER,CODE,CURRENCY,VSUM,RSUM,FLAG_DEBIT)
                  values (jr.work_date,jr.value_date,jr.DOCNUM,j_id,jr.OPERATION,jr.TYPE,jr.USERS,jr.BRANCH,jr.related,jr.ASSIST,jr.ASSIST_CURRENCY,jr.YSUBDEPARTMENT,rec.HEADER,rec.code,rec.currency,l_Saldo,l_SaldoR,'-');
               update config set value = st_tmp where NAME like 'ARCHIVE_CLOSE_DATE';                    
             end if;
             exit;
           end loop;

          /*�������� � ����� ����� � ���������*/         
           for rec in (select rowid,a.* from account a where header in ('A','C') and code = jr.code)
           loop
             if rec.code like '20202%' then 
               for rec_sub in (select rowid,a.* from account a where code like rec.code||'_%' )--and close_date is null)
               loop
                 v_ost_r := pledger.rSALDO(cHeader => rec_sub.header, cAccount => rec_sub.code, cCurrency => rec_sub.currency, dDate => l_Date);
                 v_ost := pledger.SALDO(cHeader => rec_sub.header, cAccount => rec_sub.code, cCurrency => rec_sub.currency, dDate => l_Date);
                  if v_ost = 0 and rec_sub.close_date is null then 
                   update account set close_date = l_Date where rowid = rec_sub.rowid;
                    else 
                      dbms_output.put_line('���� � �������� ��� ������: '||''''||rec_sub.code||''', �����='||v_ost_r||' ������='||v_ost||' ���� ��������= '||to_char(rec_sub.close_date,'dd.mm.yyyy'));
                  end if;
                end loop;
             end if;  
             v_ost_r := pledger.rSALDO(cHeader => rec.header, cAccount => rec.code, cCurrency => rec.currency, dDate => l_Date);
             v_ost := pledger.SALDO(cHeader => rec.header, cAccount => rec.code, cCurrency => rec.currency, dDate => l_Date);
             if v_ost_r = 0 and v_ost = 0 and rec.close_date is null then
               update account set close_date = l_Date where rowid = rec.rowid; 
               else 
                 dbms_output.put_line('���� � �������� ��� ������: '||''''||rec.code||''', �����='||v_ost_r||' ������='||v_ost||' ���� ��������= '||to_char(rec.close_date,'dd.mm.yyyy'));
             end if;
           end loop;
         end loop;
       dbms_output.put_line('Old_Reference: '||recs.Reference||' NewReference: '||l_next_Reference);
       commit;     
    end loop;
end;
/
--select * from config where NAME like 'ARCHIVE_CLOSE_DATE'

--�������� �������� ������
declare
 l_Date date ; 
 l_Saldo number;
 l_SaldoR number;
 j_id number;
 v_ost_r number;
 v_ost number;
 st_tmp varchar(50);
begin
 /*��������� ���������*/ 
 l_Date := to_date('02.09.2019','dd.mm.yyyy');
        for jr in (select * from journal where code in ('20202826600980000001')
                       --(select code from account where subdepartment in (select dept_id from zyx_deptvtb24 where date_start < '05-mar-2018') and bal = '20202')
                      and header = 'A' and work_date = l_Date and flag_debit = '-')
         loop
           for rec in (select rowid,a.* from account a where code = jr.code||'00007' and close_date is null) 
           loop
             l_Saldo := pledger.saldo(rec.header, rec.code, rec.currency, l_Date);
             if l_Saldo > 0 then
               select value into st_tmp from config where NAME like 'ARCHIVE_CLOSE_DATE'; 
               update config set value = to_char(l_Date-1,'dd.mm.yyyy') where NAME like 'ARCHIVE_CLOSE_DATE';
               l_SaldoR := pledger.Rsaldo(rec.header, rec.code, rec.currency, l_Date);
                  dbms_output.put_line('rec.code = '||rec.code||' jr.code = '||jr.code||' l_Saldo = '||l_Saldo);
               j_id := journal_id.nextval;               
               insert into journal (WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,BRANCH,RELATED,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT,HEADER,CODE,CURRENCY,VSUM,RSUM,FLAG_DEBIT)
                values (jr.work_date,jr.value_date,jr.DOCNUM,j_id,jr.OPERATION,jr.TYPE,jr.USERS,jr.BRANCH,jr.related,jr.ASSIST,jr.ASSIST_CURRENCY,jr.YSUBDEPARTMENT,rec.HEADER,rec.code,rec.currency,l_Saldo,l_SaldoR,'-');
               update config set value = st_tmp where NAME like 'ARCHIVE_CLOSE_DATE';           
             end if;
             exit;
           end loop;
 /*�������� � ����� ����� � ���������*/        
           for rec in (select rowid,a.* from account a where header in ('A','C') and code = jr.code) 
           loop
             if rec.code like '20202%' then 
               for rec_sub in (select rowid,a.* from account a where code like rec.code||'_%' and close_date is null) loop
                 v_ost_r := pledger.rSALDO(cHeader => rec_sub.header, cAccount => rec_sub.code, cCurrency => rec_sub.currency, dDate => trunc(sysdate));
                 v_ost := pledger.SALDO(cHeader => rec_sub.header, cAccount => rec_sub.code, cCurrency => rec_sub.currency, dDate => trunc(sysdate));
                  if v_ost = 0 then 
                   update account set close_date = l_Date where rowid = rec_sub.rowid;
                               dbms_output.put_line('rec_sub.code = '||rec_sub.code||' jr.code = '||jr.code);
                    else 
                      dbms_output.put_line('���� � ��������: '||''''||rec_sub.code||''', �����='||v_ost_r||' ������='||v_ost);
                  end if;
                               
                end loop;
             end if;  
             v_ost_r := pledger.rSALDO(cHeader => rec.header, cAccount => rec.code, cCurrency => rec.currency, dDate => trunc(sysdate));
             v_ost := pledger.SALDO(cHeader => rec.header, cAccount => rec.code, cCurrency => rec.currency, dDate => trunc(sysdate));
             if v_ost_r = 0 and v_ost = 0 and rec.close_date is null then
               update account set close_date = l_Date where rowid = rec.rowid;
              --              dbms_output.put_line('rec.code = '||rec.code||' jr.code = '||jr.code);           
               else 
                 dbms_output.put_line('���� � �������� ��� ������: '||''''||rec.code||''', �����='||v_ost_r||' ������='||v_ost);
             end if;
           end loop;
           commit;
         end loop;
       --dbms_output.put_line('Old_Reference: '||recs.Reference||' NewReference: '||l_next_Reference);
end;       

/
--����� � ���������
select
 COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) sald
 ,(select max(work_date) from ledger where header = a.header and code = a.code and currency = a.currency and work_date <= sysdate) dat
 ,a.* from account a where substr(code,1,20) in (select code from account where subdepartment in (select dept_id from zyx_deptvtb24 where date_start < '05-mar-2018') and bal = '20202')
and COALESCE((select wrest from ledger l WHERE header = a.header and code = a.code and currency = a.currency and rest_id = 0 and work_date =
 (select max(work_date) from ledger where header = l.header and code = l.code and currency = l.currency and rest_id = l.rest_id and work_date <= sysdate)),0) <> 0
and exists (select null from account where code = substr(a.code,1,20) and close_date is not null)
/

select r.rowid, r.* from archive r where date_work = '19-mar-2018'
                            and real_payers like '303%' and receivers_account like '20202%' and (mbfilid = mbgoid and type_doc = 6 or mbfilid <> mbgoid and type_doc = 2) 
                            and exists (select null from journal where docnum = r.reference and branch = r.branch) 
                            --and reference = 2824516675  
                 union all
                 select r.rowid, r.* from archive r where date_work = '19-mar-2018'
                        and payers_account like '303%' and receivers_account like '20202%' and type_doc in (610)
                        and exists (select null from journal where docnum = r.reference and branch = r.branch)
/                           