declare
numb varchar2(20):='971/2006/��';
ref  number;-- :=3807988;
code_ac  varchar2(20);
date_start  date :='31-dec-2012';
date_enf date :='31-jan-2013';
a1 number;
a2 number;
a3 number;
a4 number;
stake number; 
begin

select reference into ref from contracts where lower(doc_number) = numb and status =50 and type_doc = 4811;
select count(*) into a1 from coll1 where reference = ref;
DBMS_OUTPUT.PUT_LINE('                                                                              ');
if a1 =0 then
insert into coll1 select * from collector_contracts where reference =ref;
commit;
end If;
if a1 >0 then 
DBMS_OUTPUT.PUT_LINE('������ 1111 �����������');
end If;
DBMS_OUTPUT.PUT_LINE('������� '||numb||'  ('||ref);
select  t1.account  into  code_ac from contracts t1 where reference = ref ;
select percent  into stake from taxs_contracts where reference = ref  and operation = '21010107';
select sum(t.summa) into a1 from collector_contracts t where t.name = '210001'and t.reference = ref;
select pledger.rsaldo(ac1.header,ac1.code,ac1.currency,sysdate) into a2 from account ac1 where code =code_ac;
select round((sum(t.summa) * (to_date(date_enf)-to_date(date_start))/365*stake/100),2)  into a4 from collector_contracts t where t.name = '210001' and t.reference = ref;
select nvl(sum(summa),-1) into a3 from collector_contracts t where t.name = 'GRAPH_PERCENT' and t.reference = ref and work_date =date_enf ;
DBMS_OUTPUT.PUT_LINE('                                                                           ');
DBMS_OUTPUT.PUT_LINE( stake);
DBMS_OUTPUT.PUT_LINE(' ');
dbms_output.put_line( ' �� ��������  '||a1 ||'    ' ||a3   );
dbms_output.put_line('�� �����   '||a2 ||'    ' || a4 );   
DBMS_OUTPUT.PUT_LINE('                                                                               ');
select sum(summa) into a1 from  collector_contracts t where t.name = '21000207'and t.reference = ref and work_date <date_enf;
select sum(summa) into a2 from collector_contracts t where t.name = 'GRAPH_LOAN'and t.reference = ref and work_date <date_enf;
select ( pledger.rcredit(ac1.header,ac1.code,ac1.currency,AC1.OPEN_DATE ,sysdate)-pledger.rdebit(ac1.header,ac1.code,ac1.currency,AC1.OPEN_DATE+20 ,sysdate)) into a3 from account ac1 where code =code_ac;
dbms_output.put_line( '������ GRAPH_LOAN='||a2 ||'  �� 21000207= ' ||a1 || '  �� �����='|| a3 );
end;

-- select Ptools_credit.CALC_YEAR(3093983.79 , 13.5 , '31-oct-2012', '30-nov-2012', 'TWO_AS_TWO') from dual