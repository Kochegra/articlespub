declare
 i number;
  k number;
  m number;
  tmp Varchar2 (10);
  cCode varchar2(500);
  cCode1 varchar2(500);
  aarights varchar2(64);
begin
--alter session SET NLS_LANG=RUSSIAN_CIS.RU8PC866;
 aarights := '20B8711C20BB101FA49F0894E6C8AD05';
   cCode1 := '';
         cCode := '';
         for i in 0..length( aarights )/2 loop
         tmp := substr( aarights ,1 + i*2,2 );
         ccode1 := ccode1||chr(ascii(tmp));
          tmp := substr( aarights ,1 + i*2,1);
          k := ascii( substr( aarights ,1 + i*2,1 ) );
          --dbms_output.put_line('i= '||i||' k= '||k||' tmp = '||tmp);  
             if k > 57 then
                k := k-7;
             end if;
             k := k - ascii( '0' );
             m := k * 16;
          --  dbms_output.put_line('m= '||m||' k= '||k||' tmp = '||tmp);
            tmp := substr( aarights ,2 + i*2,1);   
             k := ascii( substr( aarights ,2 + i*2,1 ) );
             if k > 57 then
                k := k-7;
             end if;
             k := k - ascii( '0' );
             m := m + k;
           -- dbms_output.put_line('m= '||m||' k= '||k||' tmp = '||tmp);
             --cCode1 := cCode1||m;
             cCode := cCode || chr(m);
          end loop;
        dbms_output.put_line(cCode);       
        dbms_output.put_line(cCode1);
      -- for i in (SELECT value FROM V$NLS_VALID_VALUES WHERE parameter = 'CHARACTERSET') loop
      --   for j in (SELECT value FROM V$NLS_VALID_VALUES WHERE parameter = 'CHARACTERSET') loop
          --dbms_output.put_line(i.value||': '||convert(cCode,i.value,'CL8MSWIN1251'));
      --    dbms_output.put_line(convert(cCode,i.value,j.value));
      --   end loop; 
end loop;
end;             
/

select chr(ascii('B8')) from dual 