select Eid,b.* from boss_emp_all b where l_name = '����������' and f_name = '�����' 
/

select * from eid.eid_products where --reference = '5577481288852910' 
eid = 27279305 and pr_status = 50 and pr_type = 4
/

Declare
  v_result Varchar2(2000);
  r_card_header mbank.p_types.t_card_head;
  r_card_itog mbank.p_types.t_card_itog;
  r_card_oper mbank.p_types.t_tab_card_oper;
  r_card_oper_auth mbank.p_types.t_tab_trans_auth;
  cikl Number;
Begin
  v_result := --mbank.get_card_statement(5577486993351678, to_date('29032019','ddmmyyyy'), Sysdate, r_card_header, r_card_oper, r_card_oper_auth, r_card_itog, null, TRUE);
                mbank.get_card_statement(5417158841692157, to_date('29092019','ddmmyyyy'), Sysdate, r_card_header, r_card_oper, r_card_oper_auth, r_card_itog, null, TRUE);
   dbms_output.put_line('�����= '||r_card_header.FIRST_NAM||' '||r_card_header.CURR||' '||r_card_header.BEGIN_BALANCE||' '||r_card_header.AMOUNT_AVAILABLE);              
  cikl := 0;
  while (cikl < r_card_oper.count) loop
    insert into zyx_cont_cb (a,b,c,d,e,f) values ('AR',r_card_oper(cikl).CONTRACT_NUMBER ,to_char(r_card_oper(cikl).TRANS_DATE, 'yyyy.mm.dd'),r_card_oper(cikl).TRANS_AMOUNT,r_card_oper(cikl).TRANS_DETAILS,to_char(r_card_oper(cikl).POSTING_DATE, 'yyyy.mm.dd'));  
/*     
 dbms_output.put_line('�����= '||r_card_oper(cikl).CONTRACT_NUMBER 
                            ||', ����=' || to_char(r_card_oper(cikl).TRANS_DATE, 'yyyy-mm-dd') 
                            ||', �����='  || r_card_oper(cikl).TRANS_AMOUNT 
                            ||', ��������= '  || r_card_oper(cikl).TRANS_DETAILS);
--*/                             
      cikl := cikl + 1;
  End Loop;
dbms_output.put_line(v_result);
End;
/

select a,b,c,d,e,f from zyx_cont_cb where a = 'AR' --and substr(e,1,6) not in ('������')
--and d like '%6000%'
order by c

truncate table zyx_cont_cb
/

5577483318799236 ������� 5282853115153009
5577485589275838 ������� 5577485589275838
5577481435107853 ������� 5298848194266070
5577488303226129 �������� 5298841064109124 
5577485539046412 ������ 5298847039270859
4130641033525326 ������� 5298846994213607
5577481880042761 ��������� 5298848508113109 
5577486517424142 ����� 5417159111763033
5577487656436707 ��������� 5282850115637882
5298844437007843 ����� 5298844437007843
5298844116359143 ����������� 5298844116359143
5577489477693946 �������� 5298849229758214
5417153466286385 ������� 4652080672109308
5298841235575062 ������ 5298841235575062

/
select * from guides where type_doc = 2486
/
select distinct p.reference,h.eid,h.search_name from eid.eid_human h, eid.eid_products p where h.subdepartment in (191304)
and h.eid = p.eid and pr_status = 50 and pr_type = 2    
and rownum < 1000
/

Declare
  v_result Varchar2(2000);
  r_card_header mbank.p_types.t_card_head;
  r_card_itog mbank.p_types.t_card_itog;
  r_card_oper mbank.p_types.t_tab_card_oper;
  r_card_oper_auth mbank.p_types.t_tab_trans_auth;
  cikl Number;
Begin
  for hh in (select distinct p.reference,h.eid,h.search_name from eid.eid_human h, eid.eid_products p where h.subdepartment in --(191304)
             (191305,191306,191307,191308,191309,191310,191311,191312,191313,191314,191315)   
             and h.eid = p.eid and pr_status = 50 and pr_type = 2    
             --and rownum < 100
             )     
  loop                   
    v_result := mbank.get_card_statement(hh.reference, sysdate, Sysdate, r_card_header, r_card_oper, r_card_oper_auth, r_card_itog, null, TRUE);
    --dbms_output.put_line('�����= '||r_card_header.FIRST_NAM||' '||r_card_header.CURR||' '||r_card_header.BEGIN_BALANCE||' '||r_card_header.AMOUNT_AVAILABLE);              
    if r_card_header.AMOUNT_AVAILABLE > 300000 then 
      insert into zyx_cont_cb (a,b,c,d,e,f) values ('AR',hh.eid,hh.search_name,hh.reference,r_card_header.AMOUNT_AVAILABLE,to_char(sysdate,'yyyymmdd'));
    end if;    
  end loop;
--dbms_output.put_line(v_result);
End;
/

select distinct a,b,c,e,f from zyx_cont_cb where a = 'AR' 
order by to_number(e) desc

select distinct b "���",c "���", e from zyx_cont_cb where a = 'AR' 
order by to_number(e) desc