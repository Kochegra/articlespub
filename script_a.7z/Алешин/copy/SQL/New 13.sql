select * from eid.eid_human
/

select * from clients cl where subdepartment =5 and type_doc = 5 and status = 310 
and exists (select null from contracts where status = 50 and refer_client = cl.reference and branch_client = cl.branch)-- and date_open > sysdate -30)  
--order by related desc

eid.p_vip_get.get_vip_access

p_eid_tools_subdep.GetParam
/

declare
 SubDep varchar2(4000);
 nVIP_ACCESS number;
 nUserID number;
 nSubdepartment number;
 nEID number;
begin 
 nUserID := 854450;
 nSubdepartment := 191507;
 nEID := 25132591;
 nVIP_ACCESS := mbank.ptools.to_num_err(mbank.p_user_parameters.get_param(nUserID     => nUserID,
                                                   nSubdepID   => 5,
                                                   sParamName  => '������_��_VIP',
                                                   dDateActive => sysdate), '0');                           
  SubDep :=  ','||mbank.p_user_parameters.get_param(nUserID  => nUserID, nSubdepID  => 5,  sParamName  => '������_���������',  dDateActive => sysdate)||','; 
  --dbms_output.put_line('SubDep = '||SubDep); 
 -- dbms_output.put_line('nVIP_ACCESS = '||to_char(nVIP_ACCESS)); 
  for rec_pr in (select null from eid.eid_products pr where pr.eid = nEID and pr.pr_status <> 60 
                 and nvl(pr.date_close, sysdate + 1) > trunc(sysdate)
                 and (                                                  
                   (nVIP_ACCESS in (1, 2, 3) and nSubdepartment = pr.subdepartment and pr.pr_type < 2) or
                   (nVIP_ACCESS in (1, 2, 3) and nSubdepartment = eid.p_eid_tools2.GET_FILIAL_CARD_N(account, branch, pr_type, 'N', 'FIZ') and pr.pr_type >= 2) 
                   or  (nVIP_ACCESS in (2) and  instr(SubDep,','||to_char(pr.subdepartment)||',') > 0 and  pr.pr_type < 2 )                   
                 )
                
                )
  loop
    --return 3; -- ����� ���������
    dbms_output.put_line('EID = '||nEID);
  end loop;     
   dbms_output.put_line('�����');          
end;         

/
get_param( nUserID in NUMBER, nSubdepID in number, sParamName in varchar2, dDateActive in DATE := null)

select p_user_parameters.get_param(nUserID => u.User_ID, nSubdepID => u.Subdepartment,  sParamName  => '������_���������',  dDateActive => sysdate) from users u where User_ID = 854450;
/


Select (select status_mod from eid.eid_firma_modify where eid = :nEID and status_mod in (10, 20) and rownum < 2) fExistsMod, 
                        (select id from eid.eid_firma_modify where eid = :nEID and status_mod in (10, 20) and rownum < 2) nIDMod, 
                        --//(select 1 from eid.eid_subdepartments sub where sub.id = :nSubdep start with sub.id = :nUserBranch connect by prior sub.id = sub.parent) nSudepAccess, 
                        (select * from (select 1 from eid.eid_subdepartments sub where sub.id in (select fir.subdepartment from eid.eid_firma fir where fir.eid in (
                         select rel.eid from eid.eid_firma_relation rel start with rel.eid_to = :nEID 
                         connect by nocycle prior rel.eid = rel.eid_to 
                         and rel.status = 1 and rel.type_col in ('TWINS', 'MULTIFILIAL') 
                         union all 
                         select :nEID eid from dual)) start with sub.id in (select * from table(cast(mbank.convert_tools.str2tbl(nvl(:sUserBranchList, '-1')) as NumberTable))) 
                         connect by prior sub.id = sub.parent) where rownum < 2) nSudepAccess, 
                         
                        (select 1 from dual where nvl(eid.p_eid_tools_subdep.getparam(:nSubdep, 'BG'), '-1') = nvl(eid.p_eid_tools_subdep.getparam(:nUserBranch, 'BG'), '-2') and 
                         nvl(eid.p_eid_tools_subdep.getparam(:nUserBranch, 'BG_PRIOR'), '-1') = '1') nSudepAccess2,

                        (select 1 from dual where nvl(eid.p_eid_tools_subdep.getparam(:nSubdep, 'BG'), '-1') = nvl(eid.p_eid_tools_subdep.getparam(:nUserBranch, 'BG'), '-2') and 
                         nvl(eid.p_eid_tools_subdep.getparam(:nUserBranch, 'BG_PRIOR'), '-1') = '1') nSudepAccess2,
                          
                         eid.p_eid_firma_relation.check_status_relation(:nEID, null, 'TWINS', null, 1) nFlagTwins 
                         from dual;
                         
/


p_eid_tools_subdep.getparam (:nUserBranch, 'BG_PRIOR')

select * from eid.eid_firma where eid = 17696                          
                         
                         
                         select * from table(cast(mbank.convert_tools.str2tbl(nvl(:sUserBranchList, '-1')) as NumberTable)))
                         
                         convert_tools.str2tbl 