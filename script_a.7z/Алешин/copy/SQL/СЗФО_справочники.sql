select rowid,s.* from guides s where type_doc = 1198


        insert into guides(FOLDER,TYPE_DOC,OWNER,CHILD,DATE_WORK,CODE,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)
          select FOLDER,TYPE_DOC,OWNER,CHILD,DATE_WORK,CODE,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1 from guides@etalon g where type_doc = 1198 
          and not exists (select null from guides where type_doc = g.type_doc and nvl(code,'z') = nvl(g.code,'z')
           and nvl(code1,'z') = nvl(g.code1,'z') and date_work = g.date_work);
           --�������� �          
        --insert into variable_guides(name,reference,branch,value)              
        --  select name,gd_ref,branch,value from variable_guides where (reference,branch) in (select reference,branch  from guides g where type_doc = 5947 and code = to_char(rec.dept_id));
