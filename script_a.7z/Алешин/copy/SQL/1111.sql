select rowid, t.* from synergy_transactions t 
where vtb_tran_date > trunc(sysdate)-1
--and vtb_tran_id  in ('TS.0000000047189994','TS.0000000047183997','TS.0000000047130590','TS.0000000047152692','TS.0000000047184707')
--and vtb_tran_id like 'MB%'
--and doc303_reference is not null 
--and status in (0, 2, 3) 
--and doc303_branch = 191359
and doc_reference = 2767990878 
--2764858043


--'SP.205458701-641287'
-- 'SP.205465474-646168'
/

select reference,d.receivers_account,d.payers,d.summa,d.memo,t.vtb_tran_id from synergy_transactions t,documents d 
where vtb_tran_date > trunc(sysdate)-1
--and vtb_tran_id like 'MB%'
--and doc303_reference is not null 
--and status in (0, 2, 3) 
--and doc303_branch = 191359
--and doc_reference = 2766755868
--2764858043
and vtb_tran_id  in ('SP.205518949-689167','SP.205519505-689659','SP.205520562-690580','SP.205520667-690665')
and d.reference = t.doc_reference and d.branch = t.doc_branch  
/

select rowid,d.* from documents d where type_doc = 7 and summa =  17435

select * from journal_delete where docnum = 2765783781
/


--insert into journal_ZP
select j.* from journal j where docnum in 
(2839479682,2839479693
)
/

--delete journal j where docnum in 
(2839479682,2839479693
)
/
--������ ����� � ��� ����
select * from journal_zp
--update journal_zp 
--set code = '60322810400000000370'  --1
set assist = '60322810400000000370' --2
--set code = '60322978300000000370'  
--set assist = '60322978300000000370'
--set code = '60322840700000000370'  
--set assist = '60322840700000000370'
where docnum in 
(2839479682,2839479693)
--and substr(code,1,5) = '30305' --1
and substr(assist,1,5) = '30305'  --2
/
--insert into journal
select j.* from journal_zp  j where docnum in
--select rowid,j.* from journal_zp  j where docnum in
( 2839479682,2839479693
)
--and work_date = trunc(sysdate) --������������� ��� �������� SWIFT
/
select rowid,d.* from documents d where reference = 2800996349

/
--���������� ��������� (�� ���������)
select (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202') j, a.* from archive a
--update archive a set receivers_account = (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202') , real_receivers = (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202') 
where reference in 
(2804161600, 2805263168, 2805263171, 2805008045, 2805263176, 2805263166, 2805263164, 2805263174, 2805263165, 2805263160, 2805158697, 2805263173)
/

--update archive a set receivers_account = (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202') , real_receivers = (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202')
select (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202'),a.* from variable_archive a
--update variable_archive a  set value = (select code from journal where docnum = a.reference and branch = a.branch and substr(code,1,3) <> '202') 
where (reference,branch) in 
(select reference,branch from archive a where reference in 
(2804161600, 2805263168, 2805263171, 2805008045, 2805263176, 2805263166, 2805263164, 2805263174, 2805263165, 2805263160, 2805158697, 2805263173)
)
and substr(value,1,5) = '30305'   
--and substr(value,1,3) = '603'
/

--������� ����������
insert into documents
select * from archive where reference in (2823570949)

insert into variable_documents
select * from variable_archive where (reference,branch) in 
(select reference,branch from archive where reference in (2823570949))

delete archive where reference in (2823570949)
/

--��������� �������� � 60322 �� 30305810200810101001
select rowid,j.* from journal_ZP j where docnum in (2804161600, 2805263168, 2805263171, 2805008045, 2805263176, 2805263166, 2805263164, 2805263174, 2805263165, 2805263160, 2805158697, 2805263173)
--and substr(code,1,5) = '60322'
--30305810200810101001
order by docnum,work_date

/
--��������� ��������
declare
  j_id number;
  acc varchar2(30);
begin
  acc := '30305810200810101001';
  for rec in (select * from journal_ZP where docnum in (2839479682,2839479693)
                      and substr(code,1,5) = '60322')
  loop
    j_id := journal_id.nextval;
    insert into journal_ZP (HEADER,CODE,CURRENCY,VSUM,RSUM,WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,FLAG_DEBIT,BRANCH,RELATED,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT)
     values (rec.HEADER,rec.CODE,rec.CURRENCY,rec.VSUM,rec.RSUM,trunc(sysdate),trunc(sysdate),rec.DOCNUM,j_id,rec.OPERATION,rec.TYPE,rec.USERS,'+',rec.BRANCH,0,acc,substr(acc,6,3),rec.YSUBDEPARTMENT);
    insert into journal_ZP (HEADER,CODE,CURRENCY,VSUM,RSUM,WORK_DATE,VALUE_DATE,DOCNUM,JOURNAL_ID,OPERATION,TYPE,USERS,FLAG_DEBIT,BRANCH,RELATED,ASSIST,ASSIST_CURRENCY,YSUBDEPARTMENT)
     values (rec.HEADER,acc,substr(acc,6,3),rec.VSUM,rec.RSUM,trunc(sysdate),trunc(sysdate),rec.DOCNUM,j_id,rec.OPERATION,rec.TYPE,rec.USERS,'-',rec.BRANCH,0,rec.CODE,rec.CURRENCY,rec.YSUBDEPARTMENT);
    --commit;   
  end loop;                    
end;
/

--�������� � journal
--insert into journal
select j.* from journal_zp  j where docnum in
( 2839479682,2839479693)
and work_date = trunc(sysdate) --������������� ��� �������� SWIFT
/

select rowid, 
       sq.* 
from synergy_queries sq 
where vtb_tran_id in ('SP.205519886-689993') --'MB.933'
--status > 1
order by vtb_tran_date
/





select * from variable_documents where reference = 2765783781 and branch = 24


select * from archive where reference = 2789439962

select * from variable_archive where reference = 2789439962 and branch = 56
/


select * from documents where reference = 2804161600

select * from variable_documents where reference = 2804161600
union all
select * from variable_archive where reference = 2803801988

update documents d set folder = 0--set (receivers_account,real_receivers) = (select receivers_account,real_receivers from documents@dss where reference = d.reference)
where reference in (2804161600, 2805263168, 2805263171, 2805008045, 2805263176, 2805263166, 2805263164, 2805263174, 2805263165, 2805263160, 2805158697, 2805263173)

select * from documents where reference in (2804161600, 2805263168, 2805263171, 2805008045, 2805263176, 2805263166, 2805263164, 2805263174, 2805263165, 2805263160, 2805158697, 2805263173)


