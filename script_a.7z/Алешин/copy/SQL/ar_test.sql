create or replace package ar_tst1 is
  g number := 1;
end;
/

drop package body ar_tst1 
/

create or replace package ar_tst2 is
  function f return number;
  function f1 return number;
  function f2 return number;
end;
/

create or replace package body ar_tst2 is
  --i := 333;   
  function f return number is
   i number;
  begin    
    i := 444;
    return i;
  end;
  function f1 return number is
  begin
    return ar_tst1.g+f;
  end;
  function f2 return number is
  begin
    return ar_tst1.g;
  end;
end;
/


begin
  dbms_output.put_line(ar_tst2.f);
end;
/

select o.* from user_objects o where 1=1
--and o.status = 'INVALID' 
and OBJECT_NAME like 'AR_TST%'

/

begin
  dbms_output.put_line(ar_tst2.g);
end;
/

select * from v$version
/

select * 
  from dba_dependencies 
 where referenced_name = 'AR_TST1' 
 /
 
begin
  --dbms_output.put_line('g='||ar_tst1.g);
  --dbms_output.put_line('func f='||ar_tst2.f);
  --dbms_output.put_line('func f1='||ar_tst2.f1);
  dbms_output.put_line('func f2='||ar_tst2.f2);
end;