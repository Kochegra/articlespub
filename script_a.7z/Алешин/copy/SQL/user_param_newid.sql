drop table tmp_user_par
create table tmp_user_par as select * from user_parameters where id > 888888

drop table tmp_user_par_V
create table tmp_user_par_V as select * from user_param_values where id > 888888

select count(*) from user_parameters u where id > 888888
select count(*) from user_param_values pv where id > 888888

select count(*) from tmp_user_par
select count(*) from  tmp_user_par_V
 
--����������� �������

select user_parameters_id.nextval from dual

delete from user_parameters where id > 888888
delete from user_param_values where id > 888888

insert into user_parameters select null,depart_id,NAME from tmp_user_par

select * from user_parameters where id > 888888
select * from user_param_values pv where id > 888888

--��������� ������ ��������� � ����� id
insert into user_param_values
select nid,upv.depart_id,user_id,value,activated  from  tmp_user_par_V upv,
(select up_new.id nid,up.id,up.depart_id from user_parameters up_new, tmp_user_par up where up_new.depart_id = up.depart_id and up_new.name = up.name) uspa  
where uspa.id = upv.id and uspa.depart_id = upv.depart_id   

--������������ ��������
/*
DROP SEQUENCE MBANK.USER_PARAMETERS_ID;

CREATE SEQUENCE MBANK.USER_PARAMETERS_ID
  START WITH 888889
  MAXVALUE 1000000000000000000000000000
  MINVALUE 1
  CYCLE
  CACHE 5
  ORDER;

DROP SYNONYM INTER_MBANK.USER_PARAMETERS_ID;
CREATE OR REPLACE SYNONYM INTER_MBANK.USER_PARAMETERS_ID FOR MBANK.USER_PARAMETERS_ID;

DROP SYNONYM IBANK.USER_PARAMETERS_ID;
CREATE OR REPLACE SYNONYM IBANK.USER_PARAMETERS_ID FOR MBANK.USER_PARAMETERS_ID;

GRANT SELECT ON MBANK.USER_PARAMETERS_ID TO INTER_MBANK;
GRANT ALTER, SELECT ON MBANK.USER_PARAMETERS_ID TO ST_ADM_MBANK;
GRANT SELECT ON MBANK.USER_PARAMETERS_ID TO ST_AUD_MBANK;
GRANT SELECT ON MBANK.USER_PARAMETERS_ID TO ST_MBANK;
*/