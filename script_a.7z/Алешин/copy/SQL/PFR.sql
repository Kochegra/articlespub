select * from EID.PFR_IMP where client_eid = 10571529 and 
date_create > trunc(sysdate) order by date_create desc
/  
select rowid,p.* from EID.PFR_MONITOR p where dtstart >= trunc(sysdate)-1/48-- to_date('1.12.2015 10:02:46','dd.mm.yyyy hh24.mi.ss')
--AND NCLNT_EID = 24409886  
 order by dtstart desc
/ 

select trunc(dtstart),count(serr_soob),count(*),round(count(serr_soob)/count(*)*100) from EID.PFR_MONITOR where dtstart > trunc(sysdate)-4  group by  trunc(dtstart)
/ 
select * from bill_params

--client_eid = 17975374 and 
select * from all_tables where table_name like '%EGRUL%'

select * from SCORING_EGRUL_REQUEST where request_date > sysdate - 1/12