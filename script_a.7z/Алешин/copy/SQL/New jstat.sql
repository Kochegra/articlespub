declare
dt date;
i number;
begin
 dt := to_date('15.08.2016','dd.mm.yyyy');
 i := 0;
while dt < to_date('10.10.2017','dd.mm.yyyy') loop
insert into zyx_jstat
select /*+index(j JOURNAL_DATE_IDX)*/ mbfilid,work_date,count(*) cnt from journal j where header = 'A' and work_date = dt group by work_date;
i := i + 1;
dt := dt + 1;
if i > 32 then
  commit;
  i := 0;
end if;
end loop;
commit;
end; 