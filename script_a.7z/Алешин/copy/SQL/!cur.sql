select * from variable_archive  where reference = 2193778654

select * from archive  where reference = 2193778654

Select distinct srv_list.status_obj, gd.name status_name  from eid.eid_service_obj_list srv_list, guides gd  where 1=1  and eid = -11113442 and srv_list.id = 'EID_CLOSE_CARD_REQ_4652070172837763' and gd.type_doc = 4723 and gd.code1 = to_char(srv_list.status_obj)  order by 2

Select rowid,d.* from eid.eid_service_obj_list  d where 
d.id = 'EID_CLOSE_CARD_REQ_4652070172837763' 


select rowid,d.* from documents d where reference = 2224363650

select * from variable_documents where reference = 2224363650