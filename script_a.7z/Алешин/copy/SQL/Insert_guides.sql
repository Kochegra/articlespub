--insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1)
select * from (select BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,'405011' code,NAME,STR1,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3,CODE1 from guides where 
type_doc = 10036 and code = '405000' and str4 in (1,13,14,16,21,23,31,35,43,44,46,5,51)) g
where not exists (select null from  guides@vtbmain where type_doc = g.type_doc and code = g.code and str4 = g.str4 and str3 = g.str3) 
/

--insert into guides(BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,CODE1)
select mbfilid,0,14009,978042,'01jan1990',18,'��� ������','TYPES.CODE' from dual

'[X]',decode(ur.rights,-1,'[���]',-2,'[_��]',-3,'[�_�]',-4,'[__�]',-5,'[��_]',-6,'[_�_]',-7,'[�__]',-8,'[___]'
/

--insert into guides@dss
select * from guides g where type_doc = 14009--8067 and str1 = 997649 
/
select * from users_all where instr(upper(user_name),upper('������� �'))>0
/
select rowid,g.* from guides g where type_doc = 14009--8067 and str1 = 997649  
/
insert into guides
select guides_reference.nextval,191,null,0,8067,0,0,0,0,'01-jan-1900','UR'||user_id,'UR',user_id,null,null,null,null,1,2,null,null,null,null,null,null,' ' from users_all ua where 
user_id in (994893,995570,995445, 995444,995573,995443,995571,998453,997649 )
and not exists (select null from guides where type_doc = 8067 and str1 = ua.user_id)
/
insert into guides@khabarovsk
select guides_reference.nextval@khabarovsk,191,null,0,type_doc,0,0,0,0,'01-jan-1900',code,name,str1,str2,str3,str4,str5,NUM1,NUM2,NUM3,NUM4,NUM5,null,null,null,' ' from guides g where type_doc = 8067 and 
str1 in (385517,383131)
and not exists (select null from guides@khabarovsk where type_doc = 8067 and str1 = g.str1)
/

select guides_reference.nextval@nsibirsk,guides_reference.nextval@nnovg,guides_reference.nextval from dual

select max(id) from guides@nsibirsk
select max(id) from guides
select * from users@nsibirsk where user_id in (570001125,570006214,571575,240309434,240325374,240325375)
select * from users@nnovg where user_id in (496693,540002149)
/
--insert into guides
select guides_reference.nextval--,BRANCH,ID,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,NAME
,'191320'
,STR2,STR3,STR4,STR5,NUM1,NUM2,NUM3,NUM4,NUM5,DATE1,DATE2,DATE3
,code||'191320'||str3
from guides where type_doc = 9936 and str1 = 405008
/

--�������� � ����������  9936 ����� �� �������������� (s.id in (191306,191307,191308,191309,191310,191311,191312,191313,191314) �� �������� � g.str1 = 191304
--insert into guides
select guides_reference.nextval,g.BRANCH,g.ID,g.FOLDER,g.TYPE_DOC,g.STATUS,g.OWNER,g.VERSION,g.CHILD,g.DATE_WORK,g.CODE,g.NAME
,s.id,g.STR2,g.STR3,g.STR4,g.STR5,g.NUM1,g.NUM2,g.NUM3,g.NUM4,g.NUM5,g.DATE1,g.DATE2,g.DATE3,g.code||s.id||g.str3
from guides g,subdepartments s where g.type_doc = 9936 and str1 = '15' and s.id in (191507) --and code = '1000591'
and not exists (select null from guides where type_doc = g.type_doc and code = g.code and str1 = s.id) 
/

select * from guides where type_doc = 9936 and code = '850331'
/
select * from (
select distinct code,str3 from guides where type_doc = 9936 and str1 <> '191'
minus
select distinct code,str3 from guides where type_doc = 9936 and str1 = '191'
) where code = '850100'
/


select distinct
mbfilid BRANCH,0 FOLDER,9936 type_doc, 0 STATUS, 978042 OWNER,0 VERSION, 0 CHILD 
,date_work, g.code ,'191' str1, str2, str3, substr(g.str4,1,8)||'00000'||substr(g.str4,-7) str4, str5, g.code||'191'||str3 code1 from guides g 
where g.type_doc = 9936 and (g.code,g.str3) in 
(
select distinct code,str3 from guides where type_doc = 9936 and str1 <> '191'
minus
select distinct code,str3 from guides where type_doc = 9936 and str1 = '191'
)
and not exists (select null from guides where type_doc = 9936 and str1 = '191' and code = g.code and str3 = g.str3)
 and code = '850100'
/

--������������� ����������� 9936 ����� ����� ���� ��������
declare
  acc varchar2(50);
begin	
--insert into guides(BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,STR1,STR2,STR3,STR4,STR5,CODE1)
for gg in (select distinct
mbfilid BRANCH,0 FOLDER,9936 type_doc, 0 STATUS, 978042 OWNER,0 VERSION, 0 CHILD 
,date_work, g.code ,'191' str1, str2, str3, substr(g.str4,1,8)||'00000'||substr(g.str4,-7) str4, str5, g.code||'191'||str3 code1 from guides g 
where g.type_doc = 9936 and (g.code,g.str3) in 
(
select distinct code,str3 from guides where type_doc = 9936 and str1 <> '191'
minus
select distinct code,str3 from guides where type_doc = 9936 and str1 = '191'
)
and not exists (select null from guides where type_doc = 9936 and str1 = '191' and code = g.code and str3 = g.str3)
) loop
 begin 
  acc := gg.str4; 
  for aa in (select code from account where header = 'A' and currency = '810' and code = paccount.KEYACCOUNT(gg.str4,' '))
  loop
    acc := aa.code;
  end loop;
  insert into guides(BRANCH,FOLDER,TYPE_DOC,STATUS,OWNER,VERSION,CHILD,DATE_WORK,CODE,STR1,STR2,STR3,STR4,STR5,CODE1)
  values(gg.BRANCH,gg.FOLDER,gg.TYPE_DOC,gg.STATUS,gg.OWNER,gg.VERSION,gg.CHILD,gg.DATE_WORK,gg.CODE,gg.STR1,gg.STR2,gg.STR3,acc,gg.STR5,gg.CODE1);
 exception when OTHERS then
   dbms_output.put_line('������ >'||'gg.code = '||gg.code||' gg.code = '||gg.code1 ); 
 end; 
end loop;
end;
/

--������ ���������� � ������� �����
select * from
--delete 
guides g where type_doc = 9936 and str1 = '191' and
 exists (select null from guides where type_doc = g.type_doc and str1 = g.str1 and code = g.code and str4 = g.str4 and str3=g.str3 and date_work < g.date_work)
/

--������ �����
select (select code from account where header = 'A' and currency = '810' and code = paccount.KEYACCOUNT(g.str4,' ')) cd,g.* from guides g
--update guides g set str4 = (select code from account where header = 'A' and currency = '810' and code = paccount.KEYACCOUNT(g.str4,' '))
 where type_doc = 9936 and str1 = '191'
and (select code from account where header = 'A' and currency = '810' and code = paccount.KEYACCOUNT(g.str4,' ')) <> str4
/


--insert into guides
select --guides_reference.nextval,
g.BRANCH,g.ID,g.FOLDER,g.TYPE_DOC,g.STATUS,g.OWNER,g.VERSION,g.CHILD,g.DATE_WORK,g.CODE,g.NAME
,s.id,g.STR2,g.STR3,g.STR4,g.STR5,g.NUM1,g.NUM2,g.NUM3,g.NUM4,g.NUM5,g.DATE1,g.DATE2,g.DATE3,g.code||s.id||g.str3
from guides g,subdepartments s where g.type_doc = 9936 and str1 = '191' and s.id in (select distinct num4 from zyx_store z where OPER = 'FIL_MIGR' and num1 = 76)
and not exists (select null from guides where type_doc = g.type_doc and code = g.code and str1 = s.id) 
/

--insert into guides
select guides_reference.nextval,g.BRANCH,g.ID,g.FOLDER,g.TYPE_DOC,g.STATUS,g.OWNER,g.VERSION,g.CHILD,g.DATE_WORK,g.CODE,g.NAME
,to_char(s.id),g.STR2,g.STR3,g.STR4,g.STR5,g.NUM1,g.NUM2,g.NUM3,g.NUM4,g.NUM5,g.DATE1,g.DATE2,g.DATE3,to_char(guides_reference.nextval)
from guides g,subdepartments s where g.type_doc = 10233 and str1 = '15' and s.id in (191513)
and not exists (select null from guides where type_doc = g.type_doc and code = g.code and str1 = s.id) 
/
select * from guides g where g.type_doc = 10233 and str1 = '15'

--191344
/
--insert into guides(branch,folder,type_doc,status,owner,date_work,code,name,str1,str2,str3,str4,str5,num1,num2,num3,num4,num5,date1,date2,date3,code1)
select g.branch,folder,type_doc,status,g.owner,to_date('10.02.2017','dd.mm.yyyy'),g.code,g.name,str1,str2,str3,z.f,str5,num1,num2,num3,num4,num5,date1,date2,date3,g.code||g.str1||g.str3  
from guides g, zyx_cont_cb z  where g.type_doc = 9936 and substr(g.code,1,3) = '100'
and g.str4 = trim(z.a) and substr(z.a,1,1) = '7' 
and code1 = g.code||g.str1||g.str3
-- date_work = (select max(date_work) from guides where code = g.code and str1 = g.str1 and str3 = g.str3 and str4 = g.str4 and code1 = code||str1||str3 )
/
--��������� ��������� 
select rowid,g.* from guides g where type_doc = 9936  --and str1 = 59 --and code = '800183' 
and str4 = '70601810401931111501'
-- '70601810901091111501'
/
--70601810401931111501
-- ���������� �������������
select * from subdepartments where instr(upper(name),'�����') > 0
/

select * from guides g,subdepartments s where g.type_doc = 9936 and g.str1 = 191317 and s.id in (191320)

 /
select * from all_tab_columns where table_name = 'GUIDES'
/

select guides_reference.nextval,191,null,0,8067,0,0,0,0,'01-jan-1900','UR'||user_id,'UR',user_id,null,null,null,null,1,2,null,null,null,null,null,null,' ' from users_all ua where 
user_id in (235286421)
and not exists (select null from guides where type_doc = 8067 and str1 = ua.user_id)

--������ ������������ �����
select * from users where user_id =  1189212
select rowid,g.* from guides g where type_doc = 5947 and code = '149'
select rowid,g.* from variable_guides g where reference = 44595426
44595426

/

select * from guides where type_doc = 13067 and code in select 

code1 := to_char(sysdate,'J')+to_char(sysdate,'SSSSS');   


--13067 �������
--insert into guides (BRANCH,FOLDER,TYPE_DOC,OWNER,DATE_WORK,CODE,NAME,STR1,STR2,STR3,STR4,CODE1)
select g.*,code||name||str1 code1 from(
  select mbfilid branch, 0 folder, '13067' type_doc, 1403 owner, to_date('01.01.1990','dd.mm.yyyy') date_work,
  (select to_char(max(subd_id)) from eid.eid_subdep_variable sv,eid.eid_subdepartments s where 
     sv.type = 'BISQUIT_ID' and to_number(sv.value) = to_number(z.a) and sv.status = 1 and s.deleted <> 1) code,
  z.b name, z.c str1, z.d str2, z.e str3, z.f str4  
  from zyx_cont_cb z 
  where exists (select null from eid.eid_subdep_variable where type = 'BISQUIT_ID' and to_number(value) = to_number(z.a))
  
 ) g
 where not exists (select null from guides where type_doc = g.type_doc and code = g.code and name = g.name and str1 = g.str1)