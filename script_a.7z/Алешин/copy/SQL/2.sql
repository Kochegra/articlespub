DECLARE
  reff number:= 3808104;
  bran number := 191228;
--  dat__ date:='31-dec-2008';
  dat__ date:='31-dec-2012';
   ---------------------
   annusum1 number;
   annusum2 number;
  Date_document_cb DATE;
  date_prev date;
  rgStake NUMBER;
  rgStake_Prev NUMBER;
  rgStake_Old NUMBER;
  rgStake_new number;
  rgContracts CONTRACTS%ROWTYPE; 
  udal number:=0;
  AnnuSum number:=-1;
  dat1 date;
  sv varchar2(500);
  sc number;
  dopen date;
--
  rgAnnual_MainS varchar2(500);
    Function ROUND_ANNUAL(raContracts in Contracts%rowtype)
    Return Number is
    Begin
      return 2;
      if raContracts.Date_open <= to_date('01.03.2006', 'dd.mm.yyyy')
      and raContracts.Type_doc in (1800, 2048,1714, 1880, 1881, 454)
      Then
        Return -1;
      else
        Return 0;
      end if;
    end ;
----------------------
 function GENERATE_GRAPH(ggBranch in Number
                            , ggReference in Number
                            , ggTYPE_DOC in NUMBER := Null
                            , p_Annual in NUMBER := Null)
    return varchar2  is
     ggRESULT Varchar2(200);
     ggContracts Contracts%Rowtype;
     ggType    Number;
     ggStake   Number;
     ggStake0  Number;
     ggStake_Prev Number;
     ggCommission Number;
     ggFirst_Date Date ;
     ggLast_Date  Date ;
     ggNext_Date  Date ;
     ggPerc_Part   Number;
     ggPerc_Fixed  Number;
     ggCommiss      Number;
     ggRest      Number;
     ggPayCount      Number;
     ggLoan_Part Number;
     ggComm_Part Number;
     ggPerc_Total Number;
     ggTmp_Date   Date;
     ggAnnual     Number;
     ggTmp_Num   Number;
     ggAnnual_Main Number;
     ggTmpStr   Varchar2(200);
     ggCount     Number;
     ggTaxs P_Taxs.tTaxs;
     ggSaldo P_Taxs.tSaldo;
     ggSald0 P_Taxs.tSaldo;
     ggDiscount P_taxs.tSaldo;
     ggDiscount_Index Number;
     ggPercRound Number;
     ggFREE_LOAN_PERIOD Number;
     ggTempNext_Date    Date;
     l_PAY_DAY          number;
     l_Summa            Number;
    begin
      IF  Not UNIVERSE.GET_CONTRACT_REC(ggReference, ggBranch, NULL, NULL, NULL,
                               ggContracts)
      Then
        ggRESULT := '������� �� ������ ';
        Goto GENERATE_GRAPH_RETURN;
      end if;
      if ggContracts.Currency in ('392')
      Then
        ggPercRound := 0;
      else
        ggPercRound := 2;
      end if;
      l_Summa := nvl(Universe.VARIABLE_CONTRACT(ggContracts.Branch, ggContracts.Reference, 'SALDO'), 0);
      ggType       := Nvl( ggType_Doc , ggContracts.Type_Doc);
      ggFREE_LOAN_PERIOD := UNIVERSE.SALDO_COLLECTOR(ggContracts.Branch, ggContracts.Reference, 'FREE_LOAN_PERIOD', ggContracts.currency, ggContracts.Date_open +5);
      if UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'PERIODDEBT') >=0
      and ggContracts.type_doc in (2880, 2881, 3280,3800, 2800, 1454, 3080, 3048, 3348, 3880, 3881)
      Then
        ggPayCount   := PTOOLS_LOAN.PERIODS_AMOUNT(ggContracts,
            ggContracts.Date_open + ggFREE_LOAN_PERIOD);
dbms_output.put_line('111');            
      else
        if ggFREE_LOAN_PERIOD > 0
        then
          iF ggContracts.TYPE_DOC in (3280,3080,2881,2880,1880,1881, 3880, 3881,4381,4387)
          then
            ggPayCount   := UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'PERIOD_M') -1;
dbms_output.put_line('112');            
          else
            ggPayCount   := PTOOLS_LOAN.PERIODS_AMOUNT(ggContracts,
              ggContracts.Date_open + ggFREE_LOAN_PERIOD);
dbms_output.put_line('113');            
          end if;
        else
          ggPayCount   := UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'PERIOD_M');
          ggPayCount   := round(months_between(ggContracts.Date_work,ggContracts.date_open));
dbms_output.put_line('114');            
        end if;
      end if;
--dbms_output.put_line('115   '||ggPayCount);   return '1';         
      if  ggPayCount <= 0
      then
        if ggContracts.Type_Doc = 1880
        and  UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'IsFromPreIpotheka')>0
        Then
           ggPayCount   := PTOOLS_LOAN.PERIODS_AMOUNT(ggContracts);
           ggTmp_Date := PTOOLS_LOAN.DATE_PERIOD( ggContracts, 1);
           ggPayCount := Round(months_between(ggContracts.Date_Work, ggTmp_Date));
           ggTmp_Num := ggTmp_Date +1 - ggContracts.Date_open;
           ggTmp_Num := ggTmp_Num  -Universe.Saldo_Collector(ggContracts.Branch, ggContracts.Reference, 'FREE_LOAN_PERIOD', ggContracts.Currency, ggContracts.Date_work)
           ;
           if ggTmp_Num > 0
           Then
             ggResult := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'FREE_LOAN_PERIOD',
                                   ggContracts.Currency ,   ggContracts.Date_Open,
                                   ggTmp_Num,
                                   -ggContracts.Reference,   Globals.UserID      , ggContracts.Branch );
            end if;
            ggType := 2800;
    --      Goto GENERATE_GRAPH_RETURN;
        else
          ggRESULT := '������ � ������� �� ������.';
          Goto GENERATE_GRAPH_RETURN;
        end if;
      end if;
      if ggType in ( 1880, 1881, 3490, 3880, 3881, 4258, 4259, 4262, 4519, 4381, 4387)
      Then
        ggType := 2800;
      end if;
      If ggType in ( 3800, 2800, 1454, 3048, 3348)
      and UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'PAY_TYPE') = 1
      then
        Delete Collector_Contracts
        Where Reference  = ggContracts.Reference
        And Branch = ggContracts.Branch
        and Name in  ('GRAPH_ANNUAL' , 'SUMMA_MONTH');
        Universe.Input_var_contr(ggBranch, ggReference, 'SUMMA_MONTH',
             replace(to_char( Round(l_Summa/ggPayCount,ggPercRound)), ' ') );
        ggResult := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'SUMMA_MONTH',
                                   ggContracts.Currency ,   ggContracts.Date_Open,
                                   Round(l_Summa/ggPayCount,ggPercRound),
                                   -ggContracts.Reference,   Globals.UserID      , ggContracts.Branch );
        Goto GENERATE_GRAPH_RETURN;
      else
        Delete Collector_Contracts
        Where Reference  = ggContracts.Reference
        And Branch = ggContracts.Branch
        and Name = ( 'SUMMA_MONTH');
        Universe.Input_var_contr(ggBranch, ggReference, 'SUMMA_MONTH', null);
      end if;
      ggCommission := UNIVERSE.NUM_CONTRACT(ggBranch, ggReference, 'UNumEdit2')/100;
      ggComm_Part := Round(ggCommission * l_Summa ,ggPercRound);
      If ggType in ( 3800, 2800, 1454, 2880, 2881, 3280, 3048, 3348, 3080, 3881, 3880)
      Then --- ����������
        ggTaxs := p_taxs.GET_PERC('21010107', ggContracts, ggContracts.Date_Open, ggContracts.Date_Open);
        IF ggTaxs.Count <1
        Then
          ggResult := '�� ����������� ������.';
          Goto GENERATE_GRAPH_RETURN;
        end if;
        ggStake :=    P_TAXS.FIND_PERC( ggTaxs, ggContracts.Date_Open, l_Summa);
        ggAnnual := P_TAXS.Get_Annual(ggStake/100, l_Summa, ggPayCount , 0, ggComm_Part);
        Delete Collector_Contracts
        Where Reference  = ggContracts.Reference
        And Branch = ggContracts.Branch
        and Name = 'GRAPH_ANNUAL';
        ggResult := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'GRAPH_ANNUAL',
                                   ggContracts.Currency ,   ggContracts.Date_Open,
                                   ggAnnual,
                                   -ggContracts.Reference,   Globals.UserID      , ggContracts.Branch );
        Goto GENERATE_GRAPH_RETURN;
      end if;--- /����������
      IF   ggPayCount = 0
      Then
        Return   '  ������ ';
      end if;
      ggTaxs :=  p_taxs.Get_Perc( '21010107', ggContracts, ggContracts.Date_Open, Add_Months(ggContracts.Date_Open , ggPayCount) );
      if ggTaxs.Count <=0
      Then
          Return '��� ���������� ������';
      end if;
      p_Taxs.COMPLETE_TAXS('21010107', ggContracts, ggTaxs);
      ggStake0  := P_Taxs.FIND_PERC(ggTAXS , ggContracts.Date_Open , l_Summa);
dbms_output.put_line(  'ggStake0='||ggStake0||'    l_Summa='||l_Summa||'  ggPayCount='||ggPayCount);    
      IF p_Annual is null or p_Annual <= 0 THEN
            ggAnnual_Main := P_TAXS.Get_Annual(ggStake0/100, l_Summa, ggPayCount , ROUND_ANNUAL(ggContracts), ggComm_Part);
      ELSE
            ggAnnual_Main := p_Annual;
      END IF;
      ggDiscount(1).Rest := 0;
      Delete   From  collector_contracts
      where reference=ggContracts.Reference
      and Branch = ggContracts.Branch
      and Name in ('GRAPH_LOAN' , 'GRAPH_PERCENT', 'GRAPH_COMMISSION') and work_date>ggContracts.date_open;
    <<GENERATE_GRAPH_LOOP>>
      ggDiscount_Index := 1;
      ggStake :=     ggStake0;
      ggStake_Prev := ggStake;
      ggAnnual :=   ggAnnual_Main - ggDiscount(ggDiscount_Index).Rest;
      ggAnnual :=annusum1;
dbms_output.put_line( 'ggAnnual_Main='||ggAnnual_Main||'      ggDiscount(ggDiscount_Index).Rest='||ggDiscount(ggDiscount_Index).Rest);  
      if ggAnnual < 0
      Then
        ggResult := '�� ���������� �������� ������������ �������. ( '||ggAnnual||' )';
        Goto GENERATE_GRAPH_RETURN;
      end if;
      ggPerc_Part   := 0;
      ggPerc_Total  := 0;
      ggPerc_Fixed  := 0;
      ggRest  := l_Summa;
      ggFirst_Date := ggContracts.Date_Open +1;
      ggLast_Date  := ggContracts.Date_Work;
      ggCount := 0 ;
      ggSaldo  := ggSald0;
      While ggCount < ggPayCount
      and ggResult is null
      Loop
        IF ( ggStake_Prev != ggStake)
        THEN-- �� ������� ��� ���������� ������� ����� ������� ������
          --�� � ���� ������ ����� ���������
          if ggStake <= 0
          Then -- �� ����� ���� �� ����� �������, ��� ��� ������~!!!
            ggStake := ggStake_Prev;
          else
            ggDiscount_Index := ggDiscount_Index + 1;
            if ggDiscount_Index > ggDiscount.Count
            Then
              ggDiscount(ggDiscount_Index).Rest := 0;
            end if;
            ggAnnual := P_TAXS.Get_Annual(ggStake/100, ggRest, Greatest(1,ggPayCount-ggCount) , Round_Annual(ggContracts), ggComm_Part);
            ggAnnual := ggAnnual - ggDiscount(ggDiscount_Index).Rest;
            ggStake_Prev := ggStake;
            if ggAnnual <= 0
            then
              ggResult := '�������� ���������� ������� � �����������: '||ggAnnual;
            end if;
          end if;
        END IF;
        ggNext_Date := Least(Ptools_loan.NEXT_PAY_DAY(ggContracts, ggFirst_Date), ggLast_Date);
    --DBMS_OUTPUT.PUT_LINE('ggNext_Date:'||ggNext_Date);
    --    ggNext_Date := Least(PTOOLS_LOAN.DATE_PERIOD( ggContracts, ggCount +1), ggLast_Date);
        ggPerc_Part := Ptools_credit.CALC_YEAR(ggRest , ggStake , ggFirst_Date, ggNext_Date, 'TWO_AS_TWO');
        ggPerc_Part := Round(ggPerc_Part,ggPercRound);
dbms_output.put_line(ggNext_Date||'     ggPerc_Part='||ggPerc_Part||'   ggRest='||ggRest||'  ggStake='||ggStake||'   '||ggFirst_Date||'   '|| ggNext_Date );        
        ggPerc_Total := ggPerc_Total + ggPerc_Part;
        ggPerc_Part :=  ggPerc_Total - ggPerc_Fixed;
        ggLoan_Part := Least( ggRest, ggAnnual - ggPerc_Part - ggComm_Part) ;
        if ggCount + 1 >= ggPayCount
        Then -- ��������� �����
          if  ggLoan_Part < ggRest
          Then
            ggLoan_Part := ggRest;
          else
            null;
          end if;
        else null;
          if ggLoan_Part < 0
          then
            ggLoan_Part := 1;
            ggPerc_Part   := ggAnnual - ggLoan_Part - ggComm_Part;
          end if;
        end if;
    ---����� ������ � ���������
        ggCount := ggCount +1;
        ggSaldo(ggCount ).Work_Date := ggNext_Date;
        ggSaldo(ggCount ).Rest := ggLoan_Part;
        ggSaldo(ggCount ).Debit := ggPerc_Part;
        ggSaldo(ggCount ).Credit := ggComm_Part;
        ggFirst_Date := ggNext_Date + 1  ;
        ggRest := Greatest(0, ggRest - ggLoan_Part );
        ggPerc_Fixed := ggPerc_Fixed + ggPerc_Part;
        ggStake := P_Taxs.FIND_PERC(ggTAXS , ggNext_Date , ggRest);
      end Loop;
--return '2';
      if ggResult is not null
      Then
        GOTO GENERATE_GRAPH_RETURN;
      end if;
      if ggSaldo.Count >0
      Then
        if ggLOAN_PART <= 0
        and ggPERC_PART <= 0
        Then
          ggDiscount(ggDiscount_Index).Rest  := ggDiscount(ggDiscount_Index).Rest -100;
          if ggDiscount(ggDiscount_Index).Rest > 1
          then
            ggResult := '�������� �������� �������� ��� ������� �������';
            Goto GENERATE_GRAPH_RETURN;
          else
            Goto GENERATE_GRAPH_LOOP;
          end if;
    /*  --���������� ������ ��� ������� ��������� �������
        elsif ggLOAN_PART > 0
        and ggLOAN_PART >= ggAnnual * 1.5
        Then
          ggDiscount(ggDiscount_Index).Rest  := ggDiscount(ggDiscount_Index).Rest -1;
          if ggDiscount(ggDiscount_Index).Rest < -20
          then
            ggResult := '�������� �������� �������� ��� ������� �������';
            Goto GENERATE_GRAPH_RETURN;
          else
            Goto GENERATE_GRAPH_LOOP;
          end if;
    */
        end if;
      end if;
    --RETURN NULL;
      ggCount := 1;
      wHILE ggCount <= ggSaldo.cOUNT
      Loop
    --DBMS_OUTPUT.PUT_LINE(ggSaldo(ggCOUNT).Work_Date||' '||ggSaldo(ggCOUNT).Debit);
        ggTmpStr := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'GRAPH_LOAN',
                                   ggContracts.Currency ,   ggSaldo(ggCOUNT).Work_Date,
                                   ggSaldo(ggCOUNT).Rest,
                                   -333000,   Globals.UserID      , ggContracts.Branch );
        ggTmpStr := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'GRAPH_PERCENT',
                                   ggContracts.Currency ,   ggSaldo(ggCOUNT).Work_Date,
                                   ggSaldo(ggCOUNT).Debit,
                                   -333000,   Globals.UserID      , ggContracts.Branch );
        ggTmpStr := UNIVERSE.ADD_COLLECTOR( ggContracts.Branch , ggContracts.Reference , 'GRAPH_COMMISSION',
                                   ggContracts.Currency ,   ggSaldo(ggCOUNT).Work_Date,
                                   ggSaldo(ggCOUNT).Credit,
                                   -333000,   Globals.UserID      , ggContracts.Branch );
        ggCount := ggCount + 1;
      end Loop;
    <<GENERATE_GRAPH_RETURN>>
      return ggRESULT ;
    END ;
begin
    select * into rgContracts from contracts where reference=reff;
      Dopen :=rgContracts.date_open;
      rgContracts.date_open:=dat__;
      update contracts set date_open=dat__ where reference=rgContracts.reference and branch=rgContracts.branch;
      select * into rgContracts from contracts where reference=reff;
      sv:=UNIVERSE.VARIABLE_CONTRACT(rgContracts.branch,rgContracts.reference,'SALDO');
      sv:=UNIVERSE.VARIABLE_CONTRACT(rgContracts.branch,rgContracts.reference,'NOMINAL');
      sc:=UNIVERSE.SALDO_COLLECTOR(rgContracts.branch,rgContracts.reference,'210001',rgContracts.currency,dat__);
      UNIVERSE.INPUT_VAR_CONTR(rgContracts.branch,rgContracts.reference,'SALDO',trim(to_char(sc)));
      select sum(summa) into annusum1 from collector_contracts where reference=rgContracts.reference and branch=rgContracts.branch and
         name in ('GRAPH_PERCENT','GRAPH_LOAN') and work_date='31-aug-2012';
      select sum(summa) into annusum2 from collector_contracts where reference=rgContracts.reference and branch=rgContracts.branch and
         name in ('GRAPH_PERCENT','GRAPH_LOAN') and work_date='30-sep-2012';
      if annusum1!=annusum2 then
         DBMS_OUTPUT.PUT_LINE('��������???');
         return ;
      end if;   
      if UNIVERSE.OBOROT_COLLECTOR(rgContracts.branch,rgContracts.reference,'210001',rgContracts.currency,'01-nov-2012','30-nov-2012') !=0 then
        DBMS_OUTPUT.PUT_LINE('210001???');
        return ;
      end if;  
   DBMS_OUTPUT.PUT_LINE(GENERATE_GRAPH(rgContracts.branch,rgContracts.reference,4811 )||'   sc='||sc);
      UNIVERSE.INPUT_VAR_CONTR(rgContracts.branch,rgContracts.reference,'SALDO',sv);
      update contracts set date_open=dopen where reference=rgContracts.reference and branch=rgContracts.branch;
end;