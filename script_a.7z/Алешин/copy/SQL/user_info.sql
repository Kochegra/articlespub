declare
  usr users_all%rowtype;
  job_name varchar2(256);
  depart_name varchar2(256);
  fil_link varchar2(32);
  usr_id number;
begin
 --dbms_output.put_line('0. tab_n = '||usr.tab_n||' usr_id = '||usr_id||' depart_name = '||depart_name||' job_name = '||job_name);     
  for usr in (select * from users_all  where tab_n in ((select to_number(e) from doc2@dss where e <> '��������� �����' ))) loop       
    fil_link :=  case usr.filial_id
      when 104 then 'ekburg'      
      when 50 then 'krasnodar'
      when 47 then 'nnovg'
      when 48 then 'nsibirsk'
      when 192 then 'rostov'
      when 49 then 'spburg'
      when 354 then 'stavropol'    
      when 76 then 'khabarovsk'
      else  'main'
      end;       
         
    begin        
      execute immediate ('select user_id from users@'||fil_link||' u where params = '||usr.tab_n||' and exists (select null from all_users@'||fil_link||' where username = u.user_) and rownum < 2') into usr_id;
    exception when NO_DATA_FOUND then
      usr_id :=0;    
    end;
     
    if usr_id = 0 then
      begin 
        execute immediate ('select user_id from users@'||fil_link||' u where params = '||usr.tab_n||' and rownum < 2') into usr_id;
      exception when NO_DATA_FOUND then
        usr_id :=0;    
      end;   
    end if;
   
    if usr_id <> 0 then   
      begin        
        execute immediate ('select job from jobs@'||fil_link||' where job_id = '||usr.job) into job_name;
      exception when NO_DATA_FOUND then
        job_name :='';    
       end; 
    
      begin        
        execute immediate ('select name from subdepartments@'||fil_link||' where id = '||usr.subdepartment) into depart_name;
      exception when NO_DATA_FOUND then
        depart_name :='';    
      end;      
      update doc2@dss d set f = depart_name,g = job_name where d.e<> '��������� �����' and to_number(d.e) = to_number(usr.tab_n);
      dbms_output.put_line('1. tab_n = '||usr.tab_n||' usr_id = '||usr_id||' depart_name = '||depart_name||' job_name = '||job_name);      
    end if;
   dbms_output.put_line('2. tab_n = '||usr.tab_n||' usr_id = '||usr_id||' depart_name = '||depart_name||' job_name = '||job_name);       
  end loop;
end;
