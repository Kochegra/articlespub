select rowid,refer_client,branch_client,related,refer_from,asource,reference,branch,open_date,SECOND_NAME,FIRST_NAME,LAST_NAME,BIRTH_DATE,birth_place,PASSPORT_NUMBER,PASSPORT_DATE,PASSPORT_VIDAN
,REal_summa,summa,CALC_SUMMA,SALARY_CARDNUMBER,is_salary,EID_FIRMA,credit_type,subdepartment
,RESULT_STATUS,STATUS,RESULT_RESOLUTION,UEB_RESOLUTION,UEB_MAIN_RESOLUTION,BAD_RESOLUTION,MAN_RESOLUTION
,type_credit,work_inn,work_ogrn,IS_NOT_INSUR,ANNUAL_DAY,is_plus,st30_plan_date,IS_CORP_MEMBER
,SF.DESC_MCKINSEY,owner,SF.OK_MCKINSEY,card_type,SF.DEBT_RATIO,SF.PERIOD,SF.REJECT_HISTORY,card_plus,MONTHLY_PAYMENT
,SF.KI_EDIT_FIELDS,SF.BABIES,SF.CLICK_REPLACE,eid,IS_MEMBER,work_orgtype3,social_status,stake,mobile,phone_operator,WIFE_MOBILE,PHONE,WORK_PHONE
,PTOOLS5.PARAM_NUM(saved_params,'SUM_REFIN') + EASY_CREDIT_PAY_SUMMA
,PTOOLS5.PARAM_NUM(saved_params,'SUM_REFIN')eid
--,PTOOLS5.READ_PARAM(desc, 'IS_NOW', '0' )
,EASY_CREDIT_PAY_SUMMA
,IS_NOTIF_SMS
,av_profit
,length(birth_date)
,CARD_CODE,work_name,WORK_POSITION,post_index,new_version
,country,currency
from scoring_forms sf where reference in (537956) 
--eid = 24785606
--refer_contract = 8237579
--eid = 831128
--open_date > sysdate-200 and PASSPORT_NUMBER = '38 07 521260' 
--,2513241,2505735)-- (2497112 ) 3000000--(2179934)--4652080506620975 4652069354562801 1415404
--and SECOND_NAME = '������' --and FIRST_NAME = '������' and last_name = '����������'-- and birth_date = to_date('08.07.1980','dd.mm.yyyy') order by open_date desc
--SECOND_NAME||' '||FIRST_NAME||' '||last_name = upper('��������� ��������� ���������')
--select  rowid,s.* from SCORING_FORMS_VARIABLE s where reference in (4910736)
/

select rowid,s.* from sms_queue s where msg_code in ('79299957641') 

select rowid,ep.* from eid.eid_products ep where eid = 4935416

select rowid,e.* from eid.eid_human e where eid IN (5749005,4593359) order by date_modify desc

select rowid,e.* from eid.eid_contacts e where eid = 618240 order by date_modify desc

select rowid,e.* from eid.eid_human_modify e where eid = 18555646 order by date_modify desc

select rowid,e.* from clients e where related = 9309651

select  rowid,e.* from eid.eid_join e where feature_eid IN (5749005,4593359) 

select rowid,s.*,universe.nameowner(user_id) from scoring_forms_lock s where reference = 4495933  

select * from users where 955917777

select GetSalAccountByCard('5282855782349364') from dual

select * from 

select rowid,sfq.* from SCORING_FORMS_QUEST sfq where reference = 3025069
   select rowid,c.* from clients c where reference = 102775454 name like '%���%'
select rowid,refer_from,h.subdepartment,refer_client,branch_client,h.* from hypo_forms h where refer_from = 27216  status = 20 and result_status = 230 and open_date > trunc(sysdate)-30 and reference in 3674 (1404, 1190,  1428, 369,3269,1417, 1414,768,1889,3268, 367, 3293,3686,3683,3692,3690,3294,1432,3287,1208,3309,3311,3695,3319,1110) 

select rowid,sfq.* from SCORING_FORMS_QUEST_audit@nnovg sfq where reference = 248814
  
select rowid,s.* from SCORING_FORMS_MATRIX s where reference = 3671644

SELECT rowid,t.status,t.result_status,t.* from SCORING_FORMS t  where --open_date > '20-mar-2014' and TYPE_CREDIT = 5142 and is_member = 1
 reference in (2865564,2875042)
 
select * from EID.EID_SALARY_REGISTER where (eid_firma,eid_human) in (select EID_FIRMA,eid from scoring_forms sf where reference = 2945671) 

SELECT rowid, t.* from SCORING_FORMS_BABIES t  where reference = 3851728   _IN t

SELECT rowid,paccount.keyaccount(req_assist,substr(bank_bik,-3)),t.req_assist, t.*, DECODE(t.is_used,1,CHR(252),CHR(0)) is_used2  FROM MBANK.SCORING_FORMS_DEBT_KNR t where reference in (3510941)--(3025069)

paccount.keyaccount(req_assist,substr(bank_bik,-3)) 

select * from SCORING_FORMS_NDFL where reference = 3393368

select rowid,g.* from guides G where type_doc = 1014 and str2 = '2522281'-- str3 = '91203810800120000304' 
--890135787
--889625661 and code = '40252' 
select * from guides where type_doc = 1309 and str4 = 'MCUC14' name = 'EC/MC STANDARD' and str1 = 'RUR' and str2 like '�����%' and upper(str3) like '%����%'

select * from guides where type_doc = 5805 and name LIKE 'VISA%'

select * from types where type_id = 6122 and name LIKE 'VISA%'

select rowid,g.* from guides G where type_doc = 3202 and code = '25853'

update scoring_forms
set status = 0, result_status = 0
where reference in (2109518,2106360,2095222,2103977,2102936,2102567,2101668,2101612,2100816,2108230,2111641,2107401,2111058,2111598) 

--passport_number = '38 01 460786'
select rowid,sfv.* from scoring_forms_variable sfv where  reference = 3819830

select reference,PENSFOND_CERTIFICATE,PENSFOND_NUMBER from scoring_forms sf where PENSFOND_NUMBER is not null and open_date >  '01-oct-2013'
order by open_date
select * from scoring_forms sf where  result_status = 3 and open_date >= '01-aug-2014'

select * from mbank_audit.audit_table where table_name = 'SCORING_FORMS' and reference = 4680528  and instr(action,'change rs') > 0 order by time

select rowid,a.* from MBANK_AUDIT.SCORING_FORMS_AUDIT a where reference = 4157398  and field_name = 'ASOURCE' order by time  

select * from user_tab_columns where table_name = 'SCORING_FORMS' and column_name like '%AUTO%'
select * from user_tables where table_name like '%SCORING_F%' 

select hF.status,hf.* from hypo_forms hf where reference in (28841) 

--����� �� �������������� �� ������ �������� ������������� ���������
select * from archive where type_doc = 3058 and branch_related = -191277 and related = -1888814 and date_work >= '14-jan-2013'

select * from subdepartments where upper(NAME) like '%����%'

--id in (294,16,191173,191178,191297,13,119,126,191189,149,59,191235) = 191310 upper(NAME) like '%�����%'

select rowid,u.* from users u where user_id = 820001859 ser_ = 'MENKOV_SV' upper(USER_NAME) like '%�����%' 
select * from jobs where job_id = 35
select * from jobs_rights where object_id = 5480 and job_id = 35 (select job from users where user_id = 305188)

update account 
set owner = 763362-- (branch_contract,contract) = (select branch,reference from contracts c where reference = 3932078)
where reference in (12222540,12882844) code in ('91202810701500000024','91202810001500000025','91202810401500000023')

select rowid,a.* from account a where code in ('42305810502140100785')

select * from ledger where code = '42305810502140100785'
 ,'2020284090105000000100098')

select rowid,np.* from nosrok_pays np where refer_contract = 7053800

select rowid,c.* from contracts c where reference = 9704698

 and branch = 164 status = 50 reference in (709005213, 708799358, 525346347, 742285783, 742287396) and branch = 5
select rowid,cl.* from clients cl where reference in (102388633,102375808)

select rowid,c.* from contracts c where reference in (6082809) 
 --and branch = 5 doc_number in ('00091/15/03102-13','00067/15/03797-12') 
 status = 50 and type_doc = 5163 and subdepartment = 191257 
  
select rowid,c.* from variable_contracts c where reference in (7289011)
 
select rowid,c.* from rest_contracts c where reference = 65689  and branch = 386 and work_date = '28-may-2013' docnum in (746253957,711589119)
select * from coll1 where reference = 5143290
--delete collector_contracts c where reference = 571440  and branch = 54 and docnum = -9789 work_date = :dt
 
and docnum in 711589798 --and work_date = :dt 
select rowid,c.* from collector_contracts c where reference in (527062) -- and work_date = :dt select * from subdepartments where id in (15,191262,191347)
select rowid,c.* from rest_contracts c where reference = 5539098 and branch = 191 and work_date = :dt

select rowid,c.* from clients c where reference = 232076  
select rowid,c.* from variable_clients c where reference in (269036) --060
name = 'EID' and value = '318060'

select rowid,d.* from journal d where docnum = 1550361723 code = '20202810700100000001' and work_date = trunc(sysdate) and substr(assist,1,5) = '30232'

select to_date(related+TO_DATE('01.01.2000','dd.mm.yyyy')) dt,d.* from journal_delete d where docnum = 1376967047
 
code = '20202810700100000001' and work_date = trunc(sysdate) and substr(assist,1,5) = '30232'
  docnum in (822125052,822125055)

select rowid,d.* from documents_delete d where refer_from = 1053207095 and reference >= 1029407750  and trunc(date_create) = :dt0 --06.10.2014 26.06.2009

select rowid,(SYSTIMESTAMP - INTERVAL '200' MINUTE),d.* from documents AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '100' MINUTE) d  where reference in (2812967783)


select * from EID.EID_PC_BRANCHES where subdepartment = 
 and reference >= 1029407750-100 and trunc(date_create) = :dt0

select rowid,d.* from documents d where reference  in (2016285687 ) 

select rowid,d.* from variable_documents d where reference in (1545198079) ,1449548839)
 
insert into variable_documents  select 'PASSPORT_KOD',reference,branch,0,0,0,'772-090',null,variable_doc_id.nextval,null from documents where reference = 1408345805 :ref and branch = :br 

select rowid,d.* from archive d where reference in (1529194354)

select * from jobs_rights where job_id = 35
select * from users where user_name like '����� �.�.'


select rowid,p.* from eid.eid_products p where pr_number = '00168/15/00730-15' eid = 16301866

type_DOC = 3780 and owner = 955926533 and date_work = '05-sep-2013'
select rowid,d.* from variable_archive d where reference in  (1597162462)  and name = 'FIO'

select rowid,d.memo,d.* from archive d where reference in (2225810850)

select rowid,c.* from prc_loader.closepk_accept c where CARD = '2200650384435554' 255448,91

SELECT item rownumber,text value FROM balance WHERE count_out = 1100223865 AND branch = 191304;

select rowid,d.* from documents d where reference = 1529194354 1378536352 RECEIVERS_ACCOUNT='40817810701520100670' and status = 1000 and date_create > :dt0 and type_doc = 990

type_DOC = 3516 and  payers_operation = 850183 and status = 30 and date_work = '07-jun-2013'
type_doc = 5481 and date_work = '17-apr-2013' and  receivers like '%�������%' xsubdepartment = 191304 branch = 273 581255074 554921609
union all
--select variable_doc_id.nextval from dual  5019832334
select * from guides where type_doc = 4884 and str2 = '2521941'
select rowid,d.* from variable_documents d where reference in 1105341966 and subfield = 'CARD_TYPE' and not exists
(select null from guides where type_doc = 4884 and str2 = '2521941' and str1 = d.value)
select rowid,d.* from variable_documents d where reference in 1097268637  = 'CARD_TYPE' --5417153511837257
select rowid,d.* from variable_archive d where reference in (1296623770) and subfield = 'GROUND'

select rowid,d.* from axioma_sent_doc d where reference in (2171838083)

select rowid,d.* from variable_documents d where reference in ( 1591144343 ) ������� ���������� ��

select rowid,a.* from account a where code = '42306840001480100274'

select rowid,d.* from documents d where reference in (1591133246,1591131611)

select rowid,d.* from documents d where refer_from = 1171363303  type_doc = 1342 and owner = 745116
 type_doc = 4665 and  date_document > '01-apr-2013' payers_account in ('30233810101040000004') and RECEIVERS_BANK like '%���� ������%' --owner = 957535 -- UNIVERSE.VARIABLE_DOC(branch,reference,'USERJOB') = '����� ���������' and date_work = :dt
 and UNIVERSE.VARIABLE_DOC(branch,reference,'CARD_TYPE') like '%ELEC%' and  UNIVERSE.VARIABLE_DOC(branch,reference,'PLASTIK') LIKE 'REGUL%' 
select variable_doc_id.nextval from dual
select rowid,d.* from documents_delete d where to_char(date_create,'dd.mm.yyyy') >= '28.08.2013' and summa = 6460 --related = 563075568 ence in (681244288)
insert into variable_documents  select 'NEW_PK',reference,branch,0,0,0,:card,null,variable_doc_id.nextval,null from documents where reference = :ref and branch = :br 1331246021    5417150794451459
insert into variable_archive  select 'TAX_VALUE',reference,branch,0,0,0,:VAL,null,variable_doc_id.nextval,null from archive where reference = :ref and branch = :br
insert into variable_documents  select 'NUM_SERVCARD',reference,branch,0,0,0,:card,null,variable_doc_id.nextval,null from documents where reference = :ref and branch = :br
insert into variable_documents  select 'PLASTIC_ALLLOWED',reference,branch,0,1,0,:card,null,variable_doc_id.nextval,null from documents where reference = :ref and branch = :br
insert into variable_archive  select 'NEW_PK',reference,branch,0,0,0,:card,null,variable_doc_id.nextval,null from archive where reference = :ref and branch = :br

select column_name from user_tab_columns where table_name = 'DOCUMENTS' order by column_id
insert into documents 
select DOC_REFERENCE.NEXTVAL,REFER_FROM,doc_id.nextval,branch,BRANCH_FROM,BRANCH_RELATED,RELATED,FOLDER,TYPE_DOC,SUB_TYPE,10,DOC_NUMBER,DATE_CREATE,null,null,DATE_DOCUMENT,NUM_GROUP,PAYERS_ACCOUNT,REAL_PAYERS,PAYERS_CURRENCY,PAYERS_BIK,PAYERS_INN,PAYERS_CORACC,PAYERS_BANK,PAYERS,PAYERS_OPERATION,RECEIVERS_ACCOUNT,REAL_RECEIVERS,RECEIVERS_CURRENCY,RECEIVERS_BIK,RECEIVERS_INN,RECEIVERS_CORACC,RECEIVERS_BANK,RECEIVERS,RECEIVERS_OPERATION,SUMMA,MEMO,PAYMENT,OWNER,REFER_OFFICE,VERSION,CHILD,REAL_PAYERS_CONTRACT,REAL_RECEIVERS_CONTRACT,BRANCH_REAL_PAYERS,BRANCH_REAL_RECEIVERS,PAYERS_CONTRACT,RECEIVERS_CONTRACT,BRANCH_PAYERS,BRANCH_RECEIVERS,PAYERS_RELATED,RECEIVERS_RELATED,DEPART_PAYERS,DEPART_RECEIVERS,SHIFROPER,XSUMMACREDIT,XSUBDEPARTMENT
-- XSUMMACREDIT,XSUBDEPARTMENT,null,REFER_FROM,doc_id.nextval,null,BRANCH_FROM,BRANCH_RELATED,RELATED,FOLDER,TYPE_DOC,SUB_TYPE,STATUS,DOC_NUMBER,DATE_CREATE,DATE_WORK,DATE_VALUE,DATE_DOCUMENT,NUM_GROUP,PAYERS_ACCOUNT,REAL_PAYERS,PAYERS_CURRENCY,PAYERS_BIK,PAYERS_INN,PAYERS_CORACC,PAYERS_BANK,PAYERS,PAYERS_OPERATION,RECEIVERS_ACCOUNT,REAL_RECEIVERS,RECEIVERS_CURRENCY,RECEIVERS_BIK,RECEIVERS_INN,RECEIVERS_CORACC,RECEIVERS_BANK,RECEIVERS,RECEIVERS_OPERATION,SUMMA,MEMO,PAYMENT,OWNER,REFER_OFFICE,VERSION,CHILD,REAL_PAYERS_CONTRACT,REAL_RECEIVERS_CONTRACT,BRANCH_REAL_PAYERS,BRANCH_REAL_RECEIVERS,PAYERS_CONTRACT,RECEIVERS_CONTRACT,BRANCH_PAYERS,BRANCH_RECEIVERS,PAYERS_RELATED,RECEIVERS_RELATED,DEPART_PAYERS,DEPART_RECEIVERS,SHIFROPER 
 from documents d where reference in (897394223)


select * from journal
--delete journal
where (docnum,branch) in (select reference,branch from archive where refer_from in (2813343868, 2813334920, 2812830606, 2813859426))

select rowid,d.* from documents d where refer_from in (2813343868, 2813334920, 2812830606, 2813859426)

insert into documents select * from documents_delete d where reference in (2809737697)
insert into variable_documents select * from variable_documents_delete d where reference in (2809737697)
delete documents_delete where reference in (2809737697)

insert into documents select * from archive d where reference in (2813334981,2813334989,2813334992,2813343876,2813343877,2813343878)
insert into variable_documents select * from variable_archive d where reference in (2813334981,2813334989,2813334992,2813343876,2813343877,2813343878)
delete archive where reference  in  (2813334981,2813334989,2813334992,2813343876,2813343877,2813343878)

insert into variable_archive  select 'NEW_PK',reference,branch,0,0,0,:card,null,variable_doc_id.nextval,null from archive where reference = :ref and branch = :br  676332621 679069249
update archive set PAYERS =  '������ �20 "������������� �������� ����" ��� "����"'  
where reference in (704750742, 704750900, 704817725, 704817798, 704860368, 704860405, 704909632, 704909647, 704963582, 704963595)
update documents set status = 1000
where  type_doc = 1432 and status = 10 and payers_account in ('4652060269093255','4652080867578846')  and trunc(date_create) = '01-may-2013'
 where payers_account = '40702810400280001263' and receivers_account = '70601810500287101001' and owner = 1403 and num_group = 9999 and status = 35 

select * from types where type_id = 1652

select rowid,p.* from EID.EID_PRODUCTS p where eid = 18802336 account = '5577480000140281' 

select rowid,e.* from EID.EID_IBK_CONTROL e where eid = 17052949 reference = 5417150877735067--EID = 12885665  ���� �������� �������� ������ ���������� ���������


begin
  Eid.p_eid_tools2.check_card_info('5417155473489811'); --5417150554759828,6762370582732626,4652060328953036,4652180027744245,4652180029218636
end;

 p_eid_tools2.check_card_info


akt_number in ('000000072773') and status = 1

select rowid,a.* from archive a where reference = 1529194354

update EID.EID_CARD
set status = 3, card_status = 3  
where akt_number in ('000000072773') and status = 1

select * from subdepartments where id = 191413

select rowid,c.* from EID.EID_CARD c where pk in --'2200650371175981'--'2200650490504996' -- ('5417159073092884', '5417154006545264')
('2200650352472308','2200650371175981','2200650375687080','2200650378111187','2200650382622294','2200650388899565')
--akt_number like '%000000493596_0%' 
--date_modify > '01-feb-2017' and substr(pk,1,4) = '7588'

select rowid,c.* from EID.EID_CARD_collector c where pk in '2200650371175981' --('2200650388899565' -- ('5417159073092884', '5417154006545264')
order by work_date desc

select rowid,c.* from EID.EID_CARD_ERR c where pk in  ('5417150816464472')

select rowid,u.* from users u where user_ like 'ALESHIN%'

select c.* from EID.EID_CARD c where pk in ('2200650350138588')
union all
select c.* from EID.EID_CARD@DSS c where pk in ('5417155938790704')

akt_number in ('1621839975') 

select * from eid.eid_card where eid = 5747348 status = 1 and pin_cover = 1 and pk_type='EB'

akt_number in ('000000288568') ,'000000151537') --000000147904'


select EID.EID_CARD_OPER_Id.nextval from dual

select rowid,D.* from archive d where reference = 1529194354  1524856076


select D.* from variable_archive d where reference in (1551166990)
union all
select D.* from variable_archive@nsibirsk d where reference in (122384437)

select to_date('14.03.2015','dd.mm.yyyy')+45 from dual

select * from eid.eid_codeword cw where cw.eid = 1842418 and cw.status = 1

select * from eid.eid_proc_codeword cw where cw.eid = 2906054 and cw.status = 1

Select rowid,srv_list.*  from eid.eid_service_obj_list srv_list where 1=1 and reference_obj = 4677106 eid = 11113442 and srv_list.id like 'EID_CODEWORD%' 

SELECT  rowid,D.*  FROM eid.closing_card d where reference in (4319074)

select rowid,t.* from temp_card_4665_ t where pk = '2200650352842914'

select PTOOLS_CODEWORD_MAIN.get_proc_codeword(2906054) from dual;

insert into PRC_LOADER.CLOSEPK_ACCEPT 

SELECT  rowid,D.*  FROM eid.closing_card d where reference in (4677106)

select d.* from PRC_LOADER.CLOSEPK_ACCEPT d where card = '2200650352842914'

select rowid,d.* from EID.EID_CARD_OPER d where  card_number in ('2200650352842914')

select count(*) over(),rowid,d.* from EID.EID_CARD_OPER d where op_status = 50 and work_date >= '17-aug-2018'
/

select rowid,d.* from EID.EID_CARD_OPER d where  card_number in ('4652060113895434')
/
--insert into eid.eid_card_oper select distinct card_number,trunc(sysdate),null,'������������� ��������� �����','UNBLOCKED_DC',50,'�������� ������������',null,null,sysdate,'gruz',null from EID.EID_CARD_OPER c where  card_number in ('5417151811645941','5417152375533952','5417153541228360')

select rowid,e.* from EID.EID_CARD_COLLECTOR e where pk in  ('2200650352842914') --and  refer_obj = 1587469015
order by work_date desc 
--5417150943925585
 
--work_date = :dt and op_status = 50 and op_code = 'CARD_SET_ACTIVE'

select rowid,h.* from EID.EID_HUMAN h where EID = 19293174   --SEARCH_DOC = '4509057605' 2593
select rowid, h.* from EID.EID_HUMAN_MODIFY h where EID = 19293174 --date_modify  > '01-jan-2013' --= EID = 286563 --SEARCH_DOC = '4509057605' 2593
select rowid,h.* from EID.EID_JOIN h where FEATURE_EID = 17465038 FEATURE_EID =   13329061  --SEARCH_DOC = '4509057605' 2593
select rowid,h.* from EID.EID_DOCUMLIST h where EID = 19293174
/

--select * from mbank_audit.audit_table where table_name = 'MISSIONS'  and trunc(time) = '01-mar-2013'-- reference =  10070469
select rowid,m.* from MISSIONS m where reference in (10143809,10086270) and branch = 15000
select rowid,m.* from VARIABLE_MISSIONS m where reference in (10143809,10086270) -- and branch = 15000
select rowid,m.* from EID.EID_MISSIONS m  where eid in  (4272317) and reference in (10143809,10086270)

select * from MBANK_AUDIT.AUDIT_ARCHIVE where reference = 171219136
select variable_doc_id.nextval from dual 

Select 
EID_HUMAN_TOOLS.Get_Human_FIO(eid) client_name
,(select name from guides gd where gd.type_doc = 4590 and  gd.code = upper(srv_list.operation)  and gd.code1 = to_char(srv_list.status)) status_name
,(select sub.name from eid.eid_subdepartments sub where sub.id = owner_br) subdep
,srv_list.* from eid.eid_service_obj_list srv_list where 1=1 and eid = 28493400 --and srv_list.id = 'EID_CARD_4652070172837763'
 order by date_modify desc

--�������� �� ����� ��� � ���� ������ ������ �����
select rowid,UNIVERSE.NAMEOWNER(owner),d.* from documents d where  type_doc = 3859 and date_work = '10-apr-2013' and branch in (191350)
and exists (select null from documents where refer_from = d.reference and branch <> d.branch)

select rowid,d.* from archive d where reference = 905263402  type_doc = 4851 and date_work = '25-mar-2013' and branch in (191185)
and exists (select null from archive where refer_from = d.reference and branch <> d.branch)
/
select * from guides_all gd where type_doc = 7372 and num1 = -1
/

select tbl,priority,min(date_modify),sysdate,60*24*round(sysdate-min(date_modify),3) "����� ��������",count(*)
,(select num1||'_CHG_OBJ' from guides_all gd where type_doc = 7372 and code = ch.tbl) "���"
 from chg_obj ch where status = 0 and trunc(date_modify) >= trunc(sysdate)
group by tbl,priority
/

select min(date_modify),sysdate,60*24*round(sysdate-min(date_modify),3),count(*) from chg_obj where  status = 0 and trunc(date_modify) >= trunc(sysdate)
 and tbl = 'ACCOUNT' 
 
 /
select tbl,count(*) from chg_obj where status = 0 and trunc(date_modify) >= trunc(sysdate)-5 group by tbl order by count(*) desc
/
 select rowid,c.* from chg_obj c where status = 0 and trunc(date_modify) >= trunc(sysdate) and tbl = 'CONTRACTS' and priority = 0
/
select rowid,c.* from chg_obj c where priority = 1 and trunc(date_modify) >= trunc(sysdate)
--and status = 0 
--and exists (select null from contracts where status <> 50 and reference = c.reference and branch = c.branch) 
order by date_modify --desc --reference =  28239  674583464
/
select * from chg_obj where reference in (10209150, 10209150)
/
update chg_obj c
set priority = -1  
--select * from chg_obj
where status = 0 and trunc(date_modify) >= trunc(sysdate)  and tbl = 'CONTRACTS' and owner_id_modify =  989990
/

select * from card_to_eid where date_modify >= trunc(sysdate) and PR_NAME = '4652061009047098' status = 0
/
select task_kind,min(sys_date),count(*) from EID.DISTRIB_TRANSACTIONS where sys_date >= trunc(sysdate) and done = 0 group by task_kind

select done,count(*) from EID.DISTRIB_TRANSACTIONS where sys_date >= trunc(sysdate)-2 and done <> 0 group by done 

select * from text_files t where file_name = 'A0003_38.239' 

select max(date_load) from text_files t where file_name like 'A0002_52.288'

select universe.variable_doc(branch,reference,'PC_APPL_FILENAME'),d.* from documents d where status = 30 and date_work = :dt and type_doc = 203 
and universe.variable_doc(branch,reference,'PC_APPL_FILENAME') = 'A0002_52.288' --'A0001_21.280' 

select universe.variable_arch(branch,reference,'PC_APPL_FILENAME'),d.* from archive d where status = 30 and date_work = :dt and type_doc = 203
and universe.variable_arch(branch,reference,'PC_APPL_FILENAME') =  'A0002_77.132' 

select to_date('01.01'||EXTRACT(YEAR FROM sysdate),'dd.mm.yyyy')+271  from dual

select rowid,a.* from archive a where reference in (1431212458)

select rowid,a.* from variable_archive a where reference in (1431212458 ) 


select  rowid,c.* from card_form c where card_status > 10
 

update card_form 
set card_status = 10,black_status = 0
where doc_ref = 733235427 and card_status = 40
select status,count(*) from nosrok_pays group by status
select rowid,np.* from nosrok_pays np where refer_document = 1097268637
(refer_contract,branch_contract) in (select reference,branch from contracts where status = 50 and type_doc in (1800,5142) and doc_number in ('00039/15/00628-11','00091/15/00219-13'))  
--( '00039/15/00628-11','00091/15/00219-13','00091/15/00808-13','00091/15/03318-13','00091/15/01891-13','00091/15/02806-13','00091/15/03054-13','00091/15/03588-13','00039/15/00141-12','00091/15/03804-13')

order by 1

select rowid,d.* from variable_documents d where  reference in (2158165820) and name like 'PC_APPL_FILENAME'  --  1302351139

select rowid,vd.* from variable_documents vd
--update variable_documents set name = decode(name,'MESSAGE',name,'#'||name), value = decode(name,'MESSAGE',null,value)  
where reference in (2096784627
) and (substr(name,1,3)='PC_' or name = 'MESSAGE') and instr(name,'PC_UEB') = 0

select rowid,d.* from documents d where reference  in (2096784627)

d_1342
1475950728 191352

    UPDATE eid.Eid_Public_jurist ud  
    SET ud.Eid = NULL, ud.doc_Br = NULL, ud.doc_Ref = NULL, ud.date_Out = NULL  
      , ud.owner_Out = NULL, ud.subd_Out = NULL, ud.tabn_Out = NULL 
      , ud.Status = 0
    WHERE ud.doc_Ref = 1475951191 And ud.doc_Br = 3
    
    select * from eid.Eid_Public_jurist ud  where cert_number = '098-3048878'  ud.doc_Ref = 1475950728

select rowid,a.* from eid.eid_objects a where eid = 11113442 (select VALUE from variable_documents where reference = 1475950728 and NAME = 'EID' and TYPE = 'PERSONAL_LAWYER')

select rowid,a.* from eid.eid_services a where eid in (5636843,-5636843)


insert into variable_documents
select name,1222888702,191257,subnumber,rownumber,colnumber,value,subfield,variable_doc_id.nextval,xdate from variable_documents d where reference in (1222729567) and name = 'KOMISS'

select rowid,d.* from eid.eid_products d where  eid = 6733342 

select * from journal_delete where docnum = 1212900706

select ROWID,CC.* from collector_contracts CC where reference = 8081390 and docnum in  (1024320108,1024335232) 


select * from tax where operation = '110058'
/
select * from boss_PROFIT 
/
select * from BMV_MBANK_RB@boss where TAB_N in (1195,1207,1208,1209,1811,2473,5224,9297,10103,10247,14175,15974,17465,18844,19566,0320046,0452385,3460324,3520171,13931,2993,20264,7373,20036,1660012,14304,3610182,17969,7910
--)
,11997,309,10324,359,7461,10508,5899,5680,773,17951,0549229,0549298,0549223,0549220,0549205,0549012,0549014,0549096,0549377,0549348,0549355,15934,13289,15884,9714,10435,47127,1379,3648,18770,10103
,0549494,11)
--(0549096,0549012,0549348,0549419,0549354,0549223,0549157,0549021,0549014,0549036,47127)
order by p desc
/
10735 29657

--���������� ���������� ���������� �������
--���������� ���������� ������������ ������
--���������� ������������� ��������� � �������������� ���������

--�������� ���� ����
select * from B2_HR.bmv_mbank_emp@BOSS where upper(l_name) LIKE upper('��������') and upper(F_NAME) = upper('��������') --7373,20036,1660012,14304,3610182
--dept_name_1 = '����������� �������������� ����������' and d_out = '31-dec-2099'
--and dept_name_2 in ('���������� ���������� ���������� �������','���������� ������������� ��������� � �������������� ���������','���������� �������� ��������� �����������')
--and sex = 'F'
order by d_birth,l_name,f_name,m_name
/

���������� �������� ������������� 
/

--select address from (select * from eid.eid_human where eid = 5771981 order by date_modify desc) where rownum < 2
/

--�������� ���� ����
select ENTRY_ID,TAB_N,b.EID,L_NAME||' '||F_NAME||' '||M_NAME,D_BIRTH,PASSP_NUM,to_char(PASSP_DATE,'dd.mm.yyyy')||', '||PASSP_GRANT pasp
,(select address from (select * from eid.eid_human order by date_modify desc) where eid = b.eid and rownum < 2) address 
,(select place_birth from (select * from eid.eid_human order by date_modify desc) where eid = b.eid and rownum < 2) place_birth 
--select entry_id,b.* 
from boss_emp_all b where 1=1
--and upper(l_name) LIKE upper('������') --and upper(F_NAME) = upper('��������')
--dept_name_1 = '����������� �������������� ����������' 
and nvl(d_out,sysdate+1) > sysdate
--and dept_name_3 in '���������� ������������� ������� ���������� ������'
and eid in (48543,48538,269,2391,169409,18783933,5771981,10692123,3065744,3549)
--and sex = 'F'
order by d_birth,l_name,f_name,m_name
/

select * from boss_emp_all where tab_n in 
(select tab_n
from boss_emp_all b, boss_empall_adrs a 
where 1=1
and nvl(b.d_out,sysdate+1) > sysdate
and b.dept_name_3 in '���������� �������� ������ ��������-��������� ������������'
and b.sex = 'F'
and b.tab_n = a.TAB_NUM(+) and instr(a.address,'����������') > 0)
/

������������ ���!   

 ������, �� �������� ����, ������ �� ������� � ������.
 � ������ ������-�� ����, � � ������ ����� ������ �����.
 �� ��� ��� ���� ����, ���� ����� ��, ��� �� �����,
 ������������� � ����, ������, ����, �����. 
 � ���� �� ��� �����, �� ���������� ��� �� ������.

 ����, ������ ������
 ���.322
/

begin
  for uu in (
select * from boss_emp_all where tab_n in 
(select tab_n
from boss_emp_all b, boss_empall_adrs a 
where 1=1
and nvl(b.d_out,sysdate+1) > sysdate
and b.dept_name_3 in '���������� �������� ������ ��������-��������� ������������'
and b.sex = 'F'
and b.tab_n = a.TAB_NUM(+) and instr(a.address,'����������') > 0)
and instr(email,'@') > 0 
--and tab_n not in ('10247'
--and rownum = 1
            )            
  loop      
    mbank.p_email.send_mail(
   --  sender => '������������� �-����',
     --reciever => 'r.aleshin@vtb.ru' --uu.email,
       reciever => uu.email
       ,subject => '6 �����'
       ,mail_text => '������������ ���!   
        
 ������, �� �������� ����, ������ �� ������� � ������.
 � ������ ������-�� ����, � � ������ ����� ������ �����.
 �� ��� ��� ���� ����, ���� ����� ��, ��� �� �����!
 ������������� � ����, ������, ����, �����. 
 � ���� ��� � �����, �� ���������� ��� �� ������.

 ����, ������ ������
 ���.322 '
                       );
  end loop;
end;


/

--���-�� �����������
select count(*) from B2_HR.bmv_mbank_emp@BOSS where d_out > trunc(sysdate)
/

select * from B2_HR.bmv_mbank_emp@BOSS where tab_n = 20479 
d_out > trunc(sysdate)
/
4600454711
--������
select * from B2_HR.BMV_MBANK_LEAVE@boss where emp_id = 0549437
/

select * from B2_HR.user_tables@boss

select * from all_tables where table_name like '%LOGIN%'

select * from eid.EID_WEB_TEMP_LOGINS where eid = 17600789

select rowid,e.* from eid.eid_services e where eid = 18092049

select * from course where trunc(work_date)=trunc(sysdate) and course = 1 and currency = 'A98' order by work_date desc 

select * from course where trunc(work_date)=trunc(sysdate)-365 and course = 2 and currency = '840' order by summa_assist --desc

select c1.currency,c1.course,c1.work_date,c1.summa_assist,c2.summa_assist,c2.course,c2.work_date,c0.course,c0.work_date,c0.summa_assist from course c0,course c1, course c2 where
trunc(c1.work_date)>=trunc(sysdate)-100 and c1.course = 1 and c1.currency = 'A98' and c2.course = 2
and c2.currency = c1.currency and C2.WORK_DATE = (select max(work_date) from course where work_date <=  c1.work_date and CURRENCY = C2.CURRENCY and course = c2.course)
and c0.course = 0 and c0.currency = c1.currency and C0.WORK_DATE = (select max(work_date) from course where work_date <=  c1.work_date and CURRENCY = C0.CURRENCY and course = c0.course) 
order by c1.work_date desc 

select c1.currency,c1.course,c1.work_date,c1.summa_assist,c2.summa_assist,c2.course,c2.work_date,c0.course,c0.work_date,c0.summa_assist from course c0,course c1, course c2 where
trunc(c1.work_date)>=trunc(sysdate)-1 and c1.course = 1 and c1.currency = '840' and c2.course = 2
and c2.currency = c1.currency and C2.WORK_DATE = (select max(work_date) from course where work_date <=  c1.work_date and CURRENCY = C2.CURRENCY and course = c2.course)
and c0.course = 0 and c0.currency = c1.currency and C0.WORK_DATE = (select max(work_date) from course where work_date <=  c1.work_date and CURRENCY = C0.CURRENCY and course = c0.course) 
order by c1.work_date desc 



select * from variable_documents where reference = 1583275679

insert into variable_documents
select name,1527131310,branch,subnumber,rownumber,colnumber,value,subfield,variable_doc_id.nextval,trunc(sysdate) from variable_archive where reference = 1524386745 and name like 'PODPI%'

select * from all_objects where object_name like '%TEST_TAX%'

select * from all_tables where table_name like '%DDL%'

select * from MBANK_AUDIT.LOG_DDL where object_name like '%TEST_TAX%'

insert into Journal
select header,code,currency,vsum,rsum,trunc(sysdate),trunc(sysdate),docnum,journal_id.nextval,operation,type,users,flag_debit,branch,0,assist,assist_currency,ysubdepartment 
from Journal where docnum = 1606840146

declare
n number;
v1 varchar2(4000);
v2 varchar2(4000);
begin
mbank.ptools2.short_init_user (2025002093);
n := 0; v1 := null; v2 := null;     
 --dbms_output.put_line(start_process.WORKING(2, 5, 191346, 2257520376, null, n));
--dbms_output.put_line(DOCALGO.execdoc(405000 , 3348012, 2025002093, n, v1, v2));
dbms_output.put_line(PTOOLS2.try_exec(3348015,405000,2025002093));
end;
/
--���������� �������
select sum(pc_summa) from kvitpc@nsibirsk where proc_ref = 154392108
and  modify_date > sysdate-2
/



select * from eid.eid_human where eid = 5771981

select * from archive where type_doc = 103 and date_work > sysdate -300 and date_work < sysdate -200 


select h.eid,last_name||' '||First_name||' '||second_name "���", s.date_modify "���� �����������", s.subdepartment "���������"  from eid.eid_services s, eid.eid_human h where 
--eid = 24290313 
s_code = 92 and s_name = '������ ���������'
and h.eid = s.eid and h.date_modify = (select max(date_modify) from eid.eid_human where eid = h.eid)
and s.date_modify > '15oct2018'


--��������� - version
select to_date(trunc(1060678260/24/60/60+1990*365+4712*365),'J')+mod(1060678260/24/60/60+1990*365+4712*365,1) unver
,to_char(sysdate,'SSSSS'),to_char(sysdate,'J'),sysdate,1060678260/24/60/60+1990*365+4712*365 r
,1990*365+4712*365 ss
,24*60*60 ss
,mod(1060678260/24/60/60+1990*365+4712*365,1)*24*60*60
,to_date(mod(1060678260/24/60/60+1990*365+4712*365,1)*24*60*60,'SSSSS') s
 from dual
 /
 
 select * from admin_audit where tablename = 'PARAMVALUES' and time > sysdate-10