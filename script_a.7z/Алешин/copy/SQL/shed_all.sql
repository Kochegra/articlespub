--DISABLE_SUCC
declare 
 n varchar2(1);
begin
  for i in (select fil from (select 'rostov' fil from dual@rostov union all select 'stavropol' fil  from dual@stavropol union all select 'spburg' fil  from dual@spburg
 union all select 'nsibirsk' fil  from dual@nsibirsk union all select 'ekburg' fil from dual@ekburg union all select 'khabarovsk' fil  from dual@khabarovsk
  union all select 'nnovg' fil  from dual@nnovg ))
 loop
    dbms_output.put_line(i.fil);
   --execute immediate 'update SHED_JOBS@'||i.fil||' set disabled = ''DISABLE_SUCC'' where JOB_NAME in (''RECALC_408_ACCOUNTS'') and disabled is null';
   --execute immediate 'update SHED_HIST@'||i.fil||' set ERROR_MSG = null where JOB_NAME= ''RECALC_408_ACCOUNTS'' and ERROR_MSG is not null';
   --   execute immediate 'update SHED_HIST@'||i.fil||' set ERROR_MSG = null where JOB_NAME= ''RECALC_408_ACCOUNTS'' and ERROR_MSG is not null';
    --    execute immediate 'update shed_jobs@'||i.fil||' set marked = ''STOP_SUCCESS'' where job_name = ''RECALC_408_ACCOUNTS''';
   execute immediate select count(*) from shed_hist where task_name='���.���.�������' and job_name='RECALC_408_ACCOUNTS'

--    dbms_output.put_line(n);
  end loop;
end;
/

select rowid,sh.* from SHED_JOBS@rostov sh where JOB_NAME= 'GISGMP' and disabled is null

select rowid,sh.* from shed_tasks@rostov sh where task_name in ('GISGMP','GISGMPKVIT') and nvl(active,0) <> 1 

--select * from all_tables where table_name like '%SHED%'


select * from SHED_jobs@krasnodar sh where job_name='fil_lost_contracts'

select (select global_name from global_name@krasnodar) fil,sh.* from SHED_HIST@krasnodar sh where finished > trunc(sysdate)-10 and ERROR_MSG is not null and not exists (select null from SHED_LOG@krasnodar where job_name = sh.job_name and time_stamp > sh.finished and message in ('START','FIN_SUCCESS'))
/

declare
  shed_fil varchar2(4000);
  pl_sql varchar2(4000);
begin
  for fil in (select value from variable_guides where (reference,branch) in (select reference,branch from guides gd where gd.type_doc = 1198 and code <> 'FORM_STORAGE') and name = 'DBLINK_M') loop
    pl_sql := 'declare shed_list varchar2(4000);
                                   begin
                                     shed_list := '''';
                                       update shed_tasks@'||fil.value||' sh set active = 1 where task_name in (''GISGMP'',''GISGMPKVIT'') and nvl(active,0) <> 1; 
                                     :1 := shed_list;
                                   end;';
    begin
      execute immediate pl_sql using out shed_fil;
    exception when OTHERS then
      shed_fil := '������ �� �������� �� �������, �������� �� �������� ����';
    end;
    DBMS_output.put_line(fil.value||'. '||shed_fil);   
  end loop;
end;    
/

--update shed_jobs@'||fil.value||' sh set start_1 = ''21:45'', left = 10, top = 253 where job_name = ''LOAN.REPAYS'';
--and num1 in (49,47,354,192)
declare
  shed_fil varchar2(4000);
  pl_sql varchar2(4000);
begin
  for fil in (select value from variable_guides where (reference,branch) in (select reference,branch from guides gd where gd.type_doc = 1198 and code <> 'FORM_STORAGE' ) and name = 'DBLINK_M') loop
    pl_sql := 'declare shed_list varchar2(4000);
                                   begin
                                     shed_list := '''';
                                       update shed_jobs@'||fil.value||' sh set start_1 = ''21:30'', start_2 = ''23:00'' where job_name = ''DEMAND_ALL'';
                                     :1 := shed_list;
                                   end;';
    begin
      execute immediate pl_sql using out shed_fil;
    exception when OTHERS then
      shed_fil := '������ �� �������� �� �������, �������� �� �������� ����';
    end;
    DBMS_output.put_line(fil.value||'. '||shed_fil);   
  end loop;
end;    
/

select * from guides gd where gd.type_doc = 1198 and code <> 'FORM_STORAGE' and num1 in (49,47,354,192)
/
select * from 
 shed_jobs set start_1 = '21:45' where job_name = 'LOAN.REPAYS'
/
declare
  shed_fil varchar2(4000);
  pl_sql varchar2(4000);
  n varchar2(256);
  n1 varchar2(256);   
begin
  for fil in (select value from variable_guides where (reference,branch) 
  in (select reference,branch from guides gd where gd.type_doc = 1198 and code <> 'FORM_STORAGE' and code1 <> '201' and num1 <> 405 ) and name = 'DBLINK_M' 
  ) loop
    pl_sql := ' select job_name,start_1 from shed_jobs@'||fil.value||' where job_name = ''COUNT_PERCENT''';
      --pl_sql := 'select what,broken from all_jobs@'||fil.value||'  where instr(upper(what),upper(''PurgeAudit'')) > 0';
    begin
      execute immediate pl_sql into n,n1;
      --DBMS_output.put_line(pl_sql);   
    exception when OTHERS then
      n := '������ �� �������� �� �������, �������� �� �������� ����';
    end;
    DBMS_output.put_line(fil.value||'. '||n||'>>'||n1);   
  end loop;
end;    
/
--�����
select (select global_name from global_name@nnovg) fil,sh.* from user_jobs@nnovg sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@nsibirsk) fil,sh.* from user_jobs@nsibirsk sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@spburg) fil,sh.* from user_jobs@spburg sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@ekburg) fil,sh.* from user_jobs@ekburg sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@rostov) fil,sh.* from user_jobs@rostov sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@stavropol) fil,sh.* from user_jobs@stavropol sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
union all
select (select global_name from global_name@khabarovsk) fil,sh.* from user_jobs@khabarovsk sh where instr(upper(what),'OUR_TOOLS.') > 0 and instr(upper(what),'_ARCHIVE') > 0     
/

declare
 jb number; 
BEGIN
  select job into jb from user_jobs@nnovg sh where instr(upper(what),'OUR_TOOLS.SET_ARCHIVE(2135') > 0;
  DBMS_JOB.CHANGE@nnovg(jb, NULL,to_date('13.05.2016 0:01:00','dd.mm.yyyy hh24:mi:ss'),'TRUNC(SYSDATE)+1+1/24/60');
END;
/

BEGIN
DBMS_JOB.CHANGE(14144, NULL, NULL, 'SYSDATE + 3');
END;

select (select global_name from global_name@khabarovsk) fil,sh.* from user_jobs@stavropol sh where instr(upper(what),'OUR_TOOLS.SET_ARCHIVE(2135') > 0

select * from user_jobs sh where instr(upper(what),'OUR_TOOLS.SET_ARCHIVE(2135') > 0


--�������� ���
insert into shed_jobs@khabarovsk
select * from shed_jobs where job_name = 'OD_180_PTOOLS_RETAIL'


insert into SHED_DEPENDS@khabarovsk
select * from SHED_DEPENDS  where job_name = 'OD_180_PTOOLS_RETAIL'


