--�� ���� ������� �������� ��
declare 
 n number;
begin
  for i in (select fil from (select 'rostov' fil from dual@rostov union all select 'krasnodar' fil from dual@krasnodar union all select 'stavropol' fil  from dual@stavropol union all select 'spburg' fil  from dual@spburg
 union all select 'nsibirsk' fil  from dual@nsibirsk union all select 'ekburg' fil from dual@ekburg union all select 'kazan' fil  from dual@kazan union all select 'khabarovsk' fil  from dual@khabarovsk
  union all select 'nnovg' fil  from dual@nnovg union all select 'ufa' fil  from dual@ufa))
 loop
 --  dbms_output.put_line(i.fil);
   execute immediate 'select count(*) from chg_obj@'||i.fil||' where date_modify > sysdate-1 and tbl = ''D_1432'' and status = 1' into n;
   dbms_output.put_line(i.fil||' = '||n);
  end loop;
end;
/

select rowid,c.* from chg_obj@ufa c where date_modify > sysdate-1 and tbl = 'D_1432' and reference = 45654098 status = 1 

update  chg_obj@rostov c set status = 1 where date_modify > sysdate-1 and tbl = 'D_1432' 
/
select * from documents_delete where related = 45654098 
select * from archive where related = 45654098 
select * from documents where related = 45654098 
/
select * from documents@ufa where reference = 6595064 
select * from journal@ufa where docnum = 6595064
select * from Archive@rostov where reference = 45654098 
/
--������� ����������
insert into documents@rostov  select * from archive@rostov  d where reference in 
(select reference from chg_obj@rostov  where date_modify > sysdate-1 and status in (0,1) and tbl = 'D_1432') 

insert into variable_documents@rostov  select * from variable_archive@rostov  d where reference  in 
(select reference from chg_obj@rostov  where date_modify > sysdate-1 and status in (0,1) and tbl = 'D_1432')

delete archive@rostov  where reference  in
(select reference from chg_obj@rostov where date_modify > sysdate-1 and status in (0,1) and tbl = 'D_1432')
/

select reference,branch from documents where date_work = trunc(sysdate) and (branch_related,related) in 
(select branch,reference from chg_obj@stavropol where date_modify > sysdate-1 and tbl = 'D_1432'
union all
select branch,reference from chg_obj@spburg where date_modify > sysdate-1 and tbl = 'D_1432'
union all
select branch,reference from chg_obj@nnovg where date_modify > sysdate-1 and tbl = 'D_1432'
union all
select branch,reference from chg_obj@kazan where date_modify > sysdate-1 and tbl = 'D_1432'
)

delete jou20150422

create table jou20150422 as
insert into jou20150422
select * from journal where (docnum,branch) in
(select reference,branch from documents where date_work = trunc(sysdate) and (branch_related,related) in 
(select branch,reference from chg_obj@ufa where date_modify > sysdate-1 and tbl = 'D_1432')
)
/
-- � ���� �������� ��������� ���� �� �����
update jou20150422 set work_date = to_date('21.04.2015','dd.mm.yyyy'), value_date = to_date('21.04.2015','dd.mm.yyyy') 
/
delete from journal where (docnum, branch) in (select docnum, branch from jou20150422)
/
insert into journal select * from jou20150422 
/
update documents d set date_work = to_date('21.04.2015','dd.mm.yyyy'), date_value = to_date('21.04.2015','dd.mm.yyyy'), date_document = to_date('21.04.2015','dd.mm.yyyy')  
    where (reference, branch) in (select docnum, branch from jou20150422)
/