declare
  cnt number;
  procedure test(ii number) is
  begin
  end;
begin
  cnt := 0;
  for i in 0..cnt loop
    test(i); 
    dbms_output.put_line(to_char(i)||' = '||to_char(sysdate,'dd.mm.yyyy hh24:mi:ss'));
  end loop; 
end;