119673911889

--��������� ��
select a.id,a.state_id,a.c_main_doc,a.c_next_ref,a.c_first_ref,c_receiver#acc
,(select name from states where id=a.state_id) state_name
,a.c_block_data,a.c_clinfo
,a.c_type_doc
,a.* 
from z#docum_rc a 
where 
c_main_doc=119673850544--66172630161
--id in (66172629956,66172630200) -- ������ �� ���������� �������� c_sub_doc 
--and c_audit#rcv_file='DocMessId_65681069659'


-- ���������
select a.c_user_type--a.c_sum,a.id,a.state_id,a.c_num_kt,a.c_kl_kt#2#1
,(select name from states where class_id=a.class_id and id=a.state_id) state_name
,a.* 
from z#document a 
where 
119673850544 in (id)--,c_main_smart)
--119676279391 in (id,c_main_smart)

119673911888

-- ��������� ���������
select 
--a.c_sum,a.id,a.state_id,a.c_num_kt,a.c_kl_kt#2#1
--,(select name from states where class_id=a.class_id and id=a.state_id) state_name
--,
a.c_main_smart,a.C_IN_folder,
a.* 
from z#main_docum a 
where 
--119978356376 in (id,c_main_smart)
--119676279391 in (id,c_main_smart)
id in (119978356376,119978355063,119978356408)

select a.*
from z#folder_pay a 
where 
--119978356376 in (id,c_main_smart)
--119676279391 in (id,c_main_smart)
id in (119978356376,119978355063,119978356408)

select a.*
from z#PATTERN_DOC a where id=10538949

select * from z#bnk_ibboss where 
C_ID_MAIN_DOCUM in (119676279391) --

trunc(c_create_date)>=trunc(sysdate)-3 
and c_commondocid='CFTM_IBBS_119675340798'

select * from z#CIT_OUT_REQUEST 
where id in (select c_req_out from z#bnk_ibboss where C_ID_MAIN_DOCUM=119675340798) 
--where trunc(c_push_time)=trunc(sysdate)

-- ���������
select * from z#CIT_IN_REQUEST 
where id in (select c_receipt from z#bnk_ibboss where C_ID_MAIN_DOCUM=119675340798) 


-- response
select * from z#CIT_IN_REQUEST 
where id in (select c_req_in from z#bnk_ibboss where trunc(c_create_date)>=trunc(sysdate)-3 and c_req_in is not null and C_ID_MAIN_DOCUM=119675340798) 

