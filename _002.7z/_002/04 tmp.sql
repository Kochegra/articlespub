			select  distinct g1.C_CTRL_OBJ C_T_ID
			from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
			where g1.C_CTRL_TYPE = f1.ID and (g1.C_CTRL_STATE = 2047892 and g1.C_PRIORITY = (
				select  MIN(h1.C_PRIORITY) A$1
				from Z#AUX_CTRL_ACCEPT h1
				where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
			)) and g1.C_CTRL_TYPE = 118609769681
and g1.C_CTRL_OBJ in (119978273313)

select * from Z#AUX_CTRL_TYPE

select * from Z#COM_STATUS_PRD 

select 
(select C_NAME||' ('||C_CODE||')' from Z#AUX_CTRL_TYPE where id=a.c_ctrl_TYPE) NAME_TYPE_CTRL,
(select C_NAME||' ('||C_CODE||')' from Z#COM_STATUS_PRD where id=a.c_ctrl_STATE) NAME_STATE_CTRL,
a.* from  Z#AUX_CTRL_ACCEPT a where C_CTRL_OBJ in (--119978273313,119978330341,
119974906146)

select count(*) from z#main_docum a1 

-- zapros
select 
--count(*)
aa1.C_T_ID,aa1.C_PRIZNAK,mfr1.C_PRIZNAK,
a1.* 
from z#main_docum a1 
left join 
    (
        select distinct g1.C_CTRL_OBJ C_T_ID,'MARSHRUT' C_PRIZNAK
            from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
            where g1.C_CTRL_TYPE = f1.ID 
                and g1.C_CTRL_STATE = 2047892 
                    --and g1.C_PRIORITY = (
                        --select  MIN(h1.C_PRIORITY) A$1
                        --from Z#AUX_CTRL_ACCEPT h1
                        --where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
                    --)) 
                and g1.C_CTRL_TYPE = 118609769681
                --and g1.C_CTRL_OBJ in (119962415825)
                and g1.c_create_date >= to_date('26.09.2022','dd.mm.yyyy')
    ) aa1
on a1.id=aa1.C_T_ID --C_CTRL_OBJ    
left join (select id,'MFR' C_PRIZNAK from z#main_docum where id = 119963775719) mfr1
on a1.id=mfr1.id
where a1.c_date_doc>=to_date('26.09.2022','dd.mm.yyyy') 
and a1.id in (119964695392,119963775719,119964080350,119964421916,119964493988,119732193790,119732633117,119961891780,119964343767,119964443356,119964515344,119974918454,119977352345,
119974906210,119976825349,119976825399,
--
119977281906,119962430991,119962415825,119977280593,119974906146,119976936977)
--and (aa1.C_PRIZNAK is null or aa1.C_PRIZNAK is not null)

--zapros +
select 
--count(*)
aa1.C_T_ID,aa1.C_PRIZNAK,mfr1.c_priznak,
a1.* 
from z#main_docum a1, 
    (
        select distinct g1.C_CTRL_OBJ C_T_ID,'MARSHRUT' C_PRIZNAK
            from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
            where g1.C_CTRL_TYPE = f1.ID 
                and g1.C_CTRL_STATE = 2047892 
                    --and g1.C_PRIORITY = (
                        --select  MIN(h1.C_PRIORITY) A$1
                        --from Z#AUX_CTRL_ACCEPT h1
                        --where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
                    --)) 
                and g1.C_CTRL_TYPE = 118609769681
                --and g1.C_CTRL_OBJ in (119962415825)
                and g1.c_create_date >= to_date('26.09.2022','dd.mm.yyyy')
    ) aa1,
    (select id,'MFR' C_PRIZNAK from z#main_docum where id = 119963775719) mfr1
where a1.id=aa1.C_T_ID(+)
and a1.id=mfr1.id(+) 
and a1.c_date_doc>=to_date('26.09.2022','dd.mm.yyyy') 
and a1.id in (119964695392,119963775719,119964080350,119964421916,119964493988,119732193790,119732633117,119961891780,119964343767,119964443356,119964515344,119974918454,119977352345,
119974906210,119976825349,119976825399,
--
119977281906,119962430991,119962415825,119977280593,119974906146,119976936977)


-- zapros +2
--zapros +
select 
--count(*)
aa1.C_ID,aa1.C_PRIZNAK,
a1.* 
from z#main_docum a1, 
    (
        select distinct to_number(g1.C_CTRL_OBJ) C_ID,'MARSHRUT' C_PRIZNAK
            from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
            where g1.C_CTRL_TYPE = f1.ID 
                and g1.C_CTRL_STATE = 2047892 
                    --and g1.C_PRIORITY = (
                        --select  MIN(h1.C_PRIORITY) A$1
                        --from Z#AUX_CTRL_ACCEPT h1
                        --where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
                    --)) 
                and g1.C_CTRL_TYPE = 118609769681
                --and g1.C_CTRL_OBJ in (119962415825)
                and g1.c_create_date >= to_date('26.09.2022','dd.mm.yyyy')
         union all
         select mfr1.id C_ID,'MFR' C_PRIZNAK from z#main_docum mfr1 where mfr1.id = 119963775719       
    ) aa1
where a1.id=aa1.C_ID(+)
and a1.c_date_doc>=to_date('26.09.2022','dd.mm.yyyy') 
and a1.id in (119964695392,119963775719,119964080350,119964421916,119964493988,119732193790,119732633117,119961891780,119964343767,119964443356,119964515344,119974918454,119977352345,
119974906210,119976825349,119976825399,
--
119977281906,119962430991,119962415825,119977280593,119974906146,119976936977)


        select distinct to_number(g1.C_CTRL_OBJ) C_ID,'MARSHRUT' C_PRIZNAK
            from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
            where g1.C_CTRL_TYPE = f1.ID 
                and g1.C_CTRL_STATE = 2047892 
                    --and g1.C_PRIORITY = (
                        --select  MIN(h1.C_PRIORITY) A$1
                        --from Z#AUX_CTRL_ACCEPT h1
                        --where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
                    --)) 
                and g1.C_CTRL_TYPE = 118609769681
                --and g1.C_CTRL_OBJ in (119962415825)
                and g1.c_create_date >= to_date('26.09.2022','dd.mm.yyyy')
         union all
         select mfr1.id C_ID,'MFR' C_PRIZNAK from z#main_docum mfr1 where mfr1.id = 119963775719       



select * from z#main_docum where id = 119963775719




select  
(select count(1) from z#main_docum where id=g1.C_CTRL_OBJ) aaa,
g1.* --
--distinct g1.C_CTRL_OBJ C_T_ID
from Z#AUX_CTRL_ACCEPT g1, Z#AUX_CTRL_TYPE f1
where g1.C_CTRL_TYPE = f1.ID 
    and g1.C_CTRL_STATE = 2047892 
        --and g1.C_PRIORITY = (
				--select  MIN(h1.C_PRIORITY) A$1
				--from Z#AUX_CTRL_ACCEPT h1
				--where h1.C_CTRL_OBJ = g1.C_CTRL_OBJ and h1.C_CTRL_STATE = 2047892
			--)) 
	and g1.C_CTRL_TYPE = 118609769681
--and g1.C_CTRL_OBJ in (119962415825)
and c_create_date >= to_date('26.09.2022','dd.mm.yyyy')

select  
(select count(1) from z#main_docum where id=g1.C_CTRL_OBJ) aaa,
g1.* 
from Z#AUX_CTRL_ACCEPT g1

select 
count(*)
from z#main_docum a1 
where a1.c_date_doc>=to_date('26.09.2022','dd.mm.yyyy') 
