select md.c_filial,md.c_depart,
md.* 
from z#main_docum md
where md.C_DATE_DOC>=to_date('08.10.2022','dd.mm.yyyy')
and exists(select null from z#AUX_CTRL_ACCEPT aca,z#AUX_CTRL_TYPE act where aca.C_CTRL_TYPE = act.ID and aca.c_ctrl_obj=md.id and act.c_code='BNK_NULLACCKT_UPIB')

d1.C_CTRL_TYPE = c1.ID 
and d1.C_CTRL_OBJ in (119962430991,119962415825)
and c1.c_code='BNK_NULLACCKT_UPIB'


select * from z#AUX_CTRL_TYPE where c_code='BNK_NULLACCKT_UPIB'

select 
(select id||' '||C_CODE||' '||C_NAME from z#COM_STATUS_PRD where id=aca.c_ctrl_state) COM_STATUS_RPD--c_name='WAIT_CONF')
,(select id||' '||C_CODE||' '||C_NAME from z#AUX_CTRL_TYPE where ID=c_ctrl_type) AUX_CTRL_TYPE
,aca.* 
from z#AUX_CTRL_ACCEPT aca where c_ctrl_obj in (119962430991,119962415825)

select * from z#COM_STATUS_PRD where c_code='WAIT_CONF'

select * from z#access_param where id=118609769680 --c_code like '%UPIB%' --='BNK_NULLACCKT_UPIB'

select 
(select c_code||' '||c_name from z#access_param where id=a.obj_id) acc_par,
a.* from Object_Rights_EX a where right_class_id='AUX_CTRL_TYPE' and subj_id like '%UPIB%'


select  d1.*,c1.*
from Z#AUX_CTRL_ACCEPT d1, Z#AUX_CTRL_TYPE c1
where d1.C_CTRL_TYPE = c1.ID 
and d1.C_CTRL_OBJ in (119962430991,119962415825)
and c1.c_code='BNK_NULLACCKT_UPIB'

--and (a1.ID = d1.C_CTRL_OBJ and d1.C_CTRL_STATE = 2047892 and d1.C_PRIORITY = (
				select  MIN(e1.C_PRIORITY) 
				from Z#AUX_CTRL_ACCEPT e1
				where e1.C_CTRL_OBJ = a1.ID and e1.C_CTRL_STATE = 2047892
			) 
--and exists (select 1 from object_rights_ex o, subj_equal e where e.subj_id=SYS_CONTEXT('IBS_SYSTEM','USR') and o.subj_id=e.equal_id and o.obj_id=to_char(c1.C_ACCESS_PARAM) and o.right_class_id='AUX_CTRL_TYPE' and o.class_id='ACCESS_PARAM')
) and d1.C_CTRL_TYPE = 118609769681
