select * from z#account where c_date_op>=to_date('01012022','ddmmyyyy')

select * from z#ac_fin where c_date_close>=to_date('01012022','ddmmyyyy')

select 
--a.*,af.*
a.id,af.id,af.c_main_v_id,a.c_date_op,af.c_date_close 
from z#account a, z#ac_fin af 
where a.id=af.id and a.c_date_op>=to_date('01012021','ddmmyyyy') and af.c_date_close>=to_date('01012021','ddmmyyyy')
and substr(af.c_main_v_id,1,5) in (select c_bal_acc from z#BNK_311P_ACCS)
and af.c_main_v_id in ('40702978600030002684','40702810000810002650','42102810812090001161')

select * from values_history
where class_id='AC_FIN' 
and QUAL in (--'COM_STATUS')--, 
'CLIENT_V'--, '#NEWOBJ#'
)

and time>=to_date('01012021','ddmmyyyy')
and obj_id in (23135981612,35191902644,508846660)


select * from z#cl_hist where id in (31660624268,31379378534,31711177083,31711177059)

/
select af.* from z#ac_fin af
where
substr(af.c_main_v_id,1,5) in (select c_bal_acc from z#BNK_311P_ACCS)
and exists(select null from values_history where class_id='AC_FIN' and QUAL in ('CLIENT_V')
            and time>=to_date('01032021','ddmmyyyy') and time<=to_date('01062021','ddmmyyyy')
            and obj_id=af.id)
--and exists(select null from z#cl_hist where C_DATE_EDIT >= to_date('01032021','ddmmyyyy') and C_DATE_EDIT <=to_date('01062021','ddmmyyyy') 
--            and C_QUAL in ('REGISTER.GOS_REG_NUM_REC', 'REGISTER.DATE_REG', 'INN', 'NAME', 'LONG_NAME','KPP_ARR')
--            and C_VALUE is not null
--            and C_CLIENT_REF = af.C_CLIENT_V)            

and (exists(select null from values_history where class_id='AC_FIN' and QUAL in ('CLIENT_V')
            and time>=to_date('01032021','ddmmyyyy') and time<=to_date('01062021','ddmmyyyy')
            and obj_id=af.id)
    or
    exists(select null from z#cl_hist where C_DATE_EDIT >= to_date('01032021','ddmmyyyy') and C_DATE_EDIT <=to_date('01062021','ddmmyyyy') 
            and C_QUAL in ('REGISTER.GOS_REG_NUM_REC', 'REGISTER.DATE_REG', 'INN', 'NAME', 'LONG_NAME','KPP_ARR')
            and C_VALUE is not null
            and C_CLIENT_REF = af.C_CLIENT_V)
    )            
/

select vh.*,af.* from values_history vh,z#ac_fin af
where
vh.obj_id=af.ID
and vh.class_id='AC_FIN' and vh.QUAL='CLIENT_V'
and vh.time>=to_date('01032021','ddmmyyyy') and vh.time<=to_date('01062021','ddmmyyyy')
and substr(af.c_main_v_id,1,5) in (select c_bal_acc from z#BNK_311P_ACCS) 


select a.c_in_file_history,a.c_account,a.* from z#gni_jour a where c_working_datetime >= to_date('01012022','ddmmyyyy')

where id in (551004869,551010799,550992082,550992116,550985235,550985276,550985507,551004785) --=552714829

select * from values_history
where 
id=32327607235 and time>=to_date('01012022','ddmmyyyy')

--class_id='AC_FIN' 
--and QUAL in ('COM_STATUS','CLIENT_V','#NEWOBJ#')
and time>=to_date('18012021','ddmmyyyy')-1 and time<=to_date('18012021','ddmmyyyy')+1

and obj_id in (508846660)

select * from z#gni_jour 

select * from z#vtb_gni_acc