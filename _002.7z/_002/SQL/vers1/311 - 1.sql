--��� VTB_311P_CONTR
select * from z#VTB_311P_CONTR

-- �������� LOAD_EVENTS - �������� ������� �� ������/��������/���������

-- ��� BNK_311p_accs - ���������� ��2
select * from z#BNK_311p_accs


-----------------------------------------------------------------------------------------------------------------------
select * from z#VTB_GNI_ACC-- where a.[ACC] = ac and a.[TYPE_MSG].[0] = 1

select af.* from z#ac_fin af
where class_id= 'AC_FIN' 
and id=23039019787
--and exists(select null from z#account where c_date_op>=trunc(sysdate)-10 and id=af.id and class_id=af.class_id) 

select a.c_date_op,af.* from z#ac_fin af, z#account a
where af.id=a.id and af.class_id=a.class_id 
and af.class_id= 'AC_FIN' 
and a.c_date_op>trunc(sysdate)

select a.c_date_op,af.* from z#account a, z#ac_fin af 
where a.id=af.id and a.class_id=af.class_id 
and a.class_id= 'AC_FIN' 
--and a.c_date_op>=trunc(sysdate)-3 and a.c_date_op<=trunc(sysdate)-3
and substr(af.c_main_v_id,1,5) in (select c_bal_acc from z#BNK_311P_ACCS)
and af.C_main_v_id in ('40702810000810002650','42102810812090001161')

--PL_USV ������� �����
select * from z#pl_usv where id in (2178746149,63376886529) 

select * from z#depart where id=63336825168

select * from z#gni_jour

select d.* 
from z#depn d
where exists(select null from z#VTB_311P_CONTR where c_account=d.c_account)

select *from (
select distinct d.c_account,count(*)cnt 
from z#depn d
where exists(select null from z#VTB_311P_CONTR where c_account=d.c_account)
group by d.c_account
) where cnt>1

23039019787