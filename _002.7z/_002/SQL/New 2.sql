select a1.id,a1.CLASS_ID,a1.C_MAIN_V_ID,a1.C_TO_PRODUCT from 
Z#AC_FIN a1
--, (
--    select c2.id,c2.c_num_dog,c1.C_ACCOUNT,c1.id 
--    from Z#PRODUCT c2, Z#RKO c1
--    where c1.id=c2.id and c1.c_account=a1.id)--23135981612)
where a1.id=23135981612   


select c2.* 
from Z#PRODUCT c2
where c2.id=28293888583


select c1.* 
from Z#RKO c1
where c1.c_account=23135981612


select a1.id,a1.CLASS_ID,a1.C_MAIN_V_ID,a1.C_TO_PRODUCT from 
Z#AC_FIN a1
left join 
where a1.id=23135981612


select 
--a1.id,a1.CLASS_ID,a1.C_MAIN_V_ID,a1.C_TO_PRODUCT,d1.id,d1.c_account,c1.c_account,c1.id
--,c2.id,c2.c_num_dog
--,j.c_filename
a1.*,d1.*,c1.*,c2.*,j.*
from Z#AC_FIN a1
,Z#DEPN d1
,Z#RKO c1
,Z#PRODUCT c2
,z#GNI_JOUR j
where 
--c2.id=c1.id(+) 
a1.id=d1.c_account(+)
and a1.id=c1.c_account(+)
and coalesce(d1.id,c1.id)=c2.id(+)
and a1.id=j.c_account
--and c2.id=d1.id(+)
and 
a1.id in (23135981612,508846660)

select c1.* 
from Z#RKO c1
where c1.c_account=23135981612
   
