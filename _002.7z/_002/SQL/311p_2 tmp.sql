SELECT 
A1.*--Id ID, a1.CLASS_ID Class_Id, a3.STATE_ID State_Id, 
		from Z#AC_FIN a1, Z#BRANCH a2, Z#ACCOUNT a3, Z#CLIENT a4, Z#COM_STATUS_PRD a5, Z#TYPE_BANK_ACC a6, (
			select  c2.C_NUM_DOG C_NUM_DOG, c1.C_ACCOUNT C_ACC
			from Z#PRODUCT c2, Z#RKO c1
			where c1.id=c2.id
			  and (c1.C_ACCOUNT = a1.ID)
		) b1, Z#GNI_JOUR d1, Z#GNI_OPCLOS_ACFIN d2
		where a1.C_FILIAL=a2.id(+) and a1.id=a3.id and a1.C_CLIENT_V=a4.id(+) and a1.C_COM_STATUS=a5.id(+) and a1.C_TYPE_BANK_ACC=a6.id(+) and d1.C_GNI_BLANK=d2.id(+)
		  and (a1.ID = b1.C_ACC and a1.ID = d1.C_ACCOUNT and a1.C_MAIN_V_ID = '40702810000810002650')
		  
		  
SELECT 
A1.*--Id ID, a1.CLASS_ID Class_Id, a3.STATE_ID State_Id, 
from Z#AC_FIN a1
where a1.id=508846660
--a1.C_MAIN_V_ID = '40702810000810002650'


select * from Z#RKO where c_account=508846660

select * from Z#VTB_DEAL where c_acc_deal=508846660

select a1.* from 
Z#AC_FIN a1
, (
    select c2.id,c2.c_num_dog,c1.C_ACCOUNT,c1.id 
    from Z#PRODUCT c2, Z#RKO c1
    where c1.id=c2.id and c1.c_account=a1.id)--23135981612)
where a1.id=23135981612    


select * from Z#depn where c_account=508846660

select * from Z#PRODUCT where id=508846629

		
--		, Z#BRANCH a2, Z#ACCOUNT a3, Z#CLIENT a4, Z#COM_STATUS_PRD a5, Z#TYPE_BANK_ACC a6, (
--			select  c2.C_NUM_DOG C_NUM_DOG, c1.C_ACCOUNT C_ACC
--			from Z#PRODUCT c2, Z#RKO c1
--			where c1.id=c2.id
--			  and (c1.C_ACCOUNT = a1.ID)
--		) b1, Z#GNI_JOUR d1, Z#GNI_OPCLOS_ACFIN d2
		where a1.C_FILIAL=a2.id(+) and a1.id=a3.id and a1.C_CLIENT_V=a4.id(+) and a1.C_COM_STATUS=a5.id(+) and a1.C_TYPE_BANK_ACC=a6.id(+) and d1.C_GNI_BLANK=d2.id(+)
		  and (a1.ID = b1.C_ACC and a1.ID = d1.C_ACCOUNT and a1.C_MAIN_V_ID = '40702810000810002650')
		  
