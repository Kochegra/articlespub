select gp.* from z#gmp_pay gp 
where  c_created >= trunc(sysdate)-10
and not exists (select null from z#MD_REQS where c_md_ref=gp.C_DOC_REF)
--and id=128160934084

select * from z#MD_REQS where c_md_ref in (128341955708)

select * from z#MD_REQS


select mr.*,gp.* 
from z#gmp_pay gp
left join  z#MD_REQS mr
on gp.C_DOC_REF=mr.c_md_ref
where  gp.c_created >= trunc(sysdate)-10
