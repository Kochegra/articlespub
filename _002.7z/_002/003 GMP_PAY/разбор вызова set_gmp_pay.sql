-- ������ ������� Z$GMP_PAY_LIB.set_gmp_pay
select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_LIB.set_gmp_pay%')

Z$MAIN_DOCUM_CALC_PAR
Z$DOCUMENT_INT_INT_DOC_AUX_001
Z$UNIVERS_IMP_IMP_PL_DOC_CITY
Z$UNIVERS_IMP_LOAD_ED108
Z$DOCUMENT_RBS_LIB
Z_MAIN_DOCUM_CALC_PAR
Z$MAIN_DOCUM_EDIT_DOC


select 'LIB',a.* from all_source a where upper(text) like upper('%set_gmp_pay%')
and instr(upper(text),upper('%Z$GMP_PAY_LIB.set_gmp_pay%'))=0

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$MD_REQS_LIB.set_upno%')
