declare
stat varchar2(100);
fil varchar2(100);
begin
    stat:='FORM';
    fil:='FL';
    if not (fil='FL' and stat<>'FORM') then
        dbms_output.put_line('exec');
    else 
        dbms_output.put_line('no exec');
    end if;
end;
/
