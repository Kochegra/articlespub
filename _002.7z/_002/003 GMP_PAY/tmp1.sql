select * from z#vtb_wps

select * from z#CIT_IN_REQuest where id in (128164917723)

select * from z#CIT_OUT_REQuest where id = 201740881397
order by id desc


select * from Z#VTB_R_INTEGRATOR where c_date_time>=trunc(sysdate)
and c_cit_in_req_ref in (128164917723)
--and c_cit_out_req_ref in (128164917723)
order by c_date_time desc

select * from z#VTB_CANONIC where id=128164917734


SELECT 
A1.Id ID, a2.CLASS_ID Class_Id, 
a1.ID C_1, 
a2.C_EXT_SYS_CODE C_2, 
a2.C_DATE_TIME C_3, 
a2.C_MESS_ID C_4, 
a2.C_CIT_IN_REQ_REF REF5, 
DECODE(a2.C_CIT_IN_REQ_REF,null,null,'(***)') C_5, 
a2.C_CIT_IN_REQ_REF C_6, 
a2.C_CIT_OUT_REQ_REF REF7, 
DECODE(a2.C_CIT_OUT_REQ_REF,null,null,'(***)') C_7, 
d2.C_LOGS REF8, 
DECODE((select count(1) from Z#VTB_R_LOG tc where tc.collection_id=d2.C_LOGS and rownum=1),0,'{...}','{***}') C_8, 
b1.ID REF9, 
DECODE(b1.ID,null,null,'(***)') C_9, 
c1.ID REF10, 
DECODE(c1.ID,null,null,'(***)') C_10, 
c1.ID C_11
		from (Z#VTB_CANONIC a1 join Z#VTB_R_INTEGRATOR a2 on a1.id=a2.id) left join Z#VTB_RECV_MAINDOC b1 on TO_CHAR(a1.ID) = b1.C_PARENT_GUID left join Z#FOLDER_PAY c1 on b1.C_MAIN_DOC = c1.ID left join (Z#BNK_WPS_I_DOC_CR d1 join Z#VTB_R_ENTITY d2 on d1.id=d2.id) on d2.C_VTB_SYSTEM = a1.ID
where a1.id in (128164917734)


select * from z#main_docum where id in (128370049666)

select a.c_payment_date,a.* from z#gmp_pay a 
where 
--id in (128344797683) 
--c_doc_ref in (128344797683)
--and 
c_created >= trunc(sysdate)-1

--and id=128160934084
and c_doc_state not in ('FORM')

select * from z#MD_REQS where c_md_ref in (128370049666)

select a.c_pay_id, a.c_pay_date, a.* from z#gov_payment a where trunc(c_pay_date)>=trunc(sysdate)-10
and c_pay_id='10403497580000941612202200000002'


select a.* from z#gov_msg a where trunc(c_created)>=trunc(sysdate)-1

select * from z#gmp_add_data 

select * from z#docum_rc where 
--id=128344805569
c_main_doc in (128344797683)

select 
a.id,a.state_id,a.c_main_doc,a.c_next_ref,a.c_first_ref,c_receiver#acc
,(select name from states where id=a.state_id) state_name
,a.c_block_data,a.c_clinfo
,a.c_type_doc
,a.* 
from z#docum_rc a where a.c_main_doc=128164917965

select a.c_document_num,a.C_KL_KT#2#1,a.C_BUD_REQS#TAXPAYER_STR,a.c_code,a.C_KL_KT#2#3,
(select C_KS from z#CL_BANK_N where id=a.C_KL_KT#2#3) KT_KS,
a.c_nazn,
a.* from z#main_docum a 
where
id in (128164917965)

--and 
c_date_doc >= trunc(sysdate)-3
and C_KL_KT#2#1 like '03%'
--and C_BUD_REQS#TAXPAYER_STR='08'
and exists(select null from z#CL_BANK_N where id=a.C_KL_KT#2#3 and substr(c_KS,1,5)='40102')
--and c_code=0

and state_id='FORM'



select * from z#text_jobs


select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_LIB.set_gmp_pay%')

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_LIB.get_pay_id%')

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_SEND_PAY%')

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_CALC_PAY_ID%')

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$MD_REQS_LIB%')
