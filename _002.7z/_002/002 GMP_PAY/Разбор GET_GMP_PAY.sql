-- ��������� �������� ������


-- GMP_PAY_COND
		select	x.* from z#GMP_PAY_COND x
		where x.C_ACTIVE='1' --����������

-- GMP_PAY
		select	x.* from z#GMP_PAY x
		--where x.C_ACTIVE='1' --����������

--CHECK_PAY
select t.* from DBA_DEPENDENCIES t 
where 1=1 
and REFERENCED_NAME = 'Z$GMP_PAY_CHECK_PAY'

select 'CHECK_PAY',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_CHECK_PAY%')

-- GMP_PAY_COND_LIB
select t.* from DBA_DEPENDENCIES t 
where 1=1 
and REFERENCED_NAME = 'Z$GMP_PAY_COND_LIB'

select 'GMP_PAY_COND.LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_COND_LIB%')

-- set_GMP_pay
select 'LIB.set_GMP_pay',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_LIB.set_GMP_pay(%')
union all
select 'VTB_LIB.set_GMP_pay',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_VTB_LIB.set_GMP_pay(%')

select a.* from all_source a where upper(text) like upper('%Z#GMP_PAY_COND%')

--Z$HOOK_GMP_CHK_CP_1
select t.* from DBA_DEPENDENCIES t 
where 1=1 
and REFERENCED_NAME = 'Z$HOOK_GMP_CHK_CP_1'

select 'Z$HOOK_GMP_CHK_CP_1',a.* from all_source a where upper(text) like upper('%Z$HOOK_GMP_CHK_CP_1%')

--- �������� ��� ���, ����� ��� ���� ����������
-- ���������, ����� MAIN_DOCUM. � ��� ������,������ �� ��� �� ���������� (NULL), ���������� ��������� ���������.
--Z$GMP_PAY_LIB.CHECK_GMP_PAY
select 'Z$GMP_PAY_LIB.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_LIB.CHECK_GMP_PAY%')

select 'Z$GMP_PAY_VTB_LIB.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_VTB_LIB.CHECK_GMP_PAY%')

select 'Z$DOCUMENT_INT_INT_DOC_AUX_001.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$DOCUMENT_INT_INT_DOC_AUX_001.CHECK_GMP_PAY%')

--Z$DEPN_INTERFACE_PRX_DOCUMENT
select 'Z$DEPN_INTERFACE_PRX_DOCUMENT.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$DEPN_INTERFACE_PRX_DOCUMENT.CHECK_GMP_PAY%')
Z$DEPN_RET_DEPOSIT_LOUT ok �������� main_docum
Z$DEPN_VTB_RT_DPST_LOUT ok �������� main_docum

--Z$BC_INTERFACE_PRX_TRC
select 'Z$BC_INTERFACE_PRX_TRC.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$BC_INTERFACE_PRX_TRC.CHECK_GMP_PAY%')
Z$BANK_CLIENT_LIB_FIN ok �������� main_docum

--Z$BIPRNT_INTERFACE_PRX12072526
select 'Z$BIPRNT_INTERFACE_PRX12072526.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$BIPRNT_INTERFACE_PRX12072526.CHECK_GMP_PAY%')

--Z$DECLAR_INTERFACE_PRX12031919
select 'Z$DECLAR_INTERFACE_PRX12031919.CHECK_GMP_PAY',a.* from all_source a where upper(text) like upper('%Z$DECLAR_INTERFACE_PRX12031919.CHECK_GMP_PAY%')
Z$DECLARE_EDIT#AUTO_OUT
Z$DECLARE_FOR_PROV



select t.* from DBA_DEPENDENCIES t 
where 1=1 
and REFERENCED_NAME = 'Z$GMP_PAY_NO_SEND_NPA'

select 'LIB',a.* from all_source a where upper(text) like upper('%Z$GMP_PAY_NO_SEND_NPA%')

--Z$BUD_REQ_CHECK_LIB
select t.* from DBA_DEPENDENCIES t 
where 1=1 
and REFERENCED_NAME = 'Z$BUD_REQ_CHECK_LIB'

select 'Z$BUD_REQ_CHECK_LIB',a.* from all_source a where upper(text) like upper('%Z$BUD_REQ_CHECK_LIB.IS_CHARGE_ID%')

--VTB_GMP_PAYER_ID_USE_DISTR_LIB
select a.* from all_source a where upper(text) like upper('%VTB_GMP_PAYER_ID_USE_DISTR_LIB%')

--Z$GMP_PAY_NO_SEND_NPA -- 12492856930
select rowid,a.* from sources a 
where name='12492856930' 
--and lower(text) like '%stack%' 
order by line

--CHECK_PAY
select rowid,a.* from sources a 
where name='12601014' 
--and lower(text) like '%stack%' 
order by type,line


&debug(' utils.call_stack = ' || utils.call_stack, 0) -- GDM