select * from z#GOV_MSG_TYPE where c_code='GMP_PAY_PACK'


select  '['||a1.CLASS_ID||'].['||a1.SHORT_NAME||']' RES, Z$INTERFACE_COMPILE_LIB.GET_INT_VER(a1.SHORT_NAME) VER, a1.SHORT_NAME SN
				from METHODS a1
				where a1.CLASS_ID = UPPER('GOV_INTERFACE') and Z$INTERFACE_COMPILE_LIB.GET_LIB_NAME(a1.SHORT_NAME) = UPPER('INT_GOV_MSG')
				order by 2 desc;


select x(x.[VERSION] : ver) in ::[GOV_MSG_TYPE_VER]
				where x.[MSG_TYPE] = p_msg_type
					  and x.[REQ_TYPE] = p_req_type
					  and x.[ACTIVE] = true
					  and x.[MAIN] = true
					  
				select  a1.* --C_VERSION VER
				from Z#GOV_MSG_TYPE_VER a1
				where a1.C_MSG_TYPE = 21011832 and a1.C_REQ_TYPE = 'ImportPaymentsRequest' and a1.C_ACTIVE = '1' and a1.C_MAIN = '1';
					  