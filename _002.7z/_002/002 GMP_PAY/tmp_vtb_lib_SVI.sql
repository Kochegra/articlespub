	else				
		&debug(' version='||&tune.gmp_version(gmp_msg),0)
	
-- 		if &tune.gmp_version(gmp_msg) like '2.%' then
 		if &tune.gmp_version(gmp_msg) > '2.0' and &tune.gmp_version(gmp_msg) < '2.5' then
			return bool_char(nvl(is_resident, false) and length(inn) = 10, '2', '3') || lpad(inn, 12, '0') || kpp;
		elsif &tune.gmp_version(gmp_msg) like '2.5%' then
--> 27.10.2022 ��������� ������� ������ ��������� 101 ��� ������ 2.5
  			if p_req_101 in ('01','02') then
				return bool_char(nvl(is_resident, false) and length(inn) = 10, '2', '3') || lpad(inn, 12, '0') || '000000000';
			else
				return bool_char(nvl(is_resident, false) and length(inn) = 10, '2', '3') || lpad(inn, 12, '0') || kpp;
  			end if;
-->
		else
			return bool_char(nvl(is_resident, false), '2', '3') || inn || kpp;
		end if;
	end if;
