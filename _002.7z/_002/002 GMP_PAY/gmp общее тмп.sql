-- lib
select * from sources where name='12601021'
--and lower(text) like '%func%get_payer_id%' 
and lower(text) like '%stack%' 
order by line

-- vtb_lib
select * from sources 
where name='19435624055' 
and lower(text) like '%stack%' 
order by line

--Z$GMP_PAY_NO_SEND_NPA -- 12492856930
select rowid,a.* from sources a 
where name='12492856930' 
--and lower(text) like '%stack%' 
order by line

12601014

select * from z#gmp_pay 
where 
--id=120455916505 
--c_doc_ref in (123851480298)
c_created >= trunc(sysdate)-1

select 
a.id,a.state_id,a.c_main_doc,a.c_next_ref,a.c_first_ref,c_receiver#acc
,(select name from states where id=a.state_id) state_name
,a.c_block_data,a.c_clinfo
,a.c_type_doc
,a.* 
from z#docum_rc a where a.c_main_doc=120455916505

select a.c_document_num,a.C_KL_KT#2#1,a.C_BUD_REQS#TAXPAYER_STR,a.c_code,a.C_KL_KT#2#3,
(select C_KS from z#CL_BANK_N where id=a.C_KL_KT#2#3) KT_KS,
a.c_nazn,
a.* from z#main_docum a 
where
--id in (123154810115,123094179468,123072239946,123070196916,123070111864,123005025403,123062190676)
--) 
--and 
c_date_doc >= trunc(sysdate)-3
and C_KL_KT#2#1 like '03%'
--and C_BUD_REQS#TAXPAYER_STR='08'
and exists(select null from z#CL_BANK_N where id=a.C_KL_KT#2#3 and substr(c_KS,1,5)='40102')
--and c_code=0

and state_id='FORM'

select * from z#ac_fin where id=34139820 

select * from z#CL_BANK_N where id=34139820


select mod(12,10) from dual

select * from z#BUD_REQS