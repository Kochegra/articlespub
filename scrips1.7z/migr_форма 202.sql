-- ������ ������ ����� 202

begin preport_op10.form_rep_2857(to_date('15.11.2018','dd.mm.yyyy'),to_date('19.11.2018','dd.mm.yyyy'),'100;99;'); end; 


 v_symbols_str := p_symbols;
 v_pos := instr(v_symbols_str,';');


select instr('100;99;',';') from dual


v_symbol := substr(v_symbols_str, 1 ,v_pos-1);

select substr('100;99', 1 ,4-1) from dual

v_symbols_str := substr(v_symbols_str, v_pos+1);

select substr('100;99',4+1) from dual

select code symbol, str3 znak_db, replace(str1,' ','') mask_db,
       decode(str3, '=', 'j.code like '''||replace(replace(str1,' ',''),',','%'' or j.code like ''') ||'%''',
       'j.code not like '''||replace(replace(str1,' ',''),',','%'' and j.code not like ''') ||'%''') where_db,
                      str4 znak_cr, replace(str2,' ','') mask_cr,
       decode(str4, '=', 'j.assist like '''||replace(replace(str2,' ',''),',','%'' or j.assist like ''') ||'%''',
       'j.assist not like '''||replace(replace(str2,' ',''),',','%'' and j.assist not like ''') ||'%''') where_cr
                 from guides
                where type_doc = 6183 and code = '100' --v_symbol
                
                
select /*+ index (j journal_date_idx)*/ j.* from journal j 
               where j.work_date between to_date('16.11.2018','dd.mm.yyyy')
                                     and to_date('16.11.2018','dd.mm.yyyy')
               and j.flag_debit = '+' 
               and j.header = 'A' 
               and j.operation like '11%11' --||v_g.symbol ||''''

               --and j.code not like '40821%'--('||v_g.where_db||')
               --and j.assist like '20202%'--('||v_g.where_cr||');
               --
               and docnum in (7188693)
               
select instr('99;',';') from dual



                select * from guides
                where type_doc = 6183
                               