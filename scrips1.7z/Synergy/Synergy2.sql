--���������� ���������� 
select rowid, t.* from synergy_transactions t 
where vtb_tran_date > trunc(sysdate)-5-- and vtb_tran_date < trunc(sysdate)-1 
--vtb_tran_date > '09-jan-2018'  and vtb_tran_date < '12-jan-2018' 
--and doc_reference is not null
 --�������� �� ��������� � ������������ ��������� (���� ���������� ���������) 
--and status > 1 and exists (select null from documents where refer_from = t.doc_reference and branch_from = t.doc_branch and status < 50 and status > 10)
--���� ����� �� ������ � ������������ ���-� (�� ����������)
--and status = 1 and exists (select null from synergy_queries sq where vtb_tran_id = t.vtb_tran_id and status > 1 and vtb_tran_date = (select max(vtb_tran_date) from synergy_queries where vtb_tran_id = sq.vtb_tran_id and query_type = sq.query_type and status > 0))
--�� ���������� � �� ��� (������ �������)
--and status = 1 and nvl(status_bit_service,0) <> 1 and doc303_reference is not null --and vtb_tran_date < sysdate -1/24
--and exists (select null from documents where reference = t.doc_reference and branch = t.doc_branch and status not in (30))
--and exists (select null from documents where refer_from = t.doc_reference and branch_from = t.doc_branch and status < 50 and status > 10)
--and doc303_reference in (2824625294)
--or dko303_reference in (2811329642,2811350377,2811337206,2812237503,2811344129))
and 2875610104  in (doc303_reference,doc_reference,docnko_reference)
--and 2849218306 in (doc303_reference,doc_reference,docnko_reference)
--and vtb_tran_id in ('BQ_00002_582040827','SP.208722384-204652','SP.208722560-204790','SP.208721865-204276','SP.208721883-204288')
--and vtb_tran_id in ('BQ_00018_1225605398','BQ_00018_1225603971', 'BQ_00018_1225469852','BQ_00018_1225737371','BQ_00018_1225472898','BQ_00018_1225484629')
--and vtb_tran_id in ('MB.70366')
--'MFR.00018.1213910676','MFR.00040.1194097561','MFR.00040.1194904091'
--and instr(vtb_tran_id,'2848694860') > 0
--and status = 1 --and pc_oper_id > 0
order by vtb_tran_date desc
/

--�������� ������� ������  (1 - �����)  ( > 1 - ������) ( < 0 - �����������)  
select rowid, sq.* from synergy_queries sq 
where vtb_tran_id in ('MB.165328')
-- ('TS.0000000047331372','TS.0000000047321867') 
order by vtb_tran_date
/

--��� ������ �������� 
select * from mbank.clob_bill_params where --create_date >= trunc(sysdate) - 6/24
create_date >= to_date('13.03.2018 01:00:00', 'dd.mm.yyyy hh24:mi:ss') and create_date < to_date('13.03.2018 23:20:00', 'dd.mm.yyyy hh24:mi:ss')
and clob_data like '%BQ_00002_581982061%'
--create_date >= to_date('12.01.2018 23:05:00', 'dd.mm.yyyy hh24:mi:ss') and create_date < to_date('13.01.2018 3:59:00', 'dd.mm.yyyy hh24:mi:ss')
--and clob_data like '%TS.0000000047945159%'
--and instr(function_name,'SYNERGY') = 0 and instr(function_name,'UNIPAY') = 0 
order by gid, create_date
/

--���������� ���������� 
select st.vtb_tran_id,st.vtb_tran_date,doc.reference "����.�����",doc.payers_currency "������",doc.summa "�����",doc.xsummacredit "����� � ���"
,(select memo from (select 'A' tbl,d.* from archive d union select 'D' tbl,d.* from documents d union select 'DD' tbl, d.* from documents_delete d) where reference = doc.refer_from and branch = doc.branch_from) memo
,pc_oper_id
--,doc.status,doc.tbl, st.*,doc.* 
from synergy_transactions st, (select 'A' tbl,d.* from archive d union select 'D' tbl,d.* from documents d union select 'DD' tbl, d.* from documents_delete d) doc  
where vtb_tran_date > trunc(sysdate)-15-- and vtb_tran_date < trunc(sysdate)-1 
and vtb_tran_id in ('MB.70366')
--and vtb_tran_id in 'SP.208210555-795101'
--and nvl(status_bit_service,0) <> 1 
and nvl(st.doc303_reference,0) = doc.reference and nvl(st.doc303_branch,0) = doc.branch
/

select * from (select 'A' tbl,d.* from archive d union all select 'D' tbl,d.* from documents d union all select 'DD' tbl, d.* from documents_delete d) doc where reference = 2846896943     --2829735989 
/
--������ ���������� ��� �������������
SELECT UNIVERSE.VARIABLE_ARCH(branch,reference,'VTB24_TRAN_ID') TRAN_ID, date_work "���� ��������",payers "���������",payers_currency "������",summa "�����",memo "���������" FROM ARCHIVE a WHERE refer_from in (2790604292,2790604651,2790647360,2790647981,2790650222,2790650263,2790650965,2790651262,2790651416,2790651705,2790652063)
and branch_from =191
/
select * from variable_ARCHIVE where reference = 2790604718 and branch = 126
/
--������� ����������
select rowid,d.* from documents d where reference = 2829763838
refer_from = 2821671844
type_doc = 7 and xsubdepartment = 191350 and summa = 145000 --
--type_doc = 8 and xsubdepartment = 191355 and summa = 4545
--reference = 2769339426 --155000 �������� ����� 122841 ������ 2769513493   2769527675 --�������� ��� �������� - 2769537845
--reference = 2769307575 --720000 ��������� �.�. 120185      2769456677 53741358
--reference = 2768419189  --10000$ ������� � 122912     2769463064 53741377
/

select * from variable_documents where reference = 2826138109 and branch = 191435  2848707983
2848707984
/

select * from audit_table where reference = 2846896943
/

insert into documents (select * from archive where reference = 2846896943)
insert into variable_documents (select * from variable_archive where reference = 2846896943)
delete archive where reference = 2846896943
/
insert into documents (select * from documents_delete where reference = 2846896943)
insert into variable_documents (select * from variable_documents_delete where reference = 2846896943)
delete documents_delete where reference = 2846896943
/
--insert into journal_zp
select * from journal
--delete journal
--where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978))
where (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (2846896943))
/
--insert into journal
select * from journal_delete
--where docnum = 2841353850
where (docnum,branch) in (select reference,branch from documents where reference in (2846896943)) --and header <> 'a'
/ 

update journal_zp 
--set work_date = '10-jan2018', value_date = '10-jan2018'
set rsum = 46038, vsum = 46038
 where  (docnum,branch) in (select reference,branch from (select * from documents union all select * from archive) where reference in (2842136689))
/
--insert into journal
select * from journal_zp where  (docnum,branch) in (select reference,branch from documents a where 
reference in (2842136689)
)
/

select rowid,d.* from documents d
--update  documents set date_work =  '10-jan2018', date_value = '10-jan2018', date_document = '10-jan2018'
--update  documents set status = 1000
--where refer_from in (2821660486,2821672220)
where reference in (2846896943)
/

--�����-����� ��������� ������ ��������� � ���������  ������� ?
select * from documents d
--update  documents d set status = 1000 
where (refer_from,branch_from) in 
(select doc_reference,doc_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate)-10 and vtb_tran_date < trunc(sysdate) and status = 0 and doc_reference is not null)
and date_work < trunc(sysdate) and not exists (select null from journal where docnum = d.reference and branch = d.branch)
and status < 1000
/

select * from documents d
--update  documents d set status = 1000 
where (reference,branch) in 
(select doc_reference,doc_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate)-10 and vtb_tran_date < trunc(sysdate) and status = 0 and doc_reference is not null)
and date_work < trunc(sysdate) and status < 30
and not exists (select null from journal where docnum = d.reference and branch = d.branch)
/

--�������� ������������ ��������� � ������� ����������� �������
select * from documents d
--update  documents d set status = 1000 
where type_doc = 4215 and date_work < trunc(sysdate)-1 and status = 23
and not exists (select null from documents where refer_from = d.reference and branch_from = d.branch and status > 50) 
/

--�������� ��������� �����������
select * from documents d 
where (refer_from,branch_from) in 
(select doc_reference,doc_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate)-10 and vtb_tran_date < trunc(sysdate) and status > 1 and doc_reference is not null)
and date_work < trunc(sysdate) 
and not exists (select null from journal where docnum = d.reference and branch = d.branch) and status < 30
/

--�� ��������� ����������� �����-������
select * from documents d 
--update  documents d set status = 1000
where (reference,branch) in 
(select doc_reference,doc_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate)-20 and vtb_tran_date < trunc(sysdate) and status > 1 and doc_reference is not null)
and date_work < trunc(sysdate) and status < 30
and not exists (select null from journal where docnum = d.reference and branch = d.branch)
/


--�������� ��������������
select rowid, t.* from synergy_transactions t 
where vtb_tran_date > trunc(sysdate)-1-- and vtb_tran_date < trunc(sysdate) 
--and doc_reference = 2769226226
and doc_reference is not null
and status = 0
--and status > 1
--AND vtb_tran_id = 'SP.205520562-690580'
--and exists (select null from documents where reference = t.doc_reference and branch = t.doc_branch and status < 50)
--and vtb_tran_id in ('TS.0000000047321867')
/

select * from documents d where type_doc = 4215 and date_work = trunc(sysdate)-1 and status = 23
and not exists (select null from documents where refer_from = d.reference and branch_from = d.branch ) and status < 30
/

--����� �����-��������� �� ���������
select (select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) tran_id
  ,t.* from synergy_transactions t
where vtb_tran_date > trunc(sysdate)-- and vtb_tran_date < trunc(sysdate)-1 
--vtb_tran_date > '09-jan-2018'  and vtb_tran_date < '12-jan-2018' 
and doc_reference is not null
and instr(vtb_tran_id,'BQ_00040') > 0
and status = 1 --and pc_oper_id > 0
/

select payers_currency,sum(summa) from documents where (reference,branch) in (select doc303_reference,doc303_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate) and doc_reference is not null and instr(vtb_tran_id,'BQ_00040') > 0 and status = 1)
and status < 1000
group by payers_currency
/
select * from documents where (reference,branch) in (select doc303_reference,doc303_branch from synergy_transactions t where vtb_tran_date > trunc(sysdate) and doc_reference is not null and instr(vtb_tran_id,'BQ_00040') > 0 and status = 1)
and status < 1000

/
select * from  eid.distrib_transactions dt
--update eid.distrib_transactions dt set done = 2, err_msg = '-1379 ����� �� ������� ���24'   
where (tran_id,run_order) in 
(select tran_id,max(run_order) from eid.distrib_transactions dt where tran_id in (
select (select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) tran_id    from synergy_transactions t
where vtb_tran_date > trunc(sysdate) and doc_reference is not null and instr(vtb_tran_id,'BQ_00040') > 0 and status = 1
)
group by tran_id
) 
/

select * from eid.distrib_transactions dt where tran_id in (
select (select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) tran_id    from synergy_transactions t
where vtb_tran_date > trunc(sysdate) and doc_reference is not null and instr(vtb_tran_id,'BQ_00040') > 0 and status = 1
) 
--and done <> 2
/

select * from eid.distrib_transactions dt where  
select * from eid.distrib_transactions dt where tran_id in (
select (select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) tran_id    from synergy_transactions t
where vtb_tran_date > trunc(sysdate) and doc_reference is not null and instr(vtb_tran_id,'BQ_00040') > 0 and status = 1
) 
/

--������ ���������� 
select vtb_tran_id "ID ����������",vtb_tran_date "����",pc_oper_id "�������� � ��",D.SUMMA "�����",D.real_PAYERS "���� �����������",D.real_receivers "���� ����������", d.reference "� � ������"
,(select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) "���������� � ������" 
,(select value from  eid.distrib_features df where name = 'ACCTIDFROM' and (tran_id,task_kind,filial) in  
    (select tran_id,task_kind,filial from eid.distrib_transactions where tran_id = (select max(tran_id) from synergy_queries where vtb_tran_id = t.vtb_tran_id and tran_id is not null) and trunc(filial) = 999)) "� ��"
-- ,t.* 
  from synergy_transactions t, documents d 
where vtb_tran_date > trunc(sysdate)-- and vtb_tran_date < trunc(sysdate)-1 
--vtb_tran_date > '09-jan-2018'  and vtb_tran_date < '12-jan-2018' 
and doc_reference is not null
and instr(vtb_tran_id,'BQ_00040') > 0
and t.status = 1 --and pc_oper_id > 0
and doc303_reference = d.reference and doc303_branch = d.branch
and pc_oper_id > 0
/

select rowid,d.* from documents d where reference in (2769339426,2769456677)
/
select rowid,d.* from documents_delete d where reference = 2766774561

select rowid,d.* from documents_delete d where reference = 2766774561


 select * from documents d where status > 10 and status < 30 and date_create < sysdate - 1/24 and
                       type_doc in (12035, 12036, 12153, 12154, 12169, 12170, 12155) and
                       (
                         exists (select 1 from documents where refer_from = d.reference and branch_from = d.branch and status < 1000) or
                         exists (select 1 from documents where related = d.reference and branch_related = d.branch and status < 1000) or
                         exists (select 1 from journal where docnum = d.reference and branch = d.branch)
                       )
 /                      
--�������� � ��������� ������� ��� 

2829763838
2829777482
/

begin
 dbms_output.put_line( PKG_INTGR_SRVBIT.del_doc(2845515376, 191) );
end;
/

select * from UIDS where reference = 2829777482 and branch = 191183
/
select (select q.name from tbl_queue q where q.id =s.queue_id ),s.* from TBL_INTGR_SERVICE s where name= 'SRVBIT2' ;

select s.* from TBL_INTGR_SERVICE s where name like 'SRVBIT%' ;
/
--�������� 
select * from tbl_queue_SRVBIT2_MB_MQ where create_dt > sysdate-1
/

select * from tbl_queue_SRVBIT2_MQ_MB where create_dt > sysdate-1
/
--����� �������
select * from tbl_queue_SRVBIT1_MB_MQ where create_dt > sysdate-1/96-- and instr(message,'TS.0000000069982640') > 0
order by create_dt desc
/

select * from tbl_queue_SRVBIT1_MQ_MB where create_dt > sysdate-1/96-- and instr(message,'67AB2AF475450BE4E0530AC944ACE0B0') > 0

/
--�� ���������, ����� ������� �� ������� ���� � ��������� ��������
begin
for rec in ( 
--select t.* from synergy_transactions t where vtb_tran_date > trunc(sysdate)-4 and vtb_tran_date < trunc(sysdate) and status = 1 and nvl(status_bit_service,0) <> 1 and doc303_reference is not null
select t.* from synergy_transactions t where vtb_tran_date > trunc(sysdate)-1 and vtb_tran_id = 'MB.54529'
)
loop
  dbms_output.put_line(rec.vtb_tran_id||' '||rec.doc303_reference|| '->'||nvl(PKG_INTGR_SRVBIT.send_doc(rec.doc303_reference, rec.doc303_branch),'����������'));
end loop; 
end;
/

select * from audit_table where reference =  2809741595

--���������������
select * from journal_delete where docnum in (2809741595,2809737697)
/
--��������� ��������
declare 
 l_Ref Number; 
begin
 l_Ref := DOC_REFERENCE.NEXTVAL;
 insert into documents (reference, branch, BRANCH_FROM, BRANCH_PAYERS, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, BRANCH_RECEIVERS, BRANCH_RELATED, CHILD, DATE_CREATE, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, ID, MEMO, NUM_GROUP, OWNER, PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK, PAYERS_CONTRACT, PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS, REAL_PAYERS_CONTRACT, REAL_RECEIVERS, REAL_RECEIVERS_CONTRACT, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CONTRACT, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE, RELATED, SHIFROPER, STATUS, SUB_TYPE, SUMMA, TYPE_DOC, VERSION, XSUBDEPARTMENT, XSUMMACREDIT) 
 select l_Ref,BRANCH, BRANCH_FROM, BRANCH_PAYERS, BRANCH_REAL_PAYERS, BRANCH_REAL_RECEIVERS, BRANCH_RECEIVERS, BRANCH_RELATED, CHILD, sysdate, DATE_DOCUMENT, DATE_VALUE, DATE_WORK, DEPART_PAYERS, DEPART_RECEIVERS, DOC_NUMBER, FOLDER, ID, MEMO, NUM_GROUP, OWNER, PAYERS, PAYERS_ACCOUNT, PAYERS_BANK, PAYERS_BIK, PAYERS_CONTRACT, PAYERS_CORACC, PAYERS_CURRENCY, PAYERS_INN, PAYERS_OPERATION, PAYERS_RELATED, PAYMENT, REAL_PAYERS, REAL_PAYERS_CONTRACT, REAL_RECEIVERS, REAL_RECEIVERS_CONTRACT, RECEIVERS, RECEIVERS_ACCOUNT, RECEIVERS_BANK, RECEIVERS_BIK, RECEIVERS_CONTRACT, RECEIVERS_CORACC, RECEIVERS_CURRENCY, RECEIVERS_INN, RECEIVERS_OPERATION, RECEIVERS_RELATED, REFER_FROM, REFER_OFFICE, RELATED, SHIFROPER, STATUS, SUB_TYPE, SUMMA, TYPE_DOC, VERSION, XSUBDEPARTMENT, XSUMMACREDIT
    from archive where reference = 2809762209; 
 dbms_output.put_line('l_Ref '||l_Ref);
 insert into variable_documents (reference, BRANCH, COLNUMBER, ID, NAME, ROWNUMBER, SUBFIELD, SUBNUMBER, VALUE, XDATE) 
 select l_Ref,BRANCH, COLNUMBER, ID, NAME, ROWNUMBER, SUBFIELD, SUBNUMBER, VALUE, XDATE
    from variable_archive where reference = 2809762209; 
end;


select rowid,d.* from documents d where reference in (2811313258,2809737697)

select rowid,d.* from archive d where reference in (2809762209,2809724867) 
type_doc=12035 and xsubdepartment = 191429 and date_work = '13-feb-2018'  

select * from variable_archive where reference in (2826138109)

select rowid,d.* from documents_delete d where reference = 2809737697

select rowid,j.* from journal j where  docnum in (2809741595,2809737697,2811313258)


select * from users where user_id = 957176967  

insert into journal
select * from journal_delete where docnum in (2809741595,2809737697)

select * from tbl_swift where swift_id = '00ZBE2LJ/2007TT'

select * from tbl_swift_document where  reference = 2828101951

select rowid,cc.* from collector_contracts cc where (docnum,zbranch_docnum) in (select reference,branch from (select * from documents union all select * from archive) where refer_from in (2848707978)) 