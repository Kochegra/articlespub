��� ��� ��������
declare
 aaa varchar2(30);
 a_cod varchar2(20) :='70606810300003120801';  acode varchar2(20);  acfu varchar2(20);  dep number := 785076;  
 function open_acc(a varchar2, adep number) return varchar2 is
  aname varchar2(256):= '����';
  aown number;
 begin 
  if length(nvl(a,'')) = 20 then      
   aown := global_parameters.get_param('���_�����_��',adep);
   if substr(a,1,5) = '70601' then
     for gd in (select str1 from guides where type_doc=11295 and code=substr(a,14,7)) loop
       aname:=nvl(substr(gd.str1,1,256),'������������ � ����������� ������');
     end loop;
   end if;
   if substr(a,1,3) = '603' then
     aname := '��� �����.';
   end if;
   for aa in (select count(*) cnt from account where code = a) loop
     if aa.cnt = 0 then
       --dbms_output.put_line('a = '||a||' code = '||acode);
       INSERT INTO account(header,code,currency,open_date, modify_date,lsnum,bal, owner,client,branch_client,name, branch,subdepartment,reference)
       values('A',a,substr(acode,6,3),trunc(sysdate),sysdate,substr(a,13,7),substr(a,1,5),aown,0,0,aname,adep,adep,account_id.nextval);                
     end if;
   end loop;     
   for aa in (select code from account where code = pAcc) loop
     return aa.code;
   end loop;     
  end if;
  return null;
 exception when OTHERS then
   dbms_output.put_line('pAcc = '||pAcc||' code = '||acode);
   return null;       
 end;
begin
  acfu := lpad(global_parameters.get_param('���',dep),4,0);
  --dbms_output.put_line(' aa  str4 = '||gd.str4);
  acode := paccount.keyaccount(a_cod,substr(global_parameters.get_param('���_�������',mbfilid),-3,3));
  for a in (select count(*) cnt from account where code = acode) loop
    dbms_output.put_line(acode||' '||a_cod||' '||a.cnt); 
    if a.cnt = 0 then
      dbms_output.put_line('acode = '||acode);
      aaa := nvl(open_acc(acode,dep),'ZYX');
    end if;
  end loop;
  --commit;
end;
/

select * from account where code='70606810300003120801'




select paccount.keyaccount('70606810900003120801',substr(global_parameters.get_param('���_�������',mbfilid),-3,3)) from dual

select substr(global_parameters.get_param('���_�������',mbfilid),-3,3) from dual

select * from MBANK.PLAN_ACCOUNT where bal in ('70606','70601')