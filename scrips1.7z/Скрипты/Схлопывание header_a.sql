select * from ledger 
where work_date>=trunc(sysdate)-30
and instr(code,'99999')>0  

select * from journal 
--where work_date>=trunc(sysdate)-30 and header='a'
where docnum in (262295294)--,262292891) and branch=191

select * from v_documents where 262295294 in (reference,refer_from,related)
--reference in (262292884)--,262292891)



begin
mbank.pjournal.CORR_ACCOUNT_SUMMARY;
end;


select rowid,a.* from journal_delay_account a