-- ����������� �������
/
select t.* from DBA_DEPENDENCIES t 
where 1=1
  --and REFERENCED_TYPE = 'TABLE' 
  and REFERENCED_NAME like 'PKG_ZNO' --and REFERENCED_NAME not in ('BIP_LOAD$FL_LOG')
   --and REFERENCED_OWNER = 'MBANK'
   --and TYPE = 'TABLE'
  -- and NAME = 'P_RVP'   
/

select level, t.* from DBA_DEPENDENCIES t 
--where 
--OWNER = 'MBANK'
start with REFERENCED_NAME = 'PKG_ZNO'  
connect by nocycle prior OWNER = REFERENCED_OWNER and prior NAME = REFERENCED_NAME   
--order siblings by REFERENCED_NAME
--order by level
/


������ ������ �� ����

select * from dba_tab_modifications where 
table_owner = 'BANKROT'
order by timestamp desc 

select t.* from DBA_DEPENDENCIES t 
where 1=1 and REFERENCED_OWNER = 'BANKROT' and owner <> REFERENCED_OWNER
and substr(owner,1,5) not in ('CORP_','CHEVY','DEAL_')
order by owner

select * from DBA_TAB_PRIVS where 1=1 
and grantee like 'IBANK' 
order by owner,table_name,grantee

select * from dba_objects where 1=1
and owner = 'MBG3'
and object_type not in ('INDEX','INDEX PARTITION','TABLE PARTITION','SEQUENCE','LOB','TRIGGER','SYNONYM','TYPE BODY','TYPE','PACKAGE BODY')
order by owner

select * from v$sqlarea where sql_id = '7h35uxf5uhmm1'

select (select sql_text from v$sqlarea where sql_id = prev_sql_id),s.* from v$session s where username = 'IBANK'

select * from DBA_USERS where  username = 'MBANKEXP' 


select rowid,u.* from mb_users u where tabn = '-9999'  
and username in (select str3 from ZYX_STORE z where OPER = 'AR_INFO' and tbl = 'TABLE' and str1 is null)
order by username
