declare
pkg_name VARCHAR2(2000) := 'P_KMB';
rec_curs contracts%ROWTYPE;
rec_doc  DOCUMENTS%rowtype;
nOper VARCHAR2(2000) := null;
nResult NUMBER;
cResult VARCHAR2(2000) := null;

nSummaPercent NUMBER;
nNalog        NUMBER;
dCloseDate    DATE;
        

--*******************
/************************************************************************/
/*                         ������ ����-�������                          */
/************************************************************************/
  FUNCTION choice_package( nTypeChoice   IN NUMBER
                           ,pkg_name      IN VARCHAR2
                           ,func_name     IN VARCHAR2
                           ,rec_cur       IN OUT CONTRACTS%ROWTYPE
                           ,rec_doc       IN OUT DOCUMENTS%ROWTYPE
                           ,nOper         IN VARCHAR2
                           ,cUser         IN VARCHAR2
                           ,nOwner        IN NUMBER
                           ,nFolder       IN NUMBER
                           ,nRefGlobal    IN NUMBER := 0
                           ,nBranchGlobal IN NUMBER := 0
                           ,dCalculate    IN DATE
                           ,nSummaPercent IN OUT NUMBER
                           ,nNalog        IN OUT NUMBER
                           ,dCloseDate    IN OUT DATE
                           ,nPercent474   IN NUMBER := 0
                           ,nResult       IN OUT NUMBER
                           )

--(rec_curs, rec_doc, cUser, nOper)
  RETURN VARCHAR2
  IS
    sResult        VARCHAR2 (2000) ;
    my_curs         INTEGER;
    res_my_curs     INTEGER;
    mega_str_curs   VARCHAR2(20000);

    rec_curs        contracts%ROWTYPE;
    real_pkg_name   VARCHAR2(100);
    real_func_name  VARCHAR2(100);

    len_str         NUMBER;

  BEGIN

    real_pkg_name  := TRIM(pkg_name);
    real_func_name := TRIM(func_name);


    mega_str_curs :=
        'DECLARE '||
        ' doc_rec       documents%ROWTYPE; '||
        ' cur_rec       contracts%ROWTYPE; '||
        ' nOper         VARCHAR2(100);     '||
        ' cUser         VARCHAR2(100);     '||
        ' nOwner        NUMBER;            '||
        ' nFolder       NUMBER;            '||
        ' nRefGlobal    NUMBER;            '||
        ' nBranchGlobal NUMBER;            '||
        --------------------------------------
        ' dCalculate    DATE;              '||
        ' nSummaPercent NUMBER;            '||
        ' nNalog        NUMBER;            '||
        ' dCloseDate    DATE;              '||
        ' nPercent474   NUMBER;            '||
        ' sResult       VARCHAR2(2000);    '||
        ' nResult       NUMBER;            '||
        ' nReference    NUMBER;            '||
        ' nBranch       NUMBER;            '||
        '                                  '||
        'BEGIN                             '||
        '                                  '||
        ' sResult      := :sResult;        '||
        ' nResult      := :nResult;        '||
        ' nOper        := :nOper;          '||
        ' cUser        := :cUser;          '||
        ' nOwner       := :nOwner;         '||
        ' nFolder      := :nFolder;        '||
        ' nRefGlobal   := :nRefGlobal;     '||
        ' nBranchGlobal:= :nBranchGlobal;  '||
        '                                  '||
        ' dCalculate   := :dCalculate;     '||
        ' nSummaPercent:= :nSummaPercent;  '||
        ' nNalog       := :nNalog;         '||
        ' dCloseDate   := :dCloseDate;     '||
        ' nPercent474  := :nPercent474;    '||


        ' cur_rec.BRANCH           := :C1; '||
        ' cur_rec.REFERENCE        := :C2; '||
        ' cur_rec.REFER_FROM       := :C3; '||
        ' cur_rec.RELATED          := :C4; '||
        ' cur_rec.BRANCH_RELATED   := :C5; '||
        ' cur_rec.BRANCH_FROM      := :C6; '||
        ' cur_rec.BRANCH_CLIENT    := :C7; '||
        ' cur_rec.REFER_CLIENT     := :C8; '||
        ' cur_rec.TYPE_CLIENT      := :C9; '||
        ' cur_rec.FOLDER           := :C10;'||
        ' cur_rec.TYPE_DOC         := :C11;'||
        ' cur_rec.SUB_TYPE         := :C12;'||
        ' cur_rec.STATUS           := :C13;'||
        ' cur_rec.DOC_NUMBER       := :C14;'||
        ' cur_rec.ACCOUNT          := :C15;'||
        ' cur_rec.ASSIST           := :C16;'||
        ' cur_rec.CURRENCY         := :C17;'||
        ' cur_rec.ASSIST_CURRENCY  := :C18;'||
        ' cur_rec.DATE_WORK        := :C19;'||
        ' cur_rec.DATE_CREATE      := :C20;'||
        ' cur_rec.DATE_OPEN        := :C21;'||
        ' cur_rec.DATE_CLOSE       := :C22;'||
        ' cur_rec.DATE_PROCENT     := :C23;'||
        ' cur_rec.DATE_NEXT        := :C24;'||
        ' cur_rec.DATE_PENALTY     := :C25;'||
        ' cur_rec.DATE_MODIFY      := :C26;'||
        ' cur_rec.SUMMA            := :C27;'||
        ' cur_rec.OWNER            := :C28;'||
        ' cur_rec.PERIOD           := :C29;'||
        ' cur_rec.VERSION          := :C30;'||
        ' cur_rec.CHILD            := :C31;'||
        ' cur_rec.PERCENT          := :C32;'||
        ' cur_rec.SUBDEPARTMENT    := :C33;'||
        '                                  '||
        ' doc_rec.DATE_CREATE        := :D1;'||
        ' doc_rec.DATE_DOCUMENT      := :D2;'||
        ' doc_rec.DATE_VALUE         := :D3;'||
        ' doc_rec.DATE_WORK          := :D4;'||
        ' doc_rec.BRANCH             := :D5;'||
        ' doc_rec.BRANCH_FROM        := :D6;'||
        ' doc_rec.BRANCH_PAYERS      := :D7;'||
        ' doc_rec.BRANCH_REAL_PAYERS := :D8;'||
        ' doc_rec.BRANCH_REAL_RECEIVERS:= :D9;'||
        ' doc_rec.BRANCH_RECEIVERS   := :D10;'||
        ' doc_rec.BRANCH_RELATED     := :D11;'||
        ' doc_rec.CHILD              := :D12;'||
        ' doc_rec.DEPART_PAYERS      := :D13;'||
        ' doc_rec.DEPART_RECEIVERS   := :D14;'||
        ' doc_rec.FOLDER             := :D15;'||
        ' doc_rec.ID                 := :D16;'||
        ' doc_rec.NUM_GROUP          := :D17;'||
        ' doc_rec.OWNER              := :D18;'||
        ' doc_rec.PAYERS_CONTRACT    := :D19;'||
        ' doc_rec.REAL_PAYERS_CONTRACT:= :D20;'||
        ' doc_rec.REAL_RECEIVERS_CONTRACT:= :D21;'||
        ' doc_rec.RECEIVERS_CONTRACT := :D22;'||
        ' doc_rec.REFERENCE          := :D23;'||
        ' doc_rec.REFER_FROM         := :D24;'||
        ' doc_rec.RELATED            := :D25;'||
        ' doc_rec.STATUS             := :D26;'||
        ' doc_rec.SUB_TYPE           := :D27;'||
        ' doc_rec.SUMMA              := :D28;'||
        ' doc_rec.TYPE_DOC           := :D29;'||
        ' doc_rec.VERSION            := :D30;'||
        ' doc_rec.XSUBDEPARTMENT     := :D31;'||
        ' doc_rec.XSUMMACREDIT       := :D32;'||
        ' doc_rec.DOC_NUMBER         := :D33;'||
        ' doc_rec.MEMO               := :D34;'||
        ' doc_rec.PAYERS             := :D35;'||
        ' doc_rec.PAYERS_ACCOUNT     := :D36;'||
        ' doc_rec.PAYERS_BANK        := :D37;'||
        ' doc_rec.PAYERS_BIK         := :D38;'||
        ' doc_rec.PAYERS_CORACC      := :D39;'||
        ' doc_rec.PAYERS_CURRENCY    := :D40;'||
        ' doc_rec.PAYERS_INN         := :D41;'||
        ' doc_rec.PAYERS_OPERATION   := :D42;'||
        ' doc_rec.PAYERS_RELATED     := :D43;'||
        ' doc_rec.PAYMENT            := :D44;'||
        ' doc_rec.REAL_PAYERS        := :D45;'||
        ' doc_rec.REAL_RECEIVERS     := :D46;'||
        ' doc_rec.RECEIVERS          := :D47;'||
        ' doc_rec.RECEIVERS_ACCOUNT  := :D48;'||
        ' doc_rec.RECEIVERS_BANK     := :D49;'||
        ' doc_rec.RECEIVERS_BIK      := :D50;'||
        ' doc_rec.RECEIVERS_CORACC   := :D51;'||
        ' doc_rec.RECEIVERS_CURRENCY := :D52;'||
        ' doc_rec.RECEIVERS_INN      := :D53;'||
        ' doc_rec.RECEIVERS_OPERATION:= :D54;'||
        ' doc_rec.RECEIVERS_RELATED  := :D55;'||
        ' doc_rec.REFER_OFFICE       := :D56;'||
        ' doc_rec.SHIFROPER          := :D57;'||
        '                                    '||
        ' :sResult := '||real_pkg_name||'.'||real_func_name||' (cur_rec, ';

        -- ��� CONTROL_DEBIT_CONT, CONTROL_CREDIT_CONT
        IF nTypeChoice = 1 THEN
          mega_str_curs := mega_str_curs||'doc_rec, nOper, :nResult);';

        -- ��� EXEC_DEBIT_CONT, EXEC_CREDIT_CONT
        ELSIF nTypeChoice = 2 THEN
          mega_str_curs := mega_str_curs||'doc_rec, cUser, nOper);';

        -- ��� ROLLBACK_DEBIT_CONT, ROLLBACK_CREDIT_CONT
        ELSIF nTypeChoice = 3 THEN
          mega_str_curs := mega_str_curs||'doc_rec, nOper);';

        -- ��� PERCENT_CONT
        ELSIF nTypeChoice = 4 THEN
          mega_str_curs := mega_str_curs||'nOwner, nFolder, doc_rec);';

        -- ���  OPEN_CONT
        ELSIF nTypeChoice = 5 THEN
          mega_str_curs := mega_str_curs||'nOwner, nFolder);';

        -- ���  CLOSE_CONT
        ELSIF nTypeChoice = 6 THEN
          mega_str_curs := mega_str_curs||'nOwner, nFolder, nRefGlobal, nBranchGlobal);';

        -- ���  PERCENT_CALCULATE
        ELSIF nTypeChoice = 7 THEN
          mega_str_curs := mega_str_curs||'dCalculate, :nSummaPercent, :nNalog, :dCloseDate, nPercent474);';
        END IF;

        mega_str_curs := mega_str_curs||
        ' :C1  := cur_rec.BRANCH         ; '||
        ' :C2  := cur_rec.REFERENCE      ; '||
        ' :C3  := cur_rec.REFER_FROM     ; '||
        ' :C4  := cur_rec.RELATED        ; '||
        ' :C5  := cur_rec.BRANCH_RELATED ; '||
        ' :C6  := cur_rec.BRANCH_FROM    ; '||
        ' :C7  := cur_rec.BRANCH_CLIENT  ; '||
        ' :C8  := cur_rec.REFER_CLIENT   ; '||
        ' :C9  := cur_rec.TYPE_CLIENT    ; '||
        ' :C10 := cur_rec.FOLDER         ; '||
        ' :C11 := cur_rec.TYPE_DOC       ; '||
        ' :C12 := cur_rec.SUB_TYPE       ; '||
        ' :C13 := cur_rec.STATUS         ; '||
        ' :C14 := cur_rec.DOC_NUMBER     ; '||
        ' :C15 := cur_rec.ACCOUNT        ; '||
        ' :C16 := cur_rec.ASSIST         ; '||
        ' :C17 := cur_rec.CURRENCY       ; '||
        ' :C18 := cur_rec.ASSIST_CURRENCY; '||
        ' :C19 := cur_rec.DATE_WORK      ; '||
        ' :C20 := cur_rec.DATE_CREATE    ; '||
        ' :C21 := cur_rec.DATE_OPEN      ; '||
        ' :C22 := cur_rec.DATE_CLOSE     ; '||
        ' :C23 := cur_rec.DATE_PROCENT   ; '||
        ' :C24 := cur_rec.DATE_NEXT      ; '||
        ' :C25 := cur_rec.DATE_PENALTY   ; '||
        ' :C26 := cur_rec.DATE_MODIFY    ; '||
        ' :C27 := cur_rec.SUMMA          ; '||
        ' :C28 := cur_rec.OWNER          ; '||
        ' :C29 := cur_rec.PERIOD         ; '||
        ' :C30 := cur_rec.VERSION        ; '||
        ' :C31 := cur_rec.CHILD          ; '||
        ' :C32 := cur_rec.PERCENT        ; '||
        ' :C33 := cur_rec.SUBDEPARTMENT  ; '||
        '                                  '||
        ' :D1  := doc_rec.DATE_CREATE       ;'||
        ' :D2  := doc_rec.DATE_DOCUMENT     ;'||
        ' :D3  := doc_rec.DATE_VALUE        ;'||
        ' :D4  := doc_rec.DATE_WORK         ;'||
        ' :D5  := doc_rec.BRANCH            ;'||
        ' :D6  := doc_rec.BRANCH_FROM       ;'||
        ' :D7  := doc_rec.BRANCH_PAYERS     ;'||
        ' :D8  := doc_rec.BRANCH_REAL_PAYERS;'||
        ' :D9  := doc_rec.BRANCH_REAL_RECEIVERS;'||
        ' :D10 := doc_rec.BRANCH_RECEIVERS  ;'||
        ' :D11 := doc_rec.BRANCH_RELATED    ;'||
        ' :D12 := doc_rec.CHILD             ;'||
        ' :D13 := doc_rec.DEPART_PAYERS     ;'||
        ' :D14 := doc_rec.DEPART_RECEIVERS  ;'||
        ' :D15 := doc_rec.FOLDER            ;'||
        ' :D16 := doc_rec.ID                ;'||
        ' :D17 := doc_rec.NUM_GROUP         ;'||
        ' :D18 := doc_rec.OWNER             ;'||
        ' :D19 := doc_rec.PAYERS_CONTRACT   ;'||
        ' :D20 := doc_rec.REAL_PAYERS_CONTRACT   ;'||
        ' :D21 := doc_rec.REAL_RECEIVERS_CONTRACT;'||
        ' :D22 := doc_rec.RECEIVERS_CONTRACT;'||
        ' :D23 := doc_rec.REFERENCE         ;'||
        ' :D24 := doc_rec.REFER_FROM        ;'||
        ' :D25 := doc_rec.RELATED           ;'||
        ' :D26 := doc_rec.STATUS            ;'||
        ' :D27 := doc_rec.SUB_TYPE          ;'||
        ' :D28 := doc_rec.SUMMA             ;'||
        ' :D29 := doc_rec.TYPE_DOC          ;'||
        ' :D30 := doc_rec.VERSION           ;'||
        ' :D31 := doc_rec.XSUBDEPARTMENT    ;'||
        ' :D32 := doc_rec.XSUMMACREDIT      ;'||
        ' :D33 := doc_rec.DOC_NUMBER        ;'||
        ' :D34 := doc_rec.MEMO              ;'||
        ' :D35 := doc_rec.PAYERS            ;'||
        ' :D36 := doc_rec.PAYERS_ACCOUNT    ;'||
        ' :D37 := doc_rec.PAYERS_BANK       ;'||
        ' :D38 := doc_rec.PAYERS_BIK        ;'||
        ' :D39 := doc_rec.PAYERS_CORACC     ;'||
        ' :D40 := doc_rec.PAYERS_CURRENCY   ;'||
        ' :D41 := doc_rec.PAYERS_INN        ;'||
        ' :D42 := doc_rec.PAYERS_OPERATION  ;'||
        ' :D43 := doc_rec.PAYERS_RELATED    ;'||
        ' :D44 := doc_rec.PAYMENT           ;'||
        ' :D45 := doc_rec.REAL_PAYERS       ;'||
        ' :D46 := doc_rec.REAL_RECEIVERS    ;'||
        ' :D47 := doc_rec.RECEIVERS         ;'||
        ' :D48 := doc_rec.RECEIVERS_ACCOUNT ;'||
        ' :D49 := doc_rec.RECEIVERS_BANK    ;'||
        ' :D50 := doc_rec.RECEIVERS_BIK     ;'||
        ' :D51 := doc_rec.RECEIVERS_CORACC  ;'||
        ' :D52 := doc_rec.RECEIVERS_CURRENCY;'||
        ' :D53 := doc_rec.RECEIVERS_INN     ;'||
        ' :D54 := doc_rec.RECEIVERS_OPERATION;'||
        ' :D55 := doc_rec.RECEIVERS_RELATED ;'||
        ' :D56 := doc_rec.REFER_OFFICE      ;'||
        ' :D57 := doc_rec.SHIFROPER         ;'||
        'END;';

DBMS_OUTPUT.PUT_LINE(mega_str_curs);

    EXECUTE IMMEDIATE mega_str_curs
    USING IN OUT sResult
         ,IN OUT nResult
         ,IN nOper
         ,IN cUser
         ,IN nOwner
         ,IN nFolder
         ,IN nRefGlobal
         ,IN nBranchGlobal
         -------------------------------
         ,IN dCalculate
         ,IN OUT nSummaPercent
         ,IN OUT nNalog
         ,IN OUT dCloseDate
         ,IN nPercent474
         -------------------------------
         ,IN OUT rec_cur.BRANCH
         ,IN OUT rec_cur.REFERENCE
         ,IN OUT rec_cur.REFER_FROM
         ,IN OUT rec_cur.RELATED
         ,IN OUT rec_cur.BRANCH_RELATED
         ,IN OUT rec_cur.BRANCH_FROM
         ,IN OUT rec_cur.BRANCH_CLIENT
         ,IN OUT rec_cur.REFER_CLIENT
         ,IN OUT rec_cur.TYPE_CLIENT
         ,IN OUT rec_cur.FOLDER
         ,IN OUT rec_cur.TYPE_DOC
         ,IN OUT rec_cur.SUB_TYPE
         ,IN OUT rec_cur.STATUS
         ,IN OUT rec_cur.DOC_NUMBER
         ,IN OUT rec_cur.ACCOUNT
         ,IN OUT rec_cur.ASSIST
         ,IN OUT rec_cur.CURRENCY
         ,IN OUT rec_cur.ASSIST_CURRENCY
         ,IN OUT rec_cur.DATE_WORK
         ,IN OUT rec_cur.DATE_CREATE
         ,IN OUT rec_cur.DATE_OPEN
         ,IN OUT rec_cur.DATE_CLOSE
         ,IN OUT rec_cur.DATE_PROCENT
         ,IN OUT rec_cur.DATE_NEXT
         ,IN OUT rec_cur.DATE_PENALTY
         ,IN OUT rec_cur.DATE_MODIFY
         ,IN OUT rec_cur.SUMMA
         ,IN OUT rec_cur.OWNER
         ,IN OUT rec_cur.PERIOD
         ,IN OUT rec_cur.VERSION
         ,IN OUT rec_cur.CHILD
         ,IN OUT rec_cur.PERCENT
         ,IN OUT rec_cur.SUBDEPARTMENT
         -------------------------------
         ,IN OUT rec_doc.DATE_CREATE
         ,IN OUT rec_doc.DATE_DOCUMENT
         ,IN OUT rec_doc.DATE_VALUE
         ,IN OUT rec_doc.DATE_WORK
         ,IN OUT rec_doc.BRANCH
         ,IN OUT rec_doc.BRANCH_FROM
         ,IN OUT rec_doc.BRANCH_PAYERS
         ,IN OUT rec_doc.BRANCH_REAL_PAYERS
         ,IN OUT rec_doc.BRANCH_REAL_RECEIVERS
         ,IN OUT rec_doc.BRANCH_RECEIVERS
         ,IN OUT rec_doc.BRANCH_RELATED
         ,IN OUT rec_doc.CHILD
         ,IN OUT rec_doc.DEPART_PAYERS
         ,IN OUT rec_doc.DEPART_RECEIVERS
         ,IN OUT rec_doc.FOLDER
         ,IN OUT rec_doc.ID
         ,IN OUT rec_doc.NUM_GROUP
         ,IN OUT rec_doc.OWNER
         ,IN OUT rec_doc.PAYERS_CONTRACT
         ,IN OUT rec_doc.REAL_PAYERS_CONTRACT
         ,IN OUT rec_doc.REAL_RECEIVERS_CONTRACT
         ,IN OUT rec_doc.RECEIVERS_CONTRACT
         ,IN OUT rec_doc.REFERENCE
         ,IN OUT rec_doc.REFER_FROM
         ,IN OUT rec_doc.RELATED
         ,IN OUT rec_doc.STATUS
         ,IN OUT rec_doc.SUB_TYPE
         ,IN OUT rec_doc.SUMMA
         ,IN OUT rec_doc.TYPE_DOC
         ,IN OUT rec_doc.VERSION
         ,IN OUT rec_doc.XSUBDEPARTMENT
         ,IN OUT rec_doc.XSUMMACREDIT
         ,IN OUT rec_doc.DOC_NUMBER
         ,IN OUT rec_doc.MEMO
         ,IN OUT rec_doc.PAYERS
         ,IN OUT rec_doc.PAYERS_ACCOUNT
         ,IN OUT rec_doc.PAYERS_BANK
         ,IN OUT rec_doc.PAYERS_BIK
         ,IN OUT rec_doc.PAYERS_CORACC
         ,IN OUT rec_doc.PAYERS_CURRENCY
         ,IN OUT rec_doc.PAYERS_INN
         ,IN OUT rec_doc.PAYERS_OPERATION
         ,IN OUT rec_doc.PAYERS_RELATED
         ,IN OUT rec_doc.PAYMENT
         ,IN OUT rec_doc.REAL_PAYERS
         ,IN OUT rec_doc.REAL_RECEIVERS
         ,IN OUT rec_doc.RECEIVERS
         ,IN OUT rec_doc.RECEIVERS_ACCOUNT
         ,IN OUT rec_doc.RECEIVERS_BANK
         ,IN OUT rec_doc.RECEIVERS_BIK
         ,IN OUT rec_doc.RECEIVERS_CORACC
         ,IN OUT rec_doc.RECEIVERS_CURRENCY
         ,IN OUT rec_doc.RECEIVERS_INN
         ,IN OUT rec_doc.RECEIVERS_OPERATION
         ,IN OUT rec_doc.RECEIVERS_RELATED
         ,IN OUT rec_doc.REFER_OFFICE
         ,IN OUT rec_doc.SHIFROPER;

    RETURN sResult;

  EXCEPTION
    WHEN OTHERS THEN
      -- ������ ������ ��� ���������� � ������ ���������� �������.
      IF SQLCODE=-06550 THEN RETURN NULL;
      ELSE RAISE;
      END IF;
  END choice_package;












        BEGIN
select * into rec_curs FROM contracts WHERE reference = 226649 AND branch = 71;
SELECT * INTO rec_doc FROM documents WHERE reference = 41283342 AND branch = 76;
 
        
cResult := choice_package( 1
                                  ,pkg_name
                                  ,'CONTROL_DEBIT_CONT'
                                  ,rec_curs
                                  ,rec_doc
                                  ,nOper
                                  ,null
                                  ,null
                                  ,null
                                  ,null
                                  ,null
                                  ,null
                                  ,nSummaPercent
                                  ,nNalog
                                  ,dCloseDate
                                  ,null
                                  ,nResult
                                  );

DBMS_OUTPUT.PUT_LINE(nResult||'   '||cResult);                                  
END ;
