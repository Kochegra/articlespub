paccount.keyaccount(g.name,'411')
paccount.HEADER_ACCOUNT
and currency = substr(g.name,6,3)
substr(g_cnt.name,1,8)||'_'||substr(g_cnt.name,10,11)=substr(rec.name,1,8)||'_'||substr(rec.name,10,11) -- ����

select PTOOLS5.READ_PARAM('[AMOUNT=100][ASD=123][ZXC=321]','ASD') from dual

declare
p_RetAcc account.code%type := '40702810900950000664';
recAccount account%rowtype;
begin
    if universe.GET_ACCOUNT_REC(hd => paccount.HEADER_ACCOUNT(p_RetAcc),cd => p_RetAcc, account_rec => recAccount) then
        DBMS_OUTPUT.PUT_LINE(recAccount.close_date);
    end if;
end;
/