/*********************************** pcontract_execute ****************************/
DECLARE
   rec_doc   documents%ROWTYPE;
   result varchar(400);
BEGIN
   SELECT * INTO rec_doc FROM documents WHERE reference = 101748913 AND branch = 200;
   result :=
      pcontract_execute.control_debit_cont (nbranch      => :nbranch,
                                            nreference   => :nreference,
                                            rec_doc      => rec_doc,
                                            noper        => :noper,
                                            nresult=>:nresult);
  dbms_output.put_line(result);                                            
end;
