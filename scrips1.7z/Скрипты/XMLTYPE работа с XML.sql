--xmlns:xsi - ��� ����� ���� � �� ���� ������

with demo0 as (
    select XMLType(
--            '<GetSroRegisterResponse xmlns:xsi="http://tempuri.org/">
            '<GetSroRegisterResponse _xmlns="http://tempuri.org/">
                <GetSroRegisterResult>
                    <SROList>
                        <SRO SROID="41" FullName="�� ���� ���" RegNum="0032" DateReg="2010-12-29T00:00:00" INN="7707030411" UrAdress="107031, �. ������">
                        </SRO>
                        <SRO SROID="42" FullName="QWERTY" RegNum="0033" DateReg="2010-12-29T00:00:00" INN="7707030411" UrAdress="107031, �. ������">qaz
                        </SRO>
                    </SROList>
                </GetSroRegisterResult>
            </GetSroRegisterResponse>
            ') xml
    from dual
),
demo1 as (
    select XMLType(
            '<hello-world>
                 <word SROID="41">hello41</word>
                 <word SROID="42">hello42</word>
            </hello-world>
            ') xml
    from dual
),
demo2 as (
    select XMLType(lower(
            '<GetSroRegisterResult>
                    <SROList>
                        <SRO SROID="41" FullName="�� ���� ���" RegNum="0032" DateReg="2010-12-29T00:00:00" INN="7707030411" UrAdress="107031, �. ������">
                        </SRO>
                        <SRO SROID="42" FullName="QWERTY" RegNum="0033" DateReg="2010-12-29T00:00:00" INN="7707030411" UrAdress="107031, �. ������">werty
                        </SRO>
                    </SROList>
                </GetSroRegisterResult>
            ')) xml
    from dual
)
--select t.xml 
--,t.xml.extract('//word') cs1
--,t.xml.extract('//word[position()=1]') cs2
--,t.xml.extract('//word[@SROID="42"]/text()') cs3
--from demo1 t
--
select t.xml 
,t.xml.extract('//SROList') cs1
,t.xml.extract('//srolist') cs1
,t.xml.extract('//word[position()=1]') cs2
,t.xml.extract('//word[@SROID="42"]/text()') cs3
from demo0 t
--
--select t.xml 
--,t.xml.extract('//srolist') cs1
--,t.xml.extract('//sro') cs1
--,t.xml.extract('//sro[position()=1]') cs2
--,t.xml.extract('//sro[@sroid="42"]/text()') cs3
--from demo2 t


