-- �������

declare 
v_link  VARIABLE_GUIDES.VALUE%type;
function get_link(p_fil number)
return varchar2
is
 v_cnt number;
 v_result varchar2(2000); 
begin
    if p_fil in (191,0) then
        v_result := 'MAIN';
    elsif p_fil in (200) then
        v_result := '@MBOPERU';
    elsif p_fil in (208) then
        v_result := '@MB208';
    else
        select count(*) into v_cnt from eid.eid_subdepartments s, variable_guides vg, guides g 
            where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 
            and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=p_fil;
        
        if v_cnt>0 then
            select vg.value into v_result from eid.eid_subdepartments s, variable_guides vg, guides g 
            where S.ID = g.num1 and vg.reference = g.reference and vg.branch = g.branch and g.type_doc = 1198 
            and g.code <> 'FORM_STORAGE' and vg.name = 'DBLINK_M' and s.id=p_fil;
            v_result:='@'||v_result;
        else 
            v_result := 'NO_DATA_FOUND';
        end if;
    end if;

--    EXCEPTION
--        WHEN NO_DATA_FOUND THEN 
--            v_result := 'NO_DATA_FOUND';    
--        WHEN OTHERS THEN 
--            v_result := 'OTHERS';   
--         RAISE_APPLICATION_ERROR ( -20009, substr('������ ������ �������� �� ����������� 5386. '||sqlerrm, 1, 2000));

    return v_result;

end get_link;

begin
--    v_link := get_link(nvl(null,0));
    v_link := get_link(193);
    DBMS_OUTPUT.PUT_LINE(v_link);    
end;

/


