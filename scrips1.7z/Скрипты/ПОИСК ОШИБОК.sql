-- ����� �� ���� �������� ORACLE
select * from all_source where upper(text) like upper('%BLOCKACCOUNT%')

-- ����� �� ������
select * from sforms where text like '%�� ������ ����������� ���� �%'

GET_PAYMENT_LIST
SCD_TOOLS

CHECK_PAYMENTS_BY_STATUS  !!!
EID_UNPERS_LOCAL
PKG_FAST_PAYMENT

eid.pkg_fast_payment.check_umbo(v_date
CHECK_PAYMENTS_BY_STATUS(

PTOOLS2

D_4607
PACCOUNT
PRISK_MSFO_START
PTOOLS_EID_TO_FILIAL

------------
--����� �� �������
select replace(text,' ',''),a.* from all_source a 
where --type like '%TRIGGER%'
instr(replace(upper(text),' ',''),replace(upper(:str),' ','')) > 0 --and name like '%REP%'
--and instr(upper(text),upper('1198')) > 0 
--and owner = 'MBANK'
/

--�� ������
select * from TBL_ENTITY_SQL w
where instr(replace(upper(W.SQL_TXT),' ',''),replace(upper(:str),' ','')) > 0 
/

--�� ������
select * from sforms where instr(upper(text),upper(:str))>0
--and instr(upper(text),upper('VIP'))>0
/

--����� �� ������������
select universe.nametype(type_doc),type_doc,count(*) 
from guides where (
+ instr(nvl(replace(upper(name),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str1),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str2),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str3),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str4),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(str5),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(code1),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(num1),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(num2),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(num3),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(num4),' ',''),'z'),replace(upper(:str),' ',''))
+ instr(nvl(replace(upper(num5),' ',''),'z'),replace(upper(:str),' ',''))
) > 0
--and type_doc not in (9999,1312,1364,1365,3454,453,2372,969,1363,1978,985,4512,4853,1970,5096,4895,4336,5761
--,6701,2761,3384,6433,4765,3752,7168,1979,5027,5079,2867,5215,2895,4978)
--and type_doc in 9922
group by type_doc order by count(*) desc
/

--��������� ������������
select * from variable_guides where instr(nvl(replace(upper(value),' ',''),'z'),replace(upper(:str),' ','')) > 0
/

select rowid,d.* from guides d where reference = 28017660 --code = 70601810200392102004' reference = 8466616 -- 70601810400392740402

select rowid,d.* from VARIABLE_GUIDES d where reference = 44595690

/
--�����
select * from shed_jobs where  instr(upper(text),upper(:str)) > 0
union all
select * from shed_jobs where  instr(upper(text1),upper(:str)) > 0
union all
select * from shed_jobs where  instr(upper(text2),upper(:str)) > 0
/

--������
select * from dba_jobs  where instr(upper(what),upper(:str)) > 0
/
--� �������� ���������
select * from SMTP_MESSAGES where instr(upper(reciever),upper(:str)) > 0
/
select * from types where type_id in (10269,11512,11511) 


select * from all_objects where object_name in ('TBL_DEILT_MESSAGE_BI','DOC_ROUTING',upper('impex_1tools'))
(select distinct name from all_source where instr(upper(text),upper(:str)) > 0)
--select * from all_views where  instr(upper(text),upper(:str)) > 0
/

select * from all_tables where table_name like '%LOAN%' and owner in ('MBANK','EID') 3312594 