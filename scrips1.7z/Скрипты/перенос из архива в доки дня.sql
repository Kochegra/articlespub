--======= DOCUMENTS ARCHIVE
--select rowid,doc.* from documents doc 
--union all
--select rowid,doc.* from documents_delete doc 
--union all
select rowid,doc.* from archive doc 
where reference in (1207012554)
or refer_from in (1207012554)
or related in (1207012554)
--1207012554 in (reference,refer_from,related) 

--======= VARIABLE_DOCUMENTS
select rowid,doc.* from variable_documents doc where (reference,branch) in 
(select reference,branch from documents doc where reference in (1207012554))

--======= VARIABLE_ARCHIVE
select rowid,doc.* from variable_archive doc where (reference,branch) in 
(select reference,branch from archive doc where reference in (1207012554))

--======= JOURNAL
select rowid,j.*  from journal j where docnum in ()

--======= AUDIT_TABLE
select * from mbank_audit.audit_table where reference=


select * 
--from documents
from archive 
where reference in (184253060,184253061,184253126) 
and branch in (200)

/
-- ������� �� ������ � ��������
declare
begin 
    for rec in (select * from archive where reference in (184253060,184253061,184253126) and branch in (200)
    ) loop
        insert into documents select * from archive where reference = rec.reference and branch = rec.Branch;
        insert into variable_documents select * from variable_archive where reference = rec.reference and branch = rec.Branch;
        delete archive where reference = rec.reference and branch = rec.Branch;
        commit;
        DBMS_OUTPUT.PUT_LINE(rec.reference||'/'||rec.branch||'  ������� �� ������ � ���������!');    
    end loop;
end;
/

-- ������� �� ��������� � ��������
declare
begin 
    for rec in (select * from documents_delete where reference in (184253060,184253061,184253126) and branch in (200)
    ) loop
        insert into documents select * from documents_delete where reference = rec.reference and branch = rec.Branch;
        insert into variable_documents select * from variable_documents_delete where reference = rec.reference and branch = rec.Branch;
        delete documents_delete where reference = rec.reference and branch = rec.Branch;
        commit;
        DBMS_OUTPUT.PUT_LINE(rec.reference||'/'||rec.branch||'  ������� �� ��������� � ���������!');    
    end loop;
end;
/

