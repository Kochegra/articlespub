
-- �����
select rowid,a.* from eid.eid_firma a where inn in ('781403338108')
--eid in (3617452,3616200)

select rowid,a.* from eid.eid_firma_modify a where eid in (3344652,3461638,3456534,3337604,1454303)

select rowid,a.* from eid.eid_firma_variable a where eid in (3463024,3370072)
and type in ('L_ADDRESS_WO_CITY','L_CITY')

select rowid,a.* from eid.eid_firma_products a
where --inn in ('3906078026')
account = '40702810292000003327'


-- ����� ����
select rowid,e.* from EID.EID_FIRMA_RELATION e where eid in (3613266) or eid_to in (3613266)


-- ������
-- ����� �������� � ������������ ��������� �������
select rowid,a.* from EID.EID_FIRMA_ADDRESS

select rowid,a.* from EID.EID_FIRMA_ADDRESS_MODIFY



-- ��������� ����
select rowid,e.* from EID.EID_FIRMA_MANAGER e where eid = 3617452 --3616200

select rowid,e.* from EID.EID_FIRMA_MANAGER_MODIFY e where eid = 3617452--3616200

select rowid,e.* from EID.EID_FIRMA_MANAGER_HISTORY e where eid = 3617452--3616200

-- ����� ������� ���
select * from (

select distinct doc_number, type_doc, refer_client, branch_client,  count(doc_number) cnt
from contracts
where type_doc=6776 and status=50
group by doc_number,type_doc, refer_client, branch_client
order by 3 desc

) where cnt>1

select  
distinct 
EID,MANAGER_EID,LAST_NAME,FIRST_NAME,SECOND_NAME,FIO,SEARCH_NAME,BIRTHDAY,PLACE_BIRTH,DOC_TYPE,DOC_SERIA,DOC_NUMBER,DOC_ATTR,DOC_DATE,SEARCH_DOC,
PHONE,MANAGER_ORDER,
DATE_GET_JOB,DATE_LEAVE,E_MAIL,CMNT,POSSIBLE_TO_EDIT,KEY_EMPLOYEE,MANAGER_TYPE_HAND,MANAGER_TYPE_NAME,DOP_EMPLOYEE,CONTACT_EMPLOYEE,BIRTHDAY_SHORT,
STATUS_LPR,PHONE_PREFIX,PHONE_CODE,PHONE_VALUE,PHONE_NORMAL,UCHRED_EMPLOYEE,BENEFIT_EMPLOYEE,DELEGATE_EMPLOYEE,MANAGINGAUTH_EMPLOYEE,EID_TYPE,
BENEFIT_PROCENT,PARAMS,PROFIT_EMPLOYEE,DELEGATE_CATEGORY,DELEGATE_RIGHT,DELEGATE_STATUS,MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT_TEXT,BENEFIT_REASON,
PROFIT_REASON
,count(eid) cnt
from EID.EID_FIRMA_MANAGER e where eid = 3617452
and status<>-1
and exists (select 1 from eid.eid_firma a where eid =e.eid and branch=200)
group by
EID,MANAGER_EID,LAST_NAME,FIRST_NAME,SECOND_NAME,FIO,SEARCH_NAME,BIRTHDAY,PLACE_BIRTH,DOC_TYPE,DOC_SERIA,DOC_NUMBER,DOC_ATTR,DOC_DATE,SEARCH_DOC,
PHONE,MANAGER_ORDER,
DATE_GET_JOB,DATE_LEAVE,E_MAIL,CMNT,POSSIBLE_TO_EDIT,KEY_EMPLOYEE,MANAGER_TYPE_HAND,MANAGER_TYPE_NAME,DOP_EMPLOYEE,CONTACT_EMPLOYEE,BIRTHDAY_SHORT,
STATUS_LPR,PHONE_PREFIX,PHONE_CODE,PHONE_VALUE,PHONE_NORMAL,UCHRED_EMPLOYEE,BENEFIT_EMPLOYEE,DELEGATE_EMPLOYEE,MANAGINGAUTH_EMPLOYEE,EID_TYPE,
BENEFIT_PROCENT,PARAMS,PROFIT_EMPLOYEE,DELEGATE_CATEGORY,DELEGATE_RIGHT,DELEGATE_STATUS,MANAGINGAUTH_INPUT,MANAGINGAUTH_INPUT_TEXT,BENEFIT_REASON,
PROFIT_REASON

--'������ ��������� ���������� ��������� ���, ������������ ������������ ������'
select ount(1) from eid.eid_manager fm where fm.eid = 3613266 and fm.status = 1 --and fm.manager_eid = nManager_EID_r
and fm.id_record <> nvl(nID_Record_R_exist, -100);

select count(1) into nTemp from eid.eid_firma_manager_modify fm where fm.eid = nEID and fm.status = 1 and fm.manager_eid = nManager_EID_r
and fm.id_record <> nvl(nID_Record_R_exist, -100) and fm.id_hist = nID_Hist_R;

                            
select * from eid.eid_manager fm where fm.eid in (3618926,3613266) and fm.status = 1 --and fm.manager_eid = nManager_EID_r
--and fm.id_record <> nvl(nID_Record_R_exist, -100);

select rowid,fm.* from eid.eid_firma_manager_modify fm where fm.eid in (3618926,3613266) and fm.status = 1 and fm.manager_eid = 29240869

and fm.id_record <> nvl(nID_Record_R_exist, -100);