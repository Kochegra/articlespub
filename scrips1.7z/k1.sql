SELECT src.*, g.name AS cStatus
  FROM (SELECT /*+ INDEX (D DOCUMENT_FIND_INDEX)*/
               D.*, T.NAME NAME_DOC
          FROM DOCUMENTS D, TYPES T
         WHERE     PAYERS_ACCOUNT = '40702810539000004574'
               AND STATUS = 22
               AND T.TYPE_ID = D.TYPE_DOC
               AND ROWNUM < 100
               AND 1 = 1) src
       LEFT JOIN guides g
          ON g.type_doc = 3915 AND g.code = TO_CHAR (src.status)