select * from all_tables where table_name like 'DOC_TEMP%'

SELECT * --object_name 
FROM all_objects 
WHERE --owner = '��������' AND 
object_type = 'TABLE'
and object_name like 'DOC_TEMP%'


SELECT * FROM all_tab_columns WHERE table_name like 'DOC_TEMP%'

select * from user_col_comments

SELECT col.table_name,
  col.column_name,
  col.data_type,
  col.data_length,
  col.data_precision,
  col.data_scale,
  col.nullable,
  com.comments
FROM ALL_TAB_COLUMNS col
LEFT JOIN user_col_comments com
ON (col.table_name  = com.table_name
AND col.column_name = com.column_name)
WHERE col.TABLE_NAME = 'DOC_TEMP2'
ORDER BY table_name,
  column_name;
  
  
SELECT b.*,a.* --object_name 
FROM all_objects a 
LEFT JOIN user_col_comments b
ON (a.object_name  = b.table_name)
--AND col.column_name = com.column_name)
WHERE --owner = '��������' AND 
a.object_type = 'TABLE'
and a.object_name like 'TB_OFFERS%'

--------------------------------------------
INSERT INTO COLLECTOR_CONTRACTS 
select :name,reference,currency,:dt0,universe.SALDO_COLLECTOR(cc.branch,cc.reference,:name,cc.currency,:dt0)+:ssum
,:ssum,collector_contracts_id.NEXTVAL,-1379,users,branch,to_char(sysdate,'yyyymmdd') from collector_contracts cc where reference = :c_ref and branch = :c_br and rownum < 2

------------------- ���� Rest ������������� ��������� � �� ��������� ----------------------
begin dbms_output.put_line(UNIVERSE.ADD_COLLECTOR(273, 4984283, 'PERCENT474', 810, TO_DATE('18.01.2014', 'DD.MM.YYYY'), 9999, 979188833, 1403, 191)); end;
