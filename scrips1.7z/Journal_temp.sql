select * from clients where inn='7805203817'

--update documents set memo=replace(memo,'[04.11.2018]','04.11.2018')
select rowid,doc.* from documents doc
--where reference in (7699761)
--7700151,7700020,7699948,7700158)
--or refer_from in (7700151,7700020,7699948,7700158)
--union all
--select rowid,doc.* from archive doc
where  7706511 in (reference,refer_from,related)
--where reference in (7701376) or refer_from in (7701376) or related in (7701376) 
--where type_doc in (250) and status< 30

30305840200790101001
30305978800790101001

--1
--insert into journal
select rowid,a.* from journal a where 
docnum in (7706709)--7702999,7702998,7702997)

--2
insert into journal_zp
select a.* from journal a where
docnum in (7702982,7702989)

--3
select rowid,a.* from journal_zp a where 
docnum in (7702982,7702989)--7702999,7702998,7702997)

--4
select rowid,a.* from journal a where 
docnum in (7702982,7702989)--7702999,7702998,7702997)

--5
insert into journal
select a.* from journal_zp a where
docnum in (7702982,7702989)


select rowid,doc.* from variable_documents doc where (reference,branch) in 
        (select reference,branch from documents where reference in (7701376)) and subfield='NUMCART' --'SYMBOL'

--insert into variable_archive (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD,XDATE)        
select rowid,doc.* 
--'DBO_TYPE',REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,'TELEBANK',SUBFIELD,XDATE
from variable_archive doc where (reference,branch) in 
        (select reference,branch from archive where reference in (--7692628,
        7685492, 7685491, 7685490, 7685502, 7685489, 7685498, 7685500, 7685497, 7685496, 7685495, 7685494, 7685501))     
        --and name='DATEPLAT'



--insert into journal_zp
select a.* from journal a where 
--select a.* from journal_zp a where
--work_date>=trunc(sysdate)-1 and rsum=11449.05 --
docnum in (7700148)

47422978862090000004
47422840962090000003



select rowid,a.* from clients a where reference=185640


select code,name from(

select rowid,a.* --code, name 
from guides a where type_doc=2375 --and num3=1 
and name!='FORM_STORAGE'

) where rownum<1000  order by 1

select code,name from(

--update 
select * --num1 code, code1 name 
from guides where type_doc=4786 and code1 = '810' 

) where rownum<1000  order by 1

select * from types where type_id in (2375,4786)


select code,name from(

select a.* from guides a where a.type_doc = 851 and code != 'FORM_STORAGE' 
and exists (select 1 from variable_guides b where a.reference = b.reference and a.branch = b.branch)

select code,name from(

select a.* from guides a where a.type_doc = 851 and code != 'FORM_STORAGE' 
and exists (select 1 from variable_guides b where a.reference = b.reference and a.branch = b.branch and b.name = 'GRUPPA_VTB' and value = '1') 
and ( (code = '11' and mbfilid = mbgoid) or (code = '8' and mbfilid != mbgoid) ) 


) where rownum<1000  order by 2


select mbfilid from dual

select mbgoid from dual 


select code,name from(

select * --related code, FULL_NAME name 
from clients where type_doc = 4 and status=310
and Upper(full_name) like '%���%'

) where rownum<1000  and Upper(name) like '%���%' 



select rowid,a.* from variable_contracts a where reference=572457 --refer_client=185598 --reference=589061


select * from journal where 
--work_date>=trunc(sysdate)-1 and rsum=11449.05 --
docnum in (7698791)--7685360,7685355)

47422978862090000004
47422840962090000003

select rowid,a.* from account a where code like '47422%' --in ('47423810862000002065','47423810462000002067')
and open_date = trunc(sysdate)

select src.parentid, src.id, src.name, src.icon, reference, branch, owner from (  
select -1 as parentid,   p.obj_id as id, nvl(t.name,t2.name) as name, p.what as icon,
 to_char(p.last_date,'yyyy-mm-dd hh24:mi:ss') as sort,    nvl(t2.reference,-1) as reference, nvl(t2.branch,-1) as
  branch, nvl(t2.owner,-1) as owner  from personal_object_usage p  left join types t on t.type_id = p.obj_id and p.what <> 105  
  left join templates t2 on t2.id = p.obj_id and p.what = 105  where p.userid = 1017188   and mod(p.what,100) = 2  order by sort desc ) src 



select to_char(count(*)) from  bagstatus s  where s.work_date=to_date('06.11.2018','dd.mm.yyyy')  and s.defect = 0  
and s.currency = '810'  and s.subdepartment = universe.branch_depart(207) and (exists ( select 1 from documents d 
where d.reference = s.refer_jour and d.branch = s.branch_jour     and d.type_doc in (4889, 3369, 3381, 3758)  ) or  
exists (select 1 from archive d where d.reference = s.refer_jour and d.branch = s.branch_jour  and d.type_doc in 
(4889, 3369, 3381, 3758)  )  ) 


select rowid,a.* from MBANK.BAGBOOK a--  bagstatus a --where id=7686985



select rowid,a.* from variable_contracts a where reference in (572447,572452,572435,572457,572454,572455)