-- ������������ ���������2
  SELECT p_k2.GetRest4Cursor (
            branch,
            reference,
            775,
            27326045,
            (CASE
                WHEN type_doc IN (95, 225, 226) THEN a.summa
                ELSE a.xsummacredit
             END),
            2,
            1)                                                   SUMMAREST,
         (CASE
             WHEN type_doc IN (95, 225, 226) THEN a.summa
             ELSE a.xsummacredit
          END)                                                   summa,
         A.REFERENCE,
         A.REFER_FROM,
         A.BRANCH,
         A.BRANCH_FROM,
         A.BRANCH_RELATED,
         A.RELATED,
         A.TYPE_DOC,
         a.status,
         a.doc_number,
         a.date_work,
         a.date_value,
         a.date_document,
         a.payers_account,
         a.payers,
         a.receivers_account,
         a.receivers,
         a.memo,
         a.summa                                                 summa_doc,
         a.xsummacredit,
         a.payers_currency,
         a.payment,
         cTable,
         DATE_DOCUMENT                                           DATE_ACCEPT,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'KBK',
                                 nType)                          KBK,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'COMPDOC_STATUS',
                                 nType)                          COMPDOC_STATUS,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'TAX_MEMO',
                                 nType)                          TAX_MEMO,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'TAX_TYPEDOC',
                                 nType)                          TAX_TYPEDOC,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'OKATO',
                                 nType)                          OKATO,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'TAX_DOCNUMBER',
                                 nType)                          TAX_DOCNUMBER,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'TAX_DATEDOC',
                                 nType)                          TAX_DATEDOC,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'TAX_PERIOD',
                                 nType)                          TAX_PERIOD,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'PAYERS_KPP',
                                 nType)                          PAYERS_KPP,
         UNIVERSE.VARIABLE_PART (REFERENCE,
                                 BRANCH,
                                 'RECEIVERS_KPP',
                                 nType)                          RECEIVERS_KPP,
         (CASE
             WHEN a.status = 35
             THEN
                p_13868.get_card_account (branch,
                                          reference,
                                          27326045,
                                          775)
             ELSE
                COALESCE (UNIVERSE.VARIABLE_PART (REFERENCE,
                                                  BRANCH,
                                                  'CARD_ACCOUNT_WAIT',
                                                  nType),
                          UNIVERSE.VARIABLE_PART (REFERENCE,
                                                  BRANCH,
                                                  'CARD_ACCOUNT',
                                                  nType))
          END)                                                   CARD_ACCOUNT,
         DECODE (UNIVERSE.VARIABLE_PART (REFERENCE,
                                         BRANCH,
                                         'TYPE_SROK',
                                         nType),
                 '', ' ',
                 '0', '���������',
                 '1', UNIVERSE.VARIABLE_PART (REFERENCE,
                                              BRANCH,
                                              'STOP_SROK',
                                              nType),
                 ' ')                                            st_sr,
         DECODE (NVL (UNIVERSE.VARIABLE_PART (REFERENCE,
                                              BRANCH,
                                              'WAIT_ED201',
                                              nType),
                      '0'),
                 '0', ' ',
                 '1', ' ��������������� ED201')   st_201,
         (SELECT GREATEST (
                    NVL (
                       (SELECT MAX (A2.DATE_WORK)
                          FROM DOCUMENTS A2
                         WHERE     A2.RELATED = A.REFERENCE
                               AND A2.BRANCH_RELATED = A.BRANCH
                               AND A2.STATUS NOT IN (35, 36, 38)
                               AND A2.STATUS >= 30
                               AND A2.STATUS < 1000),
                       TO_DATE ('01.01.1900', 'dd.mm.yyyy')),
                    NVL (
                       (SELECT MAX (A2.DATE_WORK)
                          FROM ARCHIVE A2
                         WHERE     A2.RELATED = A.REFERENCE
                               AND A2.BRANCH_RELATED = A.BRANCH
                               AND A2.STATUS NOT IN (35, 36, 38)
                               AND A2.STATUS >= 30
                               AND A2.STATUS < 1000),
                       TO_DATE ('01.01.1900', 'dd.mm.yyyy')),
                    NVL (
                       (SELECT MAX (A2.DATE_WORK)
                          FROM GLOBAL_ARCHIVE A2
                         WHERE     A2.RELATED = A.REFERENCE
                               AND A2.BRANCH_RELATED = A.BRANCH
                               AND A2.STATUS NOT IN (35, 36, 38)
                               AND A2.STATUS >= 30
                               AND A2.STATUS < 1000),
                       TO_DATE ('01.01.1900', 'dd.mm.yyyy')))
            FROM DUAL)                                           DT1
    FROM (SELECT A.*, 0 nType, 'DOCUMENTS' cTable
            FROM DOCUMENTS A
           WHERE     (REFERENCE, BRANCH) IN
                        (SELECT /*+ index(COLLECTOR_CONTRACTS COLLECTOR_CONTRACT_PK)*/
                                DOCNUM, ZBRANCH_DOCNUM
                           FROM COLLECTOR_CONTRACTS
                          WHERE     REFERENCE = 27326045
                                AND BRANCH = 775
                                AND NAME = 'CARDLIST_2'
                                AND SUMMA IN (0, 1))
                 AND NOT EXISTS
                        (SELECT 1
                           FROM k2_multi k2m
                          WHERE     k2m.reference = a.reference
                                AND k2m.branch = a.branch)
          UNION ALL
          SELECT A.*, 1 nType, 'ARCHIVE' cTable
            FROM ARCHIVE A
           WHERE (REFERENCE, BRANCH) IN
                    (SELECT /*+ index(COLLECTOR_CONTRACTS COLLECTOR_CONTRACT_PK)*/
                            DOCNUM, ZBRANCH_DOCNUM
                       FROM COLLECTOR_CONTRACTS
                      WHERE     REFERENCE = 27326045
                            AND BRANCH = 775
                            AND NAME = 'CARDLIST_2'
                            AND SUMMA IN (0, 1))
          UNION ALL
          SELECT A.*, 2 nType, 'GLOBAL_ARCHIVE' cTable
            FROM GLOBAL_ARCHIVE A
           WHERE (REFERENCE, BRANCH) IN
                    (SELECT /*+ index(COLLECTOR_CONTRACTS COLLECTOR_CONTRACT_PK)*/
                            DOCNUM, ZBRANCH_DOCNUM
                       FROM COLLECTOR_CONTRACTS
                      WHERE     REFERENCE = 27326045
                            AND BRANCH = 775
                            AND NAME = 'CARDLIST_2'
                            AND SUMMA IN (0, 1))
          UNION ALL
          SELECT a.*, 0 nType, 'DOCUMENTS' cTable
            FROM DOCUMENTS A
           WHERE (REFERENCE, BRANCH) IN
                    (SELECT reference, branch
                       FROM k2_multi
                      WHERE     refer_contract = 27326045
                            AND branch_contract = 775    /*and is_main!=1*/
                                                        )) A
   WHERE STATUS IN (35, 38)
ORDER BY PAYMENT, DATE_WORK

