select rowid,a.* from tmp_tables.zyx_store a 
--where oper not in ('AUDIT_FNS','OBJ_MOVE','OWNER_UPD','AD_LOGIN24','FIL48','OLD_FIL_BM','FIL_KARANTIN_2','TEST','DSS','AR','AR_MQ','INFO')
--where oper in ('SHED_DISTR_W24','MONITOR_MB_WAY24','ERR_ACC_TRANSFER')
--where oper in ('SHED_DISTR_W24')
where oper in ('MONITOR_MB_WAY24')
--where oper in ('ERR_ACC_TRANSFER')
order by dt_mod


/
-- ������ tmp_tables.zyx_store
declare
begin

    delete from tmp_tables.zyx_store where oper in ('SHED_DISTR_W24','MONITOR_MB_WAY24','ERR_ACC_TRANSFER') and trunc(dt_mod)<trunc(sysdate)-60;  
    commit;  

end;
/
