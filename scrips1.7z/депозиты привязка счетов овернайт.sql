--update variable_contracts set value='2'
--Update  Variable_contracts a Set value = to_char((select date_work from contracts where reference=a.reference and branch=a.branch), 'dd')
select rowid,a.*
,(select date_work from contracts where reference=a.reference and branch=a.branch) ����_���������_�� 
,(select doc_number from contracts where reference=a.reference and branch=a.branch) �����_��������
from variable_contracts a 
where reference in (--569328)--
567931)
and branch=204
--and name in ('URGENT_CLOSE')
order by name,SUBFIELD

and name not like ('%F303%')
-- ��

select rowid,a.*
,(select date_work from contracts where reference=a.reference and branch=a.branch) ����_���������_�� 
,(select doc_number from contracts where reference=a.reference and branch=a.branch) �����_��������
from collector_contracts a 
where reference in (567931,569328)
and branch=204
--and name in ('URGENT_CLOSE')
order by name,SUBFIELD


select rowid,a.* from account a where contract=567931

1175194 code in ('41502810289000000258','47426810789001002835')

-- ��������� ����� ��������� � �������������
declare
ref_cnt number := 567931;
ref_br number := 204;
acc1 variable_contracts.value%type := '41502810289000000258';
acc2 variable_contracts.value%type := '47426810789001002835';
ref_acc1 variable_account.reference%type;
ref_acc2 variable_account.reference%type;
br_acc1 variable_account.branch%type;
br_acc2 variable_account.branch%type;
begin 

insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,0,acc1,'CODE'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc1 and subfield='CODE');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,1,(select currency from account where code=acc1) value,'CURR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc1 and subfield='CURR');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,2,(select reference from account where code=acc1) value,'REF'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc1 and subfield='REF');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,3,(select branch from account where code=acc1) value,'BR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc1 and subfield='BR');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,4,acc2,'PAIR_CODE'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc2 and subfield='PAIR_CODE');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,5,(select reference from account where code=acc2) value,'PAIR_REF'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc2 and subfield='PAIR_REF');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS',ref_cnt,ref_BR,0,1,6,(select branch from account where code=acc2) value,'PAIR_BR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS' and value=acc2 and subfield='PAIR_BR');

insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,0,acc2,'CODE'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc2 and subfield='CODE');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,1,(select currency from account where code=acc2) value,'CURR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc2 and subfield='CURR');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,2,(select reference from account where code=acc2) value,'REF'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc2 and subfield='REF');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,3,(select branch from account where code=acc2) value,'BR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc2 and subfield='BR');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,4,acc1,'PAIR_CODE'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc1 and subfield='PAIR_CODE');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,5,(select reference from account where code=acc1) value,'PAIR_REF'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc1 and subfield='PAIR_REF');
insert into variable_contracts value (NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE,SUBFIELD)
select 'ACCOUNTS_474',ref_cnt,ref_BR,0,1,6,(select branch from account where code=acc1) value,'PAIR_BR'
from dual where not exists (select 1 from variable_contracts where name='ACCOUNTS_474' and value=acc1 and subfield='PAIR_BR');

--- gfbh
select reference,branch into ref_acc1,br_acc1 from account where code=acc1;
select reference,branch into ref_acc2,br_acc2 from account where code=acc2;
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_REF',ref_acc1,br_acc1,0,1,0,ref_acc2 value from dual where not exists (select 1 from variable_account where reference=ref_acc1 and branch=br_acc1 and name='PAIR_REF');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_BR',ref_acc1,br_acc1,0,1,0,br_acc2 value from dual where not exists (select 1 from variable_account where reference=ref_acc1 and branch=br_acc1 and name='PAIR_BR');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_CODE',ref_acc1,br_acc1,0,1,0,acc2 value from dual where not exists (select 1 from variable_account where reference=ref_acc1 and branch=br_acc1 and name='PAIR_CODE');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'CREATE_REF',ref_acc1,br_acc1,0,1,0,ref_cnt value from dual where not exists (select 1 from variable_account where reference=ref_acc1 and branch=br_acc1 and name='CREATE_REF');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'CREATE_BR',ref_acc1,br_acc1,0,1,0,ref_br value from dual where not exists (select 1 from variable_account where reference=ref_acc1 and branch=br_acc1 and name='CREATE_BR');

insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_REF',ref_acc2,br_acc2,0,1,0,ref_acc1 value from dual where not exists (select 1 from variable_account where reference=ref_acc2 and branch=br_acc2 and name='PAIR_REF');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_BR',ref_acc2,br_acc2,0,1,0,br_acc1 value from dual where not exists (select 1 from variable_account where reference=ref_acc2 and branch=br_acc2 and name='PAIR_BR');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'PAIR_CODE',ref_acc2,br_acc2,0,1,0,acc1 value from dual where not exists (select 1 from variable_account where reference=ref_acc2 and branch=br_acc2 and name='PAIR_CODE');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'CREATE_REF',ref_acc2,br_acc2,0,1,0,ref_cnt value from dual where not exists (select 1 from variable_account where reference=ref_acc2 and branch=br_acc2 and name='CREATE_REF');
insert into variable_account(NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE)
select 'CREATE_BR',ref_acc2,br_acc2,0,1,0,ref_br value from dual where not exists (select 1 from variable_account where reference=ref_acc2 and branch=br_acc2 and name='CREATE_BR');

end;

42102810889000001111
810
1170310
204
47426810289001002461
1170311
204

select rowid,NAME,REFERENCE,BRANCH,SUBNUMBER,ROWNUMBER,COLNUMBER,VALUE from variable_account where reference in (1175193,1175194) and branch=204 and name in ('PAIR_REF','PAIR_BR','PAIR_CODE','CREATE_REF','CREATE_BR')  

select rowid,a.* from variable_account a where reference in (1164087,1164088,1175193,1175194) and name in ('PAIR_REF','PAIR_BR','PAIR_CODE','CREATE_REF','CREATE_BR')


select rowid,a.date_work-date_open,round(months_between(date_work, date_open),0) 
from contracts a 
where reference in (572887,572888)
and branch=209
