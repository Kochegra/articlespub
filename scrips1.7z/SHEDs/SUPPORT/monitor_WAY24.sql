--monitor_WAY24
--���������� ����������� ������� ��, ���������� � ����������� � �� ������24
declare
vMail number := 0;
vPNO_txt varchar2(10000) := null;
vIPNO_txt varchar2(10000) := null;
vDoc_txt varchar2(10000) := null;
vResult_txt varchar2(10000) := null;
begin
    -- ����� ������� � ����������� � WAY24
    for recPNO in (
                    select f.* from no_file f
                        where
                            date_create BETWEEN trunc(sysdate)-3
                                --TO_DATE ('20200727', 'yyyymmdd')
                                AND trunc(sysdate)
                                   + 1
                                   - 1 / (1 * 24 * 60 * 60)
--                    and exists (select 1 from contracts a where (a.reference,a.branch) in
--                                    (select contract,branch_contract from account where code in
--                                        (select value from no_files where reference = f.reference))
--                                            and type_doc in (590) and status=50 and sub_type=1
--                                            --and d_3363.contract_action_arrest_n (reference, branch)>0
--                                )
                    and exists (select 1 from contracts a where account in
                                        (select value from no_files where reference = f.reference)
                                            and type_doc in (590) and sub_type=1 --and status=50 
                                )
                    --and reference not in (2657017)
                    and not exists(select null from tmp_tables.zyx_store where oper='MONITOR_MB_WAY24' and num1=f.reference)
    ) loop
        vMail := vMail + 1;
        vPNO_txt := vPNO_txt||recPNO.reference||' '||recPNO.file_name||' '||recPNO.status||chr(9)||chr(13);
        insert into tmp_tables.zyx_store (OPER,num1,num2,str1,dt_mod) values ('MONITOR_MB_WAY24',recPNO.reference,recPNO.branch,'NO_FILE',sysdate);
        commit;
    end loop;
     -- ����� ���������� �����
    for recIPNO in (
        select * from inkp_staging i
            where i.date_load BETWEEN trunc(sysdate)-3
                                --TO_DATE ('20200727', 'yyyymmdd')
                                AND trunc(sysdate)
                                --and TO_DATE ('20190326', 'yyyymmdd')
                                + 1
                                - 1 / (1 * 24 * 60 * 60)
--            and exists (select 1 from contracts a where (a.reference,a.branch) in
--                           (select contract,branch_contract from account where code = i.ACCOUNT_NO_PAYER)
--                                and type_doc in (590) and status=50 and sub_type=1
--                            --and d_3363.contract_action_arrest_n (reference, branch)>0
--                       )
            and exists (select 1 from contracts a where account = i.ACCOUNT_NO_PAYER
                                and type_doc in (590) and sub_type=1 --and status=50 
                       )
            and not exists(select null from tmp_tables.zyx_store where oper='MONITOR_MB_WAY24' and num1=i.id)
    )loop
        vMail := vMail + 1;
        vIPNO_txt := vIPNO_txt||recIPNO.id||' '||recIPNO.file_name||' '||recIPNO.status||chr(9)||chr(13);
        insert into tmp_tables.zyx_store (OPER,num1,num2,str1,dt_mod) values ('MONITOR_MB_WAY24',recIPNO.id,recIPNO.branch,'INKP_STAGING',sysdate);
        commit;
    end loop;
     -- ����� ������� �����
    for recDoc in (select * from documents d where trunc(date_create)>=trunc(sysdate)-3 --TO_DATE ('20200727', 'yyyymmdd')
                        and type_doc in (226,/*3317,*/3363)
                        and (d.PAYERS_ACCOUNT in
                               (select c.account
                                from contracts c
                                where type_doc = 590
                                and sub_type in (1)
                                --and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
                                )
                            or d.RECEIVERS_ACCOUNT in
                               (select c.account
                                from contracts c
                                where type_doc = 590
                                and sub_type in (1)
                                --and universe.VARIABLE_CONTRACT(branch, reference, 'CARD_CORP_CONTRACT') is not null
                                )
                            )
                            and not exists(select null from tmp_tables.zyx_store where oper='MONITOR_MB_WAY24' and num1=d.reference and num2=d.branch)
    )loop
        vMail := vMail + 1;
        vDoc_txt := vDoc_txt||recDoc.reference||'/'||recDoc.branch||' '||recDoc.type_doc||' '||recDoc.status||chr(9)||chr(13);
        insert into tmp_tables.zyx_store (OPER,num1,num2,str1,dt_mod) values ('MONITOR_MB_WAY24',recDoc.reference,recDoc.branch,'DOCUMENTS',sysdate);
        commit;
    end loop;
    vResult_txt:=vResult_txt||'������� �� (�����):'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vPNO_txt||chr(9)||chr(13)||chr(9)||chr(13);
    vResult_txt:=vResult_txt||'���������� �� (�����):'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vIPNO_txt||chr(9)||chr(13)||chr(9)||chr(13);
    vResult_txt:=vResult_txt||'���������:'||chr(9)||chr(13);
    vResult_txt:=vResult_txt||vDoc_txt||chr(9)||chr(13)||chr(9)||chr(13);
    if vMail<>0 then
           P_Email.Send_Mail(Reciever => 'SHED_GORODNOV',
                             Subject => '���������� � WAY24',
                             Mail_Text => vResult_txt
                              );
    end if;
end;
/