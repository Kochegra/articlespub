--DISTRIB_ALLERT_W24

declare
v_oldExtId VARIABLE_DOCUMENTS.NAME%type;
v_exec number;
v_tr_del varchar2(200);
v_doc_no_upd number;
v_log varchar2(200);
v_upd number := 1;
v_txt varchar(10000) := '';
 function f_tran_exec(p_task_kind varchar2,p_tran_id number,p_doc_ref number) return number
 is
 begin
    for r in (select f.* from eid.distrib_transactions f where task_kind=p_task_kind
                            and tran_id in (select distinct(tran_id) from eid.distrib_features a where value = to_char(p_doc_ref))
                            and tran_id>p_tran_id and nvl(eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'DELETE_OPER'),'0')='0'
                    order by tran_id,run_order)
    loop
        if r.done <> 2 then
            return 1;
        end if;
    end loop;
    return 0;
 end;
 function f_tran_del_upd(p_task_kind varchar2,p_tran_id number,p_doc_ref number) return varchar2
 is
 begin
    for r in (select f.* from eid.distrib_transactions f
                    where task_kind=p_task_kind
                            and tran_id in (select distinct(tran_id) from eid.distrib_features a where value = to_char(p_doc_ref))
                            and tran_id>p_tran_id
                            and nvl(eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'DELETE_OPER'),'0')='1'
                    order by tran_id,run_order)
    loop
        if r.done <> 1 then
            --v_txt := v_txt||'DEL_TR '||r.tran_id||chr(9)||chr(13);
            update eid.distrib_transactions set done=1
                where tran_id=r.tran_id and task_kind=r.task_kind and filial=r.filial and run_order=r.run_order and v_upd=1;
            commit;
        end if;
    end loop;
    return null;
 end;
 function f_doc_set1000(p_doc_ref number,p_doc_branch number) return number
 is
  st number :=0;
 begin
    for r in (select p_k2.Get_Rest_K2(doc.reference, doc.branch) spisK2,doc.summa-p_k2.Get_Rest_K2(doc.reference, doc.branch) ostK2,
                (select UNIVERSE.VARIABLE_CONTRACT(c.branch,c.reference,'CARD_CORP_CONTRACT') from contracts c where account=doc.payers_account and type_doc=590 and sub_type=1) waycnt,
                UNIVERSE.VARIABLE_DOC(doc.branch,doc.reference,'WAY4_DOCEXTID') WAY4_DOCEXTID,
                (select count(*)  from journal where docnum=doc.reference and branch=DOC.BRANCH) cnt_jou,
                doc.* from documents doc where  related = p_doc_ref and branch_related = p_doc_branch and status<30)
    loop
        if r.status < 30 and r.cnt_jou=0 then
            --v_txt := v_txt||'DEL_DOC '||r.reference||' '||r.branch||chr(9)||chr(13);
            update documents set status=1000
                where reference=r.reference and branch=r.branch and v_upd=1;
            commit;
        else
            v_txt := v_txt||'WARNING_DOC '||r.reference||' '||r.branch||chr(9)||chr(13);
            st := st+1;
        end if;
    end loop;
    return st;
 end;
 function f_log_ins(p_doc_ref number,p_doc_branch number,p_task_kind varchar2, p_filial number, p_tran_id number, p_run_order number,
                        p_err varchar2, p_oldExtId varchar2) return varchar2
 is
  res varchar2(200);
 begin
    v_txt := v_txt||'INS_LOG '||p_doc_ref||' '||p_doc_branch||' tr = '||p_tran_id||chr(9)||chr(13);
    insert into tmp_tables.zyx_store (oper,num1,num2,str5,num3,num4,num6,str1,str2,dt_mod)
        select 'SHED_DISTR_W24',p_doc_ref,p_doc_branch,p_task_kind,p_filial,p_tran_id,p_run_order,p_err,p_oldExtId,sysdate from dual
            where not exists (select null from tmp_tables.zyx_store where oper='SHED_DISTR_W24' and num1=p_tran_id and num2=p_filial and num3=p_run_order and trunc(dt_mod) >= trunc(sysdate)) and v_upd=1;
    commit;
    return null;
 end;
 function f_log_upd(p_doc_ref number,p_doc_branch number,p_newExtId varchar2) return varchar2
 is
  res varchar2(200);
 begin
    v_txt := v_txt||'UPD_LOG '||p_doc_ref||' '||p_doc_branch||' newExtId = '||p_newExtId||chr(9)||chr(13);
    update tmp_tables.zyx_store set str3=p_newExtId
        where oper='SHED_DISTR_W24' and trunc(dt_mod) >= trunc(sysdate) and num1=p_doc_ref and num2=p_doc_branch and v_upd=1;
    commit;
    return null;
 end;
begin
--v_upd := 1;
    for rDoc in (select
                            eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'DOC_REF') DOC_REF,
                            eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'DOC_BRANCH') DOC_BRANCH,
                            eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'SHOW_RESULT_OPER') SHOW_RESULT_OPER,
                            f.*
                 from eid.distrib_transactions f
                    where tran_id in (select distinct(tran_id) from eid.distrib_transactions t where sys_date < sysdate-1/24
                                            and exists(select null from eid.distrib_transactions where task_kind = t.task_kind and tran_id = t.tran_id and trunc(done) <> t.done))
                        and task_kind='IP_LOCK' and done=2
                        and instr(eid.p_distrib_tran.get_feature(f.task_kind, f.tran_id, f.filial, 'SHOW_RESULT_OPER'),'������������ ������� �� �����')>0)
    loop
        v_oldExtId := UNIVERSE.VARIABLE_PART(rDoc.doc_ref,rDoc.doc_branch,'WAY4_DOCEXTID',0);
        v_txt := v_txt||rDoc.doc_ref||' '||rDoc.doc_branch||' '||v_oldExtId||chr(9)||chr(13);
        -- �������� ������ ���������� ����� ������
        v_exec := f_tran_exec(p_task_kind => rDoc.task_kind,p_tran_id => rDoc.tran_id,p_doc_ref => rDoc.doc_ref);
        -- ������ ����������
        if v_exec=0 then
            v_txt := v_txt||'upd_transaction   '||rDoc.tran_id||' '||rDoc.task_kind||' '||rDoc.filial||' '||rDoc.run_order||chr(9)||chr(13);
            update eid.distrib_transactions set done=1
                where tran_id=rDoc.tran_id and task_kind=rDoc.task_kind and filial=rDoc.filial and run_order=rDoc.run_order and v_upd=1;
            commit;
        end if;
        -- �������������� ������� ���������
        v_tr_del := f_tran_del_upd(p_task_kind => rDoc.task_kind,p_tran_id => rDoc.tran_id,p_doc_ref => rDoc.doc_ref);
        -- �������������� �������� ����������� ����������
        v_doc_no_upd := f_doc_set1000(rDoc.doc_ref,rDoc.doc_branch);
        if v_doc_no_upd > 0 then
            v_txt := v_txt||'�������� ��������� 1000 ������� ����������� ����������!'||chr(9)||chr(13);
        end if;
        -- �����������
        v_log := f_log_ins(p_doc_ref => rDoc.doc_ref,p_doc_branch => rDoc.doc_branch, p_task_kind => rDoc.task_kind, p_filial => rDoc.filial, p_tran_id => rDoc.tran_id, p_run_order => rDoc.run_order,
                        p_err => rDoc.SHOW_RESULT_OPER, p_oldExtId => v_oldExtId);

    end loop;
    for rLog in (select * from tmp_tables.zyx_store zs where oper='SHED_DISTR_W24'
                     and str3 is null
                     and trunc(dt_mod) >= trunc(sysdate))
    loop
        if trim(rLog.str2) <> trim(UNIVERSE.VARIABLE_PART(rLog.num1,rLog.num2,'WAY4_DOCEXTID',0)) then
            v_log := f_log_upd(rLog.num1,rLog.num2,UNIVERSE.VARIABLE_PART(rLog.num1,rLog.num2,'WAY4_DOCEXTID',0));
        end if;
    end loop;
    if nvl(v_txt,'0')<>'0' then
        P_Email.Send_Mail(Reciever => 'SHED_226_W24',
                          Subject => '�������������� DISTRIB �� ������24. ������������ ������� �� �����',
                          Mail_Text => v_txt);
    end if;
end;
/