--RPO_NO_EXTID
--��������� ���������� ������� ��, �� ������� ����������� ExtId �� ������24
declare
result varchar2(10000);
vExtId_old varchar2(2000);
vExtId varchar2(2000);
vText varchar2(4000) := null;
vTextExec varchar2(1000);
vTextWay varchar2(1000);
v_res_log number;
v_res number;
begin
    for rec in (select (select '[STATUS='||status||'][ERR_CODE='||err_code||'][ERR_MESS='||err_mess||']' from no_file where reference=zs.num1) NOFILE,
                        (select count(*) from no_files nf where reference=zs.num1 and exists(select null from contracts where account=nf.value and type_doc=590 and sub_type=1 and status in (50,60))) cntAcc590,
                        zs.* from tmp_tables.zyx_store zs where oper='MONITOR_MB_WAY24' and str1 is not null and trunc(dt_mod) >= trunc(sysdate) and str1 in ('NO_FILE'))
    loop
        if rec.cntAcc590=1 then
            if PTOOLS5.READ_PARAM(rec.nofile,'STATUS')='ERROR' and instr(PTOOLS5.READ_PARAM(rec.nofile,'ERR_MESS'),'GDM ����������� ������ ���/���')>0
            then
                for docRef in (SELECT c.reference,c.branch,
                                da.date_document date_doc,
                                d_3363.to_numb (da.doc_number) doc_number_num,
                                TO_CHAR (da.date_document, 'DD.MM.YYYY') date_document,
                                (select work_date from v_documents where related=c.docnum and branch_related=c.zbranch_docnum) d_otm,
                                (select work_date from v_documents where related=da.reference and branch_related=da.branch) d_otm2,
                                c.docnum doc_reference,
                                c.zbranch_docnum doc_branch,
                                da.doc_number doc_number,
                                da.payment payment,
                                da.payment type_change,
                                UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'nalog_doc_number') nalog_doc_number,
                                UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'nalog_doc_date') nalog_doc_date,
                                nvl(UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'ORGAN'), '0') ORGAN,
                                nvl(UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'ARTYPE'), '0') ARTYPE,
                                nvl(UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'ARSUM'), '0') ARSUM,
                                d_3363.related_doc_count (da.reference, da.branch, 30) is_cancel,
                                DA.PAYERS_ACCOUNT,
                                da.memo
                                FROM contracts cont, collector_contracts c, v_documents da
                                WHERE c.reference = cont.reference
                                    AND c.branch = cont.branch
                                    AND c.name = 'ARREST_ACTION_3363'
                                    AND da.status = 30
                                    AND da.reference = c.docnum
                                    AND da.branch = c.zbranch_docnum
                                    AND NVL (da.related, 0) = 0
                                    and (cont.reference,cont.branch) in (select reference,branch from contracts a where account in
                                                                            (select value from no_files where reference = rec.num1) and type_doc=590 and sub_type=1
                                                                            and UNIVERSE.VARIABLE_CONTRACT(branch,reference,'CARD_CORP_CONTRACT') is not null)
                                    and UNIVERSE.GET_FAR_VARIABLE(c.zbranch_docnum, c.docnum, 'nalog_doc_number') in (select number_stop from no_file where reference = rec.num1)
                                ORDER BY 4 desc,5 desc)
                loop
                    -- ���� �������� ���������� ExtId � ����������
                    vExtId_old := UNIVERSE.GET_FAR_VARIABLE(docRef.doc_branch, docRef.doc_reference, 'WAY4_DOCEXTID');
                    for i in 1..4
                    loop
                        if i=1 then
                            vExtId := UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'NALOG_DOC_NUMBER')||','||
                                        to_char(to_date(UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'NALOG_DOC_DATE'),'dd.mm.yyyy'),'dd.mm.yy')||','||
                                        trim(docRef.memo);
                        end if;
                        if i=2 then
                            vExtId := substr(UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'SOID_ID')||','||
                                                UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'NALOG_DOC_NUMBER')||','||
                                                to_char(to_date(UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'NALOG_DOC_DATE'),'dd.mm.yyyy'),'dd.mm.yy')||','||trim(docRef.memo),1,64);
                        end if;
                        if i=3 then
                            vExtId := UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'SOID_ID');
                        end if;
                        if i=4 then
                            vExtId := UNIVERSE.GET_FAR_VARIABLE(docRef.doc_BRANCH, docRef.doc_REFERENCE, 'ID_AREST_XXI');
                        end if;
                        UNIVERSE.Input_var_doc(docRef.doc_BRANCH, docRef.doc_REFERENCE,'WAY4_DOCEXTID', trim(vExtId));
                        commit;
                        result := pno.performw(p_reference => rec.num1, --docRef.doc_REFERENCE,
                                               p_branch => rec.num2, --docRef.doc_BRANCH,
                                               p_auto => 0);
                        commit;
                        select count(*) into v_res_log from (select rowid,a.* from CORP_CARD_WAY24_DOC_LOG a
                                                where trunc(req_date)>=trunc(sysdate)-1
                                                    and service in ('ACC_RESTRICT')
                                                    and doc_reference = docRef.doc_REFERENCE and doc_branch=docRef.doc_BRANCH
                                                    and instr(req_out,trim(vExtId))>0
                                                    and is_lock=0
                                                    and req_status=0
                                                order by req_date desc)
                                                where rownum<=1;
                        if v_res_log>0 then
                            -- num3 - �������� � ��
                            -- num4 - ��������� �� �����
                            update tmp_tables.zyx_store set num3=1,num4=0,str2='EXEC'
                                where oper='MONITOR_MB_WAY24'
                                    and str1 is not null
                                    and trunc(dt_mod) = trunc(rec.dt_mod)
                                    and str1=rec.str1
                                    and num1=rec.num1
                                    and num2=rec.num2;
                            commit;
                            exit;
                        end if;
                    end loop;
                    select count(*) into v_res from tmp_tables.zyx_store where oper='MONITOR_MB_WAY24' and str1 is not null and trunc(dt_mod) = trunc(rec.dt_mod)
                        and str1=rec.str1 and num1=rec.num1 and num2=rec.num2 and nvl(num3,0)=1;
                    if v_res=0 then
                        UNIVERSE.Input_var_doc(docRef.doc_BRANCH, docRef.doc_REFERENCE,'WAY4_DOCEXTID', trim(vExtId_old));
                        COMMIT;
                        update variable_contracts a set name='#CARD_CORP_CONTRACT'
                            where reference=docRef.reference and branch=docRef.branch and instr(name,'CARD_CORP_CONTRACT')>0;
                        commit;
                        result := pno.performw(p_reference => rec.num1, --docRef.doc_REFERENCE,
                                               p_branch => rec.num2, --docRef.doc_BRANCH,
                                               p_auto => 0);
                        commit;
                        update variable_contracts a set name='CARD_CORP_CONTRACT'
                            where reference=docRef.reference and branch=docRef.branch and instr(name,'CARD_CORP_CONTRACT')>0;
                        commit;
                        update tmp_tables.zyx_store set num3=0,num4=0,str2='EXEC'
                            where oper='MONITOR_MB_WAY24'
                                and str1 is not null
                                and trunc(dt_mod) = trunc(rec.dt_mod)
                                and str1=rec.str1
                                and num1=rec.num1
                                and num2=rec.num2;
                        commit;
                    end if;
                end loop;
            end if;
        else
            if PTOOLS5.READ_PARAM(rec.nofile,'STATUS')='ERROR' and instr(PTOOLS5.READ_PARAM(rec.nofile,'ERR_MESS'),'GDM ����������� ������ ���/���')>0 and nvl(rec.num4,0)=0
            then
                update tmp_tables.zyx_store set num3=0,num4=0,str2='MANUAL'
                    where oper='MONITOR_MB_WAY24'
                        and str1 is not null
                        and trunc(dt_mod) = trunc(rec.dt_mod)
                        and str1=rec.str1
                        and num1=rec.num1
                        and num2=rec.num2;
                commit;
            end if;
        end if;
    end loop;
    -- ��������� ��������� �� ����� � ����������� ������
    for recmail in (select (select '[FILE_NAME='||file_name||'][STATUS='||status||']' from no_file where reference=zs.num1) info,
                        zs.* from tmp_tables.zyx_store zs where oper='MONITOR_MB_WAY24'
                        and str1 is not null
                        and trunc(dt_mod) >= trunc(sysdate)
                        and str1 in ('NO_FILE')
                        and nvl(num4,0)=0 and nvl(str2,'0')<>'0'
    ) loop
        if trim(recmail.str2)='EXEC' then vTextExec := '� ������ ��������.'; end if;
        if trim(recmail.str2)='MANUAL' then vTextExec := '��������!!! ����� ���������� �������!!!'; end if;
        if nvl(recmail.num3,0)=0 and trim(recmail.str2)='EXEC' then vTextWay := '���������� �������������� � WAY.'; end if;
        vText := vText||recmail.num1||' '||PTOOLS5.READ_PARAM(recmail.info,'FILE_NAME')||' '||PTOOLS5.READ_PARAM(recmail.info,'STATUS')||' '||vTextExec||' '||vTextWay||chr(9)||chr(13);
        update tmp_tables.zyx_store set num4=1
           where oper='MONITOR_MB_WAY24'
               and str1 is not null
               and trunc(dt_mod) = trunc(recmail.dt_mod)
               and str1=recmail.str1
               and num1=recmail.num1
               and num2=recmail.num2;
        commit;
    end loop;
    if nvl(vText,'0')<>'0' then
        P_Email.Send_Mail(Reciever => 'SHED_RPO_NO_EXTID',
                          Subject => '��������� ����� �� �� ������24.',
                          Mail_Text => vText);
    end if;
end;
/