-- ������ �� �����
select rowid,a.* 
--task_name,job_name,disabled
from shed_jobs a
where --task_name in ('SUPPORT','SERVICE','IMPEX','EID_CARD_CORP') 
--service
and job_name in ('E_INKP','E_INKP_DISTRIB')
--impex
and job_name in ('POST_EXEC_INCASSO_DOC')
--EID_CARD_CORP
and job_name in ('SHED_PC_SYNC')
--support
and job_name in ('monitor_WAY24')

  