select * from users where user_id=15962

select rowid,a.* from user_param_values a where user_id=15962 and depart_id in (9,613)

select up.name name,upv.value value,to_char(upv.ACTIVATED,'dd.mm.yyyy') act
from user_param_values upv,user_parameters up
where UPV.USER_ID=15962 and UPV.ID=UP.ID and up.depart_id=9 --:xJob2 
and upv.activated =
(SELECT MAX (activated) FROM user_param_values  WHERE user_id = 15962
AND ID = upv.ID AND depart_id = 9)
--and name not in ('LAST_LOGOUT','MAINFORM','PASSWORD_EXPIRATION') --='���'
and name in ('���')
order by name

--insert into user_param_values 
select id,depart_id,15962,'1',trunc(sysdate) 
from user_parameters up where up.name = 'PASSWORD_EXPIRATION' and UP.DEPART_ID in (9,613)--usr.usr_job;


declare
v_old_job number :=9;
v_new_job number :=613;
v_user_id number :=15962;
begin
    for rec in (select up.name name,upv.value value,to_char(upv.ACTIVATED,'dd.mm.yyyy') act
                from user_param_values upv,user_parameters up
                where UPV.USER_ID=v_user_id and UPV.ID=UP.ID and up.depart_id=v_old_job 
                and upv.activated =
                (SELECT MAX (activated) FROM user_param_values  WHERE user_id = v_user_id
                AND ID = upv.ID AND depart_id = v_old_job)
                and name not in ('LAST_LOGOUT','MAINFORM','PASSWORD_EXPIRATION') --='���'
                --and name in ('���')
                order by name
    ) loop
        insert into user_param_values 
        select id,depart_id,v_user_id,rec.value,trunc(sysdate) 
        from user_parameters up where up.name = rec.name and UP.DEPART_ID in (v_new_job);
        DBMS_OUTPUT.PUT_LINE(rec.name);
    end loop;
    commit;
end;


