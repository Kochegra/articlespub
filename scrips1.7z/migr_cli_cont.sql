select d.rowid, d.* 
from collector_contracts d where --d.name='ARRESTLIST' and 
d.reference = 1091681 --:preference 
and d.branch = 200 --:pbranch 
order by d.work_date  desc


select d.rowid, d.* 
from variable_contracts d where  
d.reference = 904305 --:preference
and name = 'ACCOUNTS' 

select * from account where code in (select d.value from variable_contracts d where d.reference = 904305 and name = 'ACCOUNTS') and close_date is null 
 
select �.rowid, �.* from contracts � 
where --REFER_FROM in (1111825,1091763,967887,966791,1107535,1107591,1107529,1091756,1111814) 
--�.reference in (960169)
--doc_number in ('40701810210000000047')
--account = '40701810210000000047'
assist = '40701810210000000047'

-- ����� � ����������
--update contracts d set status=60,date_close='15-nov-2018'
select d.rowid, d.* from contracts d 
where --REFER_FROM in (1111825,1091763,967887,966791,1107535,1107591,1107529,1091756,1111814) 
d.reference in (1107507, 1109555, 1107535, 1107499, 1107529, 1108904)
and type_doc in (6776)
and status=50
and not exists (select 1 from contracts where refer_from = d.reference and branch=d.branch and status = 50) -- �������� �������
and not exists (select 1 from account where code in (select dd.value from variable_contracts dd where dd.reference = d.reference 
                and dd.branch = d.branch and dd.name = 'ACCOUNTS') and close_date is null)    -- �������� ������ � ��������� �� ����������


select * from types where upper(name) like '%����%����%'


-- �������� ���������� ����������
--update contracts c set status=1001 
select * from contracts c 
where type_doc=6776 --and status=50
and (doc_number,refer_client,branch_client) in (
        select doc_number,refer_client,branch_client from (
        select distinct doc_number, type_doc, refer_client, branch_client,  count(doc_number) cnt
        from contracts
        where type_doc=6776 --and status=50
        group by doc_number,type_doc, refer_client, branch_client
        order by 3 desc
        ) where cnt>1
        )
--and exists (select 1 from contracts where refer_from = c.reference and branch=c.branch)         
order by doc_number

--���������� ���������
select * from (
select distinct doc_number, type_doc, refer_client, branch_client,  count(doc_number) cnt
from contracts
where type_doc=6776 and status=50
group by doc_number,type_doc, refer_client, branch_client
order by 3 desc
) where cnt>1



select 
(select name from subdepartments where id = a.subdepartment) subd, 
rowid,a.* from account a where 
--reference=3148922
code in ('40701810210000000047')


select * from users where lower(user_name) like '�����%'


-- ���������� ������ ������� �� ������, ��� �����=0
--update clients qqq set owner = (select u.user_id from clients c, users u 
--                            where c.owner = 0 and u.user_ like 'ADMIN_%' and u.subdepartment=c.subdepartment and c.reference=qqq.reference
--                            and c.branch=qqq.branch)
select u.user_id,u.user_name, c.* from clients c, users u 
where --reference in (309331)
qqq.owner = 0 --and u.user_ like 'ADMIN_%' and u.subdepartment=c.subdepartment

select c.* from clients c 
where reference in (304165)
--c.owner = 0 


select rowid,c.* from variable_clients c 
where reference in (304165)
--c.owner = 0 


select rowid,c.* from collector_clients c 
where reference in (304165)
 

select rowid,a.* from MBANK_AUDIT.AUDIT_TABLE a where reference = 304165