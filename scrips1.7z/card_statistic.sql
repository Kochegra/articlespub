select rowid,
PTOOLS5.EXTRACT_WORD(1,b,'.'),
a.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a
order by b

update tmp_tables.TMP_ZYX_EXCEL_ALL@dss a set h=0

update tmp_tables.TMP_ZYX_EXCEL_ALL@dss a set a.i=PTOOLS5.EXTRACT_WORD(1,a.b,'.')

/
declare
sNum varchar2(10);
begin

    for rec in (

                select PTOOLS5.EXTRACT_WORD(1,b,'.') num, a.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a
                order by to_number(PTOOLS5.EXTRACT_WORD(1,b,'.'))
    
    ) loop
       update tmp_tables.TMP_ZYX_EXCEL_ALL@dss a set a.i=rec.num where a=rec.a;
       commit;
    end loop;

end; 

/

select a.i, a.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a where h='1' order by to_number(a.i)

/
select rowid,a.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a where h='2' 
--and a.a in ('4652080514139528','4652080171645652','4652080179909972')
--and exists (select null from EID.EID_PRODUCTS a where account=a.a)
--order by to_number(a.i)

/
declare 
DOA__VALUE varchar2(2000); -- id �������
v_sCardNumber varchar2(2000);--:= '4652080925396702'; -- �����
v_dDateFrom date :=trunc(sysdate); -- �
v_dDateTo date :=trunc(sysdate); -- ��
v_nUserBranch number := 191; -- ����� ������������
v_nUserID number :=982038; -- ���� �� ������������
begin
    for rec in (
    
    select a.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a where h='0' 
    and exists (select null from EID.EID_PRODUCTS a where account=a.a)
    order by to_number(a.i)
   
    ) loop

        v_sCardNumber:=rec.a;
        doa__value :=
            p_Card_Statement.Get_Statement_Table (sCardNumber   => v_sCardNumber,
                                                  dDateFrom     => v_dDateFrom,
                                                  dDateTo       => v_dDateTo,
                                                  nUserBranch   => v_nUserBranch,
                                                  nUserID       => v_nUserID);
                                                    
    DBMS_OUTPUT.PUT_LINE(DOA__VALUE);                                            
        
        for rec_itogo in (select csi.* from card_statement_itog csi where id=DOA__VALUE)
        loop
            update tmp_tables.TMP_ZYX_EXCEL_ALL@dss set 
                j=rec_itogo.account_number,
                k=rec_itogo.LAST_NAME||' '||rec_itogo.FIRST_NAME||' '||rec_itogo.SECOND_NAME,
                l=rec_itogo.begin_balance,
                m=rec_itogo.BLOCKED_AMOUNT,
                n=rec_itogo.END_BALANCE,
                o=rec_itogo.AMOUNT_AVAILABLE,
                p=rec_itogo.OWN_TOTAL_BALANCE,
                q=rec_itogo.LIMIT_BALANCE,
                h='2'
            where a=rec.a and i=rec.i;
            commit;
        end loop;
    
    end loop;
end;
/
 
-- ������� ���� ��������
/
declare 
begin
    for rec in (
    
    select a.*,b.* from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a,EID.EID_PRODUCTS b 
    where a.a=b.account
    --exists (select null from EID.EID_PRODUCTS a where account=a.a)
    order by to_number(a.i)
   
    ) loop

            update tmp_tables.TMP_ZYX_EXCEL_ALL@dss set 
                r=to_char(rec.date_close,'dd.mm.yyyy')
            where a=rec.a and i=rec.i;
            commit;
        end loop;
    
    end loop;
end;
/



select rowid,
a.i "�/�",
a.a "��",
a.B "���� ������",
a.r "���� ��������",
PTOOLS5.EXTRACT_WORD(1,a.j,'/') "��������� ����",
a.m "������������� �������",
a.n "�������� ������",
a.o "��������� ������",
a.k "���"
--a.* 
from tmp_tables.TMP_ZYX_EXCEL_ALL@dss a 
--where --h='2' 
--and a.a in ('4652080514139528','4652080171645652','4652080179909972')
--and exists (select null from EID.EID_PRODUCTS a where account=a.a)
order by to_number(a.i)